import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { TitleCasePipe, DatePipe, CurrencyPipe } from '@angular/common';
import { LookupService, Account, DateUtil, Principal } from '../shared';
import { MasterdataService } from '../shared/masterdata/masterdata.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { MultiSelectModule } from 'primeng/multiselect';
import { DropdownModule } from 'primeng/dropdown';
import { CheckboxModule } from 'primeng/checkbox';
import { ReportsModal } from './reports.model';
import { ReportsService } from './reports.service';

@Component({
    selector: 'lis-reports',
    templateUrl: './reports.component.html',
    providers: [TitleCasePipe, DatePipe, CurrencyPipe]
})

export class ReportsComponent implements OnInit {

    public searchModel: ReportsModal = new ReportsModal();
    public displayMessage: boolean;
    public userMessage: string;
    public banks: any[];
    public consortiums: any[];
    public currentAccount: Account;
    public isMarshUser: boolean;
    public app: any[];
    public selectReport: any[];
    public natureOfApp: any[];
    public marshAppStatus: any[];
    public showTblData: boolean;
    public defaultAdverseOptoin: string;
    public dateTypes: any[];
    public tranche: any[];
    public totalRecords: number;
    public userid: string;
    public isUOB: boolean;

    constructor(
        private lookupService: LookupService,
        private masterdataService: MasterdataService,
        private principal: Principal,
        private spinner: NgxSpinnerService,
        private reportsService: ReportsService,
        private router: Router, private datePipe: DatePipe,
        private titlePipe: TitleCasePipe, private currencyPipe: CurrencyPipe
    ) {
        this.showTblData = false;
    }

    ngOnInit() {
        this.init();
        this.loadTranche();
        this.loadBanks();
        this.loadConsortiums();
        this.initAccount();
        this.loadApp();
    }

    init() {
        this.userid = '';
        this.displayMessage = false;
        this.searchModel = new ReportsModal();
        this.isMarshUser = false;
        this.isUOB = false;

        this.selectReport = [
            { label: 'LIS Tracking Spreadsheet', value: 'LIS Tracking Spreadsheet' },
            { label: 'Weekly Report for Outstanding Applications', value: 'Weekly Report for Outstanding Applications' },
            { label: 'Approval Ratio by APP', value: 'Approval Ratio by APP' },
            { label: 'Turn Around Time Report by APP', value: 'Turn Around Time Report by APP' },
            { label: 'Loan Renewal Report', value: 'Loan Renewal Report' },
            { label: 'Profitability Report', value: 'Profitability Report' },
            { label: 'Comparison Report Across LIS Tranches Based on APP', value: 'Comparison Report Across LIS Tranches Based on APP' },
            { label: 'Premium and Limits Report across LIS Tranches Based on APP', value: 'Premium and Limits Report across LIS Tranches Based on APP' },
            { label: 'Overdue Report across LIS Tranches', value: 'Overdue Report across LIS Tranches' },
            { label: 'Premium Allocation Report by APP', value: 'Premium Allocation Report by APP' },
            { label: 'Adverse Information Report by APP', value: 'Adverse Information Report by APP' },
            { label: 'Monthly Claims Report (Internal Use)', value: 'Monthly Claims Report (Internal Use)' },
            { label: 'Capacity Allocation Report (Part of Master Data Management)', value: 'Capacity Allocation Report (Part of Master Data Management)' },
        ];

        this.natureOfApp = [
            { label: 'New', value: 'New' },
            { label: 'Cancel Utilised', value: 'Cancel Utilised' },
            { label: 'Cancel Un-Utilised', value: 'Cancel Un-Utilised' },
            { label: 'Decrease Un-Utilised', value: 'Decrease Un-Utilised' },
            { label: 'Renewal', value: 'Renewal' },
            { label: 'Mid-Term INCR Un-Utilised', value: 'Mid-Term INCR Un-Utilised' },
            { label: 'Mid-Term INCR Utilised', value: 'Mid-Term INCR Utilised' },
            { label: 'Decrease Utilised', value: 'Decrease Utilised' },
            { label: 'Temporary Increase', value: 'Temporary Increase' }
        ];
        this.marshAppStatus = [
            { label: 'Draft', value: 'Draft' },
            { label: 'Processing', value: 'Processing' },
            { label: 'Answered', value: 'Answered' },
            { label: 'Duplicate', value: 'Duplicate' }
        ];

        this.dateTypes = [
            { label: 'Any', value: 'Any' },
            { label: 'Marsh Submission Date', value: 'Marsh Submission Date' },
            { label: 'COFANET Submission Date', value: 'COFANET Submission Date' },
            { label: 'LO Acceptance Date', value: 'LO Acceptance Date' },
            { label: 'Loan Expiry Date', value: 'Loan Expiry Date' }
        ];

        this.tranche = [
            { label: '5', value: '5' },
            { label: '6', value: '6' },
            { label: '7', value: '7' }
        ];

        this.app = [];
        this.banks = [];
        this.consortiums = [];
    }

    initAccount() {
        this.principal.identity().then((account) => {
            if (account) {
                this.currentAccount = account;
                this.userid = this.currentAccount.login;
                if (!this.currentAccount.bank) {
                    this.isMarshUser = true;
                } else {
                    this.isMarshUser = false;
                    if (this.currentAccount.bank === 'UOB') {
                        this.isUOB = true;
                    }
                    this.searchModel.pfiCode = [];
                    this.searchModel.pfiCode[0] = this.currentAccount.bank;
                }
                let dateLabel = 'COFANET Submission Date';
                if (this.isUOB) {
                    dateLabel = 'Submission Date';
                }
                // this.dateTypes = [
                //     { label: 'Any', value: 'Any' },
                //     { label: 'Marsh Submission Date', value: 'Marsh Submission Date' },
                //     { label: dateLabel, value: 'COFANET Submission Date' },
                //     { label: 'LO Acceptance Date', value: 'LO Acceptance Date' },
                //     { label: 'Loan Expiry Date', value: 'Loan Expiry Date' }
                // ];
            }
        });

    }

    loadTranche() {
        // this.lookupService.getCurrentTranche().subscribe((tranche) => {
        //     if (tranche) {
        //       this.searchModel.tranche = tranche;
        //     }
        //   });
    }

    loadBanks() {
        this.lookupService.banks().subscribe((banks) => {
            const bankList = banks;
            bankList.forEach((val) => {
                const bank = { label: val.bankCode, value: val.bankCode };
                this.banks.push(bank);
            });
        });
    }

    loadConsortiums() {
        this.masterdataService.consortiums().subscribe((consortiums) => {
            const consoList = consortiums;
            consoList.forEach((val) => {
                const conso = { label: val.consortiumName, value: val._id };
                this.consortiums.push(conso);
            });
            this.consortiums.push({ label: 'All', value: 'All' });
        });
    }

    loadApp() {
        this.masterdataService.app().subscribe((app) => {
            const appResult = app;
            appResult.forEach((val) => {
                const ap = { label: val.app.toString(), value: val.app };
                this.app.push(ap);
            });
        });
    }

    generate() {
        // return this.reportsService.generateReport().subscribe((response) => {
        //     this.searchModel = response;
        // });
    }

    clearDate() {
        if (!this.searchModel.typeOfDate) {
            this.searchModel.fromDate = '';
            this.searchModel.toDate = '';
        }
    }

    clear() {
        this.searchModel = new ReportsModal();
    }

    cancel() {
        this.router.navigate(['']);
    }
}
