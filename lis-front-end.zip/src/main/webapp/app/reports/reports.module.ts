import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { LisAppSharedModule } from '../shared';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { PaginatorModule } from 'primeng/paginator';
import { MultiSelectModule } from 'primeng/multiselect';
import { CheckboxModule } from 'primeng/checkbox';
import { RadioButtonModule } from 'primeng/radiobutton';
import { DropdownModule } from 'primeng/dropdown';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { LISCurrencyMaskModule } from '../shared/currency/currency-mask.module';
import { ReportsService } from './reports.service';
import { ReportsRoute } from './reports.route';
import { ReportsComponent } from './reports.component';

@NgModule({
    imports: [
        LisAppSharedModule,
        NgbModule,
        TableModule,
        CheckboxModule,
        RadioButtonModule,
        DropdownModule,
        BsDatepickerModule,
        MultiSelectModule,
        DialogModule,
        LISCurrencyMaskModule,
        CurrencyMaskModule,
        RouterModule.forChild(ReportsRoute),
    ],
    declarations: [
        ReportsComponent
    ],
    entryComponents: [
        ReportsComponent,
    ],
    providers: [
        ReportsService
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class ReportsModule { }
