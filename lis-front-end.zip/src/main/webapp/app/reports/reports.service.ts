import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { SERVER_API_URL } from '../app.constants';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { ReportsModal } from './reports.model';

@Injectable()
export class ReportsService {

    private resourceUrl = SERVER_API_URL;

    constructor(private http: HttpClient) { }

    /***
    * Loan edit detail: UOB
    *
    */
  generateReport(): Observable<ReportsModal> {
    return this.http.get<ReportsModal>(
      this.resourceUrl + ''
    );
  }

}
