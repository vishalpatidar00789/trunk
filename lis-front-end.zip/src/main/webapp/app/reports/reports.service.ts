import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { SERVER_API_URL } from '../app.constants';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { ReportsModal } from './reports.model';

@Injectable()
export class ReportsService {

    private resourceUrl = SERVER_API_URL;

    constructor(private http: HttpClient) { }

    /***
    * Generate Reports
    *
    */
  generateReport(reportsModal: ReportsModal): Observable<HttpResponse<ReportsModal>> {
    delete reportsModal['__v'];
    delete reportsModal['createdBy'];
    delete reportsModal['createdDate'];
    delete reportsModal['lastModifiedBy'];
    delete reportsModal['lastModifiedDate'];
    return this.http.put<ReportsModal>(
      this.resourceUrl + 'report/generateReport',
      reportsModal,
      { observe: 'response' }
    );
  }

}
