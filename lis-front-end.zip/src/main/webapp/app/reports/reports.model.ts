export class ReportsModal {

    constructor(
        public reportName?: string,
        public marshRefNo?: string,
        public borrowerName?: string,
        public uenNumber?: string,
        public pfiCode?: any [],
        public consortium?: string,
        public typeOfDate?: string,
        public fromDate?: string,
        public toDate?: string,
        public natureOfApplication?: any [],
        public marshApplicationStatus?: any [],
        public excludeExpiredApplications?: string,
        public app?: any [],
        public tranche?: any[],
) {
   this.typeOfDate = null;
}
}
