import { Routes, Route } from '@angular/router';
import { UserRouteAccessService } from '../shared';
import { ReportsComponent } from './reports.component';

export const ReportsRoute: Routes = [
    {
        path: 'reports',
        component: ReportsComponent,
        canActivate: [UserRouteAccessService],
        data: {
            authorities: ['PFI_ADMIN', 'USER_ADMIN'],
            pageTitle: 'Generate Reports'
        }
    }
];
