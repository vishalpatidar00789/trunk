import { Routes, Route } from '@angular/router';

import { UserRouteAccessService } from '../shared';

import { FormUploadComponent, ValidationSummaryComponent } from './';

export const FormUploadRoute: Routes = [
  {
    path: 'form-upload',
    component: FormUploadComponent,
    canActivate: [UserRouteAccessService],
    data: {
      authorities: ['IT_ADMIN', 'USER_ADMIN'],
      pageTitle: 'Form 1 Upload'
    }
  }
];
