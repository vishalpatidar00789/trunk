import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { SERVER_API_URL } from '../app.constants';
import { FormUpload } from './form-upload.model';

@Injectable()
export class FormUploadService {
  private resourceUrl = SERVER_API_URL + 'form-upload';

  constructor(private http: HttpClient) {}

  createFormUpload(formUpload: FormUpload) {
    return <any>this.http.post(this.resourceUrl, formUpload);
  }

  updateFormUpload(formUpload: FormUpload) {
    const id = formUpload._id;
    delete formUpload._id;
    delete formUpload['__v'];
    console.log(JSON.stringify(formUpload));
    return <any>this.http.put(this.resourceUrl + '/' + id, formUpload);
  }

  getFormDetailsByPfiCode(pfiCode: string) {
    return <any>this.http.get(this.resourceUrl + '/' + pfiCode);
  }

  uploadFile(fileData) {
    const headers = new HttpHeaders();
    headers.append('Access-Control-Allow-Origin', '*');

    return <any>this.http.post(this.resourceUrl + '/uploadForm1', fileData, {
      headers
    });
  }
}
