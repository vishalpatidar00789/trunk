import { Component, OnInit, Input } from '@angular/core';
import {
  Router,
  ActivatedRouteSnapshot,
  NavigationEnd,
  ActivatedRoute
} from '@angular/router';
import { FormUploadExportData } from '../form-upload.model';
import { ITEMS_PER_PAGE } from '../../shared';
import { ValidationSummary } from './validation-summary.model';

@Component({
  selector: 'lis-validation-summary',
  templateUrl: './validation-summary.component.html'
})
export class ValidationSummaryComponent implements OnInit {
  @Input('formUploadExportData')
  set formUploadExportData(value: FormUploadExportData) {
    this._formUploadExportData = value;
    if (this.formUploadExportData.validationSummary) {
      this.validationSummaryList = this.formUploadExportData.validationSummary.filter(
        (validateData) => {
          return validateData.validatationType === 'fail';
        }
      );
      this.totalRecords = this.validationSummaryList.length;
    }
  }
  _formUploadExportData: FormUploadExportData;
  get formUploadExportData(): FormUploadExportData {
    return this._formUploadExportData;
  }
  validationSummaryList: ValidationSummary[];
  formUploadColumns: any[];
  itemsPerPage: number;
  totalRecords = 0;
  sales = [
    {
      brand: 'Apple',
      lastYearSale: '51%',
      thisYearSale: '40%',
      lastYearProfit: '$54,406.00',
      thisYearProfit: '$43,342'
    },
    {
      brand: 'Samsung',
      lastYearSale: '83%',
      thisYearSale: '96%',
      lastYearProfit: '$423,132',
      thisYearProfit: '$312,122'
    },
    {
      brand: 'Microsoft',
      lastYearSale: '38%',
      thisYearSale: '5%',
      lastYearProfit: '$12,321',
      thisYearProfit: '$8,500'
    },
    {
      brand: 'Philips',
      lastYearSale: '49%',
      thisYearSale: '22%',
      lastYearProfit: '$745,232',
      thisYearProfit: '$650,323,'
    },
    {
      brand: 'Song',
      lastYearSale: '17%',
      thisYearSale: '79%',
      lastYearProfit: '$643,242',
      thisYearProfit: '500,332'
    },
    {
      brand: 'LG',
      lastYearSale: '52%',
      thisYearSale: ' 65%',
      lastYearProfit: '$421,132',
      thisYearProfit: '$150,005'
    },
    {
      brand: 'Sharp',
      lastYearSale: '82%',
      thisYearSale: '12%',
      lastYearProfit: '$131,211',
      thisYearProfit: '$100,214'
    },
    {
      brand: 'Panasonic',
      lastYearSale: '44%',
      thisYearSale: '45%',
      lastYearProfit: '$66,442',
      thisYearProfit: '$53,322'
    },
    {
      brand: 'HTC',
      lastYearSale: '90%',
      thisYearSale: '56%',
      lastYearProfit: '$765,442',
      thisYearProfit: '$296,232'
    },
    {
      brand: 'Toshiba',
      lastYearSale: '75%',
      thisYearSale: '54%',
      lastYearProfit: '$21,212',
      thisYearProfit: '$12,533'
    }
  ];
  constructor(private router: Router, private route: ActivatedRoute) {}

  ngOnInit() {
    this.formUploadColumns = [
      { field: 'pfi', header: 'PFI' },
      { field: 'lisAppNo', header: 'LIS Application No.' },
      { field: 'domesticLIS', header: 'Domestic (%)' },
      { field: 'exportLIS', header: 'Export (%)' },
      { field: 'tradeFacilities', header: 'Trade Facilities' },
      { field: 'bgFacility', header: 'BG Facility' },
      {
        field: 'totalLISLimitApplied',
        header: 'Total LIS Limit Applied (SGD)'
      },
      {
        field: 'LOAcceptanceDate',
        header:
          'LO Acceptance Date/ Renewal Notification/ Anniversary Date (dd/mm/yyyy)'
      },
      {
        field: 'borrowerName',
        header: 'Borrower Name (sort by alphabetical order)'
      },
      { field: 'UENNumber', header: 'UEN*' },
      { field: 'latestYearTurnover', header: 'Latest Year Turnover (SGD)' },
      { field: 'latestYearNPBT', header: 'Latest Year NPBT (SGD)' },
      {
        field: 'limitsApprovedPrimaryOnly',
        header: 'Limits Approved Primary Trade Facilities Only(SGD)'
      },
      {
        field: 'limitsApprovedAuto',
        header: 'Limits Approved Auto Top-Up (SGD)'
      },
      {
        field: 'limitsApprovedPrimaryBGOnly',
        header: 'Limits Approved Primary BG Only(SGD)'
      },
      { field: 'tenureBGS3', header: 'Tenure of BG Facility (Months)' },
      { field: 'limitsApprovedLISPlus', header: 'Limits Approved LIS+ (SGD)' },
      // {
      //   field: 'lisPrimaryS3',
      //   header: 'LIS 5 Primary Trade Facilites (% p.a.)'
      // },
      // { field: 'lisAutoS3', header: 'LIS 5 Auto Top-Up (% p.a.)' },
      // { field: 'lisBGS3', header: 'LIS 5 BG Facility (% p.a.)' },
      { field: 'typeOfLimit', header: 'Type of Limit Change' },
      {
        field: 'totalAppliedLimit',
        header: 'Total Applied Limit Changes (SGD)'
      },
      {
        field: 'approvedLimitChangesPrimary',
        header: 'Approved Limit Changes Primary TF (SGD)'
      },
      {
        field: 'approvedLimitChangesAuto',
        header: 'Approved Limit Changes Auto Top-up (SGD)'
      },
      {
        field: 'approvedLimitChangesBG',
        header: 'Approved Limit Changes BG Facility (SGD)'
      },
      { field: 'tenureBGS5', header: 'Tenure of BG Facility (Months)' },
      { field: 'proRateChange', header: 'Pro-Rate Quarter Charge (%)' },
      {
        field: 'date1Limit',
        header: 'Date 1 Limit Increase Start Date (dd/mm/yyyy)'
      },
      {
        field: 'date2Limit',
        header: 'Date 2 Limit Increase End Date (dd/mm/yyyy)'
      },
      // { field: 'lisPrimaryS5', header: 'LIS 5 Primary TF (% p.a.)' },
      // { field: 'lisAutoS5', header: 'LIS 5 Auto Top-Up (% p.a.)' },
      // { field: 'lisBGS5', header: 'LIS 5 BG Facility (% p.a.)' },
      { field: 'totalApprovedLimit', header: 'Total Approved Limit Changes' },
      { field: 'appliedMidTerm', header: 'Applied Mid-Term Limit (SGD)' },
      { field: 'approvedMidTerm', header: 'Approved Mid-Term Limit (SGD)' },
      {
        field: 'limitIncreaseDate',
        header: 'Limit IncreaseStart Date (dd/mm/yyyy)'
      },
      // { field: 'remarks', header: 'Remarks (if any)' },
      // {
      //   field: 'totalLIS5LimitsApproved',
      //   header: 'Total LIS 5 Limits Approved (SGD)'
      // },
      // {
      //   field: 'totalLISPlusLimitsApproved',
      //   header: 'Total LIS+ Limits Approved (SGD)'
      // },
      // { field: 'lis5Primary', header: 'LIS 5 Primary (SGD)' },
      // { field: 'lis5Auto', header: 'LIS 5 Auto-Top Up (SGD)' },
      // { field: 'lis5BG', header: 'LIS 5 BG Facility (SGD)' },
      // { field: 'lisPlusS9', header: 'LIS+ (SGD)' },
      { field: 'validatationType', header: 'Validation Result' }
    ];
    this.itemsPerPage = ITEMS_PER_PAGE;
  }

  checkDiscrepancyStatus(discrepancyList: any[], fieldType: string) {
    const status = false;
    if (discrepancyList) {
      const fieldStatus = discrepancyList.find((field) => {
        return field === fieldType;
      });
      if (fieldStatus) {
        return true;
      }
    }
    return status;
  }
}
