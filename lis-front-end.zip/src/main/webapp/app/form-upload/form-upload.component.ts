import { Component, OnInit } from '@angular/core';
import {
  Router,
  ActivatedRouteSnapshot,
  NavigationEnd,
  ActivatedRoute
} from '@angular/router';

import { Title } from '@angular/platform-browser';
import { Principal, ITEMS_PER_PAGE } from '../shared';
import {
  NotificationService,
  NotificationOption
} from '../shared/alert/notification.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormUploadService } from './form-upload.service';
import { FormUploadExportData, FormUpload } from './form-upload.model';
import { ValidationSummary } from './validation-summary/validation-summary.model';

@Component({
  selector: 'lis-form-upload',
  templateUrl: './form-upload.component.html'
})
export class FormUploadComponent implements OnInit {
  formUploadColumns: any[];
  userid: string;
  tickVisible = false;
  fileData: Array<File> = [];
  showError = false;
  formUploadExportData: FormUploadExportData;
  itemsPerPage: number;
  totalRecords = 0;
  totalPassCount: number;
  totalFailCount: number;
  totalNFCount: number;
  validationPopUpShow = false;
  managePopUpShow = false;
  formUploadData: FormUpload;
  constructor(
    private principal: Principal,
    private titleService: Title,
    private router: Router,
    private route: ActivatedRoute,
    private formUploadService: FormUploadService,
    private notificationService: NotificationService,
    private spinner: NgxSpinnerService
  ) {}

  private getPageTitle(routeSnapshot: ActivatedRouteSnapshot) {
    let title: string =
      routeSnapshot.data && routeSnapshot.data['pageTitle']
        ? routeSnapshot.data['pageTitle']
        : 'lisApp';
    if (routeSnapshot.firstChild) {
      title = this.getPageTitle(routeSnapshot.firstChild) || title;
    }
    return title;
  }

  ngOnInit() {
    // this.formUploadExportData = new FormUploadExportData();
    // this.formUploadExportData.validationSummary = [];
    // this.formUploadExportData.validationSummary[0] = new ValidationSummary();
    // this.formUploadExportData.validationSummary[0].pfiName = 'HLF';
    // this.formUploadExportData.validationSummary[0].lisAppNo = 'ABC123';

    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.titleService.setTitle(
          this.getPageTitle(this.router.routerState.snapshot.root)
        );
      }
      if (!(event instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });

    this.principal.identity().then((account) => {
      if (account) {
        this.userid = account.login;
      }
    });

    this.formUploadColumns = [
      { field: 'pfi', header: 'PFI' },
      { field: 'lisAppNo', header: 'LIS Application No.' },
      { field: 'borrowerName', header: 'Borrower Name' },
      { field: 'UENNumber', header: 'UEN' },
      {
        field: 'LOAcceptanceDate',
        header:
          'LO Acceptance Date/ Renewal Notification/ Anniversary Date (dd/mm/yyyy)'
      },
      {
        field: 'date1Limit',
        header: 'Limit Increase Start Date (DD/MM/YYYY)'
      },
      { field: 'validatationType', header: 'Validation Result' }
    ];
    this.itemsPerPage = ITEMS_PER_PAGE;
  }

  formUploadFile(fileInput: any) {
    this.tickVisible = false;
    this.fileData = <Array<File>>fileInput.target.files;
    const formData = new FormData();
    const files: Array<File> = this.fileData;

    if (files.length === 0) {
      this.showError = true;
      setTimeout(() => {
        this.showError = false;
      }, 3000);
      return;
    }

    const file: File = files[0];
    formData.append('file', file, file.name);
    this.spinner.show();

    this.formUploadService.uploadFile(formData).subscribe(
      (resultData) => {
        if (resultData) {
          console.dir(resultData);
          this.formUploadExportData = Object.assign({}, resultData);
          if (this.formUploadExportData.pfi) {
            this.formUploadService
              .getFormDetailsByPfiCode(this.formUploadExportData.pfi)
              .subscribe((data) => {
                this.formUploadData = new FormUpload();
                this.formUploadData = data;
              });
          }
          this.getRecordCount();
        }
        this.spinner.hide();
        this.tickVisible = true;
      },
      (error) => {
        const notificationOption = new NotificationOption();
        notificationOption.title = '';
        notificationOption.message = 'Please upload valid file and try again.';
        notificationOption.type = 'error';
        notificationOption.toastrConfig = {
          positionClass: 'toast-bottom-right',
          disableTimeOut: true
        };
        this.notificationService.showNotification(notificationOption);
        this.tickVisible = false;
        this.spinner.hide();
      }
    );
  }

  getRecordCount() {
    this.totalRecords = null;
    this.totalPassCount = null;
    this.totalFailCount = null;
    if (this.formUploadExportData.validationSummary) {
      this.totalRecords = this.formUploadExportData.validationSummary.length;
      this.getValidationCount();
    }
  }
  async getValidationCount() {
    if (this.formUploadExportData.validationSummary) {
      this.totalPassCount = await this.formUploadExportData.validationSummary.filter(
        (formData) => formData.validatationType === 'pass'
      ).length;
      this.totalFailCount = await this.formUploadExportData.validationSummary.filter(
        (formData) => formData.validatationType === 'fail'
      ).length;
      this.totalNFCount = await this.formUploadExportData.validationSummary.filter(
        (formData) => formData.validatationType === 'invalid'
      ).length;
      if (this.totalFailCount <= 0 && this.totalPassCount > 0) {
        const notificationOption = new NotificationOption();
        notificationOption.title = 'Notification';
        notificationOption.message =
          'Validation has been successfully completed';
        this.notificationService.showNotification(notificationOption);
      } else {
        const notificationOption = new NotificationOption();
        notificationOption.title = '';
        notificationOption.message =
          'There are validation discrepancies in the Uploaded Form1.Please refer to Validation Summary for more details.';
        notificationOption.type = 'error';
        notificationOption.toastrConfig = {
          disableTimeOut: true
        };
        this.notificationService.showNotification(notificationOption);
      }
      if (this.totalNFCount > 0) {
        const notificationOption = new NotificationOption();
        notificationOption.clear = false;
        notificationOption.title = '';
        notificationOption.message =
          'One or more record(s) could not be validated because of invalid data in uploaded form.';
        notificationOption.type = 'warning';
        notificationOption.toastrConfig = {
          disableTimeOut: true
        };
        this.notificationService.showNotification(notificationOption);
      }
    } else {
      const notificationOption = new NotificationOption();
      notificationOption.message = 'No Records Found';
      notificationOption.type = 'error';
      this.notificationService.showNotification(notificationOption);
    }
  }

  commitChanges() {
    if (this.formUploadExportData) {
      let formData = new FormUpload();
      if (this.formUploadData && this.formUploadData._id) {
        formData = this.formUploadData;
        this.formUploadService
          .updateFormUpload(formData)
          .subscribe((resultData) => {
            this.formUploadData = resultData;
            const notificationOption = new NotificationOption();
            notificationOption.title = 'Notification';
            notificationOption.message = 'Commit changes completed';
            this.notificationService.showNotification(notificationOption);
          });
      } else {
        formData.pfiCode = this.formUploadExportData.pfi;
        this.formUploadService
          .createFormUpload(formData)
          .subscribe((resultData) => {
            this.formUploadData = new FormUpload();
            this.formUploadData = resultData;
            const notificationOption = new NotificationOption();
            notificationOption.title = 'Notification';
            notificationOption.message = 'Commit changes completed';
            this.notificationService.showNotification(notificationOption);
          });
      }
    }
  }
}
