import { ValidationSummary } from './validation-summary/validation-summary.model';

export class FormUpload {
  _id: string;
  pfiCode: string;
  lastCommitedDate?: Date;
  lastCommitedBy?: string;
}

export class FormUploadExportData {
  policyNumber: string;
  pfi: string;
  reportingMonth: string;
  validationSummary: ValidationSummary[];
}
