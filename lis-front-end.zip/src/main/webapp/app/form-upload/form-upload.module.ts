import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { LisAppSharedModule } from '../shared';
import {
    FormUploadComponent,
    FormUploadRoute,
    ValidationSummaryComponent
} from './';
import { FormUploadService } from './form-upload.service';

@NgModule({
    imports: [
        LisAppSharedModule,
        RouterModule.forChild(FormUploadRoute),
    ],
    declarations: [
        FormUploadComponent,
        ValidationSummaryComponent
    ],
    providers: [
        FormUploadService
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class LisAppFormUploadModule { }
