export class ClaimModel {
    constructor(
        public _id?: string,
        public status?: string,
        public marshRefNo?: string,
        public loanMarshRefNo?: string,
        public baseLoanId?: string,
        public consortium?: string,
        public createdBy?: string,
        public createdDate?: Date,
        public lastModifiedBy?: string,
        public lastModifiedDate?: Date,

        public pfiCode?: string,
        public pfiName?: string,
        public policyNumber?: string,
        public insurers?: string,
        public tranche?: number,
        public app?: number,
        public nameOfStaff?: string,
        public dateReportedToMarsh?: Date,
        public nameOfPerson?: string,
        public jobTitle?: string,
        public regCompanyName?: string,
        public uen?: string,
        public businessActivity?: string,
        public loAcceptanceDate?: Date,
        public approvedPrimaryLimit?: number,
        public approvedTopUpLimit?: number,
        public approvedBGLimit?: number,
        public approvedLisPlusLimit?: number,
        public outstandingPrincipal?: number,
        public interest?: number,
        public legalFees?: number,
        public remarks?: string,

        public pfiANL?: string,
        public pfiANLTxt?: string,
        public invoice?: string,
        public deliveryOrder?: string,
        public purchaseOrder?: string,
        public purchaseOrderTxt?: string,
        public applicationForInvoice?: string,
        public facilityDetails?: string,
        public facilityDetailsTxt?: string,
        public financeNotification?: string,
        public financeAdviceNote?: string,
        public financeAdviceNoteTxt?: string,
        public limitRequestForm?: string,
        public limitEndorsementForm?: string,
        public currentStatement?: string,
        public tradeStatement?: string,
        public tradeStatementTxt?: string,
        public creditApplication?: string,
        public writeOffMemo?: string,
        public letterOfAcceptance?: string,
        public guarantee?: string,
        public guaranteeTxt?: string,
        public acraSearch?: string,
        public individualSearch?: string,
        public individualSearchTxt?: string,
        public demandLetter?: string,
        public demandLetterTxt?: string,
        public statutoryDemand?: string,
        public statutoryDemandTxt?: string,
        public originatingSummon?: string,
        public originatingSummonTxt?: string,
        public windingUpOrder?: string,
        public windingUpOrderTxt?: string,
        public bankruptcyApplication?: string,
        public bankruptcyApplicationTxt?: string,
        public bankruptcyOrder?: string,
        public bankruptcyOrderTxt?: string,
        public borrower?: string,
        public guarantors?: string,
        public guarantorsTxt?: string,
        public legalCostInvoices?: string,
        public legalCostInvoicesTxt?: string,
        public recoveryDetails?: string,
        public recoveryDetailsTxt?: string,
        public approvedSuppliers?: string,
        public approvedSuppliersTxt?: string,
        public beneficiaryDemandLetter?: string,
        public beneficiaryDemandLetterTxt?: string,
        public pfiGuarantee?: string,
        public pfiGuaranteeTxt?: string,
        public letterOfAward?: string,
        public letterOfAwardTxt?: string,
        public claimProgressPayment?: string,
        public claimProgressPaymentTxt?: string,
        public lossesSuffered?: string,
        public lossesSufferedTxt?: string,
        public otherDocuments?: string,
        
        /**
         * Supporting documents
         */
        public supportingDocs?: any,
    ) {
        /**
         * Supporting documents type
         */
        this.supportingDocs = [
            { name: 'ANL Claim Statement', id: '', status: false, files: '' },
            { name: 'Invoice', id: '', status: false, files: '' },
            { name: 'Delivery order/Bill of lading', id: '', status: false, files: '' },
            { name: 'Purchase order/Sales contract', id: '', status: false, files: '' },
            { name: 'Application for invoice financing', id: '', status: false, files: '' },
            { name: 'Facility Details-TR', id: '', status: false, files: '' },
            { name: 'Invoice Financing Buyers-Finance Notification', id: '', status: false, files: '' },
            { name: 'Finance Advice/Debit Advice/Debit Note', id: '', status: false, files: '' },
            { name: 'Limit Request Form', id: '', status: false, files: '' },
            { name: 'Limit Endorsement Form', id: '', status: false, files: '' },
            { name: 'Current Statement', id: '', status: false, files: '' },
            { name: 'Trade Statement', id: '', status: false, files: '' },
            { name: 'Credit Memo/Credit Application', id: '', status: false, files: '' },
            { name: 'Write-off Memo', id: '', status: false, files: '' },
            { name: 'Letter of offer and Acceptance', id: '', status: false, files: '' },
            { name: 'Guarantee', id: '', status: false, files: '' },
            { name: 'ACRA Search', id: '', status: false, files: '' },
            { name: 'Individual Search', id: '', status: false, files: '' },
            { name: 'Demand Letter', id: '', status: false, files: '' },
            { name: 'Statutory Demand', id: '', status: false, files: '' },
            { name: 'Originating Summon', id: '', status: false, files: '' },
            { name: 'Winding Up Order', id: '', status: false, files: '' },
            { name: 'Bankruptcy Application', id: '', status: false, files: '' },
            { name: 'Bankruptcy Order', id: '', status: false, files: '' },
            { name: 'Proof of Debt-Borrower', id: '', status: false, files: '' },
            { name: 'Proof of Debt-Guarantors', id: '', status: false, files: '' },
            { name: 'Legal cost invoices', id: '', status: false, files: '' },
            { name: 'Recovery details', id: '', status: false, files: '' },
            { name: 'Approved suppliers by the bank', id: '', status: false, files: '' },
            { name: 'Demand Letter from the Beneficiary', id: '', status: false, files: '' },
            { name: 'Copy of Banker’s Guarantee', id: '', status: false, files: '' },
            { name: 'Letter of Award', id: '', status: false, files: '' },
            { name: 'Latest Claim Progress Payment', id: '', status: false, files: '' },
            { name: 'Non-performance of the contract and the losses suffered', id: '', status: false, files: '' },
            { name: 'Others', id: '', status: false, files: '' }
        ]
    }
}

export class ClaimProcess {
    id: string;
    status?: string;
    tranche?: string;
    marshRefNo: string;
    isViewClaim: boolean;
    constructor() {
      this.status = 'Draft';
      this.tranche = '5';
      this.isViewClaim = false;
    }
  }
