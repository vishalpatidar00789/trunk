import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { Router, ActivatedRouteSnapshot, NavigationEnd, ActivatedRoute } from '@angular/router';

import { Title } from '@angular/platform-browser';
import { ClaimModel, ClaimProcess } from './claim.model';
import { Principal, MasterdataService } from '../shared';
import { ClaimService } from './claim.service';
import { NotificationOption, NotificationService } from '../shared/alert/notification.service';
import { NgForm } from '@angular/forms';

@Component({
    selector: 'lis-claim',
    templateUrl: './claim.component.html'
})
export class ClaimComponent implements OnInit {

    data: string;
    showManageDoc: boolean = false;
    popUp: boolean;
    dialogTitle: string;
    docType: string;
    public claimModel: ClaimModel = new ClaimModel();
    public claimProcess: ClaimProcess = new ClaimProcess();
    public collectionType: string;
    public currentAccount: any;
    public userid: string;
    public claimId: string;
    public getLoanResult: any;
    public viewClaim: boolean;
    public tranches: any[];

    @Input('selectedClaimResult') selectedClaimResult: ClaimModel;
    @Input('isViewClaim') isViewClaim: boolean;
    @ViewChild('claimSubmissionForm') claimSubmissionForm: NgForm;

    constructor(
        private claimService: ClaimService,
        private titleService: Title,
        private router: Router,
        private route: ActivatedRoute,
        private principal: Principal,
        private notificationService: NotificationService,
        private masterdataService: MasterdataService,
    ) {
        this.principal.identity().then((account) => {
            if (account) {
                this.currentAccount = account;
                this.userid = this.currentAccount.login;
            }
        });

        this.viewClaim = false;
    }

    private getPageTitle(routeSnapshot: ActivatedRouteSnapshot) {
        let title: string = (routeSnapshot.data && routeSnapshot.data['pageTitle']) ? routeSnapshot.data['pageTitle'] : 'lisApp';
        if (routeSnapshot.firstChild) {
            title = this.getPageTitle(routeSnapshot.firstChild) || title;
        }
        return title;
    }

    ngOnInit() {

        const loanId = this.route.snapshot.paramMap.get('loanId');
        const editDraftClaim = this.route.snapshot.paramMap.get('editDraftClaim');
        const deleteDraftClaim = this.route.snapshot.paramMap.get('deleteDraftClaim');
        const editDuplicateClaim = this.route.snapshot.paramMap.get('editDuplicateClaim');
        const deleteDuplicateClaim = this.route.snapshot.paramMap.get('deleteDuplicateClaim');

        this.collectionType = 'CLAIM';

        if (this.isViewClaim) {
            // console.log('this.selectedClaimResult._id', this.selectedClaimResult._id);
            this.viewSubmittedClaim(this.selectedClaimResult._id);
        } else if (loanId) {
            this.createClaim(loanId);
        } else if (editDraftClaim) {
            this.editClaim(editDraftClaim);
        }

        this.router.events.subscribe((event) => {
            if (event instanceof NavigationEnd) {
                this.titleService.setTitle(this.getPageTitle(this.router.routerState.snapshot.root));
            }
            if (!(event instanceof NavigationEnd)) {
                return;
            }
            window.scrollTo(0, 0);
        });
    }

    loadTranches() {
        this.masterdataService.tranches().subscribe((tranch) => {
            const tranchResult = tranch;
            tranchResult.forEach((val) => {
                const fromDate = new Date(val.fromDate);
                const toDate = new Date(val.toDate);
                const todayDate = new Date();
                if (val.trancheName && (todayDate > fromDate && todayDate <= toDate)) {
                    const trancheValue = val.trancheName.charAt(val.trancheName.length - 1);
                    if (trancheValue) {
                        this.claimModel.tranche = parseInt(trancheValue, 10);
                        // console.log('this.claimModel.tranche', this.claimModel.tranche);
                    }
                }
            });
        });
    }

    createClaim(loanId) {
        if (loanId) {
            this.claimService.getLoanById(loanId).subscribe((loanResult: any) => {
                // console.log('get Loan result', JSON.stringify(loanResult));
                if (loanResult) {
                    this.getLoanResult = loanResult;
                    this.claimModel.status = loanResult.status;
                    this.claimModel.consortium = loanResult.consortium;
                    this.claimModel.app = loanResult.app;
                    this.claimModel.loanMarshRefNo = loanResult.marshRefNo;
                    // this.claimModel.tranche = 5;
                    if (loanResult.sponsorForm) {
                        this.claimModel.businessActivity = loanResult.sponsorForm.businessActivity;
                        this.claimModel.regCompanyName = loanResult.sponsorForm.regComName;
                        this.claimModel.uen = loanResult.sponsorForm.ACRANo;
                    }
                    if (loanResult.creditInfo) {
                         if (loanResult.creditInfo.lisCoinsurer) {
                            this.claimModel.insurers = loanResult.creditInfo.lisCoinsurer;
                        } else {
                            this.claimModel.insurers = loanResult.creditInfo.pfiName;
                        }

                        this.claimModel.pfiCode = loanResult.creditInfo.pfiCode;
                        this.claimModel.pfiName = loanResult.creditInfo.pfiName;
                        this.claimModel.approvedPrimaryLimit = loanResult.creditInfo.primary;
                        this.claimModel.approvedTopUpLimit = loanResult.creditInfo.autoTopUp;
                        this.claimModel.approvedBGLimit = loanResult.creditInfo.bg;
                        this.claimModel.approvedLisPlusLimit = loanResult.creditInfo.lisPlus;
                        this.claimModel.loAcceptanceDate = loanResult.creditInfo.loAcceptanceDate;
                        this.setDateFormat();
                        this.loadTranches();
                        this.claimService.getPolicyById(loanResult.creditInfo.pfiCode).subscribe((policyResult: any) => {
                            // console.log('Create Claim policyResult', JSON.stringify(policyResult));
                            if (policyResult) {
                                this.claimModel.policyNumber = policyResult.primaryLayer + '';
                                this.claimService.createClaim(this.claimModel).subscribe((claimResult) => {
                                    // console.log('createClaim claimModel._id', claimResult);
                                    if (claimResult) {
                                        this.claimModel._id = claimResult.body._id;
                                        this.claimId = claimResult.body._id;
                                        this.defaultSelected();
                                    }
                                });
                            }
                        });
                    }
                }
            });
        }
    }

    editClaim(claimId) {
        // console.log("Editing Draft Claims Starts.");
        this.claimService
            .getClaimById(claimId)
            .subscribe((draftClaimApplication: any) => {
                // console.log('draftClaimApplication', draftClaimApplication);
                if (draftClaimApplication) {
                    this.claimModel = draftClaimApplication;
                }
            });
        this.loadTranches();
        // console.log("Editing Draft Claims Ends.");
    }

    viewSubmittedClaim(selectedClaimId) {
        this.viewClaim = true;
        this.claimService.getClaimInfo(selectedClaimId).subscribe((claimResult: any) => {
            // console.log('Load Resouce', JSON.stringify(claimResult));
            if (claimResult) {
                this.claimModel._id = claimResult._id;
                this.claimModel.status = claimResult.status;
                this.claimModel.marshRefNo = claimResult.marshRefNo;
                this.claimModel.loanMarshRefNo = claimResult.loanMarshRefNo;
                this.claimModel.baseLoanId = claimResult.baseLoanId;
                this.claimModel.consortium = claimResult.consortium;

                this.claimModel.pfiCode = claimResult.pfiCode;
                this.claimModel.pfiName = claimResult.pfiName;
                this.claimModel.policyNumber = claimResult.policyNumber;
                this.claimModel.insurers = claimResult.insurers;
                this.claimModel.tranche = claimResult.tranche;
                this.claimModel.app = claimResult.app;
                this.claimModel.nameOfStaff = claimResult.nameOfStaff;
                this.claimModel.dateReportedToMarsh = claimResult.dateReportedToMarsh;
                this.claimModel.nameOfPerson = claimResult.nameOfPerson;
                this.claimModel.jobTitle = claimResult.jobTitle;
                this.claimModel.regCompanyName = claimResult.regCompanyName;
                this.claimModel.uen = claimResult.uen;
                this.claimModel.businessActivity = claimResult.businessActivity;
                this.claimModel.loAcceptanceDate = claimResult.loAcceptanceDate;
                this.claimModel.approvedPrimaryLimit = claimResult.approvedPrimaryLimit;
                this.claimModel.approvedTopUpLimit = claimResult.approvedTopUpLimit;
                this.claimModel.approvedBGLimit = claimResult.approvedBGLimit;
                this.claimModel.approvedLisPlusLimit = claimResult.approvedLisPlusLimit;
                this.claimModel.outstandingPrincipal = claimResult.outstandingPrincipal;
                this.claimModel.interest = claimResult.interest;
                this.claimModel.legalFees = claimResult.legalFees;
                this.claimModel.remarks = claimResult.remarks;

                this.claimModel.pfiANL = claimResult.pfiANL;
                this.claimModel.pfiANLTxt = claimResult.pfiANLTxt;
                this.claimModel.invoice = claimResult.invoice;
                this.claimModel.deliveryOrder = claimResult.deliveryOrder;
                this.claimModel.purchaseOrder = claimResult.purchaseOrder;
                this.claimModel.purchaseOrderTxt = claimResult.purchaseOrderTxt;
                this.claimModel.applicationForInvoice = claimResult.applicationForInvoice;
                this.claimModel.facilityDetails = claimResult.facilityDetails;
                this.claimModel.facilityDetailsTxt = claimResult.facilityDetailsTxt;
                this.claimModel.financeNotification = claimResult.financeNotification;
                this.claimModel.financeAdviceNote = claimResult.financeAdviceNote;
                this.claimModel.financeAdviceNoteTxt = claimResult.financeAdviceNoteTxt;
                this.claimModel.limitRequestForm = claimResult.limitRequestForm;
                this.claimModel.limitEndorsementForm = claimResult.limitEndorsementForm;
                this.claimModel.currentStatement = claimResult.currentStatement;
                this.claimModel.tradeStatement = claimResult.tradeStatement;
                this.claimModel.tradeStatementTxt = claimResult.tradeStatementTxt;
                this.claimModel.creditApplication = claimResult.creditApplication;
                this.claimModel.writeOffMemo = claimResult.writeOffMemo;
                this.claimModel.letterOfAcceptance = claimResult.letterOfAcceptance;
                this.claimModel.guarantee = claimResult.guarantee;
                this.claimModel.guaranteeTxt = claimResult.guaranteeTxt;
                this.claimModel.acraSearch = claimResult.acraSearch;
                this.claimModel.individualSearch = claimResult.individualSearch;
                this.claimModel.individualSearchTxt = claimResult.individualSearchTxt;
                this.claimModel.demandLetter = claimResult.demandLetter;
                this.claimModel.demandLetterTxt = claimResult.demandLetterTxt;
                this.claimModel.statutoryDemand = claimResult.statutoryDemand;
                this.claimModel.statutoryDemandTxt = claimResult.statutoryDemandTxt;
                this.claimModel.originatingSummon = claimResult.originatingSummon;
                this.claimModel.originatingSummonTxt = claimResult.originatingSummonTxt;
                this.claimModel.windingUpOrder = claimResult.windingUpOrder;
                this.claimModel.windingUpOrderTxt = claimResult.windingUpOrderTxt;
                this.claimModel.bankruptcyApplication = claimResult.bankruptcyApplication;
                this.claimModel.bankruptcyApplicationTxt = claimResult.bankruptcyApplicationTxt;
                this.claimModel.bankruptcyOrder = claimResult.bankruptcyOrder;
                this.claimModel.bankruptcyOrderTxt = claimResult.bankruptcyOrderTxt;
                this.claimModel.borrower = claimResult.borrower;
                this.claimModel.guarantors = claimResult.guarantors;
                this.claimModel.guarantorsTxt = claimResult.guarantorsTxt;
                this.claimModel.legalCostInvoices = claimResult.legalCostInvoices;
                this.claimModel.legalCostInvoicesTxt = claimResult.legalCostInvoicesTxt;
                this.claimModel.recoveryDetails = claimResult.recoveryDetails;
                this.claimModel.recoveryDetailsTxt = claimResult.recoveryDetailsTxt;
                this.claimModel.approvedSuppliers = claimResult.approvedSuppliers;
                this.claimModel.approvedSuppliersTxt = claimResult.approvedSuppliersTxt;
                this.claimModel.beneficiaryDemandLetter = claimResult.beneficiaryDemandLetter;
                this.claimModel.beneficiaryDemandLetterTxt = claimResult.beneficiaryDemandLetterTxt;
                this.claimModel.pfiGuarantee = claimResult.pfiGuarantee;
                this.claimModel.pfiGuaranteeTxt = claimResult.pfiGuaranteeTxt;
                this.claimModel.letterOfAward = claimResult.letterOfAward;
                this.claimModel.letterOfAwardTxt = claimResult.letterOfAwardTxt;
                this.claimModel.claimProgressPayment = claimResult.claimProgressPayment;
                this.claimModel.claimProgressPaymentTxt = claimResult.claimProgressPaymentTxt;
                this.claimModel.lossesSuffered = claimResult.lossesSuffered;
                this.claimModel.lossesSufferedTxt = claimResult.lossesSufferedTxt;
                this.claimModel.otherDocuments = claimResult.otherDocuments;
                // this.claimModel.supportingDocs = claimResult.supportingDocs;
                // this.claimModel = claimResult;
                this.setDateFormat();
                this.loadTranches();
            }
        });
    }

    setDateFormat() {
        if (this.claimModel.dateReportedToMarsh) {
            this.claimModel.dateReportedToMarsh = new Date(
                this.claimModel.dateReportedToMarsh
            );
        }
        if (this.claimModel.loAcceptanceDate) {
            this.claimModel.loAcceptanceDate = new Date(
                this.claimModel.loAcceptanceDate
            );
        }
    }

    defaultSelected() {
        this.claimModel.pfiANL = 'Yes';
        this.claimModel.invoice = 'Yes';
        this.claimModel.deliveryOrder = 'Yes';
        this.claimModel.applicationForInvoice = 'Yes';
        this.claimModel.financeNotification = 'Yes';
        this.claimModel.limitRequestForm = 'Yes';
        this.claimModel.limitEndorsementForm = 'Yes';
        this.claimModel.currentStatement = 'Yes';
        this.claimModel.creditApplication = 'Yes';
        this.claimModel.writeOffMemo = 'Yes';
        this.claimModel.letterOfAcceptance = 'Yes';
        this.claimModel.acraSearch = 'Yes';
        this.claimModel.borrower = 'Yes';
    }

    submitClaim() {

        if (!this.isValidate()) {
            return;
        }
        this.claimService.claimdata = this.claimModel;
        // this.claimService.claimModelData.next(this.claimModel);

        this.claimService.submitClaim(this.claimModel).subscribe((res) => {

            if (res.status === 200) {
                const claimResult = res.body;
                // console.log('claimResult', claimResult);
                this.claimModel.loanMarshRefNo = claimResult['loanMarshRefNo'];
                this.claimModel.marshRefNo = claimResult['marshRefNo'];
                this.claimModel.status = claimResult['status'];

                const notificationOption = new NotificationOption();
                notificationOption.toastrConfig = {
                    positionClass: 'toast-top-right'
                };
                notificationOption.title = 'Notification';
                notificationOption.message = 'Claim Information Submitted Successfully';
                this.notificationService.showNotification(notificationOption);
                this.claimSubmissionForm.form.markAsPristine();
                this.router.navigate(['./claim-submitted']);
            }
        }, (error) => {
            console.error(error);
        });
    }

    updateStack(event, supportDoc) {
        if (this.claimModel.supportingDocs) {
            this.claimModel.supportingDocs.forEach((element) => {
                if (element.name === supportDoc) {
                    element.status = true;
                    if (element.files && element.files != '') {
                        element.files += ', ' + event.filename;
                    } else {
                        element.files = event.filename + ' ';
                    }
                }
            });
        }
        // this.isValidate();
    }

    isValidate() {

        let errorDoc = false;
        const notificationOption = new NotificationOption();
        notificationOption.title = '';
        notificationOption.clear = false;
        notificationOption.type = 'error';
        notificationOption.toastrConfig = {
            positionClass: 'toast-bottom-right',
            disableTimeOut: true
        };
        if (!this.isDocumentValid()) {
            notificationOption.message = 'Please select and complete mandatory section.'
            this.notificationService.showNotification(notificationOption);
            return false;
        }


        let errorMessage = 'Please upload document for ';
        this.notificationService.clearNotification();

        if (this.claimModel.supportingDocs) {
            this.claimModel.supportingDocs.forEach(element => {
                let field = element.name;
                switch (field) {
                    case "ANL Claim Statement":
                        if (!element.status && this.claimModel.pfiANL === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'ANL Claim Statement.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Invoice":
                        if (!element.status && this.claimModel.invoice === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Invoice.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Delivery order/Bill of lading":
                        if (!element.status && this.claimModel.deliveryOrder === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Delivery order/Bill of lading.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Purchase order/Sales contract":
                        if (!element.status && this.claimModel.purchaseOrder === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Purchase order/Sales contract.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;
                    case "Application for invoice financing":
                        if (!element.status && this.claimModel.applicationForInvoice === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Application for invoice financing.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;
                    case "Facility Details-TR":
                        if (!element.status && this.claimModel.facilityDetails === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Facility Details-TR.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Invoice Financing Buyers-Finance Notification":
                        if (!element.status && this.claimModel.financeNotification === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Invoice Financing Buyers-Finance Notification.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Finance Advice/Debit Advice/Debit Note":
                        if (!element.status && this.claimModel.financeAdviceNote === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Finance Advice/Debit Advice/Debit Note.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Limit Request Form":
                        if (!element.status && this.claimModel.limitRequestForm === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Limit Request Form.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;
                    case "Limit Endorsement Form":
                        if (!element.status && this.claimModel.limitEndorsementForm === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Limit Endorsement Form.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;
                    case "Current Statement":
                        if (!element.status && this.claimModel.currentStatement === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Current Statement.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Trade Statement":
                        if (!element.status && this.claimModel.tradeStatement === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Trade Statement.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Credit Memo/Credit Application":
                        if (!element.status && this.claimModel.creditApplication === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Credit Memo/Credit Application.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Write-off Memo":
                        if (!element.status && this.claimModel.writeOffMemo === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Write-off Memo.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;
                    case "Letter of offer and Acceptance":
                        if (!element.status && this.claimModel.letterOfAcceptance === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Letter of offer and Acceptance.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;
                    case "Guarantee":
                        if (!element.status && this.claimModel.guarantee === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Guarantee.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "ACRA Search":
                        if (!element.status && this.claimModel.acraSearch === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'ACRA Search.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Individual Search":
                        if (!element.status && this.claimModel.individualSearch === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Individual Search.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Demand Letter":
                        if (!element.status && this.claimModel.demandLetter === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Demand Letter.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;
                    case "Statutory Demand":
                        if (!element.status && this.claimModel.statutoryDemand === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Statutory Demand.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;
                    case "Originating Summon":
                        if (!element.status && this.claimModel.originatingSummon === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Originating Summon.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Winding Up Order":
                        if (!element.status && this.claimModel.windingUpOrder === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Winding Up Order.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Bankruptcy Application":
                        if (!element.status && this.claimModel.bankruptcyApplication === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Bankruptcy Application.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Bankruptcy Order":
                        if (!element.status && this.claimModel.bankruptcyOrder === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Bankruptcy Order.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;
                    case "Proof of Debt-Borrower":
                        if (!element.status && this.claimModel.borrower === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Proof of Debt-Borrower.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;
                    case "Proof of Debt-Guarantors":
                        if (!element.status && this.claimModel.guarantors === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Proof of Debt-Guarantors.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Legal cost invoices":
                        if (!element.status && this.claimModel.legalCostInvoices === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Legal cost invoices.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Recovery details":
                        if (!element.status && this.claimModel.recoveryDetails === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Recovery details.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Approved suppliers by the bank":
                        if (!element.status && this.claimModel.approvedSuppliers === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Approved suppliers by the bank.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;
                    case "Demand Letter from the Beneficiary":
                        if (!element.status && this.claimModel.beneficiaryDemandLetter === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Demand Letter from the Beneficiary.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;
                    case "Copy of Banker’s Guarantee":
                        if (!element.status && this.claimModel.pfiGuarantee === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Copy of Banker’s Guarantee.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Letter of Award":
                        if (!element.status && this.claimModel.letterOfAward === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Letter of Award.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Latest Claim Progress Payment":
                        if (!element.status && this.claimModel.claimProgressPayment === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Latest Claim Progress Payment.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    case "Non-performance of the contract and the losses suffered":
                        if (!element.status && this.claimModel.lossesSuffered === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Non-performance of the contract and the losses suffered.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;
                    case "Others":
                        if (!element.status && this.claimModel.otherDocuments === "Yes") {
                            notificationOption.message =
                                errorMessage +
                                'Others.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    default:
                        break;
                }
            });
        }
        if (errorDoc) {
            return false;
        } else return true;
    }

    isDocumentValid() {
        // TODO: Update the logic as per mandatory fields
        let sectionChecked = (
            this.claimModel.pfiANL ||
            this.claimModel.invoice ||
            this.claimModel.deliveryOrder ||
            this.claimModel.applicationForInvoice ||
            this.claimModel.financeNotification ||
            this.claimModel.limitRequestForm ||
            this.claimModel.limitEndorsementForm ||
            this.claimModel.currentStatement ||
            this.claimModel.creditApplication ||
            this.claimModel.writeOffMemo ||
            this.claimModel.letterOfAcceptance ||
            this.claimModel.acraSearch ||
            this.claimModel.borrower
        );

        if (sectionChecked === 'Yes') {
            // console.log('sectionChecked Yes', sectionChecked);
            return true;
        } else {
            // console.log('sectionChecked No', sectionChecked);
            return false;
        }
    }

    saveAsDraft() {
        this.claimService.saveAsDraftClaim(this.claimModel).subscribe((res) => {
            const notificationOption = new NotificationOption();
            notificationOption.toastrConfig = {
                positionClass: 'toast-top-right'
            };
            notificationOption.title = 'Notification';
            notificationOption.message = res.body['success'];
            this.notificationService.showNotification(notificationOption);
            this.claimSubmissionForm.form.markAsPristine();
        });
    }

    reset(field: string) {
        this.claimModel[field] = undefined;
    }

    goToTop() {
        window.scrollTo(0, 0);
    }

    onManageDocClick(documentType) {
        this.dialogTitle = "Manage Documents";
        this.docType = documentType;
        this.popUp = true;
        this.showManageDoc = true;
    }

    hidePopup(event) {
        this.popUp = false;
        this.showManageDoc = false;
    }

    fromManageDoc(file) {
        if (file.metadata.documentType) {
            this.updateStack(file, file.metadata.documentType);
        }
    }

}
