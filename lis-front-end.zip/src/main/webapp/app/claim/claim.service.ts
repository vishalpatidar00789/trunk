import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { SERVER_API_URL } from '../app.constants';
import { ClaimModel } from './claim.model';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class ClaimService {

    private resourceUrl = SERVER_API_URL;
    claimdata:ClaimModel;
    claimModelData = new BehaviorSubject<ClaimModel>(new ClaimModel());
    claimModelData$= this.claimModelData.asObservable();    
    
    constructor(private http: HttpClient) { }    

    getLoanById(loanId: string) {
        return <any>this.http.get(this.resourceUrl + 'loanform/loan/' + loanId);
    }

    getClaimById(claimId: string) {
        console.log("claimId: " + claimId);
        return <any>this.http.get(this.resourceUrl + 'claim/info/' + claimId);
    }

    deleteClaimById(claimId: string) {
        console.log("claimId: " + claimId);
        return <any>this.http.delete(this.resourceUrl + 'claim/delete/' + claimId);
    }

    getPolicyById(pfiCode: string) {
        return <any>this.http.get(this.resourceUrl + 'master-data/policyByPfiCode/' + pfiCode);
    }

    createClaim(claimModel: ClaimModel): Observable<HttpResponse<ClaimModel>> {        
        delete claimModel['__v'];
        // delete claimModel['_id'];
        delete claimModel['createdBy'];
        delete claimModel['createdDate'];
        delete claimModel['lastModifiedBy'];
        delete claimModel['lastModifiedDate'];
        return this.http.post<ClaimModel>(
            this.resourceUrl + 'claim/create-claim', claimModel, { observe: 'response' }
        );
    }

    submitClaim(claimModel: ClaimModel): Observable<HttpResponse<ClaimModel>> {
        const _id = claimModel['_id'];
        delete claimModel['__v'];
        // delete claimModel['_id'];
        delete claimModel['createdBy'];
        delete claimModel['createdDate'];
        delete claimModel['lastModifiedBy'];
        delete claimModel['lastModifiedDate'];
            
        return this.http.put<ClaimModel>(
          this.resourceUrl + 'claim/submitClaim/'+ _id, claimModel, { observe: 'response' }
        );
    }
    
    saveAsDraftClaim(claimModel: ClaimModel): Observable<HttpResponse<ClaimModel>> {
        const _id = claimModel['_id'];
        delete claimModel['__v'];
        // delete claimModel['_id'];
        delete claimModel['createdBy'];
        delete claimModel['createdDate'];
        delete claimModel['lastModifiedBy'];
        delete claimModel['lastModifiedDate'];
    
        console.log('request paylod:: ' + JSON.stringify(claimModel));
        return this.http.put<ClaimModel>(
          this.resourceUrl + 'claim/saveAsDraft/'+ _id, claimModel, { observe: 'response' }
        );
    }

    getClaimInfo(claimId: string) {
        return <any>this.http.get(this.resourceUrl + 'claim/info/' + claimId);
    }
}
