export class ClaimSupportingDocuments {
    constructor(
        public _id?: string,
        public marshRefNo?: string,        
        public borrowerName?: string,
        public pfiCode?: string,
        public staffName?: string,
        public uenNumber?: string,
        public typeOfRequest?:string,
        public claimSubmissionStatus?:string
    ) {
    }
}
