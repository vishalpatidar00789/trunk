import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { TitleCasePipe, DatePipe } from '@angular/common';
import { NgForm } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotificationService } from '../../shared/alert/notification.service';
import { ClaimSupportingDocuments } from './claim-supporting-documents.model';
import { ManageSupportingDocumentsService } from '../../loan/manage-supporting-documents/manage-supporting-documents.service';
import { ClaimSearchResults } from '../claim-search/claim-search-results/claim-search-results.model';
import { Document } from '../../shared/document-list/documents.model'

@Component({
    selector: 'claim-supporting-documents',
    templateUrl: './claim-supporting-documents.component.html',
    providers: [TitleCasePipe, DatePipe]
})
export class ClaimSupportingDocumentsComponent implements OnInit, OnChanges {

    collectionType: string;
    displayMessage: boolean;
    userMessage: string;    
    documentTypes: any[];
    docType:string;
    model: ClaimSupportingDocuments;
    documentList: Document[];
    @Input() userid: string;
    @Input() isMarshUser: boolean;
    @Input() selectedClaimResult: ClaimSearchResults;
    @Output() closePopUp = new EventEmitter<boolean>();

    constructor(
        private manageSupportingDoc: ManageSupportingDocumentsService,
        private notificationService: NotificationService,
        private supportingDocservice: ManageSupportingDocumentsService,
        private spinner: NgxSpinnerService, private datePipe: DatePipe,
        private titlePipe: TitleCasePipe) {
    }

    ngOnChanges() {        
        if (this.selectedClaimResult) {
            this.model = new ClaimSupportingDocuments();
            this.model.marshRefNo = this.selectedClaimResult.marshRefNo;
            this.model.uenNumber = this.selectedClaimResult.aCRArefNo;
            this.model.borrowerName = this.selectedClaimResult.borrowerRegName;
            this.model.staffName = this.selectedClaimResult.requesterName;
            this.model.pfiCode = this.selectedClaimResult.pfiName;
            this.model.claimSubmissionStatus = this.selectedClaimResult.status;
            this.model._id = this.selectedClaimResult._id;            
        }
    }

    ngOnInit() {
        console.log(this.selectedClaimResult);
        this.displayMessage = false;        
        this.collectionType = 'CLAIM';
        this.docType='';
        this.documentTypes = [
            { label: 'ANL Claim Statement', value: 'ANL Claim Statement' },
            { label: 'Invoice', value: 'Invoice' },
            { label: 'Delivery order/Bill of lading', value: 'Delivery order/Bill of lading' },
            { label: 'Purchase order/Sales contract', value: 'Purchase order/Sales contract' },
            { label: 'Application for invoice financing', value: 'Application for invoice financing' },
            { label: 'Facility Details-TR', value: 'Facility Details-TR' },
            { label: 'Invoice Financing Buyers-Finance Notification', value: 'Invoice Financing Buyers-Finance Notification' },
            { label: 'Finance Advice/Debit Advice/Debit Note', value: 'Finance Advice/Debit Advice/Debit Note' },
            { label: 'Limit Request Form', value: 'Limit Request Form' },
            { label: 'Limit Endorsement Form', value: 'Limit Endorsement Form' },
            { label: 'Current Statement', value: 'Current Statement' },
            { label: 'Trade Statement', value: 'Trade Statement' },
            { label: 'Credit Memo/Credit Application', value: 'Credit Memo/Credit Application' },
            { label: 'Write-off Memo', value: 'Write-off Memo' },
            { label: 'Letter of offer and Acceptance', value: 'Letter of offer and Acceptance' },
            { label: 'Guarantee', value: 'Guarantee' },
            { label: 'ACRA Search', value: 'ACRA Search' },
            { label: 'Individual Search', value: 'Individual Search' },
            { label: 'Demand Letter', value: 'Demand Letter' },
            { label: 'Statutory Demand', value: 'Statutory Demand' },
            { label: 'Originating Summon', value: 'Originating Summon' },
            { label: 'Winding Up Order', value: 'Winding Up Order' },
            { label: 'Bankruptcy Application', value: 'Bankruptcy Application' },
            { label: 'Bankruptcy Order', value: 'Bankruptcy Order' },
            { label: 'Proof of Debt-Borrower', value: 'Proof of Debt-Borrower' },
            { label: 'Proof of Debt-Guarantors', value: 'Proof of Debt-Guarantors' },
            { label: 'Legal cost invoices', value: 'Legal cost invoices' },
            { label: 'Recovery details', value: 'Recovery details' },
            { label: 'Approved suppliers by the bank', value: 'Approved suppliers by the bank' },
            { label: 'Demand Letter from the Beneficiary', value: 'Demand Letter from the Beneficiary' },
            { label: 'Copy of Banker’s Guarantee', value: 'Copy of Banker’s Guarantee' },
            { label: 'Letter of Award', value: 'Letter of Award' },
            { label: 'Latest Claim Progress Payment', value: 'Latest Claim Progress Payment' },
            { label: 'Non-performance of the contract and the losses suffered', value: 'Non-performance of the contract and the losses suffered' },            
            { label: 'Others', value: 'Others' }
        ]

       this.getDocumentsById();
    }

    getDocumentsById(){
        this.supportingDocservice.getDocumentsByAppRefId(this.model._id).subscribe(files => {
            if (files) {
                this.documentList = [];
                let file: Document;
                files.forEach(element => {
                    if (element) {
                        file = new Document();
                        file._id = element._id;
                        file.filename = element.metadata.fileName;
                        file.uploadDate = this.datePipe.transform(element.uploadDate, 'dd-MMM-yyy,h:mm:ss a');
                        file.documentType = element.metadata.documentType;
                        file.uploadedBy = element.metadata.uploadedBy;
                        this.documentList.push(file);
                    }
                });
                this.sort();
            }
        })
    }

    cancel() {
        this.closePopUp.emit(true);
    }

    afterUpload(uploadedFile: any) {
        let file: Document;
        file = new Document();
        file._id = uploadedFile._id;
        file.filename = uploadedFile.filename;
        file.uploadDate = this.datePipe.transform(new Date(), 'dd-MMM-yyy,h:mm:ss a');
        file.documentType = uploadedFile.metadata.documentType;
        file.uploadedBy = this.userid;
        this.documentList.push(file);
        this.sort();
    }

    sort() {
        this.documentList.sort(function (b, a) {
            if (a.uploadDate < b.uploadDate) return -1;
            if (a.uploadDate > b.uploadDate) return 1;
            return 0;
        });
    }

}