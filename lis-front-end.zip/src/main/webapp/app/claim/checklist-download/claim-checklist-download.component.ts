import { Component, OnInit, ViewChild, ElementRef, Input } from '@angular/core';

import * as jspdf from 'jspdf';
import * as html2canvas from 'html2canvas';
import { ClaimModel, SupportingDocs } from '../claim.model';
import { ManageDocument } from '../../shared/manage-documents/manage-documents.model';
import { ManageDocumentsService } from '../../shared/manage-documents/manage-documents.service';

@Component({
  selector: 'lis-checklist-download',
  templateUrl: './claim-checklist-download.component.html'
})
export class ClaimChecklistDownloadComponent implements OnInit {

  public checklist: boolean;
  public documentList: ManageDocument[];
  public supportingDoc: SupportingDocs = new SupportingDocs();
  public btnDisabled: boolean;

  @Input('claimModel') claimModel: ClaimModel;
  @Input('viewClaim') viewClaim: boolean;

  @ViewChild('content') content: ElementRef;
  @ViewChild('content2') content2: ElementRef;
  @ViewChild('content3') content3: ElementRef;

  constructor(
    private manageDocService: ManageDocumentsService,
  ) {
    this.checklist = false;
    this.btnDisabled = false;
  }

  ngOnInit() {
    this.supportingDocs();
  }

  public export2Pdf() {
    this.btnDisabled = true;
    const content = this.content.nativeElement;
    const content2 = this.content2.nativeElement;
    const content3 = this.content3.nativeElement;
    const pdf = new jspdf('p', 'px', 'a4');
    pdf.setFontSize(10);
    const width = pdf.internal.pageSize.width;
    const height = pdf.internal.pageSize.height;
    html2canvas(content).then((canvas) => {
      const imgData1 = canvas.toDataURL('image/jpeg', 1.0);
      html2canvas(content2).then((canvas2) => {
        const imgData2 = canvas2.toDataURL('image/jpeg', 1.0);
        html2canvas(content3).then((canvas3) => {
          const imgData3 = canvas3.toDataURL('image/jpeg', 1.0);
          pdf.addImage(imgData1, 'JPEG', 10, 10, 430, 520);
          pdf.addPage();
          pdf.addImage(imgData2, 'JPEG', 10, 10, 430, 520);
          pdf.addPage();
          pdf.addImage(imgData3, 'JPEG', 10, 10, 430, 520);
          pdf.save('checklist.pdf');
          this.btnDisabled = false;
        });
      });
    });
  }

  supportingDocs() {
    if (this.claimModel.supportingDocs) {
      this.claimModel.supportingDocs.forEach(async(element) => {
        const field = element.name;
        switch (field) {
          case 'ANL Claim Statement':
            if (!element.status && this.claimModel.pfiANL === 'Yes') {
              this.supportingDoc.anlDoc = await this.getFiles(element.name);
            }
            break;

          case 'Invoice':
            if (!element.status && this.claimModel.invoice === 'Yes') {
              this.supportingDoc.invoiceDoc = await this.getFiles(element.name);
            }
            break;

          case 'Delivery order/Bill of lading':
            if (!element.status && this.claimModel.deliveryOrder === 'Yes') {
              this.supportingDoc.deliveryDoc = await this.getFiles(element.name);
            }
            break;

          case 'Purchase order/Sales contract':
            if (!element.status && this.claimModel.purchaseOrder === 'Yes') {
              this.supportingDoc.purchaseDoc = await this.getFiles(element.name);
            }
            break;
          case 'Application for invoice financing':
            if (!element.status && this.claimModel.applicationForInvoice === 'Yes') {
              this.supportingDoc.appinvoiceDoc = await this.getFiles(element.name);
            }
            break;
          case 'Facility Details-TR':
            if (!element.status && this.claimModel.facilityDetails === 'Yes') {
              this.supportingDoc.facilityDoc = await this.getFiles(element.name);
            }
            break;

          case 'Invoice Financing Buyers-Finance Notification':
            if (!element.status && this.claimModel.financeNotification === 'Yes') {
              this.supportingDoc.invoiceFinancingDoc = await this.getFiles(element.name);
            }
            break;

          case 'Finance Advice/Debit Advice/Debit Note':
            if (!element.status && this.claimModel.financeAdviceNote === 'Yes') {
              this.supportingDoc.financeAdviceDoc = await this.getFiles(element.name);
            }
            break;

          case 'Limit Request Form':
            if (!element.status && this.claimModel.limitRequestForm === 'Yes') {
              this.supportingDoc.limitRequestDoc = await this.getFiles(element.name);
            }
            break;
          case 'Limit Endorsement Form':
            if (!element.status && this.claimModel.limitEndorsementForm === 'Yes') {
              this.supportingDoc.limitEndorsementDoc = await this.getFiles(element.name);
            }
            break;
          case 'Current Statement':
            if (!element.status && this.claimModel.currentStatement === 'Yes') {
              this.supportingDoc.currentStatementDoc = await this.getFiles(element.name);
            }
            break;

          case 'Trade Statement':
            if (!element.status && this.claimModel.tradeStatement === 'Yes') {
              this.supportingDoc.tradeStatementDoc = await this.getFiles(element.name);
            }
            break;

          case 'Credit Memo/Credit Application':
            if (!element.status && this.claimModel.creditApplication === 'Yes') {
              this.supportingDoc.creditMemoDoc = await this.getFiles(element.name);
            }
            break;

          case 'Write-off Memo':
            if (!element.status && this.claimModel.writeOffMemo === 'Yes') {
              this.supportingDoc.writeOffMemoDoc = await this.getFiles(element.name);
            }
            break;
          case 'Letter of offer and Acceptance':
            if (!element.status && this.claimModel.letterOfAcceptance === 'Yes') {
              this.supportingDoc.letterOfOfferDoc = await this.getFiles(element.name);
            }
            break;
          case 'Guarantee':
            if (!element.status && this.claimModel.guarantee === 'Yes') {
              this.supportingDoc.guaranteeDoc = await this.getFiles(element.name);
            }
            break;

          case 'ACRA Search':
            if (!element.status && this.claimModel.acraSearch === 'Yes') {
              this.supportingDoc.acraSearchDoc = await this.getFiles(element.name);
            }
            break;

          case 'Individual Search':
            if (!element.status && this.claimModel.individualSearch === 'Yes') {
              this.supportingDoc.individualSearchDoc = await this.getFiles(element.name);
            }
            break;

          case 'Demand Letter':
            if (!element.status && this.claimModel.demandLetter === 'Yes') {
              this.supportingDoc.demandLetterDoc = await this.getFiles(element.name);
            }
            break;
          case 'Statutory Demand':
            if (!element.status && this.claimModel.statutoryDemand === 'Yes') {
              this.supportingDoc.statutoryDemandDoc = await this.getFiles(element.name);
            }
            break;
          case 'Originating Summon':
            if (!element.status && this.claimModel.originatingSummon === 'Yes') {
              this.supportingDoc.originatingSummonDoc = await this.getFiles(element.name);
            }
            break;

          case 'Winding Up Order':
            if (!element.status && this.claimModel.windingUpOrder === 'Yes') {
              this.supportingDoc.windingUpOrderDoc = await this.getFiles(element.name);
            }
            break;

          case 'Bankruptcy Application':
            if (!element.status && this.claimModel.bankruptcyApplication === 'Yes') {
              this.supportingDoc.bankruptcyAppDoc = await this.getFiles(element.name);
            }
            break;

          case 'Bankruptcy Order':
            if (!element.status && this.claimModel.bankruptcyOrder === 'Yes') {
              this.supportingDoc.bankruptcyOrderDoc = await this.getFiles(element.name);
            }
            break;
          case 'Proof of Debt-Borrower':
            if (!element.status && this.claimModel.borrower === 'Yes') {
              this.supportingDoc.proofOfDebtBorrowerDoc = await this.getFiles(element.name);
            }
            break;
          case 'Proof of Debt-Guarantors':
            if (!element.status && this.claimModel.guarantors === 'Yes') {
              this.supportingDoc.proofOfDebtGuarantorsDoc = await this.getFiles(element.name);
            }
            break;

          case 'Legal cost invoices':
            if (!element.status && this.claimModel.legalCostInvoices === 'Yes') {
              this.supportingDoc.legalCostInvoicesDoc = await this.getFiles(element.name);
            }
            break;

          case 'Recovery details':
            if (!element.status && this.claimModel.recoveryDetails === 'Yes') {
              this.supportingDoc.recoveryDetailsDoc = await this.getFiles(element.name);
            }
            break;

          case 'Approved suppliers by the bank':
            if (!element.status && this.claimModel.approvedSuppliers === 'Yes') {
              this.supportingDoc.approvedSuppliersDoc = await this.getFiles(element.name);
            }
            break;
          case 'Demand Letter from the Beneficiary':
            if (!element.status && this.claimModel.beneficiaryDemandLetter === 'Yes') {
              this.supportingDoc.demandLetterBeneficiaryDoc = await this.getFiles(element.name);
            }
            break;
          case 'Copy of Banker’s Guarantee':
            if (!element.status && this.claimModel.pfiGuarantee === 'Yes') {
              this.supportingDoc.copyOfBankeGuaranteeDoc = await this.getFiles(element.name);
            }
            break;

          case 'Letter of Award':
            if (!element.status && this.claimModel.letterOfAward === 'Yes') {
              this.supportingDoc.letterOfAwardDoc = await this.getFiles(element.name);
            }
            break;

          case 'Latest Claim Progress Payment':
            if (!element.status && this.claimModel.claimProgressPayment === 'Yes') {
              this.supportingDoc.latestClaimProgressPaymentDoc = await this.getFiles(element.name);
            }
            break;

          case 'Non-performance of the contract and the losses suffered':
            if (!element.status && this.claimModel.lossesSuffered === 'Yes') {
              this.supportingDoc.nonPerformanceContractDoc = await this.getFiles(element.name);
            }
            break;
          case 'Others':
            if (!element.status && this.claimModel.otherDocuments === 'Yes') {
              this.supportingDoc.othersDoc = await this.getFiles(element.name);
            }
            break;

          default:
            break;
        }
      });
    }
  }

  async getFiles(documentType): Promise<any> {
    const payload = { docType: documentType, refAppId: this.claimModel._id };
    return new Promise<any> ((resolve, reject) => {
      this.manageDocService.getDocumentsByDocTypeAndAppRefId(payload).subscribe((files) => {
        const emptyArr: string[] = [];
        if (files) {
          resolve(files);
        } else {
          resolve(emptyArr);
        }
      });
    });
  }
}
