import { Component, OnInit } from '@angular/core';
import { ClaimService } from './claim.service';
import { ClaimModel } from './claim.model';

@Component({
    selector: 'claim-submitted-view',
    templateUrl: './claim-submitted-view.component.html'
})
export class ClaimSubmittedViewComponent implements OnInit {

    claimModel: ClaimModel;

    constructor(
        private claimService: ClaimService
    ) { }

    ngOnInit() {
        this.claimModel = this.claimService.claimdata;

        // this.claimService.claimModelData$.subscribe((value) => {
        //     this.claimModel=Object.assign({}, value);  
        //     console.log('###',JSON.stringify(this.claimModel));
        //   });
    }
}
