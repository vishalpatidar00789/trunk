import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { LisAppSharedModule } from '../shared';
import {
    ClaimRoute,
    ClaimComponent,
} from './';
import { ClaimService } from './claim.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { PaginatorModule } from 'primeng/paginator';
import { MultiSelectModule } from 'primeng/multiselect';
import { CheckboxModule } from 'primeng/checkbox';
import { RadioButtonModule } from 'primeng/radiobutton';
import { DropdownModule } from 'primeng/dropdown';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { LISCurrencyMaskModule } from '../shared/currency/currency-mask.module';
import { ClaimSearchResultsComponent } from './claim-search/claim-search-results/claim-search-results.component';
import { ClaimSearchCriteriaComponent } from './claim-search/claim-search-criteria/claim-search-criteria.component';
import { ClaimSearchCriteriaService } from './claim-search/claim-search-criteria/claim-search-criteria.service';
import { ClaimSearchResultsService } from './claim-search/claim-search-results/claim-search-results.service';
import { ClaimSubmittedViewComponent } from './claim-submitted-view.component';
import { ClaimSupportingDocumentsComponent } from './supporting-documents/claim-supporting-documents.component';
import { ClaimChecklistDownloadComponent } from './checklist-download/claim-checklist-download.component';

@NgModule({
    imports: [
        LisAppSharedModule,
        NgbModule,
        TableModule,
        CheckboxModule,
        RadioButtonModule,
        DropdownModule,
        BsDatepickerModule,
        MultiSelectModule,
        DialogModule,
        LISCurrencyMaskModule,
        CurrencyMaskModule,
        RouterModule.forChild(ClaimRoute),
    ],
    declarations: [
        ClaimComponent,
        ClaimSearchCriteriaComponent,
        ClaimSearchResultsComponent,
        ClaimSubmittedViewComponent,
        ClaimSupportingDocumentsComponent,
        ClaimChecklistDownloadComponent
    ],
    entryComponents: [
        ClaimComponent,
    ],
    providers: [
        ClaimService,
        ClaimSearchCriteriaService,
        ClaimSearchResultsService
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class LisAppClaimModule { }
