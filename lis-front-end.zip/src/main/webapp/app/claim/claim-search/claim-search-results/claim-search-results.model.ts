export class ClaimSearchResults {
    constructor(
        public _id?: string,
        public marshRefNo?: string,
        public loanMarshRefNo?: string,
        public baseLoanId?: string,
        public typeOfRequest?:string,
        public status?: string,
        public pfiCode?: string,
        public consortium?: string,
        public borrowerRegName?: string,
        public aCRArefNo?: string,
        public pfiName?: string,
        public requesterName?: string,
        public natureOfApplication?: string,
        public submissionDate?: string,
        public marshSubmissionDate?: string,
        public loAcceptanceDate?: string,
        public loanExpiryDate?: string,
        public app?: string,
        public totalRequstedLimitSGD?: number,
        public primary?: number,
        public autoTopUp?: number,
        public bg?: number,
        public lisPlus?: number,
        public foreignCurrency?: number,
        public foreignCurrencyAmount?: number,
        public exchangeRate?: number,
        public adverseStatus?: string,
        public additionalInfo?: string,
        public overdue?: string,
        public overdueDate?: Date,
        public listOfOverdue?: boolean,
        public repaymentPlanAttached?: boolean
       

    ) {        
    }
}
