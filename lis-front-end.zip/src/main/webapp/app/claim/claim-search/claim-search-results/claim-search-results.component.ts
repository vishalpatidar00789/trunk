import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild, Input, OnChanges
} from '@angular/core';
import { LOAN_SEARCH_RESULT_ITEMS_PER_PAGE } from './../../../shared/constants/pagination.constants';
import { TieredMenu } from 'primeng/tieredmenu';
import { MenuItem } from 'primeng/api';
import { ClaimSearchResults } from './claim-search-results.model';
import { ClaimSearchResultsService } from './claim-search-results.service';
import { ClaimSearchCriteriaService } from '../claim-search-criteria/claim-search-criteria.service';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { Paginator } from 'primeng/paginator';
import { Table } from 'primeng/table';
import { LoanAdverseInfo } from '../../../loan/loan-adverse-info/loan-adverse-info.model';
import { LoanService } from '../../../loan/loan.service';
import { ClaimService } from '../../claim.service';
import { NotificationOption, NotificationService } from '../../../shared/alert/notification.service';

@Component({
  selector: 'claim-search-results',
  templateUrl: './claim-search-results.component.html'
})
export class ClaimSearchResultsComponent
  implements OnInit, OnDestroy, OnChanges {
  @Input() claimResultList: ClaimSearchResults[];
  @Input() isMarshUser: boolean;
  @Input() totalRecords: number;  
  @Input() userid: string;
  @Input() isUOB: boolean;

  public isUobRecored: boolean;
  public items: MenuItem[];
  public cols: any[];
  public frozenCols: any[];
  public itemsPerPage: number;
  public popUp: boolean;
  public adverseInfoModel: boolean;
  public loAcceptanceModel: boolean;
  public claimSupportingDocModel: boolean;
  public viewSubmitClaimModel: boolean;
  public isViewClaim: boolean;
  public selectedClaimResult: ClaimSearchResults;
  public claimResultList2: ClaimSearchResults[];
  public dialogTitle: string;
  public cloneLoanResultList: any[];
  public dialogTopPostion: number;
  isMidTerm = false;
  public baseLoanId: string;

  @ViewChild('tieredMenu') tieredMenu: TieredMenu;
  @ViewChild('table') table: Table;
  constructor(
    private loanService: LoanService,
    private loanSearchResultsService: ClaimSearchResultsService,
    private loanSearchCriteriaService: ClaimSearchCriteriaService,
    private claimService: ClaimService,
    private router: Router,
    private route: ActivatedRoute,
    private notificationService: NotificationService,
  ) { }

  ngOnChanges() {
    this.table.reset();
    this.cloneLoanResultList = this.claimResultList;
    this.claimResultList2 = [];
    setTimeout(() => {
      this.table.reset();
      this.claimResultList2 = this.cloneLoanResultList;
    }, 1000);

    this.itemsPerPage = LOAN_SEARCH_RESULT_ITEMS_PER_PAGE;

    this.cols = [
      { field: 'marshRefNo', header: 'LIS Claim Reference Number' },      
      { field: 'borrowerRegName', header: 'Borrower Name' },
      { field: 'aCRArefNo', header: 'UEN Number' },
      { field: 'pfiCode', header: 'PFI' },      
      { field: 'marshSubmissionDate', header: 'Marsh Submission  Date' },
      // { field: 'submissionDate', header: cofanetDate },
      { field: 'loAcceptanceDate', header: 'LO Acceptance Date ' },
      // { field: 'loanExpiryDate', header: 'Loan Expiry Date' },
      { field: 'status', header: 'Claim Submission Status' },
      { field: 'tranche', header: 'Tranche' },      
      { field: 'app', header: 'APP' },
      { field: 'totalRequstedLimitSGD', header: 'Total Applied Limit (S$)' },
      { field: 'primary', header: 'Approved Limit(Primary) S$' },
      { field: 'autoTopUp', header: 'Approved Limit(Top-up) S$' },
      { field: 'bg', header: 'Approved Limit(BG) S$' },
      { field: 'lisPlus', header: 'Approved Limit(LIS+) S$' }
    ];
  }

  ngOnInit() {
    this.popUp = false;
    this.viewSubmitClaimModel = false;
    this.isViewClaim = false;
    this.dialogTitle = '';
    this.isUobRecored = false;
  }

  ngOnDestroy() { }

  hidePopup(event) {
    this.popUp = false;
    this.viewSubmitClaimModel = false;
    this.isViewClaim = false;
  }

  showPopup(result, model: any) {
    this.popUp = true;
    this.selectedClaimResult = result;
    // console.log('Check user', JSON.stringify(this.selectedClaimResult));
    if (model == 1) {
      this.dialogTitle = 'View Submitted Application';
      this.viewSubmitClaimModel = true;
      this.dialogTopPostion = 10;
      this.isViewClaim = true;
    } else if (model == 2) {
      
    } else if (model == 4) {

    } else if (model == 3) {
      this.dialogTitle = 'Claim Supporting Documents';
      this.claimSupportingDocModel = true;
    }
  }

  editClaim(result) {
    this.selectedClaimResult = result;
    if (this.selectedClaimResult._id) {
      console.log("Navigating to Edit Draft claim: " + this.selectedClaimResult._id);
      this.router.navigate([`../claim/edit/${this.selectedClaimResult._id}`], {
        relativeTo: this.route
      });
    }
  }

  deleteClaim(result) {
    this.selectedClaimResult = result;
    if (this.selectedClaimResult._id) {
      console.log("Navigating to Delete Draft claim: " + this.selectedClaimResult._id);
      this.claimService
        .deleteClaimById(this.selectedClaimResult._id)
        .subscribe((res: any) => {
          if (res) {
            console.log("Deleting Draft claims almost done.: " + JSON.stringify(res));
            if (res['success']) {
              const notificationOption = new NotificationOption();
              notificationOption.toastrConfig = {
                positionClass: 'toast-top-right'
              };
              notificationOption.title = 'Notification';
              notificationOption.message = res['success'];
              console.log("Index: " + this.claimResultList2.indexOf(result));
              this.totalRecords = this.totalRecords - 1;
              this.claimResultList2.splice(this.claimResultList2.indexOf(result), 1);
              this.notificationService.showNotification(notificationOption);
            }
          }
        });
    }
  }

  routClaim(result) {
    this.selectedClaimResult = result;
    // const navigationExtras: NavigationExtras = {
    //   queryParams: {
    //     "loanId": this.selectedClaimResult._id
    //   }
    // };
    const marshRefNo = this.selectedClaimResult.marshRefNo.replace('/', '_');
    this.router.navigate(['/claim', { id: marshRefNo }]);

    // if (this.selectedClaimResult.pfiCode === 'UOB') {
    //   this.router.navigate(['/claim'], navigationExtras);
    // } else {
    //   this.router.navigate(['/claim'], navigationExtras);
    // }
  }
}
