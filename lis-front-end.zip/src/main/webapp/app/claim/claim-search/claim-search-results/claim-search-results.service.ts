import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { SERVER_API_URL } from '../../../app.constants';
import { PFILoan, UOBLoan } from '../../../loan';

@Injectable()
export class ClaimSearchResultsService {
  private resourceUrl = SERVER_API_URL;

  constructor(private http: HttpClient) {}

  submitClaimEditPFI(
    loanDetailsModal: PFILoan
  ): Observable<HttpResponse<PFILoan>> {
    // const id = loanDetailsModal['_id'];
    delete loanDetailsModal['__v'];
    // delete loanDetailsModal['_id'];
    delete loanDetailsModal['createdDate'];
    delete loanDetailsModal['updatedAt'];
    delete loanDetailsModal['adverseInfo'];
    delete loanDetailsModal['creditInfo']['supportingDocs'];
    delete loanDetailsModal['creditInfo']['borrowersGroup'];
    delete loanDetailsModal['loanRequestType'];

    // console.log(JSON.stringify(loanDetailsModal));
    return this.http.put<PFILoan>(
      this.resourceUrl + 'loanform/update-adhoc-by-id',
      loanDetailsModal,
      { observe: 'response' }
    );
  }

  submitClaimEditUOB(
    loanDetailsModal: UOBLoan
  ): Observable<HttpResponse<UOBLoan>> {
    delete loanDetailsModal['__v'];
    delete loanDetailsModal['createdDate'];
    delete loanDetailsModal['updatedAt'];
    delete loanDetailsModal['adverseInfo'];
    delete loanDetailsModal['creditInfo']['supportingDocs'];
    delete loanDetailsModal['creditInfo']['borrowersGroup'];
    delete loanDetailsModal['loanRequestType'];

    // console.log(JSON.stringify(loanDetailsModal));
    return this.http.put<UOBLoan>(
      this.resourceUrl + 'loanform/update-adhoc-by-id',
      loanDetailsModal,
      { observe: 'response' }
    );
  }
}
