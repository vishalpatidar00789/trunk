export class ClaimSearchCriteria {
    constructor(
            public marshRefNo?:string,
            public borrowerName?:string,
            public uenNumber?:string,
            public pfiCode?:any [],
            public consortium?:string,
            public tranche?: string,
            // public adverseStatus?:string,
            public typeOfDate?:string,
            public fromDate?:string,
            public toDate?:string,
            // public natureOfApplication?:any [],
            public marshClaimApplicationStatus?:any [],
            // public excludeExpiredApplications?:string,
            public app?:any [],
    ){ 
       this.typeOfDate=null;
    }
}
