import { Routes, Route } from '@angular/router';

import { UserRouteAccessService } from '../shared';

import {   
    ClaimComponent    
} from './';
import { ClaimSearchCriteriaComponent } from './claim-search/claim-search-criteria/claim-search-criteria.component';
import { ClaimSearchResultsComponent } from './claim-search/claim-search-results/claim-search-results.component';
import { ClaimSubmittedViewComponent } from './claim-submitted-view.component';

export const ClaimRoute: Routes = [
    {
        path: 'claim',
        component: ClaimComponent,
        canActivate: [UserRouteAccessService],
        data: {
            authorities: ['PFI_USER', 'PFI_ADMIN'],
            pageTitle: 'Claim Request'
        }
    },
    {
        path: 'claim/:loanId',
        component: ClaimComponent,
        canActivate: [UserRouteAccessService],
        data: {
            authorities: ['PFI_USER', 'PFI_ADMIN'],
            pageTitle: 'Claim Request'
        }
    },
    {
        path: 'claim/edit/:editDraftClaim',
        component: ClaimComponent,
        canActivate: [UserRouteAccessService],
        data: {
            authorities: ['PFI_USER', 'PFI_ADMIN'],
            pageTitle: 'Claim Request'
        }
    },
    {
        path: 'claim/delete/:deleteDraftClaim',
        component: ClaimComponent,
        canActivate: [UserRouteAccessService],
        data: {
            authorities: ['PFI_USER', 'PFI_ADMIN'],
            pageTitle: 'Claim Request'
        }
    },
    {
        path: 'claim-search-criteria',
        component: ClaimSearchCriteriaComponent,
        data: {
            authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN'],
            pageTitle: 'Claim Search'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'claim-search-results',
        component: ClaimSearchResultsComponent,
        data: {
            authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN'],
            pageTitle: 'Loan Search Result'
        }
    },
    {
        path: 'claim-submitted',
        component: ClaimSubmittedViewComponent,
        canActivate: [UserRouteAccessService],
        data: {
            authorities: ['PFI_USER', 'PFI_ADMIN'],
            pageTitle: 'Claim Acknowledgment'
        }
    },
];
