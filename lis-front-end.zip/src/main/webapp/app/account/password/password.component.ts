import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Principal } from '../../shared';
import { PasswordService } from './password.service';
import { NotificationService, NotificationOption } from '../../shared/alert/notification.service';

@Component({
    selector: 'jhi-password',
    templateUrl: './password.component.html'
})
export class PasswordComponent implements OnInit {
    doNotMatch: string;
    error: string;
    success: string;
    account: any;
    password: string;
    confirmPassword: string;
    private maxLength = 8;
    private minLength = 8;
    private uppercaseMinCount = 1;
    private lowercaseMinCount = 1;
    private numberMinCount = 1;
    private specialMinCount = 1;
    private UPPERCASE_RE = /([A-Z])/g;
    private LOWERCASE_RE = /([a-z])/g;
    private NUMBER_RE = /([\d])/g;
    private SPECIAL_CHAR_RE = /([\!@#$%^&*?\-])/g;
    private NON_REPEATING_CHAR_RE = /([\w\d\!@#$%^&*?\-])\1{1,}/g;

    constructor(
        private passwordService: PasswordService,
        private principal: Principal,
        private notificationService: NotificationService,
        private router: Router,
    ) {
    }

    ngOnInit() {
        this.principal.identity().then((account) => {
            this.account = account;
        });
    }

    public isStrongEnough(password) {
        var uc = password.match(this.UPPERCASE_RE);
        const lc = password.match(this.LOWERCASE_RE);
        const n = password.match(this.NUMBER_RE);
        const sc = password.match(this.SPECIAL_CHAR_RE);
        const nr = password.match(this.NON_REPEATING_CHAR_RE);
        return password.length >= this.minLength &&
            !nr &&
            uc && uc.length >= this.uppercaseMinCount &&
            lc && lc.length >= this.lowercaseMinCount &&
            n && n.length >= this.numberMinCount &&
            sc && sc.length >= this.specialMinCount;
    }

    changePassword() {
        if (this.password !== this.confirmPassword) {
            this.error = null;
            this.success = null;
            this.doNotMatch = 'ERROR';
        } else if (this.isStrongEnough(this.password)) {
            this.error = 'Password is not strong enough.';
            this.success = null;
        } else {
            this.doNotMatch = null;
            this.passwordService.save(this.password).subscribe((result) => {
                this.error = null;
                // console.log('response from server:: ' + JSON.stringify(result));
                const notificationOption = new NotificationOption();
                notificationOption.title = 'Notification';
                if (result && result['success']) {
                    notificationOption.type = 'success';
                    notificationOption.message = result['success'];
                    this.principal.setForcePasswordReset();
                    this.router.navigate(['/']);
                } else if (result && result['error']) {
                    notificationOption.type = 'error';
                    notificationOption.toastrConfig = {
                        positionClass: 'toast-bottom-right'
                    };
                    notificationOption.message = result['error'];
                }
                this.notificationService.showNotification(notificationOption);
            }, () => {
                this.success = null;
                this.error = 'ERROR';
            });
        }
    }
}
