import {
  Component,
  OnInit,
  AfterViewInit,
  ViewChild,
  ElementRef
} from '@angular/core';
import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';
import { NgxSpinnerService } from 'ngx-spinner';
import { DatePipe, TitleCasePipe } from '@angular/common';
import {
  Account,
  // LoginModalService,
  Principal,
  Bank,
  LookupService
} from '../shared';
import { LoanSearchResults } from '../loan/loan-search/loan-search-results/loan-search-results.model';
import { LoanSearchCriteriaService } from '../loan/loan-search/loan-search-criteria/loan-search-criteria.service';
import { LoanNew, LoanProcess, SponsorEForm } from '../loan';
import { LoanService } from '../loan/loan.service';
import { SponsorEFormService } from '../loan/sponsor-eform/sponsor-eform.service';
import { CreditInfo } from '../loan/mid-term/mid-term.model';
import { Router } from '@angular/router';

@Component({
  selector: 'jhi-home',
  templateUrl: './home.component.html',
  styleUrls: ['home.scss'],
  providers: [TitleCasePipe, DatePipe]
})
export class HomeComponent implements OnInit {
  isUOB: boolean;
  userid: string;
  account: Account;
  modalRef: NgbModalRef;
  isMarshUser: boolean;
  loanResultList: LoanSearchResults[];
  totalRecords: number;
  searchModel: LoanSearchModel;
  showResult: boolean;
  resultTitle: string;
  loginTimer: any;
  bank: Bank;
  tranche: any;
  loanProcess: LoanProcess;

  constructor(
    private principal: Principal,
    // private loginModalService: LoginModalService,
    private eventManager: JhiEventManager,
    private spinner: NgxSpinnerService,
    private loanSearchCriteriaService: LoanSearchCriteriaService,
    private datePipe: DatePipe,
    private titlePipe: TitleCasePipe,
    private loanService: LoanService,
    private lookupService: LookupService,
    private sponsorEFormService: SponsorEFormService,
    private router: Router
  ) {
    this.lookupService.getCurrentTranche().subscribe((tranche) => {
      if (tranche) {
        this.tranche = tranche;
      }
    });
  }

  ngOnInit() {
    this.principal.identity().then((account) => {
      if (account) {
        this.account = account;
        this.userid = this.account.login;
        if (this.account) {
          this.loadSearchComponent();
        }
      }
    });
    this.registerAuthenticationSuccess();
  }

  registerAuthenticationSuccess() {
    this.eventManager.subscribe('authenticationSuccess', (message) => {
      this.principal.identity().then((account) => {
        this.account = account;
        this.userid = this.account.login;
        this.loadSearchComponent();
        if (this.account.userType === 'EXT' && this.account.isForceResetPassword) {
          // navigate to reset password
          this.router.navigate(['password']);
        } else if (this.account.changePasswordDateTime &&
          (new Date().getTime() - new Date(this.account.changePasswordDateTime).getTime()) / (1000 * 60 * 60 * 24) > 90) {
          console.log('log time ::' + (new Date().getTime() - new Date(this.account.changePasswordDateTime).getTime()) / (1000 * 60 * 60 * 24))
          this.router.navigate(['password']);
        }
      });
    });
  }

  loadSearchComponent() {
    this.searchModel = new LoanSearchModel();
    this.showResult = false;
    this.resultTitle = '';
    this.isUOB = false;
    this.searchModel.marshLoanApplicationStatus = [];
    if (!this.account.bank) {
      this.isMarshUser = true;
      this.resultTitle = 'Displaying Processing Status Record';
      this.searchModel.marshLoanApplicationStatus[0] = 'Processing';
    } else {
      this.isMarshUser = false;
      if (this.account.bank === 'UOB') {
        this.isUOB = true;
      }
      this.resultTitle = 'Displaying Draft Status Records';
      this.searchModel.pfiCode = [];
      this.searchModel.pfiCode[0] = this.account.bank;
      this.searchModel.marshLoanApplicationStatus[0] = 'Draft';
    }
    this.showSearchResult();
  }

  isAuthenticated() {
    return this.principal.isAuthenticated();
  }

  login() {
    // this.modalRef = this.loginModalService.open();
  }

  showSearchResult() {
    let searchResult;
    this.loanResultList = [];
    this.spinner.show();

    this.loanSearchCriteriaService
      .searchLoanApplication(this.searchModel)
      .subscribe((res) => {
        searchResult = res;
        searchResult.forEach((element) => {
          let loanResult = new LoanSearchResults();
          loanResult._id = element._id;
          loanResult.marshRefNo = element.marshRefNo;
          loanResult.loanMarshRefNo = element.loanMarshRefNo;
          loanResult.baseLoanId = element.baseLoanId;
          loanResult.typeOfRequest = element.typeOfRequest;
          loanResult.status = element.status;
          loanResult.marshSubmissionDate = element.createdDate;
          loanResult.app = element.app;
          loanResult.consortium = element.consortium;

          let sponserForm = element.sponsorForm;
          if (sponserForm) {
            loanResult.borrowerRegName = sponserForm.regComName;
            loanResult.aCRArefNo = sponserForm.ACRANo;
          }

          let creditInfo = element.creditInfo;
          if (creditInfo) {
            loanResult.pfiCode = creditInfo.pfiCode;
            loanResult.pfiName = creditInfo.pfiName;
            if (creditInfo.sgdCurrency)
              loanResult.totalRequstedLimitSGD = creditInfo.sgdCurrency;
            else
              loanResult.totalRequstedLimitSGD =
                creditInfo.totalRequstedLimitSGD;
            if (creditInfo.submissionDate)
              loanResult.submissionDate = creditInfo.submissionDate;
            loanResult.primary = creditInfo.primary;
            loanResult.autoTopUp = creditInfo.autoTopUp;
            loanResult.bg = creditInfo.bg;
            loanResult.lisPlus = creditInfo.lisPlus;
            loanResult.requesterName = creditInfo.requesterName;
            loanResult.foreignCurrency = creditInfo.foreignCurrency;
            loanResult.foreignCurrencyAmount = creditInfo.foreignCurrencyAmount;
            loanResult.exchangeRate = creditInfo.exRate;
            if (creditInfo.natureOfApplication)
              loanResult.natureOfApplication = creditInfo.natureOfApplication;
            if (creditInfo.loAcceptanceDate)
              loanResult.loAcceptanceDate = creditInfo.loAcceptanceDate;
            if (creditInfo.loanExpiryDate)
              loanResult.loanExpiryDate = creditInfo.loanExpiryDate;
          }
          let adverseInfo = element.adverseInfo;
          if (adverseInfo) {
            loanResult.adverseStatus = this.titlePipe.transform(
              adverseInfo.adverseStatus
            );
            loanResult.additionalInfo = adverseInfo.additionalInfo;
            loanResult.overdueDate = adverseInfo.overdueDate;
            loanResult.listOfOverdue = adverseInfo.listOfOverdue;
            loanResult.overdue = adverseInfo.overdue;
            loanResult.repaymentPlanAttached =
              adverseInfo.repaymentPlanAttached;
          }

          this.loanResultList.push(loanResult);
        });
        this.totalRecords = this.loanResultList.length;
        this.showResult = true;
        setTimeout(() => {
          this.spinner.hide();
        }, 500);
      });
  }
  newLoanApplication() {
    this.loanService.setLoanStepProcess(Object.assign({}, new LoanProcess()));
    this.sponsorEFormService.setSponsorEForm(
      Object.assign({}, new SponsorEForm())
    );
    this.createNewLoan();
  }

  createNewLoan() {
    const loan = new LoanNew();
    this.principal.identity().then((account) => {
      if (account && account.bank) {
        this.lookupService
          .getBankByCode(account.bank)
          .subscribe((bankDetails) => {
            this.bank = new Bank();
            if (bankDetails) {
              this.bank = bankDetails;
              loan.consortium = this.bank.consortiumid;
              loan.loanRequestSeqNo = 1;
              const creditInfo = new CreditInfo();
              creditInfo.pfiName = this.bank.bankName;
              creditInfo.pfiCode = this.bank.bankCode;
              loan.creditInfo = creditInfo;
              this.loanService.createLoan(loan).subscribe((loanResult) => {
                const loanProcess = new LoanProcess();
                loanProcess.id = loanResult._id;
                loanProcess.status = loanResult.status;
                if (this.tranche) {
                  loanProcess.tranchName = this.tranche.trancheName;
                }
                this.loanProcess = Object.assign({}, loanProcess);
                this.loanService.setLoanStepProcess(this.loanProcess);
              });
            }
          });
      }
    });
  }
}

class LoanSearchModel {
  constructor(
    public pfiCode?: any[],
    public marshLoanApplicationStatus?: any[]
  ) { }
}
