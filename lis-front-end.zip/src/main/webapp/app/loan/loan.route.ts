import { Injectable } from '@angular/core';
import {
  Resolve,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Routes
} from '@angular/router';

import { UserRouteAccessService } from '../shared';
import { JhiPaginationUtil } from 'ng-jhipster';
import { PFICreditLimitComponent } from './pfi/pfi-credit-limit.component';
import { UobCreditLimitComponent } from './uob/uob-credit-limit.component';
import { LoanComponent } from './loan.component';
import { UobAdhocComponent } from './adhoc';
import { LoanSearchCriteriaComponent } from './loan-search/loan-search-criteria/loan-search-criteria.component';
import { LoanSearchResultsComponent } from './loan-search/loan-search-results/loan-search-results.component';
import { LoanAdverseInfoComponent } from './loan-adverse-info/loan-adverse-info.component';
import { SponsorEFormUploadComponent, SponsorEFormComponent } from '.';
import { LoanBaseComponent } from './sponsor-eform/sponsor-eform-base.component';
import { SponsorSubmittedViewComponent } from './sponsor-eform/sponsor.submitted-view.component';
import { UnsavedChangesGuardService } from './sponsor-eform/unsaved-changes.gaurds';

export const LoanApplicationRoute: Routes = [
  {
    path: 'loan',
    component: LoanComponent,
    data: {
      authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN'],
      loanRequestType: 'base-loan',
      pageTitle: 'Loan Application'
    },
    canActivate: [UserRouteAccessService],
    children: [
      {
        path: 'new',
        component: LoanBaseComponent,
        children: [
          {
            path: 'sponsor-eform-upload',
            component: SponsorEFormUploadComponent
          },
          {
            path: 'sponsor-eform',
            component: SponsorEFormComponent,
            // canDeactivate: [UnsavedChangesGuardService],
            children: [
              {
                path: 'pfi-user',
                component: PFICreditLimitComponent
              },
              {
                path: 'uob-user',
                component: UobCreditLimitComponent
              }
            ]
          },
          {
            path: 'submitted',
            component: SponsorSubmittedViewComponent,
            data: {              
              pageTitle: 'Loan Acknowledgment'
             }            
          }
        ]
      },
      {
        path: 'edit/:loanId',
        component: LoanBaseComponent,
        children: [
          {
            path: 'sponsor-eform-upload',
            component: SponsorEFormUploadComponent
          },
          {
            path: 'sponsor-eform',
            component: SponsorEFormComponent,
            children: [
              {
                path: 'pfi-user',
                component: PFICreditLimitComponent
              },
              {
                path: 'uob-user',
                component: UobCreditLimitComponent
              }
            ]
          },
          {
            path: 'submitted',
            component: SponsorSubmittedViewComponent
          }
        ]
      }
    ]
  },
  {
    path: 'loan-search-criteria',
    component: LoanSearchCriteriaComponent,
    data: {
      authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN'],
      pageTitle: 'Loan Search'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: 'loan-search-results',
    component: LoanSearchResultsComponent,
    data: {
      authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN'],
      pageTitle: 'Loan Search Result'
    }
  },
  {
    path: 'loan-adverse-info',
    component: LoanAdverseInfoComponent,
    data: {
      authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN'],
      pageTitle: 'Loan Adverse Info'
    }
  }
  // {
  //   path: 'loan-edit-detail',
  //   component: LoanAdverseInfoComponent,
  //   data: {
  //     authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN'],
  //     pageTitle: 'Loan Edit Detail'
  //   }
  // }
];
