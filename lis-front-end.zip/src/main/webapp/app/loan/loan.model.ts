import { PFICreditLimit } from './pfi/pfi-credit-limit.model';
import { UobCreditLimit } from './uob/uob-credit-limit.model';
import { SponsorEForm, Subsideries } from './sponsor-eform/sponsor-eform.model';

export class Loan {
  public _id: string;
  public marshRefNo: string;
  public status: string;
  public consortium: string;
  public app: number;
  public loanRequestSeqNo: number;
  public grossSGDPremiumPL: number;
  public grossSGDPremiumTUL: number;
  public grossSGDPremiumBG: number;
  public grossSGDPremiumLISPlus: number;
  public isClaimSubmitted: boolean;
  constructor() {
    this.status = 'Draft';
    this.isClaimSubmitted = false;

  }
}

export class PFILoan extends Loan {
  public sponsorForm: SponsorEForm;
  public creditInfo: PFICreditLimit;
}

export class UOBLoan extends Loan {
  public sponsorForm: SponsorEForm;
  public creditInfo: UobCreditLimit;
}

export class LoanNew extends Loan {
  public creditInfo: CreditInfo;
}

export class CreditInfo {
  public pfiName?: string;
  public pfiCode?: string;
}

export class LoanProcess {
  id: string;
  status?: string;
  tranchName?: string;
  marshRefNo: string;
  completedStep: number;
  isViewLoan: boolean;
  isSponsorUploaded: boolean;
  loanBaseId: string;
  isMidTerm: boolean;
  isMidTermIncrease: boolean;
  constructor() {
    this.status = 'Draft';
    this.tranchName = 'LIS5';
    this.completedStep = null;
    this.isViewLoan = false;
    this.isSponsorUploaded = false;
    this.isMidTerm = false;
    this.isMidTermIncrease = true;
  }
}

export enum CompletedStep {
  stepOne = 1,
  stepTwo,
  stepCompleted
}

export  class SupportingDocuments{
  documents?:any [];
  refAppId?:string;
  collection?:string
  constructor(){
  }
}