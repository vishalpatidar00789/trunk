export class ManageLOAcceptance{
    constructor(
    public marshRefNo?:string,
    public status?: string,
    public borrowerName?:string,
    public pfiName?: string,
    public staffName?:string,
    public uenNumber?: string,
    public _id?:string  
    ){          
    }
}