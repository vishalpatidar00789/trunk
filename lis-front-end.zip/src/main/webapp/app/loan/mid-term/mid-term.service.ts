import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, Subject } from 'rxjs/Rx';
import { SERVER_API_URL } from '../../app.constants';

import { createRequestOption } from '../../shared';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { CRRPremiumRate, Loan } from '..';

@Injectable()
export class MidTermService {
  private resourceUrl = SERVER_API_URL;

  constructor(private http: HttpClient) {}

  createMidTermLoan(loanData) {
    console.log(JSON.stringify(loanData));
    return <any>this.http.post(this.resourceUrl + 'mid-term', loanData); //change url
  }

  // Save As Draft Loan
  updateMidTermLoan(loan: any) {
    const id = loan._id;
    delete loan._id;
    console.log(JSON.stringify(loan));
    return <any>(
      this.http.put(SERVER_API_URL + 'mid-term/saveAsDraft/' + id, loan)
    );
  }

  // Submit Loan Application
  // submitMidTermLoan(loan: any) {
  //   const id = loan._id;
  //   delete loan._id;
  //   console.log("2"+JSON.stringify(loan));
  //   return <any>this.http.put(this.resourceUrl + 'mid-term/submit/' + id, loan);
  // }
  // Submit Loan Application
  submitMidTermLoan(loan: any) {
    const id = loan._id;
    delete loan._id;
    console.log(JSON.stringify(loan));
    return <any>(
      this.http.put(SERVER_API_URL + 'mid-term/submit/' + id, loan)
    );
  }

  getMidTermLoanById(loanId: string) {
    return <any>this.http.get(this.resourceUrl + 'mid-term/' + loanId);
  }
   // Submit Loan Application
   submitMidTermEditLoan(loanDetailsModal: any) {
    const id = loanDetailsModal._id;
    delete loanDetailsModal['_id'];
    delete loanDetailsModal['__v'];
    delete loanDetailsModal['createdDate'];
    delete loanDetailsModal['updatedAt'];
    delete loanDetailsModal['adverseInfo'];
    delete loanDetailsModal['creditInfo']['supportingDocs'];
    delete loanDetailsModal['creditInfo']['borrowersGroup'];
    delete loanDetailsModal['loanRequestType'];
    console.log(JSON.stringify(loanDetailsModal));
    return <any>(
      this.http.put(
        this.resourceUrl + 'mid-term/submit/' + id,
        loanDetailsModal
      )
    );
  }

  dlValidation(loan: any) {
    delete loan['_id'];
    return <any>this.http.post(SERVER_API_URL + 'mid-term/dlValidation', loan);
  }

  bgValidation(loan: any) {
    delete loan['_id'];
    return <any>this.http.post(SERVER_API_URL + 'mid-term/bgValidation', loan);
  }
}
