import {
  Component,
  OnInit,
  Input,
  ViewChild,
  OnChanges,
  Output,
  EventEmitter,
  AfterViewChecked,
  ChangeDetectorRef
} from '@angular/core';
import { SelectItem } from 'primeng/api';
import { NgForm } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { Currencies, LookupService } from '../../../shared';
import { PFIMidTermLoan } from '../mid-term.model';
import { LoanSearchResults } from '../../loan-search/loan-search-results/loan-search-results.model';
import { LoanSearchResultsService } from '../../loan-search/loan-search-results/loan-search-results.service';
import {
  NotificationService,
  NotificationOption
} from '../../../shared/alert/notification.service';
import { ManageSupportingDocumentsService } from '../../manage-supporting-documents/manage-supporting-documents.service';
import { MidTermService } from '../mid-term.service';
import { PFILoan } from '../..';
import { LoanService } from '../../loan.service';
import * as moment from 'moment';
import { LoanSearchCriteriaService } from '../../loan-search/loan-search-criteria/loan-search-criteria.service';
import { LoanSearchCriteria } from '../../loan-search/loan-search-criteria/loan-search-criteria.model';
import { Document } from '../../../shared/document-list/documents.model';

@Component({
  selector: 'lis-mid-term-edit-pfi',
  templateUrl: './mid-term-edit-pfi.component.html',
  styles: []
})
export class MidTermEditPfiComponent
  implements OnInit, OnChanges, AfterViewChecked {
  public LoanAppStatus: SelectItem[];
  public typeOfLimit: SelectItem[];
  public TypeOfLISPlusLimit: SelectItem[];
  public natureOfApplication: SelectItem[];
  public utilization: SelectItem[];
  public currencyListItem: SelectItem[];
  marshUser = true;
  data: any = [];
  currencyList: Currencies[];
  public submitPFI: any;
  public midTermDetailsModal: PFIMidTermLoan;
  public documentList: Document[];
  public cols: any[];
  adhocLISPlus = 0;
  adhocBgLimit = 0;
  adhocAutotopupLimit = 0;
  midTermLISPlus = 0;
  midTermBgLimit = 0;
  midTermAutotopupLimit = 0;
  adhocLISPlusCurrency = 0;
  adhocBgLimitCurrency = 0;
  adhocAutotopupLimitCurrency = 0;
  midTermLISPlusCurrency = 0;
  midTermBgLimitCurrency = 0;
  midTermAutotopupLimitCurrency = 0;
  baseLoan: PFILoan;

  @Input()
  loanResult: LoanSearchResults;
  // @Input() marshRefNo: string;
  @Input()
  selectedLoanResult: LoanSearchResults;
  @Input()
  userid: string;
  @Input()
  isMarshUser: boolean;
  @Output()
  closePopUp = new EventEmitter<boolean>();
  @Output()
  openPopUp = new EventEmitter<boolean>();

  @ViewChild('midTermDetailsForm')
  midTermDetailsForm: NgForm;
  type: string;
  midTermApprovedPrimaryLimit = 0;

  constructor(
    private lookup: LookupService,
    private loanSearchService: LoanSearchCriteriaService,
    private notificationService: NotificationService,
    private supportingDocservice: ManageSupportingDocumentsService,
    private datePipe: DatePipe,
    private midTermService: MidTermService,
    private loanService: LoanService,
    private cdr: ChangeDetectorRef
  ) {}

  ngAfterViewChecked() {
    if (!this.isMarshUser) {
      this.midTermDetailsForm.form.disable();
      this.cdr.detectChanges();
    }
  }

  ngOnChanges() {}

  ngOnInit() {
    this.getLoanEditDetails();
    this.getSubmittedDocList();
    this.getAllLoanTypes();
    this.lookup.getCurrencyList().subscribe(data => {
      this.currencyList = data;
    });

    this.LoanAppStatus = [
      { label: 'Processing', value: 'Processing' },
      { label: 'Answered', value: 'Answered' },
      { label: 'Duplicate', value: 'Duplicate' }
    ];

    this.typeOfLimit = [
      { label: 'DL', value: 'DL' },
      { label: 'CL', value: 'CL' },
      { label: 'DL & BG', value: 'DL & BG' },
      { label: 'CL & BG', value: 'CL & BG' }
    ];

    this.TypeOfLISPlusLimit = [
      { label: 'Stand-alone LIS +', value: 'Stand-alone LIS +' },
      {
        label: 'Joint-Insured with LIS 5 & LIS +',
        value: 'Joint-Insured with LIS 5 & LIS +'
      }
    ];

    this.natureOfApplication = [
      { label: 'NEW', value: 'NEW' },
      { label: 'CANCEL UTILISED', value: 'CANCEL UTILISED' },
      { label: 'CANCEL UN-UTILISED', value: 'CANCEL UN-UTILISED' },
      { label: 'DECREASE UN-UTILISED', value: 'DECREASE UN-UTILISED' },
      { label: 'RENEWAL', value: 'RENEWAL' },
      {
        label: 'MID-TERM INCR - UN-UTILISED',
        value: 'MID-TERM INCR - UN-UTILISED'
      },
      { label: 'DECREASE UTILISED', value: 'DECREASE UTILISED' },
      { label: 'MID-TERM INCR - UTILISED', value: 'MID-TERM INCR - UTILISED' },
      { label: 'Temporary Increase', value: 'Temporary Increase' }
    ];

    this.utilization = [
      { label: 'Utilised', value: 'Utilised' },
      { label: 'Un-Utilised', value: 'Un-Utilised' },
      { label: 'Nil Decisions', value: 'Nil Decisions' },
      { label: 'Cancel Un-Utilised', value: 'Cancel Un-Utilised' }
    ];

    this.currencyListItem = [
      { label: 'AUD', value: 'AUD' },
      { label: 'CNY', value: 'CNY' },
      { label: 'EUR', value: 'EUR' },
      { label: 'HKD', value: 'HKD' },
      { label: 'IDR', value: 'IDR' },
      { label: 'INR', value: 'INR' },
      { label: 'JPY', value: 'JPY' },
      { label: 'KRW', value: 'KRW' },
      { label: 'MYR', value: 'MYR' },
      { label: 'NOK', value: 'NOK' },
      { label: 'PHP', value: 'PHP' },
      { label: 'THB', value: 'THB' },
      { label: 'TWD', value: 'TWD' },
      { label: 'USD', value: 'USD' }
    ];

    this.cols = [
      { field: 'documentType', header: 'Document Type' },
      { field: 'filename', header: 'Uploaded Document Name' },
      { field: 'uploadDate', header: 'Date Of Upload' },
      { field: 'uploadedBy', header: 'Uploaded By' }
    ];
  }

  async getLoanEditDetails() {
    return this.midTermService
      .getMidTermLoanById(this.selectedLoanResult._id)
      .subscribe(response => {
        // console.log('loanDetails', JSON.stringify(response));
        this.midTermDetailsModal = new PFIMidTermLoan();
        this.midTermDetailsModal = response;
        if (this.midTermDetailsModal) {
          if (this.midTermDetailsModal.isMidTermIncrease) {
            this.type = 'Incremental';
          } else {
            this.type = 'Decremental';
          }
          this.setDateFormat();
          this.baseLoan = new PFILoan();
          if (this.midTermDetailsModal.loanBaseId) {
            this.loanService
              .getLoanById(this.midTermDetailsModal.loanBaseId)
              .subscribe((loanbaseResult: any) => {
                if (loanbaseResult) {
                  this.baseLoan = loanbaseResult;
                  if (this.baseLoan) {
                    this.autoPopulateBaseLoan();
                  }
                }
                // this.purposeOfLoan();
                if (this.midTermDetailsModal.isMidTermIncrease) {
                  this.calculateLoanAmtInc();
                  this.calculateLoanAmtforeignCurrencyInc();
                } else {
                  this.calculateLoanAmtDec();
                  this.calculateLoanAmtforeignCurrencyDec();
                }
                this.openPopUp.emit(true);
              });
          }
        }
      });
  }

  autoPopulateBaseLoan() {
    this.midTermDetailsModal.creditInfo.typeOfLimit = this.baseLoan.creditInfo.typeOfLimit;
    this.midTermDetailsModal.sponsorForm.loanDomesticTrade1 = this.baseLoan.sponsorForm.loanDomesticTrade1;
    this.midTermDetailsModal.sponsorForm.loanDomesticTrade2 = this.baseLoan.sponsorForm.loanDomesticTrade2;
    this.midTermDetailsModal.sponsorForm.purposeOfLoan = this.baseLoan.sponsorForm.purposeOfLoan;
    const limit = this.GetLimitValue();
    this.midTermDetailsModal.creditInfo.totalRequstedLimitSGD = limit;

    if (this.baseLoan.creditInfo.loAcceptanceDate) {
      let expDate = this.baseLoan.creditInfo.loAcceptanceDate;
      expDate = new Date(expDate.setMonth(expDate.getMonth() + 12));
      expDate = new Date(expDate.setDate(expDate.getDate() - 1));
      this.midTermDetailsModal.creditInfo.loanExpiryDate = expDate;
    }
    this.midTermDetailsModal.creditInfo.LIS5TurnaroundDays = moment(
      this.baseLoan.creditInfo.insurersApprovalDate
    ).diff(this.midTermDetailsModal.creditInfo.submissionDate, 'days');
    this.midTermDetailsModal.creditInfo.turnaroundWithLISPLUSDays = moment(
      this.midTermDetailsModal.creditInfo.LISPlusApprovedDate
    ).diff(this.midTermDetailsModal.creditInfo.insurersApprovalDate, 'days');
  }

  getAllLoanTypes() {
    const searchCriteria = new LoanSearchCriteria();
    searchCriteria.uenNumber = this.selectedLoanResult.aCRArefNo;
    this.loanSearchService
      .searchLoanApplication(searchCriteria)
      .subscribe(data => {
        data.forEach(element => {
          if (data.typeOfRequest === 'adhoc') {
            if (element.creditInfo.totalApprovedLISPlusLimitInForce) {
              this.adhocLISPlus +=
                element.creditInfo.totalApprovedLISPlusLimitInForce;
            }
            if (
              element.creditInfo.totalApprovedLISPlusLimitInForceForeignCurrency
            ) {
              this.adhocLISPlusCurrency +=
                element.creditInfo.totalApprovedLISPlusLimitInForceForeignCurrency;
            }
            if (element.creditInfo.totalApprovedBGlimitInForce) {
              this.adhocBgLimit +=
                element.creditInfo.totalApprovedBGlimitInForce;
            }
            if (element.creditInfo.totalApprovedBGlimitInForceForeignCurrency) {
              this.adhocBgLimitCurrency +=
                element.creditInfo.totalApprovedBGlimitInForceForeignCurrency;
            }
            if (element.creditInfo.totalApprovedAutoTopUpLimitInForce) {
              this.adhocAutotopupLimit +=
                element.creditInfo.totalApprovedAutoTopUpLimitInForce;
            }
            if (
              element.creditInfo
                .totalApprovedAutoTopUpLimitInForceForeignCurrency
            ) {
              this.adhocAutotopupLimitCurrency +=
                element.creditInfo.totalApprovedAutoTopUpLimitInForceForeignCurrency;
            }
          } else if (element.status === 'answered') {
            this.addAllMidtermValues(element);
          }
        });
        if (this.adhocLISPlus) {
        }
      });
  }

  addAllMidtermValues(element: any) {
    if (element.creditInfo.totalApprovedLISPlusLimitInForce) {
      if (element.isMidTermIncrease) {
        this.midTermLISPlus +=
          element.creditInfo.totalApprovedLISPlusLimitInForce;
      } else {
        this.midTermLISPlus -=
          element.creditInfo.totalApprovedLISPlusLimitInForce;
      }
    }
    if (element.creditInfo.totalApprovedLISPlusLimitInForceForeignCurrency) {
      if (element.isMidTermIncrease) {
        this.midTermLISPlusCurrency +=
          element.creditInfo.totalApprovedLISPlusLimitInForceForeignCurrency;
      } else {
        this.midTermLISPlusCurrency -=
          element.creditInfo.totalApprovedLISPlusLimitInForceForeignCurrency;
      }
    }
    if (element.creditInfo.totalApprovedBGlimitInForce) {
      if (element.isMidTermIncrease) {
        this.midTermBgLimitCurrency +=
          element.creditInfo.totalApprovedBGlimitInForceForeignCurrency;
      } else {
        this.midTermBgLimitCurrency -=
          element.creditInfo.totalApprovedBGlimitInForceForeignCurrency;
      }
    }
    if (element.creditInfo.totalApprovedBGlimitInForceForeignCurrency) {
      if (element.creditInfo.totalApprovedBGlimitInForceForeignCurrency) {
        this.midTermBgLimit +=
          element.creditInfo.totalApprovedBGlimitInForceForeignCurrency;
      } else {
        this.midTermBgLimit -=
          element.creditInfo.totalApprovedBGlimitInForceForeignCurrency;
      }
    }
    if (element.creditInfo.totalApprovedAutoTopUpLimitInForce) {
      if (element.isMidTermIncrease) {
        this.midTermAutotopupLimit +=
          element.creditInfo.totalApprovedAutoTopUpLimitInForce;
      } else {
        this.midTermAutotopupLimit -=
          element.creditInfo.totalApprovedAutoTopUpLimitInForce;
      }
    }

    if (element.creditInfo.totalApprovedAutoTopUpLimitInForceForeignCurrency) {
      if (element.isMidTermIncrease) {
        this.midTermAutotopupLimit +=
          element.creditInfo.totalApprovedAutoTopUpLimitInForceForeignCurrency;
      } else {
        this.midTermAutotopupLimit -=
          element.creditInfo.totalApprovedAutoTopUpLimitInForceForeignCurrency;
      }
    }

    if (element.creditInfo.totalApprovedLimitInForce) {
      if (element.isMidTermIncrease) {
        this.midTermApprovedPrimaryLimit +=
          element.creditInfo.totalApprovedLimitInForce;
      } else {
        {
          this.midTermApprovedPrimaryLimit -=
            element.creditInfo.totalApprovedLimitInForce;
        }
      }
    }
  }

  save() {
    if (this.midTermDetailsModal) {
      this.midTermService
        .submitMidTermEditLoan(this.midTermDetailsModal)
        .subscribe(res => {
          const notificationOption = new NotificationOption();
          notificationOption.toastrConfig = {
            positionClass: 'toast-top-right'
          };
          notificationOption.title = 'Notification';
          this.notificationService.showNotification(notificationOption);
        });
    }
  }

  cancel() {
    this.closePopUp.emit(true);
  }

  onLoanTabChange(event) {
    console.log(event);
  }

  confirmChange(val) {
    console.log(val);
  }

  onChangeCurrency(event) {
    if (this.midTermDetailsModal.creditInfo['foreignCurrency'] === '-1') {
      this.midTermDetailsModal.creditInfo['foreignCurrencyAmount'] = null;
      this.midTermDetailsModal.creditInfo['exRate'] = null;
    }
  }

  onlyNumberKey(event) {
    return event.charCode === 8 || event.charCode === 0 || event.charCode === 46
      ? null
      : event.charCode >= 48 && event.charCode <= 57;
  }

  purposeOfLoanCalculate(event) {
    if (this.midTermDetailsModal.sponsorForm !== undefined) {
      let total_domesticval: number;
      const total_value = 100;

      if (
        isNaN(this.midTermDetailsModal.sponsorForm.loanDomesticTrade1) ||
        isNaN(this.midTermDetailsModal.sponsorForm.loanDomesticTrade2)
      ) {
        console.log('This is not a number');
      } else {
        if (
          event.target.name === 'loanDomesticTrade1' &&
          event.target.value <= 100
        ) {
          total_domesticval = total_value - event.target.value;
          this.midTermDetailsModal.sponsorForm.loanDomesticTrade2 = total_domesticval;
        } else if (
          event.target.name === 'loanDomesticTrade2' &&
          event.target.value <= 100
        ) {
          total_domesticval = total_value - event.target.value;
          this.midTermDetailsModal.sponsorForm.loanDomesticTrade1 = total_domesticval;
        } else if (
          event.target.name === 'loanDomesticTrade1' &&
          event.target.value > 100
        ) {
          this.midTermDetailsModal.sponsorForm.loanDomesticTrade1 = 100;
          this.midTermDetailsModal.sponsorForm.loanDomesticTrade2 = 0;
        } else if (
          event.target.name === 'loanDomesticTrade2' &&
          event.target.value > 100
        ) {
          this.midTermDetailsModal.sponsorForm.loanDomesticTrade2 = 100;
          this.midTermDetailsModal.sponsorForm.loanDomesticTrade1 = 0;
        }

        this.purposeOfLoan();
      }
    }
  }

  purposeOfLoan() {
    if (this.midTermDetailsModal.sponsorForm !== undefined) {
      let domesticval: number;
      let exportVal: number;
      let purposeOfLoan: string;
      domesticval = this.midTermDetailsModal.sponsorForm.loanDomesticTrade1;
      exportVal = this.midTermDetailsModal.sponsorForm.loanDomesticTrade2;

      if (domesticval === 100) {
        purposeOfLoan = 'Domestic';
      } else if (exportVal === 100) {
        purposeOfLoan = 'Export';
      } else if (domesticval > 0 && exportVal > 0) {
        purposeOfLoan = 'Domestic and Export';
      }
      this.midTermDetailsModal.sponsorForm.purposeOfLoan = purposeOfLoan;
    }
  }

  setDateFormat() {
    if (this.midTermDetailsModal.creditInfo.submissionDate) {
      this.midTermDetailsModal.creditInfo.submissionDate = new Date(
        this.midTermDetailsModal.creditInfo.submissionDate
      );
    }
    if (this.midTermDetailsModal.creditInfo.insurersApprovalDate) {
      this.midTermDetailsModal.creditInfo.insurersApprovalDate = new Date(
        this.midTermDetailsModal.creditInfo.insurersApprovalDate
      );
    }
    if (this.midTermDetailsModal.creditInfo.loAcceptanceDate) {
      this.midTermDetailsModal.creditInfo.loAcceptanceDate = new Date(
        this.midTermDetailsModal.creditInfo.loAcceptanceDate
      );
    }
    if (this.midTermDetailsModal.creditInfo.loanExpiryDate) {
      this.midTermDetailsModal.creditInfo.loanExpiryDate = new Date(
        this.midTermDetailsModal.creditInfo.loanExpiryDate
      );
    }
    if (this.midTermDetailsModal.creditInfo.dateSentForLISPlus) {
      this.midTermDetailsModal.creditInfo.dateSentForLISPlus = new Date(
        this.midTermDetailsModal.creditInfo.dateSentForLISPlus
      );
    }
    if (this.midTermDetailsModal.creditInfo.lISPlusApprovedDate) {
      this.midTermDetailsModal.creditInfo.lISPlusApprovedDate = new Date(
        this.midTermDetailsModal.creditInfo.lISPlusApprovedDate
      );
    }
  }

  convertToNumber(val) {
    return Number(val.replace(/[^0-9\.]+/g, ''));
  }

  calculateLoanAmt() {
    if (this.midTermDetailsModal.isMidTermIncrease) {
      this.calculateLoanAmtInc();
    } else {
      this.calculateLoanAmtDec();
    }
  }

  calculateLoanAmtforeignCurrency() {
    if (this.midTermDetailsModal.isMidTermIncrease) {
      this.calculateLoanAmtforeignCurrencyInc();
    } else {
      this.calculateLoanAmtforeignCurrencyDec();
    }
  }

  // for mid term request type increase
  calculateLoanAmtInc() {
    // debugger;
    let approvedPrimaryLimit: number;
    let topUpLimit: number;
    let bgLimit: number;
    let lISPlus: number;
    const midTerm = this.baseLoan.creditInfo.primary || 0; // Mid-term application not yet completed, so meanwhile it is set as 0 value.
    let totalApprovedLimit: number;
    let totalRequstedLimitSGD: number;
    let totalApprovedLimitincludingLISPLUS: number;
    let lis5approvalratio: number;
    let increasedLimit = 0;

    approvedPrimaryLimit =
      this.midTermDetailsModal.creditInfo.approvedPrimaryLayer || 0;
    topUpLimit =
      this.midTermDetailsModal.creditInfo.approvedAutoTopUpLayer || 0;
    bgLimit = this.midTermDetailsModal.creditInfo.approvedBgLayer || 0;
    lISPlus = this.midTermDetailsModal.creditInfo.approvedSGDLimitLISPlus || 0;

    // get LIS5 Total Approvaed Limit [primary + top-up + bg]
    totalApprovedLimit = approvedPrimaryLimit + topUpLimit + bgLimit;
    this.midTermDetailsModal.creditInfo.lis5TotalApprovedLimit = totalApprovedLimit;

    // get LIS5 Total Approvaed Limit includeing LIS Plus [primary + top-up + bg + LIS Plus]
    totalApprovedLimitincludingLISPLUS = totalApprovedLimit + lISPlus;
    this.midTermDetailsModal.creditInfo.totalApprovedLimitincludingLISPLUS = totalApprovedLimitincludingLISPLUS;

    // Total Applied  Limit for LIS 5
    totalRequstedLimitSGD =
      this.midTermDetailsModal.creditInfo.totalRequstedLimitSGD || 0;
    // LIS 5 Approval Ratio (%)
    lis5approvalratio =
      this.midTermDetailsModal.creditInfo.LIS5ApprovalRatio || 0;
    this.midTermDetailsModal.creditInfo.totalApprovedPrimaryLimitInForce =
      this.midTermApprovedPrimaryLimit +
      this.midTermDetailsModal.creditInfo.afterMidTempIncreaseTxt;
    // auto top up in force
    this.midTermDetailsModal.creditInfo.totalApprovedAutoTopUpLimitInForce =
      (this.baseLoan.creditInfo.approvedAutoTopUpLayer || 0) +
      this.adhocAutotopupLimit;
    // bg in force
    this.midTermDetailsModal.creditInfo.totalApprovedBGlimitInForce =
      (this.baseLoan.creditInfo.approvedBgLayer || 0) + this.adhocBgLimit;
    // lis plus in force
    this.midTermDetailsModal.creditInfo.totalApprovedLISPlusLimitInForce =
      this.baseLoan.creditInfo.totalApprovedLimitincludingLISPLUS +
      this.adhocLISPlus;
    this.midTermDetailsModal.creditInfo.totalApprovedLimitInForce =
      approvedPrimaryLimit + topUpLimit + bgLimit + lISPlus + midTerm;

    if (totalRequstedLimitSGD) {
      lis5approvalratio =
        Math.round(totalApprovedLimit) / totalRequstedLimitSGD;
      if (lis5approvalratio) {
        this.midTermDetailsModal.creditInfo.LIS5ApprovalRatio = Number(
          lis5approvalratio.toFixed(2)
        );
      }
    }
    if (this.midTermDetailsModal.creditInfo.approvedPrimaryLayer) {
      const approvalRatioLISPLUS: number =
        totalApprovedLimitincludingLISPLUS / totalRequstedLimitSGD;
      if (approvalRatioLISPLUS) {
        this.midTermDetailsModal.creditInfo.approvalRatioWithLISPLUS = Number(
          approvalRatioLISPLUS.toFixed(2)
        );
      }
    }
  }

  GetLimitValue() {
    let increasedLimit = 0;

    switch (this.midTermDetailsModal.creditInfo.requestLimit) {
      case 'afterMidTempDecrease':
        increasedLimit =
          this.midTermDetailsModal.creditInfo.afterMidTempDecreaseTxt || 0;
        break;
      case 'afterTempIncrease':
        increasedLimit =
          this.midTermDetailsModal.creditInfo.afterTempIncreaseTxt || 0;
        break;
      case 'beforeMidTempIncrease':
        increasedLimit =
          this.midTermDetailsModal.creditInfo.beforeMidTempIncreaseTxt || 0;
        break;
      case 'afterMidTempDecrease':
        increasedLimit =
          -this.midTermDetailsModal.creditInfo.afterMidTempDecreaseTxt || 0;
        break;
      case 'beforeMidTempDecrease':
        increasedLimit =
          -this.midTermDetailsModal.creditInfo.beforeMidTempDecreaseTxt || 0;
        break;
      default:
        break;
    }

    return increasedLimit;
  }

  // for mid term request type decrease
  calculateLoanAmtDec() {
    // debugger;
    let approvedPrimaryLimit: number;
    let topUpLimit: number;
    let bgLimit: number;
    let lISPlus: number;
    const midTerm = this.baseLoan.creditInfo.primary || 0; // Mid-term application not yet completed, so meanwhile it is set as 0 value.
    let totalApprovedLimit: number;
    let totalRequstedLimitSGD: number;
    let totalApprovedLimitincludingLISPLUS: number;
    let lis5approvalratio: number;

    approvedPrimaryLimit =
      -this.midTermDetailsModal.creditInfo.approvedPrimaryLayer || 0;
    topUpLimit =
      -this.midTermDetailsModal.creditInfo.approvedAutoTopUpLayer || 0;
    bgLimit = -this.midTermDetailsModal.creditInfo.approvedBgLayer || 0;
    lISPlus = -this.midTermDetailsModal.creditInfo.approvedSGDLimitLISPlus || 0;

    // get LIS5 Total Approvaed Limit [primary + top-up + bg]
    totalApprovedLimit = approvedPrimaryLimit + topUpLimit + bgLimit;
    this.midTermDetailsModal.creditInfo.lis5TotalApprovedLimit = totalApprovedLimit;

    // get LIS5 Total Approvaed Limit includeing LIS Plus [primary + top-up + bg + LIS Plus]
    totalApprovedLimitincludingLISPLUS = totalApprovedLimit + lISPlus;
    this.midTermDetailsModal.creditInfo.totalApprovedLimitincludingLISPLUS = totalApprovedLimitincludingLISPLUS;

    // Total Applied  Limit for LIS 5
    totalRequstedLimitSGD =
      this.midTermDetailsModal.creditInfo.totalRequstedLimitSGD || 0;
    // LIS 5 Approval Ratio (%)
    lis5approvalratio =
      this.midTermDetailsModal.creditInfo.LIS5ApprovalRatio || 0;
    this.midTermDetailsModal.creditInfo.totalApprovedPrimaryLimitInForce =
      midTerm + this.midTermDetailsModal.creditInfo.afterMidTempIncreaseTxt;
    // auto top up in force
    this.midTermDetailsModal.creditInfo.totalApprovedAutoTopUpLimitInForce =
      this.baseLoan.creditInfo.autoTopUp + this.adhocAutotopupLimit;
    // bg in force
    this.midTermDetailsModal.creditInfo.totalApprovedBGlimitInForce =
      this.baseLoan.creditInfo.bg + this.adhocBgLimit;
    // lis plus in force
    this.midTermDetailsModal.creditInfo.totalApprovedLISPlusLimitInForce =
      this.baseLoan.creditInfo.totalApprovedLimitincludingLISPLUS +
      this.adhocLISPlus;
    this.midTermDetailsModal.creditInfo.totalApprovedLimitInForce =
      approvedPrimaryLimit + topUpLimit + bgLimit + lISPlus + midTerm;

    if (totalRequstedLimitSGD) {
      lis5approvalratio =
        Math.round(totalApprovedLimit) / totalRequstedLimitSGD;
      if (lis5approvalratio) {
        this.midTermDetailsModal.creditInfo.LIS5ApprovalRatio = Number(
          lis5approvalratio.toFixed(2)
        );
      }
    }
    if (this.midTermDetailsModal.creditInfo.approvedPrimaryLayer) {
      const approvalRatioLISPLUS: number =
        totalApprovedLimitincludingLISPLUS / totalRequstedLimitSGD;
      if (approvalRatioLISPLUS) {
        this.midTermDetailsModal.creditInfo.approvalRatioWithLISPLUS = Number(
          approvalRatioLISPLUS.toFixed(2)
        );
      }
    }
  }

  // for mid term request type increase
  calculateLoanAmtforeignCurrencyInc() {
    // debugger;
    let approvedPrimaryLimit: number;
    let topUpLimit: number;
    let bgLimit: number;
    let lISPlus: number;

    const midTerm =
      this.baseLoan.creditInfo.approvedPrimaryLayerForeignCurrency || 0; // Mid-term application not yet completed, so meanwhile it is set as 0 value.
    let totalApprovedLimit: number;
    let totalRequstedLimitSGD: number;
    let totalApprovedLimitincludingLISPLUS: number;
    let lis5approvalratio: number;

    approvedPrimaryLimit =
      this.midTermDetailsModal.creditInfo.approvedPrimaryLayerForeignCurrency ||
      0;
    topUpLimit =
      this.midTermDetailsModal.creditInfo
        .approvedAutoTopUpLayerForeignCurrency || 0;
    bgLimit =
      this.midTermDetailsModal.creditInfo.approvedBgLayerForeignCurrency || 0;
    lISPlus =
      this.midTermDetailsModal.creditInfo
        .approvedSGDLimitLISPlusForeignCurrency || 0;

    // get LIS5 Total Approvaed Limit [primary + top-up + bg]
    totalApprovedLimit = approvedPrimaryLimit + topUpLimit + bgLimit;
    this.midTermDetailsModal.creditInfo.lis5TotalApprovedLimitForeignCurrency = totalApprovedLimit;

    // get LIS5 Total Approvaed Limit includeing LIS Plus [primary + top-up + bg + LIS Plus]
    totalApprovedLimitincludingLISPLUS = totalApprovedLimit + lISPlus;
    this.midTermDetailsModal.creditInfo.totalApprovedLimitincludingLISPLUSForeignCurrency = totalApprovedLimitincludingLISPLUS;

    // Total Applied Limit for LIS 5 of Foreign Currency Amount
    totalRequstedLimitSGD =
      this.midTermDetailsModal.creditInfo.foreignCurrencyAmount || 0;
    // Approval Ratio With LIS PLUS (%)
    lis5approvalratio =
      this.midTermDetailsModal.creditInfo.approvalRatioWithLISPLUS || 0;

    this.midTermDetailsModal.creditInfo.totalApprovedPrimaryLimitInForceForeignCurrency =
      approvedPrimaryLimit + midTerm;
    this.midTermDetailsModal.creditInfo.totalApprovedAutoTopUpLimitInForceForeignCurrency =
      topUpLimit + midTerm;
    this.midTermDetailsModal.creditInfo.totalApprovedBGlimitInForceForeignCurrency =
      bgLimit + midTerm;
    this.midTermDetailsModal.creditInfo.totalApprovedLISPlusLimitInForceForeignCurrency =
      lISPlus + midTerm;
    this.midTermDetailsModal.creditInfo.totalApprovedLimitInForceForeignCurrency =
      totalApprovedLimitincludingLISPLUS + midTerm;
  }

  // for mid term request type decrease
  calculateLoanAmtforeignCurrencyDec() {
    // debugger;
    let approvedPrimaryLimit: number;
    let topUpLimit: number;
    let bgLimit: number;
    let lISPlus: number;

    const midTerm =
      this.baseLoan.creditInfo.approvedPrimaryLayerForeignCurrency || 0; // Mid-term application not yet completed, so meanwhile it is set as 0 value.
    let totalApprovedLimit: number;
    let totalRequstedLimitSGD: number;
    let totalApprovedLimitincludingLISPLUS: number;
    let lis5approvalratio: number;

    approvedPrimaryLimit =
      this.midTermDetailsModal.creditInfo.approvedPrimaryLayerForeignCurrency ||
      0;
    topUpLimit =
      this.midTermDetailsModal.creditInfo
        .approvedAutoTopUpLayerForeignCurrency || 0;
    bgLimit =
      this.midTermDetailsModal.creditInfo.approvedBgLayerForeignCurrency || 0;
    lISPlus =
      this.midTermDetailsModal.creditInfo
        .approvedSGDLimitLISPlusForeignCurrency || 0;

    // get LIS5 Total Approvaed Limit [primary + top-up + bg]
    totalApprovedLimit = approvedPrimaryLimit + topUpLimit + bgLimit;
    this.midTermDetailsModal.creditInfo.lis5TotalApprovedLimitForeignCurrency = totalApprovedLimit;

    // get LIS5 Total Approvaed Limit includeing LIS Plus [primary + top-up + bg + LIS Plus]
    totalApprovedLimitincludingLISPLUS = totalApprovedLimit + lISPlus;
    this.midTermDetailsModal.creditInfo.totalApprovedLimitincludingLISPLUSForeignCurrency = totalApprovedLimitincludingLISPLUS;

    // Total Applied Limit for LIS 5 of Foreign Currency Amount
    totalRequstedLimitSGD =
      this.midTermDetailsModal.creditInfo.foreignCurrencyAmount || 0;
    // Approval Ratio With LIS PLUS (%)
    lis5approvalratio =
      this.midTermDetailsModal.creditInfo.approvalRatioWithLISPLUS || 0;

    this.midTermDetailsModal.creditInfo.totalApprovedPrimaryLimitInForceForeignCurrency =
      approvedPrimaryLimit + midTerm;
    this.midTermDetailsModal.creditInfo.totalApprovedAutoTopUpLimitInForceForeignCurrency =
      topUpLimit + this.adhocAutotopupLimitCurrency;
    this.midTermDetailsModal.creditInfo.totalApprovedBGlimitInForceForeignCurrency =
      bgLimit + this.adhocBgLimitCurrency;
    this.midTermDetailsModal.creditInfo.totalApprovedLISPlusLimitInForceForeignCurrency =
      lISPlus + midTerm;
    this.midTermDetailsModal.creditInfo.totalApprovedLISPlusLimitInForceForeignCurrency =
      totalApprovedLimitincludingLISPLUS + this.adhocLISPlusCurrency;
  }

  getSubmittedDocList() {
    /** Get View document list */

    this.supportingDocservice
      .getDocumentsByAppRefId(this.selectedLoanResult._id)
      .subscribe(files => {
        if (files) {
          this.documentList = [];
          let file: Document;
          files.forEach(element => {
            if (element) {
              file = new Document();
              file._id = element._id;
              file.filename = element.metadata.fileName;
              file.uploadDate = this.datePipe.transform(
                element.uploadDate,
                'dd-MMM-yyy,h:mm:ss a'
              );
              file.documentType = element.metadata.documentType;
              file.uploadedBy = element.metadata.uploadedBy;
              this.documentList.push(file);
            }
          });

          this.sort();
        }
      });
  }

  sort() {
    this.documentList.sort(function(b, a) {
      return (
        new Date(a.uploadDate).getTime() - new Date(b.uploadDate).getTime()
      );
    });
  }

  loAcceptanceDate() {
    let loAcceptanceDate: Date;
    let loanExpiryDate: Date;
    loAcceptanceDate = new Date(
      this.midTermDetailsModal.creditInfo.loAcceptanceDate
    );

    loanExpiryDate = new Date(
      loAcceptanceDate.setMonth(loAcceptanceDate.getMonth() + 12)
    );
    this.midTermDetailsModal.creditInfo.loanExpiryDate = loanExpiryDate;
  }

  changeRequestLimit() {
    this.clearRequestTypeText();
  }

  clearRequestTypeText() {
    this.midTermDetailsModal.creditInfo.afterTempIncreaseTxt = null;
    this.midTermDetailsModal.creditInfo.afterMidTempIncreaseTxt = null;
    this.midTermDetailsModal.creditInfo.beforeMidTempIncreaseTxt = null;
    this.midTermDetailsModal.creditInfo.afterMidTempDecreaseTxt = null;
    this.midTermDetailsModal.creditInfo.beforeMidTempDecreaseTxt = null;
  }

  onLoAccepDateChange(value: Date) {
    let loanExpiryDate: Date;
    if (value) {
      const loAcceptanceDate = new Date(value);
      loanExpiryDate = new Date(
        loAcceptanceDate.setMonth(loAcceptanceDate.getMonth() + 12)
      );
      loanExpiryDate = new Date(
        loanExpiryDate.setDate(loanExpiryDate.getDate() - 1)
      );
      this.midTermDetailsModal.creditInfo.loanExpiryDate = loanExpiryDate;
    }
  }
}
