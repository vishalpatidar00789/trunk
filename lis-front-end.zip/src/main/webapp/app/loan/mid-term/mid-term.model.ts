import { Loan } from '../loan.model';
import { SponsorEForm } from '../sponsor-eform/sponsor-eform.model';
import { UobCreditLimit } from '../uob/uob-credit-limit.model';
import { PFICreditLimit } from '../pfi/pfi-credit-limit.model';

export class MidTermLoan extends Loan {
  public loanBaseId: string;
  public isMidTermIncrease: boolean;
  constructor() {
    super();
    this.isMidTermIncrease = true;
  }
}

export class PFIMidTermLoan extends MidTermLoan {
  public sponsorForm: SponsorEForm;
  public creditInfo: PFIMidTermCreditLimit;
}

export class UOBMidTermLoan extends MidTermLoan {
  public sponsorForm: SponsorEForm;
  public creditInfo: UOBMidTermCreditLimit;
}

export class MidTermLoanNew extends MidTermLoan {
  public creditInfo: CreditInfo;
}

export class CreditInfo {
  public pfiName?: string;
  public pfiCode?: string;
}

export class PFIMidTermCreditLimit extends PFICreditLimit {
  public requestLimit?: string;
  public afterTempIncreaseTxt?: number;
  public afterMidTempIncreaseTxt?: number;
  public beforeMidTempIncreaseTxt?: number;
  public afterMidTempDecreaseTxt?: number;
  public beforeMidTempDecreaseTxt?: number;
  public proRateRatio?: number;
}

export class UOBMidTermCreditLimit extends UobCreditLimit {
    public requestLimitValue?: number;
    public requestLimitForeignValue?: number;
    public proRateRatio?: number;
}
