import { Injectable } from '@angular/core';
import { Routes } from '@angular/router';
import { LoanComponent } from '../loan.component';
import { UserRouteAccessService } from '../../shared';
import { LoanBaseComponent, SponsorEFormUploadComponent, SponsorEFormComponent, PFICreditLimitComponent, SponsorSubmittedViewComponent, UobCreditLimitComponent } from '..';

export const MidTermRoute: Routes = [
  {
    path: 'mid-term',
    component: LoanComponent,
    data: {
      authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN'],
      loanRequestType: 'mid-term',
      pageTitle: 'Mid-Term Application'
    },
    canActivate: [UserRouteAccessService],
    children: [
      {
        path: 'new/:loanBaseId',
        component: LoanBaseComponent,
        children: [
          {
            path: 'sponsor-eform-upload',
            component: SponsorEFormUploadComponent
          },
          {
            path: 'sponsor-eform',
            component: SponsorEFormComponent,
            children: [
              {
                path: 'pfi-user',
                component: PFICreditLimitComponent
              },
              {
                path: 'uob-user',
                component: UobCreditLimitComponent
              }
            ]
          },
          {
            path: 'submitted',
            component: SponsorSubmittedViewComponent
          }
        ]
      },
      {
        path: 'edit/:midTermId',
        component: LoanBaseComponent,
        children: [
          {
            path: 'sponsor-eform-upload',
            component: SponsorEFormUploadComponent
          },
          {
            path: 'sponsor-eform',
            component: SponsorEFormComponent,
            children: [
              {
                path: 'pfi-user',
                component: PFICreditLimitComponent
              },
              {
                path: 'uob-user',
                component: UobCreditLimitComponent
              }
            ]
          },
          {
            path: 'submitted',
            component: SponsorSubmittedViewComponent
          }
        ]
      }
    ]
  }
];
