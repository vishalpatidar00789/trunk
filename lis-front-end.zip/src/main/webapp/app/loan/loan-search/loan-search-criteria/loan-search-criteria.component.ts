import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { TitleCasePipe, DatePipe, CurrencyPipe } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
import { LoanSearchCriteria } from './loan-search-criteria.model';
import { LoanSearchResults } from './../loan-search-results/loan-search-results.model';
import { LoanSearchCriteriaService } from './loan-search-criteria.service';
import { LookupService, Account, DateUtil, Principal } from '../../../shared';
import { MasterdataService } from '../../../shared/masterdata/masterdata.service';
import { Router } from '@angular/router';
import { MultiSelectModule } from 'primeng/multiselect';
import { DropdownModule } from 'primeng/dropdown';
import { CheckboxModule } from 'primeng/checkbox';

@Component({
    selector: 'loan-search-criteria',
    templateUrl: './loan-search-criteria.component.html',
    providers: [TitleCasePipe, DatePipe, CurrencyPipe]
})
export class LoanSearchCriteriaComponent implements OnInit, OnDestroy {
    displayMessage: boolean;
    userMessage: string;
    searchModel: LoanSearchCriteria;
    banks: any[];
    consortiums: any[];
    currentAccount: Account;
    isMarshUser: boolean;
    app: any[];
    loanResultList: LoanSearchResults[];
    natureOfApp: any[];
    marshAppStatus: any[];
    showTblData: boolean = false;
    defaultAdverseOptoin: string;
    dateTypes: any[];
    adverseStatus: any[];
    totalRecords: number;
    userid: string;
    isUOB: boolean;
    // click:boolean=false;
    // showManageDoc: boolean=false;

    constructor(
        private lookupService: LookupService,
        private masterdataService: MasterdataService,
        private principal: Principal,
        private spinner: NgxSpinnerService,
        private loanSearchCriteriaService: LoanSearchCriteriaService,
        private router: Router, private datePipe: DatePipe,
        private titlePipe: TitleCasePipe, private currencyPipe: CurrencyPipe) {
    }

    ngOnInit() {
        this.init();
        this.loadBanks();
        this.loadConsortiums();
        this.initAccount();
        this.loadApp();
    }

    init() {
        this.userid = '';
        this.displayMessage = false;
        this.searchModel = new LoanSearchCriteria();
        this.isMarshUser = false;
        this.loanResultList = [];
        this.isUOB = false;


        this.natureOfApp = [
            { label: 'New', value: 'New' },
            { label: 'Cancel Utilised', value: 'Cancel Utilised' },
            { label: 'Cancel Un-Utilised', value: 'Cancel Un-Utilised' },
            { label: 'Decrease Un-Utilised', value: 'Decrease Un-Utilised' },
            { label: 'Renewal', value: 'Renewal' },
            { label: 'Mid-Term INCR Un-Utilised', value: 'Mid-Term INCR Un-Utilised' },
            { label: 'Mid-Term INCR Utilised', value: 'Mid-Term INCR Utilised' },
            { label: 'Decrease Utilised', value: 'Decrease Utilised' },
            { label: 'Temporary Increase', value: 'Temporary Increase' }
        ];
        this.marshAppStatus = [
            { label: 'Draft', value: 'Draft' },
            { label: 'Processing', value: 'Processing' },
            { label: 'Answered', value: 'Answered' },
            { label: 'Duplicate', value: 'Duplicate' }
        ];
        this.adverseStatus = [
            { label: 'All', value: 'All' },
            { label: 'Yes', value: 'Yes' },
            { label: 'No', value: 'No' }
        ];
        this.app = [];
        this.banks = [];
        this.consortiums = [];
    }

    ngOnDestroy() {
    }

    initAccount() {
        this.principal.identity().then((account) => {
            if (account) {
                this.currentAccount = account;
                this.userid = this.currentAccount.login;
                if (!this.currentAccount.bank) {
                    this.isMarshUser = true;
                } else {
                    this.isMarshUser = false;
                    if (this.currentAccount.bank == 'UOB') {
                        this.isUOB = true;
                    }
                    this.searchModel.pfiCode = [];
                    this.searchModel.pfiCode[0] = this.currentAccount.bank;
                }
                let dateLabel = 'COFANET Submission Date';
                if (this.isUOB)
                    dateLabel = 'Submission Date';
                this.dateTypes = [
                    { label: 'Any', value: 'Any' },
                    { label: 'Marsh Submission Date', value: 'Marsh Submission Date' },
                    { label: dateLabel, value: 'COFANET Submission Date' },
                    { label: 'LO Acceptance Date', value: 'LO Acceptance Date' },
                    { label: 'Loan Expiry Date', value: 'Loan Expiry Date' }
                ];
            }
        });

    }

    loadBanks() {
        this.lookupService.banks().subscribe((banks) => {
            const bankList = banks;
            bankList.forEach(val => {
                let bank = { label: val.bankCode, value: val.bankCode };
                this.banks.push(bank);
            })
        });
    }

    loadConsortiums() {
        this.masterdataService.consortiums().subscribe((consortiums) => {
            const consoList = consortiums;
            consoList.forEach(val => {
                let conso = { label: val.consortiumName, value: val._id };
                this.consortiums.push(conso);
            });
            this.consortiums.push({ label: 'All', value: 'All' });
        });
    }

    loadApp() {
        this.masterdataService.app().subscribe((app) => {
            const appResult = app;
            appResult.forEach(val => {
                let ap = { label: val.app.toString(), value: val.app };
                this.app.push(ap);
            });
        })
    }

    search() {
        if (this.searchModel) {

            this.removeEmptyFromModel();

            if (!this.validateForAtLeastOneField()) {
                this.userMessage = 'Please enter atleast one search criteria.';
                this.displayMessage = true;
                // window.scrollTo(0, 0);
                setTimeout(() => {
                    this.displayMessage = false;
                }, 5000);
                return false;
            }

            if (this.searchModel.typeOfDate) {
                if (!this.searchModel.fromDate && !this.searchModel.toDate) {
                    this.userMessage = 'Please Select From Date / To Date.';
                    this.displayMessage = true;
                    // window.scrollTo(0, 0);
                    setTimeout(() => {
                        this.displayMessage = false;
                    }, 5000);
                    return false;
                }
            }

            let searchResult;
            this.loanResultList = [];
            this.spinner.show();
            this.loanSearchCriteriaService.searchLoanApplication(this.searchModel).subscribe((res) => {
                // console.log('get Result::', JSON.stringify(res));
                searchResult = res;
                searchResult.forEach(element => {
                    let loanResult = new LoanSearchResults();
                    loanResult._id = element._id;
                    loanResult.typeOfRequest = element.typeOfRequest;
                    loanResult.marshRefNo = element.marshRefNo;
                    loanResult.loanMarshRefNo = element.loanMarshRefNo;
                    loanResult.baseLoanId = element.baseLoanId;
                    loanResult.typeOfRequest=element.typeOfRequest;
                    loanResult.status = element.status;
                    loanResult.marshSubmissionDate = element.createdDate;
                    loanResult.app = element.app;
                    loanResult.consortium = element.consortium;

                    let sponserForm = element.sponsorForm;
                    if (sponserForm) {
                        loanResult.borrowerRegName = sponserForm.regComName;
                        loanResult.aCRArefNo = sponserForm.ACRANo;
                    }

                    let creditInfo = element.creditInfo;
                    if (creditInfo) {
                        loanResult.pfiCode = creditInfo.pfiCode;
                        loanResult.pfiName = creditInfo.pfiName;
                        if (creditInfo.sgdCurrency)
                            loanResult.totalRequstedLimitSGD = creditInfo.sgdCurrency
                        else
                            loanResult.totalRequstedLimitSGD = creditInfo.totalRequstedLimitSGD;
                        if (creditInfo.submissionDate)
                            loanResult.submissionDate = creditInfo.submissionDate;
                        loanResult.primary = creditInfo.primary;
                        loanResult.autoTopUp = creditInfo.autoTopUp;
                        loanResult.bg = creditInfo.bg;
                        loanResult.lisPlus = creditInfo.lisPlus;
                        loanResult.requesterName = creditInfo.requesterName;
                        loanResult.foreignCurrency = creditInfo.foreignCurrency;
                        loanResult.foreignCurrencyAmount = creditInfo.foreignCurrencyAmount;
                        loanResult.exchangeRate = creditInfo.exRate;
                        if (creditInfo.natureOfApplication)
                            loanResult.natureOfApplication = creditInfo.natureOfApplication;
                        if (creditInfo.loAcceptanceDate)
                            loanResult.loAcceptanceDate = creditInfo.loAcceptanceDate;
                        if (creditInfo.loanExpiryDate)
                            loanResult.loanExpiryDate = creditInfo.loanExpiryDate;
                    }                   

                    let adverseInfo = element.adverseInfo;
                    if (adverseInfo) {
                        loanResult.adverseStatus = this.titlePipe.transform(adverseInfo.adverseStatus);
                        loanResult.additionalInfo =adverseInfo.additionalInfo;
                        loanResult.overdueDate = adverseInfo.overdueDate;
                        loanResult.listOfOverdue = adverseInfo.listOfOverdue;
                        loanResult.overdue = adverseInfo.overdue;
                        loanResult.repaymentPlanAttached = adverseInfo.repaymentPlanAttached;
                    }
                    this.loanResultList.push(loanResult);
                });
                this.totalRecords = this.loanResultList.length;
                this.sort();
                this.showTblData = true;
                setTimeout(() => {
                    this.spinner.hide();
                }, 500);
            });
        }
    }

    sort(){
        this.loanResultList.sort(function (b, a) {            
            if (a.submissionDate < b.submissionDate) return -1;
            if (a.submissionDate > b.submissionDate) return 1;
            return 0;
        });
    }

    removeEmptyFromModel() {

        /***** */
        if (!this.searchModel.adverseStatus) {
            delete this.searchModel.adverseStatus;
        }
        if (!this.searchModel.consortium) {
            delete this.searchModel.consortium;
        }
        if (!this.searchModel.typeOfDate) {
            delete this.searchModel.typeOfDate;
        }
        if (!this.searchModel.fromDate) {
            delete this.searchModel.fromDate;
        }
        if (!this.searchModel.toDate) {
            delete this.searchModel.toDate;
        }
        ////****////
        if (this.searchModel.app && this.searchModel.app.length == 0) {
            delete this.searchModel.app;
        }
        if (this.searchModel.natureOfApplication && this.searchModel.natureOfApplication.length == 0) {
            delete this.searchModel.natureOfApplication;
        }
        if (this.searchModel.marshLoanApplicationStatus && this.searchModel.marshLoanApplicationStatus.length == 0) {
            delete this.searchModel.marshLoanApplicationStatus;
        }
        if (this.searchModel.pfiCode && this.searchModel.pfiCode.length == 0) {
            delete this.searchModel.pfiCode;
        }
    }

    validateForAtLeastOneField() {
        if (this.searchModel.marshRefNo) {
            return true;
        }
        if (this.searchModel.borrowerName) {
            return true;
        }
        else if (this.searchModel.uenNumber) {
            return true;
        }
        else if (this.searchModel.pfiCode) {
            return true;
        }
        else if (this.searchModel.consortium) {
            return true;
        }
        else if (this.searchModel.adverseStatus) {
            return true;
        }
        else if (this.searchModel.typeOfDate) {
            return true;
        }
        else if (this.searchModel.natureOfApplication) {
            return true;
        }
        else if (this.searchModel.marshLoanApplicationStatus) {
            return true;
        }
        else if (this.searchModel.excludeExpiredApplications) {
            return true;
        }
        else if (this.searchModel.app) {
            return true;
        }
        else return false;
    }

    clearDate() {
        if (!this.searchModel.typeOfDate) {
            this.searchModel.fromDate = '';
            this.searchModel.toDate = '';
        }
    }

    clear() {
        let pfi = '';
        if (!this.isMarshUser)
            pfi = this.searchModel.pfiCode[0];

        this.searchModel = new LoanSearchCriteria();
        if (!this.isMarshUser) {
            this.searchModel.pfiCode = [];
            this.searchModel.pfiCode[0] = pfi;
        }
        // this.loanResultList = [];
    }

    cancel() {
        this.router.navigate(['']);
    }

    // manageDoc(){
    //     this.click=true;
    //     this.showManageDoc=true;
    // }
}