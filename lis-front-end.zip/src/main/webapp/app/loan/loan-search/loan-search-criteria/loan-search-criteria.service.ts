import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { SERVER_API_URL } from '../../../app.constants';

@Injectable()
export class LoanSearchCriteriaService {

    // private resourceUrl = SERVER_API_URL + 'loanform/search';
    private resourceUrl = SERVER_API_URL + 'search-loan-adhoc-midterm';
    constructor(private http: HttpClient) { }

    searchLoanApplication(searchCriteria){
        return <any>this.http.post(this.resourceUrl, searchCriteria);
    }
}
