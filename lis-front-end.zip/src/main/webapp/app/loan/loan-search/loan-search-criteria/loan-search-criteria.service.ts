import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { SERVER_API_URL } from '../../../app.constants';
import { LoanSearchResults } from '../loan-search-results/loan-search-results.model';

@Injectable()
export class LoanSearchCriteriaService {

    // private resourceUrl = SERVER_API_URL + 'loanform/search';
    private resourceUrl = SERVER_API_URL + 'search-loan-adhoc-midterm';
    constructor(private http: HttpClient) { }

    searchLoanApplication(searchCriteria){
        console.log(JSON.stringify(searchCriteria));
        return <any>this.http.post(this.resourceUrl, searchCriteria);
    }

    convertToLoanResult(element){
        let loanResult = new LoanSearchResults();
                    loanResult._id = element._id;
                    loanResult.marshRefNo = element.marshRefNo;
                    loanResult.loanMarshRefNo = element.loanMarshRefNo;
                    loanResult.baseLoanId = element.baseLoanId;
                    loanResult.typeOfRequest=element.typeOfRequest;
                    loanResult.status = element.status;
                    loanResult.marshSubmissionDate = element.createdDate;
                    loanResult.app = element.app;
                    loanResult.consortium = element.consortium;
                    loanResult.isClaimSubmitted = element.isClaimSubmitted;

                    let sponserForm = element.sponsorForm;
                    if (sponserForm) {
                        loanResult.borrowerRegName = sponserForm.regComName;
                        loanResult.aCRArefNo = sponserForm.ACRANo;
                    }

                    let creditInfo = element.creditInfo;
                    if (creditInfo) {
                        loanResult.pfiCode = creditInfo.pfiCode;
                        loanResult.pfiName = creditInfo.pfiName;
                        if (creditInfo.sgdCurrency)
                            loanResult.totalRequstedLimitSGD = creditInfo.sgdCurrency
                        else
                            loanResult.totalRequstedLimitSGD = creditInfo.totalRequstedLimitSGD;
                        if (creditInfo.submissionDate)
                            loanResult.submissionDate = creditInfo.submissionDate;
                        loanResult.primary = creditInfo.primary;
                        loanResult.autoTopUp = creditInfo.autoTopUp;
                        loanResult.bg = creditInfo.bg;
                        loanResult.lisPlus = creditInfo.lisPlus;
                        loanResult.requesterName = creditInfo.requesterName;
                        loanResult.foreignCurrency = creditInfo.foreignCurrency;
                        loanResult.foreignCurrencyAmount = creditInfo.foreignCurrencyAmount;
                        loanResult.exchangeRate = creditInfo.exRate;
                        if (creditInfo.natureOfApplication)
                            loanResult.natureOfApplication = creditInfo.natureOfApplication;
                        if (creditInfo.loAcceptanceDate)
                            loanResult.loAcceptanceDate = creditInfo.loAcceptanceDate;
                        if (creditInfo.loanExpiryDate)
                            loanResult.loanExpiryDate = creditInfo.loanExpiryDate;
                    }                   

                    let adverseInfo = element.adverseInfo;
                    if (adverseInfo) {
                        loanResult.adverseStatus = adverseInfo.adverseStatus;
                        loanResult.additionalInfo =adverseInfo.additionalInfo;
                        loanResult.overdueDate = adverseInfo.overdueDate;
                        loanResult.listOfOverdue = adverseInfo.listOfOverdue;
                        loanResult.overdue = adverseInfo.overdue;
                        loanResult.repaymentPlanAttached = adverseInfo.repaymentPlanAttached;
                    }
                    return loanResult;
    }
}
