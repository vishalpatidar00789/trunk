import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  Input,
  OnChanges
} from '@angular/core';
import { LOAN_SEARCH_RESULT_ITEMS_PER_PAGE } from './../../../shared/constants/pagination.constants';
import { TieredMenu } from 'primeng/tieredmenu';
import { MenuItem } from 'primeng/api';
import { LoanSearchResults } from './loan-search-results.model';
import { LoanSearchResultsService } from './loan-search-results.service';
import { LoanSearchCriteriaService } from '../loan-search-criteria/loan-search-criteria.service';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { Paginator } from 'primeng/paginator';
import { Table } from 'primeng/table';
import { LoanAdverseInfo } from '../../loan-adverse-info/loan-adverse-info.model';
import { LoanService } from '../../loan.service';

@Component({
  selector: 'loan-search-results',
  templateUrl: './loan-search-results.component.html'
})
export class LoanSearchResultsComponent
  implements OnInit, OnDestroy, OnChanges {
  @Input() loanResultList: LoanSearchResults[];
  @Input() isMarshUser: boolean;
  @Input() totalRecords: number;  
  @Input() userid: string;
  @Input() isUOB: boolean;
  @Input() fromHome:boolean;

  public isUobRecored: boolean;
  public items: MenuItem[];
  public cols: any[];
  public frozenCols: any[];
  public itemsPerPage: number;
  public popUp: boolean;
  public adverseInfoModel: boolean;
  public loAcceptanceModel: boolean;
  public manageSupportingDocModel: boolean;
  public viewSubmitModel: boolean;
  public viewSubmitAdhocModel: boolean;
  public loanEditModel: boolean;
  public adhocEditModel: boolean;
  public loanDetailsModel: boolean;
  public adhocDetailsModel: boolean;
  public midTermDetailsModel: boolean;
  public selectedLoanResult: LoanSearchResults;
  public loanResultList2: LoanSearchResults[];
  public dialogTitle: string;
  public loanViewId: string;
  public adhocViewId: string;
  public pfiCode: string;
  public cloneLoanResultList: any[];
  public dialogTopPostion: number;
  public marshRefNo: string;
  public adhocStatus: string;
  public isMidTerm :boolean;  
  public baseLoanId: string;
  public typeOfRequest: string;

  @ViewChild('tieredMenu') tieredMenu: TieredMenu;
  @ViewChild('table') table: Table;
  constructor(
    private loanService: LoanService,
    private loanSearchResultsService: LoanSearchResultsService,
    private loanSearchCriteriaService: LoanSearchCriteriaService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnChanges() {
    this.table.reset();
    this.cloneLoanResultList = this.loanResultList;
    this.loanResultList2 = [];
    setTimeout(() => {
      this.table.reset();
      this.loanResultList2 = this.cloneLoanResultList;
    }, 1000);

    this.itemsPerPage = LOAN_SEARCH_RESULT_ITEMS_PER_PAGE;   
  
    this.initColumn();
   
  }

  initColumn(){
    let cofanetDate = 'COFANET Submission Date';
    if (this.isUOB) {
      cofanetDate = 'Submission Date';
    }

    let submissionDate='Marsh Submission Date';
    if(this.fromHome){
      submissionDate='Last saved Date';
  }


    this.cols = [
      { field: 'marshRefNo', header: 'Marsh Reference Number' },
      { field: 'typeOfRequest', header: 'Loan Request Type' },
      { field: 'borrowerRegName', header: 'Borrower Name' },
      { field: 'aCRArefNo', header: 'UEN Number' },
      { field: 'pfiCode', header: 'PFI' },
      { field: 'natureOfApplication', header: 'Nature of Application' },      
      { field: 'marshSubmissionDate', header:  submissionDate},
      { field: 'submissionDate', header: cofanetDate },
      { field: 'loAcceptanceDate', header: 'LO Acceptance Date ' },
      { field: 'loanExpiryDate', header: 'Loan Expiry Date' },
      { field: 'status', header: 'Marsh Loan Application Status' },
      { field: 'adverseStatus', header: 'Adverse Status' },
      { field: 'app', header: 'APP' },
      { field: 'totalRequstedLimitSGD', header: 'Total Applied Limit (S$)' },
      { field: 'primary', header: 'Approved Limit(Primary) S$' },
      { field: 'autoTopUp', header: 'Approved Limit(Top-up) S$' },
      { field: 'bg', header: 'Approved Limit(BG) S$' },
      { field: 'lisPlus', header: 'Approved Limit(LIS+) S$' }
    ];
  }

  ngOnInit() {
    this.isMidTerm = false;    
    this.popUp = false;
    this.adverseInfoModel = false;
    this.loAcceptanceModel = false;
    this.manageSupportingDocModel = false;
    this.viewSubmitModel = false;
    this.viewSubmitAdhocModel = false;
    this.dialogTitle = '';
    this.loanEditModel = false;
    this.adhocEditModel = false;
    this.loanDetailsModel = false;
    this.adhocDetailsModel = false;
    this.isUobRecored = false;
    this.midTermDetailsModel=false;
  }

  ngOnDestroy() { }

  hidePopup(event) {
    this.adverseInfoModel = false;
    this.loAcceptanceModel = false;
    this.manageSupportingDocModel = false;
    this.viewSubmitModel = false;
    this.viewSubmitAdhocModel = false;
    this.loanEditModel = false;
    this.adhocEditModel = false;
    this.loanDetailsModel = false;
    this.adhocDetailsModel = false;
    this.midTermDetailsModel=false;
  }

  updateAdverseInfo(loanAdverseInfo: LoanAdverseInfo) {
    if (loanAdverseInfo.adverseInfo) {
      this.selectedLoanResult.additionalInfo =
        loanAdverseInfo.adverseInfo.additionalInfo;
      this.selectedLoanResult.adverseStatus =
        loanAdverseInfo.adverseInfo.adverseStatus;
      this.selectedLoanResult.listOfOverdue =
        loanAdverseInfo.adverseInfo.listOfOverdue;
      this.selectedLoanResult.overdue = loanAdverseInfo.adverseInfo.overdue;
      this.selectedLoanResult.overdueDate =
        loanAdverseInfo.adverseInfo.overdueDate;
      this.selectedLoanResult.repaymentPlanAttached =
        loanAdverseInfo.adverseInfo.repaymentPlanAttached;
    }
  }

  showPopup(result, model: any) {
    this.popUp = true;
    this.isMidTerm = false;
    this.selectedLoanResult = result;
    // console.log('Check user', JSON.stringify(this.selectedLoanResult));
    if (model == 1) {
      let typeOfRequest;
      switch (this.selectedLoanResult.typeOfRequest) {
        case 'loan':
          typeOfRequest = 'Loan';
          break;
        case 'midterm':
          typeOfRequest = 'Mid-Term';
          break;
        case 'adhoc':
          typeOfRequest = 'Adhoc';
          break;
      }
      this.dialogTitle = `${typeOfRequest} Adverse Information`;
      this.adverseInfoModel = true;
      this.dialogTopPostion = 10;
    } else if (model == 2) {
      this.dialogTitle = 'Manage LO Acceptance';
      this.loAcceptanceModel = true;
      this.dialogTopPostion = 60;
    } else if (model == 3) {
      this.dialogTitle = 'Manage Supporting Documents';
      this.dialogTopPostion = 10;
      this.manageSupportingDocModel = true;
    } else if (model == 4) {
      // this.dialogTitle = 'Create Other Ad-hoc Request';
      // this.adhocModel = true;
      const navigationExtras: NavigationExtras = {
        queryParams: {
          "_id": this.selectedLoanResult._id
        }
      };
      if (this.selectedLoanResult.pfiCode === 'UOB') {
        this.router.navigate(['/adhoc-uobuser'], navigationExtras);
      } else {
        this.router.navigate(['/adhoc-pfiuser'], navigationExtras);
      }
      // if (this.selectedLoanResult.pfiCode === 'UOB') {
      //     this.router.navigate(['/adhoc-uobuser',  this.selectedLoanResult._id]);
      // } else {
      //     this.router.navigate(['/adhoc-pfiuser',  this.selectedLoanResult._id]);
    } else if (model == 5) {
      if (result) {
        this.dialogTitle = 'View Submitted Application';
        this.popUp = false;
        this.viewSubmitModel = true;
        this.loanViewId = result._id;
      }
    } else if (model == 6) {
      this.popUp = false;
      if (this.selectedLoanResult._id) {
        this.router.navigate([`../loan/edit/${this.selectedLoanResult._id}`], {
          relativeTo: this.route
        });
      }
    } else if (model == 8) {
      console.log('View Submitted Other Ad-hoc Requests');
      if (result) {
        this.dialogTitle = 'View Submitted Other Ad-hoc Requests';
        console.log('Submit id: ' + result._id);
        console.log('Result pfiCode: ' + result.pfiCode);
        this.adhocViewId = result._id;
        this.pfiCode = result.pfiCode;
        this.popUp = false;
        this.viewSubmitAdhocModel = true;
      }
    } else if (model == 9) {
      this.popUp = false;
      if (this.selectedLoanResult._id) {
        this.router.navigate(
          [
            `../mid-term/new/${
            this.selectedLoanResult._id
            }/sponsor-eform-upload`
          ],
          {
            relativeTo: this.route
          }
        );
      }
    } else if (model == 10) {
      this.popUp = false;
      if (this.selectedLoanResult._id) {
        this.router.navigate([`../mid-term/edit/${this.selectedLoanResult._id}`], {
          relativeTo: this.route
        });
      }
    } else if (model == 11) {
      this.popUp = false;
      const navigationExtras: NavigationExtras = {
        queryParams: {
          "adhocId": this.selectedLoanResult._id
        }
      };
      if (this.selectedLoanResult.pfiCode === 'UOB') {
        this.router.navigate(['/adhoc-uobuser'], navigationExtras);
      } else {
        this.router.navigate(['/adhoc-pfiuser'], navigationExtras);
      }
    } else if (model == 12) {
      // if (this.isMarshUser) {
      //   this.dialogTitle = 'View/Edit Other Ad-hoc Request Application Details';
      // } else {
      //   this.dialogTitle = 'View Other Ad-hoc Request Application Details';
      // }
      // this.popUp = false;
      // this.viewSubmitModel = false;
      // this.adhocEditModel = true;
      // console.log("Adhoc-selectedLoanResult._id: " + this.selectedLoanResult._id);
      // console.log("Adhoc-selectedLoanResult.baseLoanId: " + this.selectedLoanResult.baseLoanId);


      // this.showEditLoanPopup(result, model);
    } else if (model == 13) {
      if (result) {
        this.dialogTitle = 'View Submitted Mid-Term/Temp Application';
        this.popUp = false;
        this.isMidTerm = true;
        this.viewSubmitModel = true;
        this.loanViewId = result._id;
      }
    }
  }

  showEditLoanPopup(result) {
    this.selectedLoanResult = result;
    this.typeOfRequest = result.typeOfRequest;
    this.marshRefNo = this.selectedLoanResult.marshRefNo;

    if (this.selectedLoanResult.pfiCode === 'UOB') {
      this.isUobRecored = true;
    } else {
      this.isUobRecored = false;
    }

    
    if (this.typeOfRequest === 'adhoc') {

      if (this.isMarshUser) {
        this.dialogTitle = 'View/Edit Other Ad-hoc Request Application Details';
      } else {
        this.dialogTitle = 'View Other Ad-hoc Request Application Details';
      }
      this.loanEditModel = true;

    } else if (this.typeOfRequest === 'midterm') {
      if (this.isMarshUser) {
        this.dialogTitle = 'View/Edit Mid-Term/Temp Details';
      } else {
        this.dialogTitle = 'View Mid-Term/Tem Details';
      }
      this.midTermDetailsModel = true;
    }else {
      if (this.isMarshUser) {
        this.dialogTitle = 'View/Edit Loan Details';
      } else {
        this.dialogTitle = 'View Loan Details';
      }
      this.loanEditModel = true;
    }
    this.dialogTopPostion = 10;
  }

  routClaim(result) {
    this.selectedLoanResult = result;
    if (this.selectedLoanResult._id) {
      this.router.navigate(['/claim/'+ this.selectedLoanResult._id]);
    }
  }
}
