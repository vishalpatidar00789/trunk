import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { SERVER_API_URL } from '../../../app.constants';
import { PFILoan, UOBLoan } from '../..';

@Injectable()
export class LoanSearchResultsService {
  private resourceUrl = SERVER_API_URL;

  constructor(private http: HttpClient) {}

  /***
   * Loan edit detail: UOB
   *
   */
  getPFIEditDetail(marshRefNo?: any): Observable<PFILoan> {
    return this.http.get<PFILoan>(
      this.resourceUrl + 'loanform/loanByMarshId/' + marshRefNo
    );
  }

 
  submitLoanEditPFI(
    loanDetailsModal: PFILoan
  ): Observable<HttpResponse<PFILoan>> {
    const _id = loanDetailsModal['_id'];
    delete loanDetailsModal['__v'];
    delete loanDetailsModal['_id'];
    delete loanDetailsModal['createdDate'];
    delete loanDetailsModal['updatedAt'];
    delete loanDetailsModal['adverseInfo'];
    delete loanDetailsModal['creditInfo']['supportingDocs'];
    delete loanDetailsModal['creditInfo']['borrowersGroup'];
    delete loanDetailsModal['loanRequestType'];

    // console.log('request paylod:: ' + JSON.stringify(loanDetailsModal));
    return this.http.put<PFILoan>(
      this.resourceUrl + 'loanform/update-loan-by-id',
      loanDetailsModal,
      { observe: 'response' }
    );
  }

  submitAdhocEditPFI(
    loanDetailsModal: PFILoan
  ): Observable<HttpResponse<PFILoan>> {
    // const id = loanDetailsModal['_id'];
    delete loanDetailsModal['__v'];
    // delete loanDetailsModal['_id'];
    delete loanDetailsModal['createdDate'];
    delete loanDetailsModal['updatedAt'];
    delete loanDetailsModal['adverseInfo'];
    delete loanDetailsModal['creditInfo']['supportingDocs'];
    delete loanDetailsModal['creditInfo']['borrowersGroup'];
    delete loanDetailsModal['loanRequestType'];

    // console.log(JSON.stringify(loanDetailsModal));
    return this.http.put<PFILoan>(
      this.resourceUrl + 'loanform/update-adhoc-by-id',
      loanDetailsModal,
      { observe: 'response' }
    );
  }

  submitAdhocEditUOB(
    loanDetailsModal: UOBLoan
  ): Observable<HttpResponse<UOBLoan>> {
    delete loanDetailsModal['__v'];
    delete loanDetailsModal['createdDate'];
    delete loanDetailsModal['updatedAt'];
    delete loanDetailsModal['adverseInfo'];
    delete loanDetailsModal['creditInfo']['supportingDocs'];
    delete loanDetailsModal['creditInfo']['borrowersGroup'];
    delete loanDetailsModal['loanRequestType'];

    // console.log(JSON.stringify(loanDetailsModal));
    return this.http.put<UOBLoan>(
      this.resourceUrl + 'loanform/update-adhoc-by-id',
      loanDetailsModal,
      { observe: 'response' }
    );
  }

  /***
   * Loan edit detail: UOB
   *
   */
  getUOBEditDetail(marshRefNo?: any): Observable<UOBLoan> {
    return this.http.get<UOBLoan>(
      this.resourceUrl + 'loanform/loanByMarshId/' + marshRefNo
    );
  }

  submitLoanEditUOB(
    loanDetailsModal: UOBLoan
  ): Observable<HttpResponse<UOBLoan>> {
    const _id = loanDetailsModal['_id'];
    delete loanDetailsModal['__v'];
    delete loanDetailsModal['_id'];
    delete loanDetailsModal['createdDate'];
    delete loanDetailsModal['updatedAt'];
    delete loanDetailsModal['adverseInfo'];
    delete loanDetailsModal['creditInfo']['supportingDocs'];
    delete loanDetailsModal['creditInfo']['borrowersGroup'];
    delete loanDetailsModal['loanRequestType'];

    return this.http.put<UOBLoan>(
      this.resourceUrl + 'loanform/update-loan-by-id',
      loanDetailsModal,
      { observe: 'response' }
    );
  }

  /***
   * Loan edit detail: Get Mid-Term Loan by ID
   *
   */
  getMidTermLoanById(loanId: string) {
    return <any>this.http.get(this.resourceUrl + 'mid-term/' + loanId);
  }
}
