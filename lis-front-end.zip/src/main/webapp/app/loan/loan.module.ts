import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LisAppSharedModule } from '../shared';
import { PFICreditLimitComponent } from './pfi/pfi-credit-limit.component';
import { PFICreditLimitService } from './pfi/pfi-credit-limit.service';
import { UobCreditLimitComponent } from './uob/uob-credit-limit.component';
import { LoanSearchCriteriaComponent } from './loan-search/loan-search-criteria/loan-search-criteria.component';
import { UobCreditLimitService } from './uob/uob-credit-limit.service';
import { LoanApplicationRoute } from './loan.route';
import { LoanComponent } from './loan.component';
import { SponsorEFormComponent, SponsorEFormUploadComponent } from '.';
import { SponsorEFormService } from './sponsor-eform/sponsor-eform.service';
import { LoanService } from './loan.service';
import { MatTabsModule } from '@angular/material/tabs';
import { CdkTableModule } from '@angular/cdk/table';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DatePipe } from '@angular/common';
import { LoanSearchCriteriaService } from './loan-search/loan-search-criteria/loan-search-criteria.service';
import { LoanSearchResultsComponent } from './loan-search/loan-search-results/loan-search-results.component';
import { LoanSearchResultsService } from './loan-search/loan-search-results/loan-search-results.service';
import { TableModule } from 'primeng/table';
import { TieredMenuModule } from 'primeng/tieredmenu';
import { DialogModule } from 'primeng/dialog';
import { MultiSelectModule } from 'primeng/multiselect';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { LoanAdverseInfoComponent } from './loan-adverse-info/loan-adverse-info.component';
import { LoanAdverseInfoService } from './loan-adverse-info/loan-adverse-info.service';
import { MessageModule } from 'primeng/message';
import { RadioButtonModule } from 'primeng/radiobutton';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { LoanNavBarComponent } from '../layouts/loan-navbar/loan-nabar.component';
import { LoanBaseComponent } from './sponsor-eform/sponsor-eform-base.component';
import { SponsorSubmittedViewComponent } from './sponsor-eform/sponsor.submitted-view.component';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PaginatorModule } from 'primeng/paginator';
import { TabViewModule } from 'primeng/tabview';
import { ManageLOAcceptanceComponent } from './manage-LO-acceptance/manage-LO-acceptance.component';
import { ManageSupportingDocumentsComponent } from './manage-supporting-documents/manage-supporting-documents.component';
import { ManageSupportingDocumentsService } from './manage-supporting-documents/manage-supporting-documents.service';
import { LoanViewComponent } from './loan-view/loan-view.component';
import { LISCurrencyMaskModule } from '../shared/currency/currency-mask.module';
import { DocumentComponent } from '../shared/document-list/documents.component';
import { UnsavedChangesGuardService } from './sponsor-eform/unsaved-changes.gaurds';
import { MidTermService } from './mid-term/mid-term.service';
import { MidTermRoute } from './mid-term/mid-term.route';
import { LoanAdhocApplicationModule } from './adhoc/adhoc.module';
import { PFILoanDetailComponent } from './loan-edit-details/pfi/pfi-loan-detail.component';
import { UOBLoanDetailComponent } from './loan-edit-details/uob/uob-loan-detail.component';
// import { PFIAdhocDetailComponent } from './adhoc-edit-details/pfi/pfi-adhoc-detail.component';
// import { UOBAdhocDetailComponent } from './adhoc-edit-details/uob/uob-adhoc-detail.component';
import { MidTermEditPfiComponent } from './mid-term/mid-term-edit-pfi/mid-term-edit-pfi.component';
import { MidTermEditUobComponent } from './mid-term/mid-term-edit-uob/mid-term-edit-uob.component';

const PAGE_SET_STATES = [...LoanApplicationRoute, ...MidTermRoute];

@NgModule({
  imports: [
    MatTabsModule,
    CdkTableModule,
    BrowserAnimationsModule,
    LisAppSharedModule,
    TableModule,
    TieredMenuModule,
    DialogModule,
    MultiSelectModule,
    CheckboxModule,
    DropdownModule,
    MessageModule,
    RadioButtonModule,
    BsDatepickerModule,
    NgbModule.forRoot(),
    PaginatorModule,
    TabViewModule,
    RouterModule.forRoot(PAGE_SET_STATES, { useHash: true }),
    CurrencyMaskModule,
    LISCurrencyMaskModule,
    LoanAdhocApplicationModule
  ],
  declarations: [
    LoanComponent,
    LoanNavBarComponent,
    LoanBaseComponent,
    LoanViewComponent,
    PFICreditLimitComponent,
    UobCreditLimitComponent,
    SponsorEFormUploadComponent,
    SponsorEFormComponent,
    SponsorSubmittedViewComponent,
    LoanSearchResultsComponent,
    LoanSearchCriteriaComponent,
    LoanAdverseInfoComponent,
    ManageLOAcceptanceComponent,
    ManageSupportingDocumentsComponent,    
    PFILoanDetailComponent,
    UOBLoanDetailComponent,
    // PFIAdhocDetailComponent,
    MidTermEditPfiComponent,
    MidTermEditUobComponent
  ],
  providers: [
    PFICreditLimitService,
    UobCreditLimitService,
    SponsorEFormService,
    LoanService,
    DatePipe,
    LoanSearchCriteriaService,
    LoanSearchResultsService,
    LoanAdverseInfoService,
    ManageSupportingDocumentsService,
    UnsavedChangesGuardService,
    MidTermService
  ],
  exports: [LoanSearchResultsComponent],

  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class LoanApplicationModule {}
