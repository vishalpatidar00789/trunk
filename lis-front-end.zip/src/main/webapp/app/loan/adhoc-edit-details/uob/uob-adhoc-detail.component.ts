// import { Component, OnInit, Input, ViewChild, OnChanges, EventEmitter, Output } from '@angular/core';
// import { SelectItem } from 'primeng/api';
// import { LoanSearchResults } from '../../loan-search/loan-search-results/loan-search-results.model';
// import { UOBLoan } from '../../loan.model';
// import { Currencies, LookupService, Bank } from '../../../shared';
// import { NotificationOption, NotificationService } from '../../../shared/alert/notification.service';
// import { NgForm } from '@angular/forms';
// import { CRRPremiumRate } from '../..';
// import { LoanService } from '../../loan.service';
// import { LoanSearchResultsService } from '../../loan-search/loan-search-results/loan-search-results.service';
// import { ManageSupportingDocumentsService } from '../../manage-supporting-documents/manage-supporting-documents.service';
// import { DatePipe } from '@angular/common';
// import { Document } from '../../../shared/document-list/documents.model';
// import { HttpResponse } from '@angular/common/http';

// @Component({
//     selector: 'lis-uob-adhoc-detail',
//     templateUrl: './uob-adhoc-detail.component.html'
// })
// export class UOBAdhocDetailComponent implements OnInit, OnChanges {

//     public LoanAppStatus: SelectItem[];
//     public typeOfLimit: SelectItem[];
//     public TypeOfLISPlusLimit: SelectItem[];
//     public natureOfApplication: SelectItem[];
//     public utilization: SelectItem[];
//     public currencyListItem: SelectItem[];
//     marshUser: boolean = true;
//     data: any = [];
//     currencyList: Currencies[];
//     public submitPFI: any;
//     public loanDetailsModal: UOBLoan;
//     public documentList: Document[];
//     public cols: any[];

//     successMessage: boolean;
//     errorMessage: boolean;
//     isExceptionalCrrRate: boolean;
//     crrRate: number;
//     uobLoan: UOBLoan;
//     disableFutureDate = new Date();
//     cRRPremiumRateList: CRRPremiumRate[];
//     cRRNonEditList: CRRPremiumRate[];
//     cRREditList: CRRPremiumRate[];
//     bank: Bank;

//     @Input() loanResult: LoanSearchResults;
//     // @Input() marshRefNo: string;
//     @Input() selectedLoanResult: LoanSearchResults;
//     @Input() adhocStatus: string;
//     @Input() userid: string;
//     @Input() isMarshUser: boolean;
//     @Output() closePopUp = new EventEmitter<boolean>();
//     @Output() openPopUp = new EventEmitter<boolean>();

//     @ViewChild('loanDetailsForm') loanDetailsForm: NgForm;

//     constructor(
//         private lookup: LookupService,
//         private loanSearchResultsService: LoanSearchResultsService,
//         private notificationService: NotificationService,
//         private loanService: LoanService,
//         private supportingDocservice: ManageSupportingDocumentsService,
//         private datePipe: DatePipe,
//     ) { }

//     ngOnChanges() {
//         if (this.getLoanEditDetails()) {
//             setTimeout(() => {
//                 this.purposeOfLoan();
//                 this.setDateFormat();
//                 this.calculateLoanAmt();
//                 this.calculateLoanAmtforeignCurrency();
//                 this.getSubmittedDocList();
//                 this.openPopUp.emit(true);
//             }, 500);
//         }
//     }

//     ngOnInit() {
//         console.log('isMarshUser', this.isMarshUser);
//         this.lookup.getCurrencyList().subscribe((data) => {
//             this.currencyList = data;
//         });

//         this.loanService.getCRRPremiumRate().subscribe((crrPremium) => {
//             this.cRRPremiumRateList = crrPremium;
//         });

//         this.LoanAppStatus = [
//             { label: 'Draft', value: 'Draft' },
//             { label: 'Processing', value: 'Processing' },
//             { label: 'Answered', value: 'Answered' },
//             { label: 'Duplicate', value: 'Duplicate' }
//         ];

//         this.typeOfLimit = [
//             { label: 'DL', value: 'DL' },
//             { label: 'CL', value: 'CL' },
//             { label: 'DL & BG', value: 'DL & BG' },
//             { label: 'CL & BG', value: 'CL & BG' }
//         ];

//         this.TypeOfLISPlusLimit = [
//             { label: 'Stand-alone LIS +', value: 'Stand-alone LIS +' },
//             { label: 'Joint-Insured with LIS 5 & LIS +', value: 'Joint-Insured with LIS 5 & LIS +' },
//             { label: 'Not visible to PFI users', value: 'Not visible to PFI users' }
//         ];

//         this.natureOfApplication = [
//             { label: 'NEW', value: 'NEW' },
//             { label: 'CANCEL UTILISED', value: 'CANCEL UTILISED' },
//             { label: 'CANCEL UN-UTILISED', value: 'CANCEL UN-UTILISED' },
//             { label: 'DECREASE UN-UTILISED', value: 'DECREASE UN-UTILISED' },
//             { label: 'RENEWAL', value: 'RENEWAL' },
//             { label: 'MID-TERM INCR - UN-UTILISED', value: 'MID-TERM INCR - UN-UTILISED' },
//             { label: 'DECREASE UTILISED', value: 'DECREASE UTILISED' },
//             { label: 'MID-TERM INCR - UTILISED', value: 'MID-TERM INCR - UTILISED' },
//             { label: 'Temporary Increase', value: 'Temporary Increase' }
//         ];

//         this.utilization = [
//             { label: 'Utilised', value: 'Utilised' },
//             { label: 'Un-Utilised', value: 'Un-Utilised' },
//             { label: 'Nil Decisions', value: 'Nil Decisions' },
//             { label: 'Cancel Un-Utilised', value: 'Cancel Un-Utilised' }
//         ];

//         this.currencyListItem = [
//             { label: 'AUD', value: 'AUD' },
//             { label: 'CNY', value: 'CNY' },
//             { label: 'EUR', value: 'EUR' },
//             { label: 'HKD', value: 'HKD' },
//             { label: 'IDR', value: 'IDR' },
//             { label: 'INR', value: 'INR' },
//             { label: 'JPY', value: 'JPY' },
//             { label: 'KRW', value: 'KRW' },
//             { label: 'MYR', value: 'MYR' },
//             { label: 'NOK', value: 'NOK' },
//             { label: 'PHP', value: 'PHP' },
//             { label: 'THB', value: 'THB' },
//             { label: 'TWD', value: 'TWD' },
//             { label: 'USD', value: 'USD' },
//         ];

//         this.cols = [
//             { field: 'documentType', header: 'Document Type' },
//             { field: 'filename', header: 'Uploaded Document Name' },
//             { field: 'uploadDate', header: 'Date Of Upload' },
//             { field: 'uploadedBy', header: 'Uploaded By' }
//         ];
//     }

//     async getLoanEditDetails() {
//         console.log('Base loan ID: ', this.selectedLoanResult.baseLoanId);
//         if (this.selectedLoanResult.baseLoanId) {
//             return this.loanService.getLoanById(this.selectedLoanResult.baseLoanId).subscribe((response) => {
//                 // console.log('loanDetails', JSON.stringify(response));
//                 response.status = this.selectedLoanResult.status;
//                 this.loanDetailsModal = response;
//             });
//         }
//     }

//     save() {
//         if (this.loanDetailsModal) {
//             this.loanSearchResultsService.submitAdhocEditUOB(this.loanDetailsModal).subscribe((res) => {
//                 // console.log('Submit result', JSON.stringify(res));
//                 if (res instanceof HttpResponse) {
//                     this.submitPFI = res.body;;
//                     const notificationOption = new NotificationOption();
//                     notificationOption.toastrConfig = {
//                         positionClass: 'toast-top-right'
//                     };
//                     notificationOption.title = 'Notification';
//                     notificationOption.message = 'Application Saved Successfully';
//                     this.notificationService.showNotification(notificationOption);
//                     this.loanDetailsForm.form.markAsPristine();
//                 }
//             });
//         }
//     }

//     // save() {
//     //     if (this.loanDetailsModal) {
//     //         this.loanSearchResultsService.submitLoanEditUOB(this.loanDetailsModal).subscribe((res) => {
//     //             // console.log('Submit result', JSON.stringify(res));
//     //             this.submitPFI = res;
//     //             const notificationOption = new NotificationOption();
//     //             notificationOption.toastrConfig = {
//     //                 positionClass: 'toast-top-right'
//     //             };
//     //             notificationOption.title = 'Notification';
//     //             notificationOption.message = 'Application Saved Successfully';
//     //             this.notificationService.showNotification(notificationOption);
//     //             this.loanDetailsForm.form.markAsPristine();
//     //         });
//     //     }
//     // }

//     cancel() {
//         this.closePopUp.emit(true);
//     }

//     onLoanTabChange(event) {
//         console.log(event);
//     }

//     confirmChange(val) {
//         console.log(val);
//     }

//     onChangeCurrency(event) {
//         if (this.loanDetailsModal.creditInfo['foreignCurrency'] == '-1') {
//             this.loanDetailsModal.creditInfo['foreignCurrencyAmount'] = null;
//             this.loanDetailsModal.creditInfo['exRate'] = null;
//         }
//     }

//     onlyNumberKey(event) {
//         return event.charCode == 8 || event.charCode == 0 || event.charCode == 46
//             ? null
//             : event.charCode >= 48 && event.charCode <= 57;
//     }

//     purposeOfLoanCalculate(event) {
//         if (this.loanDetailsModal.sponsorForm !== undefined) {
//             let total_domesticval: number;
//             let total_value: number = 100;

//             if (isNaN(this.loanDetailsModal.sponsorForm.loanDomesticTrade1) || isNaN(this.loanDetailsModal.sponsorForm.loanDomesticTrade2)) {
//                 console.log('This is not a number');
//             } else {

//                 if (event.target.name == 'loanDomesticTrade1' && event.target.value <= 100) {
//                     total_domesticval = total_value - event.target.value;
//                     this.loanDetailsModal.sponsorForm.loanDomesticTrade2 = total_domesticval;
//                 } else if (event.target.name == 'loanDomesticTrade2' && event.target.value <= 100) {
//                     total_domesticval = total_value - event.target.value;
//                     this.loanDetailsModal.sponsorForm.loanDomesticTrade1 = total_domesticval;
//                 } else if (event.target.name == 'loanDomesticTrade1' && event.target.value > 100) {
//                     this.loanDetailsModal.sponsorForm.loanDomesticTrade1 = 100;
//                     this.loanDetailsModal.sponsorForm.loanDomesticTrade2 = 0;
//                 } else if (event.target.name == 'loanDomesticTrade2' && event.target.value > 100) {
//                     this.loanDetailsModal.sponsorForm.loanDomesticTrade2 = 100;
//                     this.loanDetailsModal.sponsorForm.loanDomesticTrade1 = 0;
//                 }

//                 this.purposeOfLoan();

//             }
//         }
//     }

//     purposeOfLoan() {

//         if (this.loanDetailsModal.sponsorForm !== undefined) {
//             let domesticval: number;
//             let exportVal: number;
//             let purposeOfLoan: string;
//             domesticval = this.loanDetailsModal.sponsorForm.loanDomesticTrade1;
//             exportVal = this.loanDetailsModal.sponsorForm.loanDomesticTrade2;

//             if (domesticval > exportVal) {
//                 purposeOfLoan = 'Domestic';
//             } else if (exportVal > domesticval) {
//                 purposeOfLoan = 'Export';
//             } else if (domesticval > 0 && exportVal > 0) {
//                 purposeOfLoan = 'Domestic and Export';
//             }
//             this.loanDetailsModal.sponsorForm.purposeOfLoan = purposeOfLoan;
//         }
//     }

//     setDateFormat() {
//         if (this.loanDetailsModal.creditInfo.submissionDate) {
//             this.loanDetailsModal.creditInfo.submissionDate = new Date(
//                 this.loanDetailsModal.creditInfo.submissionDate
//             );
//         }
//         if (this.loanDetailsModal.creditInfo.insurersApprovalDate) {
//             this.loanDetailsModal.creditInfo.insurersApprovalDate = new Date(
//                 this.loanDetailsModal.creditInfo.insurersApprovalDate
//             );
//         }
//         if (this.loanDetailsModal.creditInfo.loAcceptanceDate) {
//             this.loanDetailsModal.creditInfo.loAcceptanceDate = new Date(
//                 this.loanDetailsModal.creditInfo.loAcceptanceDate
//             );
//         }
//         if (this.loanDetailsModal.creditInfo.loanExpiryDate) {
//             this.loanDetailsModal.creditInfo.loanExpiryDate = new Date(
//                 this.loanDetailsModal.creditInfo.loanExpiryDate
//             );
//         }
//         if (this.loanDetailsModal.creditInfo.dateSentForLISPlus) {
//             this.loanDetailsModal.creditInfo.dateSentForLISPlus = new Date(
//                 this.loanDetailsModal.creditInfo.dateSentForLISPlus
//             );
//         }
//         if (this.loanDetailsModal.creditInfo.lISPlusApprovedDate) {
//             this.loanDetailsModal.creditInfo.lISPlusApprovedDate = new Date(
//                 this.loanDetailsModal.creditInfo.lISPlusApprovedDate
//             );
//         }

//     }

//     convertToNumber(val) {
//         return Number(val.replace(/[^0-9\.]+/g, ''));
//     }

//     calculateLoanAmt() {
//         // debugger;
//         let approvedPrimaryLimit: number;
//         let topUpLimit: number;
//         let bgLimit: number;
//         let lISPlus: number;

//         let midTerm: number = 0; // Mid-term application not yet completed, so meanwhile it is set as 0 value.
//         let totalApprovedLimit: number;
//         let totalRequstedLimitSGD: number;
//         let totalApprovedLimitincludingLISPLUS: number;
//         let lis5approvalratio: number;

//         approvedPrimaryLimit = this.loanDetailsModal.creditInfo.approvedPrimaryLayer || 0;
//         topUpLimit = this.loanDetailsModal.creditInfo.approvedAutoTopUpLayer || 0;
//         bgLimit = this.loanDetailsModal.creditInfo.approvedBgLayer || 0;
//         lISPlus = this.loanDetailsModal.creditInfo.approvedSGDLimitLISPlus || 0;

//         // get LIS5 Total Approvaed Limit [primary + top-up + bg]
//         totalApprovedLimit = (approvedPrimaryLimit + topUpLimit + bgLimit);
//         this.loanDetailsModal.creditInfo.lis5TotalApprovedLimit = totalApprovedLimit;


//         // get LIS5 Total Approvaed Limit includeing LIS Plus [primary + top-up + bg + LIS Plus]
//         totalApprovedLimitincludingLISPLUS = totalApprovedLimit + lISPlus;
//         this.loanDetailsModal.creditInfo.totalApprovedLimitincludingLISPLUS = totalApprovedLimitincludingLISPLUS;

//         // Total Applied  Limit for LIS 5
//         totalRequstedLimitSGD = this.loanDetailsModal.creditInfo.totalRequstedLimitSGD || 0;
//         // LIS 5 Approval Ratio (%)
//         lis5approvalratio = this.loanDetailsModal.creditInfo.LIS5ApprovalRatio || 0;

//         this.loanDetailsModal.creditInfo.totalApprovedPrimaryLimitInForce = (approvedPrimaryLimit + midTerm);
//         this.loanDetailsModal.creditInfo.totalApprovedAutoTopUpLimitInForce = (topUpLimit + midTerm);
//         this.loanDetailsModal.creditInfo.totalApprovedBGlimitInForce = (bgLimit + midTerm);
//         this.loanDetailsModal.creditInfo.totalApprovedLISPlusLimitInForce = (lISPlus + midTerm);
//         this.loanDetailsModal.creditInfo.totalApprovedLimitInForce = (totalApprovedLimitincludingLISPLUS + midTerm);

//         if (totalRequstedLimitSGD) {
//             lis5approvalratio = (Math.round(totalApprovedLimit * 100) / totalRequstedLimitSGD);
//             if (lis5approvalratio) {
//                 this.loanDetailsModal.creditInfo.LIS5ApprovalRatio = Number((lis5approvalratio).toFixed(2));
//             }
//         }
//     }

//     calculateLoanAmtforeignCurrency() {
//         // debugger;
//         let approvedPrimaryLimit: number;
//         let topUpLimit: number;
//         let bgLimit: number;
//         let lISPlus: number;

//         let midTerm: number = 0; // Mid-term application not yet completed, so meanwhile it is set as 0 value.
//         let totalApprovedLimit: number;
//         let totalRequstedLimitSGD: number;
//         let totalApprovedLimitincludingLISPLUS: number;
//         let lis5approvalratio: number;

//         approvedPrimaryLimit = this.loanDetailsModal.creditInfo.approvedPrimaryLayerForeignCurrency || 0;
//         topUpLimit = this.loanDetailsModal.creditInfo.approvedAutoTopUpLayerForeignCurrency || 0;
//         bgLimit = this.loanDetailsModal.creditInfo.approvedBgLayerForeignCurrency || 0;
//         lISPlus = this.loanDetailsModal.creditInfo.approvedSGDLimitLISPlusForeignCurrency || 0;

//         // get LIS5 Total Approvaed Limit [primary + top-up + bg]
//         totalApprovedLimit = (approvedPrimaryLimit + topUpLimit + bgLimit);
//         this.loanDetailsModal.creditInfo.lis5TotalApprovedLimitForeignCurrency = totalApprovedLimit;


//         // get LIS5 Total Approvaed Limit includeing LIS Plus [primary + top-up + bg + LIS Plus]
//         totalApprovedLimitincludingLISPLUS = totalApprovedLimit + lISPlus;
//         this.loanDetailsModal.creditInfo.totalApprovedLimitincludingLISPLUSForeignCurrency = totalApprovedLimitincludingLISPLUS;

//         // Total Applied Limit for LIS 5 of Foreign Currency Amount
//         totalRequstedLimitSGD = this.loanDetailsModal.creditInfo.totalRequstedLimitSGDForeignCurrency || 0;
//         // Approval Ratio With LIS PLUS (%)
//         lis5approvalratio = this.loanDetailsModal.creditInfo.approvalRatioWithLISPLUS || 0;

//         this.loanDetailsModal.creditInfo.totalApprovedPrimaryLimitInForceForeignCurrency = (approvedPrimaryLimit + midTerm);
//         this.loanDetailsModal.creditInfo.totalApprovedAutoTopUpLimitInForceForeignCurrency = (topUpLimit + midTerm);
//         this.loanDetailsModal.creditInfo.totalApprovedBGlimitInForceForeignCurrency = (bgLimit + midTerm);
//         this.loanDetailsModal.creditInfo.totalApprovedLISPlusLimitInForceForeignCurrency = (lISPlus + midTerm);
//         this.loanDetailsModal.creditInfo.totalApprovedLimitInForceForeignCurrency = (totalApprovedLimitincludingLISPLUS + midTerm);

//         if (totalRequstedLimitSGD) {
//             lis5approvalratio = (Math.round(totalApprovedLimit * 100) / totalRequstedLimitSGD);
//             if (lis5approvalratio) {
//                 this.loanDetailsModal.creditInfo.approvalRatioWithLISPLUS = Number((lis5approvalratio).toFixed(2));
//             }
//         }
//     }

//     onlyNumberKeyValue(event) {
//         return event.charCode >= 48 && event.charCode <= 57;
//     }

//     changeCRR() {
//         this.isExceptionalCrrRate = false;
//         this.loanDetailsModal.creditInfo.exceptionalCrrRate = null;
//         let crrRateValue = this.loanDetailsModal.creditInfo.borrowersCrr;
//         if (
//             crrRateValue &&
//             crrRateValue % 1 == 0 &&
//             crrRateValue > 0 &&
//             crrRateValue <= 15
//         ) {
//             if (this.cRRPremiumRateList) {
//                 this.cRRPremiumRateList.forEach((crrData) => {
//                     let fromLimit = crrData.from;
//                     let toLimit = crrData.to;
//                     // if (fromLimit || fromLimit < 0 || toLimit || toLimit < 0) { return; }
//                     if (crrRateValue >= fromLimit && crrRateValue <= toLimit) {
//                         this.loanDetailsModal.creditInfo.crrRate = crrData._id;
//                     }
//                 });
//             }
//         } else {
//             this.loanDetailsModal.creditInfo.borrowersCrr = null;
//             this.loanDetailsModal.creditInfo.crrRate = null;
//         }
//     }

//     changeNoCRR() {
//         this.isExceptionalCrrRate = false;
//         this.loanDetailsModal.creditInfo.borrowersCrr = 0;
//         this.loanDetailsModal.creditInfo.exceptionalCrrRate = null;
//     }

//     getCRRNonEditList() {
//         if (this.cRRPremiumRateList) {
//             return this.cRRPremiumRateList.filter(
//                 (data) => data.from > 0 && data.to > 0
//             );
//         }
//         return [];
//     }

//     getCRREditList() {
//         if (this.cRRPremiumRateList) {
//             return this.cRRPremiumRateList.find((data) => data.from <= 0);
//         }
//         return [];
//     }

//     setCRRValue(item: number) {
//         if (this.cRRPremiumRateList && this.cRRPremiumRateList[item]) {
//             return this.cRRPremiumRateList[item]._id;
//         } else {
//             return '';
//         }
//     }

//     setCRRLabel(item: number) {
//         if (this.cRRPremiumRateList && this.cRRPremiumRateList[item]) {
//             return this.cRRPremiumRateList[item].tierRatingDescription;
//         } else {
//             return '';
//         }
//     }

//     exceptionalCrrRateChange() {
//         this.isExceptionalCrrRate = true;
//         this.loanDetailsModal.creditInfo.borrowersCrr = null;
//     }

//     changeLisType() {
//         if (this.loanDetailsModal.creditInfo.lisType) {
//             switch (this.loanDetailsModal.creditInfo.lisType) {
//                 case 'new':
//                     this.loanDetailsModal.creditInfo.renewalFromSGDTxt = null;
//                     this.loanDetailsModal.creditInfo.renewalFromUSDTxt = null;
//                     this.loanDetailsModal.creditInfo.renewalToSGDTxt = null;
//                     this.loanDetailsModal.creditInfo.renewalToUSDTxt = null;
//                     this.loanDetailsModal.creditInfo.increaseLimitToSGD = null;
//                     this.loanDetailsModal.creditInfo.increaseLimitToUSD = null;
//                     this.loanDetailsModal.creditInfo.decreaseLimitToSGD = null;
//                     this.loanDetailsModal.creditInfo.decreaseLimitToUSD = null;
//                     break;
//                 case 'renewalAtSameAmount':
//                     this.loanDetailsModal.creditInfo.renewalFromSGDTxt = null;
//                     this.loanDetailsModal.creditInfo.renewalFromUSDTxt = null;
//                     this.loanDetailsModal.creditInfo.renewalToSGDTxt = null;
//                     this.loanDetailsModal.creditInfo.renewalToUSDTxt = null;
//                     this.loanDetailsModal.creditInfo.increaseLimitToSGD = null;
//                     this.loanDetailsModal.creditInfo.increaseLimitToUSD = null;
//                     this.loanDetailsModal.creditInfo.decreaseLimitToSGD = null;
//                     this.loanDetailsModal.creditInfo.decreaseLimitToUSD = null;
//                     break;
//                 case 'renewalFrom':
//                     this.loanDetailsModal.creditInfo.increaseLimitToSGD = null;
//                     this.loanDetailsModal.creditInfo.increaseLimitToUSD = null;
//                     this.loanDetailsModal.creditInfo.decreaseLimitToSGD = null;
//                     this.loanDetailsModal.creditInfo.decreaseLimitToUSD = null;
//                     break;
//                 case 'increaseLimitTo':
//                     this.loanDetailsModal.creditInfo.renewalFromSGDTxt = null;
//                     this.loanDetailsModal.creditInfo.renewalFromUSDTxt = null;
//                     this.loanDetailsModal.creditInfo.renewalToSGDTxt = null;
//                     this.loanDetailsModal.creditInfo.renewalToUSDTxt = null;
//                     this.loanDetailsModal.creditInfo.decreaseLimitToSGD = null;
//                     this.loanDetailsModal.creditInfo.decreaseLimitToUSD = null;
//                     break;
//                 case 'decreaseLimitTo':
//                     this.loanDetailsModal.creditInfo.renewalFromSGDTxt = null;
//                     this.loanDetailsModal.creditInfo.renewalFromUSDTxt = null;
//                     this.loanDetailsModal.creditInfo.renewalToSGDTxt = null;
//                     this.loanDetailsModal.creditInfo.renewalToUSDTxt = null;
//                     this.loanDetailsModal.creditInfo.increaseLimitToSGD = null;
//                     this.loanDetailsModal.creditInfo.increaseLimitToUSD = null;
//                     break;
//                 default:
//                     return true;
//             }
//         } else {
//         }
//     }

//     getSubmittedDocList() {
//         /** Get View document list */
//         this.supportingDocservice.getDocumentsByAppRefId(this.selectedLoanResult._id).subscribe(files => {
//             if (files) {
//                 this.documentList = [];
//                 let file: Document;
//                 files.forEach(element => {
//                     if (element) {
//                         file = new Document();
//                         file._id = element._id;
//                         file.filename = element.metadata.fileName;
//                         file.uploadDate = this.datePipe.transform(element.uploadDate, 'dd-MMM-yyy,h:mm:ss a');
//                         file.documentType = element.metadata.documentType;
//                         file.uploadedBy = element.metadata.uploadedBy;
//                         this.documentList.push(file);
//                     }
//                 });

//                 this.sort();
//             }
//         });
//     }

//     sort() {
//         this.documentList.sort(function (b, a) {
//             return new Date(a.uploadDate).getTime() - new Date(b.uploadDate).getTime()
//         });
//     }

//     // getDays() {
//     //     this.datediff(this.parseDate(first.value), this.parseDate(second.value))
//     // }

//     // parseDate(str) {
//     //     let mdy = str.split('/');
//     //     return new Date(mdy[2], mdy[0]-1, mdy[1]);
//     // }

//     // datediff(first, second) {
//     //     // Take the difference between the dates and divide by milliseconds per day.
//     //     // Round to nearest whole number to deal with DST.
//     //     return Math.round((second-first)/(1000*60*60*24));
//     // }
// }
