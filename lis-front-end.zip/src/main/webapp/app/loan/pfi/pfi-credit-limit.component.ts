import {
  Component,
  OnInit,
  OnDestroy,
  ElementRef,
  ViewChild,
  AfterViewChecked,
  ChangeDetectorRef
} from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription, Observer } from 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { NgForm } from '@angular/forms';
import { PFICreditLimit } from './pfi-credit-limit.model';
import { PFICreditLimitService } from './pfi-credit-limit.service';
import { LoanService } from '../loan.service';
import {
  Principal,
  FileUploadComponent,
  Account,
  LookupService,
  Currencies,
  Bank
} from '../../shared';
import { SponsorEForm } from '../sponsor-eform/sponsor-eform.model';
import { DateUtil } from '../../shared/date-formatter/date-util';
import { SponsorEFormService } from '../sponsor-eform/sponsor-eform.service';
import { ConfirmationService } from 'primeng/components/common/api';
import {
  NotificationService,
  NotificationOption
} from '../../shared/alert/notification.service';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import {
  PFILoan,
  LoanProcess,
  CompletedStep,
  SupportingDocuments
} from '../loan.model';
import { NgxSpinnerService } from 'ngx-spinner';
import {
  PFIMidTermCreditLimit,
  PFIMidTermLoan
} from '../mid-term/mid-term.model';
import { MidTermService } from '../mid-term/mid-term.service';

@Component({
  selector: 'lis-pfi-credit-limit',
  templateUrl: './pfi-credit-limit.component.html'
})
export class PFICreditLimitComponent
  implements OnInit, OnDestroy, AfterViewChecked {
  @ViewChild('creditForm')
  creditForm: NgForm;
  loanProcess: LoanProcess;
  filesToUpload: Array<File> = [];
  data: any = [];
  pfiCreditLimit: any;
  sponsorForm: SponsorEForm = new SponsorEForm();
  pfiLoan: any;
  eventSubscriber: Subscription;
  routeData: any;
  links: any;
  totalItems: any;
  queryCount: any;
  itemsPerPage: any;
  page: any;
  predicate: any;
  previousPage: any;
  reverse: any;
  loanId = '';
  currentAccount: Account;
  currencyList: Currencies[];
  disableFutureDate = new Date();
  bank: Bank;
  userid: string;
  dlResult: boolean;
  baseLoan: PFILoan;
  discretionaryLimitAmount: number;
  bankersGuaranteeAmount: number;
  collectionType: string;
  manageDoc = { name: '', documentType: '' };
  approvedBGLayer = 0;
  popUp: boolean;
  sponsorFormSubscription: Subscription;
  loanProcessSubscription: Subscription;
  isAlldocumentUploaded = false;

  constructor(
    private cdr: ChangeDetectorRef,
    private sponsorEFormService: SponsorEFormService,
    private pfiCreditService: PFICreditLimitService,
    private midTermService: MidTermService,
    private parseLinks: JhiParseLinks,
    private jhiAlertService: JhiAlertService,
    private eventManager: JhiEventManager,
    private principal: Principal,
    private loanService: LoanService,
    private router: Router,
    private route: ActivatedRoute,
    private lookUpService: LookupService,
    private _eref: ElementRef,
    private notificationService: NotificationService,
    private spinner: NgxSpinnerService,
    private confirmationService: ConfirmationService
  ) {
    this.loanProcessSubscription = this.loanService.loanProcess$.subscribe(
      loanProcess => {
        this.loanProcess = Object.assign({}, loanProcess);
      }
    );
    this.sponsorFormSubscription = this.sponsorEFormService.springEForm$.subscribe(
      sponsorForm => {
        this.sponsorForm = sponsorForm;
      }
    );
    this.principal.identity().then(account => {
      if (account) {
        this.currentAccount = account;
        this.userid = this.currentAccount.login;
      }
    });
  }

  ngAfterViewChecked() {
    // console.dir(this.pfIForm.form);
    if (this.loanProcess.isViewLoan) {
      this.creditForm.form.disable();
      this.cdr.detectChanges();
    }
  }

  ngOnInit() {
    this.popUp = false;
    if (this.loanProcess) {
      if (this.loanProcess.isMidTerm) {
        this.collectionType = 'MIDTERM';
        this.pfiCreditLimit = new PFIMidTermCreditLimit();
        if (this.loanProcess.id) {
          this.midTermService
            .getMidTermLoanById(this.loanProcess.id)
            .subscribe((loanResult: any) => {
              if (loanResult) {
                if (loanResult.sponsorForm.dateofIncorporation) {
                  this.pfiCreditLimit = loanResult.creditInfo;
                }
                this.baseLoan = new PFILoan();
                if (this.loanProcess.loanBaseId) {
                  this.loanService
                    .getLoanById(this.loanProcess.loanBaseId)
                    .subscribe((loanbaseResult: any) => {
                      if (loanbaseResult) {
                        this.baseLoan = loanbaseResult;
                        if (!loanResult.sponsorForm.dateofIncorporation) {
                          this.autoPopulateBaseLoan();
                        }
                      }
                    });
                }
                if (!this.pfiCreditLimit.preshipmentApprovalChkBx) {
                  this.pfiCreditLimit.preshipmentApprovalChkBx = false;
                }
                if (!this.pfiCreditLimit.companySearchesChkBx) {
                  this.pfiCreditLimit.companySearchesChkBx = false;
                }
                if (!this.pfiCreditLimit.pfiInternalCreditChkBx) {
                  this.pfiCreditLimit.pfiInternalCreditChkBx = false;
                }
                if (!this.pfiCreditLimit.latestAuditedChkBx) {
                  this.pfiCreditLimit.latestAuditedChkBx = false;
                }
                if (!this.pfiCreditLimit.latestSignedChkBx) {
                  this.pfiCreditLimit.latestSignedChkBx = false;
                }
                if (!this.pfiCreditLimit.forOverseasChkBx) {
                  this.pfiCreditLimit.forOverseasChkBx = false;
                }
                this.pfiCreditLimit.pfiName = loanResult.creditInfo.pfiName;
                this.pfiCreditLimit.pfiCode = loanResult.creditInfo.pfiCode;
                this.validateDocuments();
                this.setDateFormat();
              }
            });
        }
      } else {
        this.collectionType = 'LOAN';
        this.pfiCreditLimit = new PFICreditLimit();
        if (this.loanProcess.id) {
          this.loanService
            .getLoanById(this.loanProcess.id)
            .subscribe((loanResult: any) => {
              if (loanResult) {
                if (loanResult.sponsorForm.dateofIncorporation) {
                  this.pfiCreditLimit = loanResult.creditInfo;
                  this.setDateFormat();
                }
                this.validateDocuments();
                this.pfiCreditLimit.pfiName = loanResult.creditInfo.pfiName;
                this.pfiCreditLimit.pfiCode = loanResult.creditInfo.pfiCode;
              }
            });
        }
      }
    }

    // this.pfiCreditService.pfiCreditLimit$.subscribe((pfiForm) => {
    //   this.pfiCreditLimit = pfiForm;
    //   this.setDateFormat();
    // });
    this.lookUpService.getCurrencyList().subscribe(data => {
      this.currencyList = data;
    });

    this.lookUpService.getLimitDetails().subscribe(limitData => {
      if (limitData) {
        limitData.forEach(limit => {
          if (limit.applicationType === 'Discretionary limit') {
            this.discretionaryLimitAmount = limit.maximumLimit / 1000000;
          } else if (limit.applicationType === 'Bankers Guarantee') {
            this.bankersGuaranteeAmount = limit.maximumLimit / 1000000;
          }
        });
      }
    });

    if (
      this.loanProcess.isSponsorUploaded &&
      this.loanProcess.completedStep !== CompletedStep.stepCompleted
    ) {
      this.autoPopulateFromSponser();
    }
  }

  setDateFormat() {
    if (this.pfiCreditLimit.submissionDate) {
      this.pfiCreditLimit.submissionDate = new Date(
        this.pfiCreditLimit.submissionDate
      );
    }
    if (this.pfiCreditLimit.latestSignedDt) {
      this.pfiCreditLimit.latestSignedDt = new Date(
        this.pfiCreditLimit.latestSignedDt
      );
    }
    if (this.pfiCreditLimit.latestAuditedDt) {
      this.pfiCreditLimit.latestAuditedDt = new Date(
        this.pfiCreditLimit.latestAuditedDt
      );
    }
  }

  add() {
    if (this.pfiCreditLimit.borrowersGroup) {
      if (this.pfiCreditLimit.borrowersGroup.length < 99) {
        this.pfiCreditLimit.borrowersGroup.push({ name: '' });
      } else {
        alert('99 Borrowers Group can be added.!');
      }
    }
  }

  remove() {
    if (this.pfiCreditLimit.borrowersGroup) {
      this.pfiCreditLimit.borrowersGroup.pop();
    }
  }

  removeMe(me) {
    for (var i = 0; this.pfiCreditLimit.borrowersGroup.length; i++) {
      let borrower = this.pfiCreditLimit.borrowersGroup[i];
      if (borrower['name'] === me.name) {
        this.pfiCreditLimit.borrowersGroup.splice(i, 1);
        return;
      }
    }
  }

  private onSaveError() {}

  private autoPopulateBaseLoan() {
    if (this.baseLoan && this.baseLoan.creditInfo) {
      this.pfiCreditLimit.foreignCurrency = this.baseLoan.creditInfo.foreignCurrency;
      this.pfiCreditLimit.foreignCurrencyAmount = this.baseLoan.creditInfo.foreignCurrencyAmount;
      this.pfiCreditLimit.exRate = this.baseLoan.creditInfo.exRate;
      this.pfiCreditLimit.primary = this.baseLoan.creditInfo.primary;
      this.pfiCreditLimit.autoTopUp = this.baseLoan.creditInfo.autoTopUp;
      this.pfiCreditLimit.bg = this.baseLoan.creditInfo.bg;
      this.pfiCreditLimit.lisPlus = this.baseLoan.creditInfo.lisPlus;
      this.pfiCreditLimit.approvedPrimaryLayer = this.baseLoan.creditInfo.approvedPrimaryLayer;
      this.pfiCreditLimit.approvedBgLayer = this.baseLoan.creditInfo.approvedBgLayer;

      if (
        !this.loanProcess.isMidTermIncrease &&
        this.collectionType !== 'LOAN'
      ) {
        this.pfiCreditLimit.borrowerRegName = this.baseLoan.creditInfo.borrowerRegName;
        this.pfiCreditLimit.aCRArefNo = this.baseLoan.creditInfo.aCRArefNo;
        this.pfiCreditLimit.totalRequstedLimitSGD = this.baseLoan.creditInfo.totalRequstedLimitSGD;

        this.pfiCreditLimit.inventoryTradeTxt = this.baseLoan.creditInfo.inventoryTradeTxt;
        this.pfiCreditLimit.inventoryTradeChkBx = this.baseLoan.creditInfo.inventoryTradeChkBx;

        this.pfiCreditLimit.structuredWorkingCapTxt = this.baseLoan.creditInfo.structuredWorkingCapTxt;
        this.pfiCreditLimit.workingCapChkBx = this.baseLoan.creditInfo.workingCapChkBx;

        this.pfiCreditLimit.resourceFactoringTxt = this.baseLoan.creditInfo.resourceFactoringTxt;
        this.pfiCreditLimit.resourceFactoringChkBx = this.baseLoan.creditInfo.resourceFactoringChkBx;

        this.pfiCreditLimit.overseaseWorkingTxt = this.baseLoan.creditInfo.overseaseWorkingTxt;
        this.pfiCreditLimit.overseaseWorkingChkBx = this.baseLoan.creditInfo.overseaseWorkingChkBx;

        this.pfiCreditLimit.bankersGuaranteeTxt = this.baseLoan.creditInfo.bankersGuaranteeTxt;
        this.pfiCreditLimit.bankersGuaranteeChkBx = this.baseLoan.creditInfo.bankersGuaranteeChkBx;
      }
    }
  }

  private autoPopulateFromSponser() {
    if (this.sponsorForm) {
      this.pfiCreditLimit.borrowerRegName = this.sponsorForm.regComName;
      this.pfiCreditLimit.aCRArefNo = this.sponsorForm.ACRANo;
      this.pfiCreditLimit.totalRequstedLimitSGD = null;
      this.pfiCreditLimit.totalRequstedLimitSGD = this.sponsorForm.total;

      this.pfiCreditLimit.inventoryTradeTxt = this.sponsorForm.invStockFinancing;
      this.pfiCreditLimit.inventoryTradeChkBx = this.sponsorForm.invStockFinancingChecked;

      this.pfiCreditLimit.structuredWorkingCapTxt = this.sponsorForm.workingCapital;
      this.pfiCreditLimit.workingCapChkBx = this.sponsorForm.workingCapitalChecked;

      this.pfiCreditLimit.resourceFactoringTxt = this.sponsorForm.aRDiscount;
      this.pfiCreditLimit.resourceFactoringChkBx = this.sponsorForm.aRDiscountChecked;

      this.pfiCreditLimit.overseaseWorkingTxt = this.sponsorForm.capitalLoan;
      this.pfiCreditLimit.overseaseWorkingChkBx = this.sponsorForm.capitalLoanChecked;

      this.pfiCreditLimit.bankersGuaranteeTxt = this.sponsorForm.bankerGuarantee;
      this.pfiCreditLimit.bankersGuaranteeChkBx = this.sponsorForm.bankerGuaranteeChecked;
    }
  }

  ngOnDestroy() {
    this.notificationService.clearNotification();
    if (this.sponsorFormSubscription) {
      this.sponsorFormSubscription.unsubscribe();
    }
    if (this.loanProcessSubscription) {
      this.loanProcessSubscription.unsubscribe();
    }
  }

  private onError(error) {
    this.jhiAlertService.error(error.message, null, null);
  }

  updateStack(uploadedFile, supportDoc) {
    if (supportDoc === 'borrowerGroup') {
      return;
    }

    this.pfiCreditLimit.supportingDocs.forEach(element => {
      if (element.name === supportDoc) {
        element.status = true;
        if (element.files && element.files != '') {
          element.files += ', ' + uploadedFile.filename;
        } else {
          element.files = uploadedFile.filename + ' ';
        }
      }
    });
  }

  validateDocuments() {
    if (
      this.pfiCreditLimit.preshipmentApprovalChkBx &&
      this.pfiCreditLimit.companySearchesChkBx &&
      this.pfiCreditLimit.pfiInternalCreditChkBx &&
      this.pfiCreditLimit.latestAuditedChkBx &&
      this.pfiCreditLimit.latestSignedChkBx &&
      (this.pfiCreditLimit.inventoryTradeChkBx === true ||
        this.pfiCreditLimit.workingCapChkBx === true ||
        this.pfiCreditLimit.resourceFactoringChkBx === true ||
        this.pfiCreditLimit.overseaseWorkingChkBx === true)
    ) {
      this.isAlldocumentUploaded = true;
    } else {
      this.isAlldocumentUploaded = false;
    }
  }

  isSupportingDocValidate() {
    let errorDoc = false;
    const notificationOption = new NotificationOption();
    notificationOption.title = '';
    notificationOption.clear = false;
    notificationOption.type = 'error';
    notificationOption.toastrConfig = {
      positionClass: 'toast-bottom-right',
      disableTimeOut: true
    };
    let errorMessage = 'Please upload document for ';
    this.notificationService.clearNotification();

    this.pfiCreditLimit.supportingDocs.forEach(element => {
      let field = element.name;
      switch (field) {
        case 'overseasCapital':
          if (!element.status && this.pfiCreditLimit.overseaseWorkingChkBx) {
            notificationOption.message =
              errorMessage +
              'Overseas Working Capital Loans Support in section 1';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;

        case 'preshipmentApproval':
          if (!element.status && this.pfiCreditLimit.preshipmentApprovalChkBx) {
            notificationOption.message =
              errorMessage + 'Pre-shipment approval is required';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;

        case 'sponsersApplication':
          if (!element.status && this.pfiCreditLimit.lisSponsersApplChkBx) {
            notificationOption.message =
              errorMessage + 'Sponsors’ Application Form';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;

        case 'companySearches':
          if (!element.status && this.pfiCreditLimit.companySearchesChkBx) {
            notificationOption.message =
              errorMessage + 'Company searches and/or individual searches';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;

        case 'pfiInternalCreditMemo':
          if (!element.status && this.pfiCreditLimit.pfiInternalCreditChkBx) {
            notificationOption.message =
              errorMessage + 'PFI’s internal Credit Memo Approval';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;

        case 'latestAudited':
          if (!element.status && this.pfiCreditLimit.latestAuditedChkBx) {
            notificationOption.message =
              errorMessage + 'Latest Audited Financials from Borrower';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;

        case 'latestSigned':
          if (!element.status && this.pfiCreditLimit.latestSignedChkBx) {
            notificationOption.message =
              errorMessage + 'Latest signed Management Accounts from Borrower';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;

        case 'additionalItems':
          if (!element.status && this.pfiCreditLimit.additionalItemChkBx) {
            notificationOption.message = errorMessage + 'Additional Items';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;

        case 'overseasCapital2':
          if (!element.status && this.pfiCreditLimit.forOverseasChkBx) {
            notificationOption.message =
              errorMessage + 'Oversease working capital in section 3.';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;
      }
    });

    if (errorDoc) {
      return false;
    } else {
      return true;
    }
  }

  validateExchangeCurrency() {
    if (
      this.pfiCreditLimit.foreignCurrencyAmount &&
      !this.pfiCreditLimit.exRate
    ) {
      const notificationOption = new NotificationOption();
      notificationOption.title = 'Error';
      notificationOption.message =
        'Please enter currency exchange rate as well.';
      notificationOption.type = 'error';
      this.notificationService.showNotification(notificationOption);
      return false;
    } else if (
      !this.pfiCreditLimit.foreignCurrencyAmount &&
      this.pfiCreditLimit.exRate
    ) {
      const notificationOption = new NotificationOption();
      notificationOption.title = 'Error';
      notificationOption.message =
        'Please enter Foreign Currency Amount to endorse.';
      notificationOption.type = 'error';
      this.notificationService.showNotification(notificationOption);

      return false;
    } else if (
      this.pfiCreditLimit.foreignCurrencyAmount &&
      this.pfiCreditLimit.exRate
    ) {
      if (!this.pfiCreditLimit.foreignCurrency) {
        const notificationOption = new NotificationOption();
        notificationOption.title = 'Error';
        notificationOption.message = 'Please select Foreign Currency type.';
        notificationOption.type = 'error';
        this.notificationService.showNotification(notificationOption);

        //alert('Please select Foreign Currency type.');
        return false;
      }
    }
    return true;
  }

  onlyNumberKey(event) {
    return event.charCode == 8 || event.charCode == 0 || event.charCode == 46
      ? null
      : event.charCode >= 48 && event.charCode <= 57;
    //|| event.charCode == 44
  }

  goToUploadForm() {
    this.pfiCreditService.setPFICreditLimit(this.pfiCreditLimit);
    this.router.navigate(['../../sponsor-eform-upload'], {
      relativeTo: this.route
    });
  }

  saveAsDraft() {
    this.updateLoan();
  }

  async updateLoan(status?: string) {
    this.setValidSponsorValue();

    if (this.loanProcess.isMidTerm) {
      this.pfiLoan = new PFIMidTermLoan();
      this.pfiLoan.isMidTermIncrease = this.loanProcess.isMidTermIncrease;
    } else {
      this.pfiLoan = new PFILoan();
    }
    this.pfiLoan._id = this.loanProcess.id;
    this.pfiCreditLimit.appliedAmountDL =
      this.pfiCreditLimit.totalRequstedLimitSGD -
      this.pfiCreditLimit.bankersGuaranteeTxt;

    let requestType;
    if (this.pfiCreditLimit.requestLimit == 'afterMidTempIncrease') {
      requestType = this.pfiCreditLimit.afterMidTempIncreaseTxt;
    }
    if (this.pfiCreditLimit.requestLimit == 'afterTempIncrease') {
      requestType = this.pfiCreditLimit.afterTempIncreaseTxt;
    }
    if (this.pfiCreditLimit.requestLimit == 'beforeMidTempIncrease') {
      requestType = this.pfiCreditLimit.beforeMidTempIncreaseTxt;
    }
    if (this.pfiCreditLimit.requestLimit == 'afterMidTempDecrease') {
      requestType = this.pfiCreditLimit.afterMidTempDecreaseTxt;
    }
    if (this.pfiCreditLimit.requestLimit == 'beforeMidTempDecrease') {
      requestType = this.pfiCreditLimit.beforeMidTempDecreaseTxt;
    }

    if (!isNaN(this.pfiCreditLimit.approvedBgLayer)) {
      this.approvedBGLayer = this.pfiCreditLimit.approvedBgLayer;
    }

    if (this.pfiLoan.isMidTermIncrease) {
      console.log(
        requestType +
          '/' +
          this.pfiCreditLimit.bankersGuaranteeTxt +
          '/' +
          this.approvedBGLayer
      );
      this.pfiCreditLimit.appliedIncAmountDL =
        requestType -
        (this.pfiCreditLimit.bankersGuaranteeTxt - this.approvedBGLayer);
      console.log(
        'this.pfiCreditLimit.appliedIncAmountDL=' +
          this.pfiCreditLimit.appliedIncAmountDL
      );
      this.pfiCreditLimit.appliedIncAmountBG =
        this.pfiCreditLimit.bankersGuaranteeTxt - this.approvedBGLayer;
      console.log(
        'this.pfiCreditLimit.appliedIncAmountBG=' +
          this.pfiCreditLimit.appliedIncAmountBG
      );
      console.log(
        this.pfiCreditLimit.bankersGuaranteeTxt + '/' + this.approvedBGLayer
      );
    } else {
      this.pfiCreditLimit.appliedIncAmountDL =
        requestType -
        (this.approvedBGLayer - this.pfiCreditLimit.bankersGuaranteeTxt);
      this.pfiCreditLimit.appliedIncAmountBG =
        this.approvedBGLayer - this.pfiCreditLimit.bankersGuaranteeTxt;
    }

    this.pfiLoan.creditInfo = this.pfiCreditLimit;
    this.pfiLoan.sponsorForm = this.sponsorForm;
    this.loanService.pfiData = this.pfiLoan;
    // TODO: Need to add logic for app
    //this.pfiLoan.app = 3;

    if (this.loanProcess.id) {
      if (status) {
        // if (!this.validateExchangeCurrency()) {
        //   this.spinner.hide();
        //   return false;
        // }
        if (!this.isSupportingDocValidate()) {
          return;
        }
        if (!this.checkTotalAmount()) {
          return;
        }
        if (this.loanProcess.isMidTerm) {
          if (!this.checkRequestTypeAmount()) {
            return;
          }
        }

        // if (!this.validateDocumentSubmit()) {
        //   return;
        // }

        let loanType;
        if (this.loanProcess.isMidTerm) {
          loanType = 'MIDTERM';
        } else {
          loanType = 'LOAN';
        }
        console.log('loanType:' + loanType);
        const dlResult = await this.dlValidation(this.pfiLoan, loanType)
          .first()
          .toPromise();
        console.log('DL Final:: ' + dlResult);

        if (dlResult) {
          const bgvalid = await this.bgValidation(this.pfiLoan, loanType)
            .first()
            .toPromise();
          console.log('BG Final:: ' + bgvalid);
          if (!bgvalid) {
            return;
          }
        } else {
          return;
        }
        // }
        this.spinner.show();
        this.pfiLoan.status = status;
        if (this.loanProcess.isMidTerm) {
          let marshRefNoSubpart;
          if (this.baseLoan.marshRefNo) {
            marshRefNoSubpart = this.baseLoan.marshRefNo.split('/');
          }
          const masrshRefNo = parseInt(marshRefNoSubpart[1], 10) + 1;
          if (masrshRefNo < 10) {
            this.pfiLoan.marshRefNo = marshRefNoSubpart[0] + '/0' + masrshRefNo;
          } else {
            this.pfiLoan.marshRefNo = marshRefNoSubpart[0] + '/' + masrshRefNo;
          }

          if (!this.pfiLoan.createdDate) {
            this.pfiLoan.createdDate = new Date();
          }
          this.midTermService
            .submitMidTermLoan(this.pfiLoan)
            .subscribe(loanResult => {
              if (loanResult) {
                this.submitConfig(loanResult);
              }
            });
        } else {
          this.loanService.submitLoan(this.pfiLoan).subscribe(loanResult => {
            if (loanResult) {
              this.submitConfig(loanResult);
            }
          });
        }
      } else {
        if (this.loanProcess.isMidTerm) {
          this.midTermService.updateMidTermLoan(this.pfiLoan).subscribe(
            res => {
              //this.creditForm.form.markAsPristine();
              this.notificationService.showNotification();
            },
            error => {}
          );
        } else {
          this.loanService.updateLoan(this.pfiLoan).subscribe(
            res => {
              //this.creditForm.form.markAsPristine();
              this.notificationService.showNotification();
            },
            error => {}
          );
        }
      }
    }
  }

  submitLoan() {
    if (this.isAlldocumentUploaded) {
      this.updateLoan('Processing');
    } else {
      const notificationOption = new NotificationOption();
      notificationOption.toastrConfig = {
        positionClass: 'toast-bottom-right'
      };
      notificationOption.title = 'Error';
      notificationOption.message = 'Upload all the required documents.';
      notificationOption.type = 'error';
      this.notificationService.showNotification(notificationOption);
    }
  }

  submitConfig(loanResult: any) {
    const loanProcess = this.loanProcess;
    loanProcess.status = loanResult.status;
    loanProcess.completedStep = CompletedStep.stepCompleted;
    loanProcess.marshRefNo = loanResult.marshRefNo;
    loanProcess.isViewLoan = true;
    this.loanProcess = Object.assign({}, loanProcess);
    this.loanService.setLoanStepProcess(this.loanProcess);
    //this.loanService.setStatus(loanResult.status);
    //window.scrollTo(0, 0);
    this.spinner.hide();
    const notificationOption = new NotificationOption();
    notificationOption.toastrConfig = {
      positionClass: 'toast-top-right'
    };
    notificationOption.title = 'Notification';
    notificationOption.message = 'Application Submitted Successfully';
    this.notificationService.showNotification(notificationOption);
    //this.creditForm.form.markAsPristine();
    this.router.navigate(['../../submitted'], {
      relativeTo: this.route
    });
  }

  dlValidation(loanData: any, loanType: any): Observable<boolean> {
    return Observable.create((observer: Observer<boolean>) => {
      this.loanService
        .dlValidation(Object.assign({}, loanData), loanType)
        .subscribe(
          res => {
            this.dlResult = res;
            if (this.dlResult === false) {
              // Confirmation: This application shall be submitted as a DL application, instead of CL.Do you still want to continue?”
              this.confirmationService.confirm({
                message:
                  ' This application shall be submitted as a CL application, instead of DL.Do you still want to continue? ',
                header: 'Confirmation',
                icon: 'fa fa-times',
                accept: () => {
                  observer.next(true);
                  observer.complete();
                },
                reject: () => {
                  observer.next(false);
                  observer.complete();
                }
              });
            } else {
              observer.next(true);
              observer.complete();
            }
          },
          error => {
            observer.next(false);
            observer.complete();
          }
        );
    });
  }

  bgValidation(loanData: any, loanType: any): Observable<boolean> {
    return Observable.create((observer: Observer<boolean>) => {
      this.loanService
        .bgValidation(Object.assign({}, loanData), loanType)
        .subscribe(
          res => {
            const bgResult = res;
            console.log(bgResult.message);
            if (bgResult.message === 'BG1V_Fail') {
              const notificationOption = new NotificationOption();
              notificationOption.toastrConfig = {
                positionClass: 'toast-bottom-right',
                disableTimeOut: true
              };
              notificationOption.title = 'Error';
              notificationOption.message =
                ' Applied BG is more than the 50% of Trade Facilities Limit, You cannot submit this application';
              notificationOption.type = 'error';

              this.notificationService.showNotification(notificationOption);
              observer.next(false);
              observer.complete();
            } else if (
              bgResult.message === 'BG2V_Fail' &&
              this.dlResult === true
            ) {
              this.confirmationService.confirm({
                message:
                  ' This application shall be submitted as a CL application, instead of DL.Do you still want to continue? ',
                header: 'Confirmation',
                icon: 'fa fa-times',
                accept: () => {
                  observer.next(true);
                  observer.complete();
                },
                reject: () => {
                  observer.next(false);
                  observer.complete();
                }
              });
            } else {
              observer.next(true);
              observer.complete();
            }
          },
          error => {
            observer.next(false);
            observer.complete();
          }
        );
    });
  }

  setValidSponsorValue() {
    this.sponsorForm.invStockFinancing =
      this.sponsorForm.invStockFinancing == null
        ? 0
        : this.sponsorForm.invStockFinancing;
    this.sponsorForm.workingCapital =
      this.sponsorForm.workingCapital == null
        ? 0
        : this.sponsorForm.workingCapital;
    this.sponsorForm.aRDiscount =
      this.sponsorForm.aRDiscount == null ? 0 : this.sponsorForm.aRDiscount;
    this.sponsorForm.capitalLoan =
      this.sponsorForm.capitalLoan == null ? 0 : this.sponsorForm.capitalLoan;
    this.sponsorForm.bankerGuarantee =
      this.sponsorForm.bankerGuarantee == null
        ? 0
        : this.sponsorForm.bankerGuarantee;
  }

  confirmChange(mode: string) {
    let messageText: string;
    let detailsText: string;

    switch (mode) {
      case 'TotalLimit':
        if (
          this.pfiCreditLimit.totalRequstedLimitSGD === this.sponsorForm.total
        ) {
          return;
        }
        messageText =
          'Total Requested limit amount entered is different from total limits mentioned in Sponsor form section. Do you still want to continue?';
        detailsText = 'Total Request Limit amount will be saved';
        break;
      case 'Inventory':
        if (
          this.pfiCreditLimit.inventoryTradeTxt ===
          this.sponsorForm.invStockFinancing
        ) {
          return;
        }
        messageText =
          'Inventory / Stock Financing entered is different from Sponsor form section. Do you still want to continue?';
        detailsText = 'Inventory / Stock Financing amount will be saved';
        break;
      case 'Structured':
        if (
          this.pfiCreditLimit.structuredWorkingCapTxt ===
          this.sponsorForm.workingCapital
        ) {
          return;
        }
        messageText =
          'Structured Pre-delivery Working Capital entered is different from Sponsor form section. Do you still want to continue?';
        detailsText =
          'Structured Pre-delivery Working Capital amount will be saved';
        break;
      case 'Recourse':
        if (
          this.pfiCreditLimit.resourceFactoringTxt ===
          this.sponsorForm.aRDiscount
        ) {
          return;
        }
        messageText = `With Recourse for: Factoring / Bill or Invoice / AR Discounting entered is different from Sponsor 
          form section. Do you still want to continue?`;
        detailsText =
          'Recourse for: Factoring / Bill or Invoice / AR Discounting amount will be saved';
        break;
      case 'Overseas':
        if (
          this.pfiCreditLimit.overseaseWorkingTxt ===
          this.sponsorForm.capitalLoan
        ) {
          return;
        }
        messageText =
          'Overseas Working Capital Loans Support entered is different from Sponsor form section. Do you still want to continue?';
        detailsText =
          'Overseas Working Capital Loans Support amount will be saved';
        break;
      case 'BG':
        if (
          this.pfiCreditLimit.bankersGuaranteeTxt ===
          this.sponsorForm.bankerGuarantee
        ) {
          return;
        }
        messageText =
          'Banker’s Guarantee entered is different from Sponsor form section. Do you still want to continue?';
        detailsText = 'Banker’s Guarantee amount will be saved';
        break;
    }

    this.confirmationService.confirm({
      message: messageText,
      header: 'Confirmation',
      icon: 'fa fa-times',
      accept: () => {
        const notificationOption = new NotificationOption();
        notificationOption.title = 'Notification';
        notificationOption.message = detailsText;
        notificationOption.type = 'info';
        this.notificationService.showNotification(notificationOption);
      },
      reject: () => {
        switch (mode) {
          case 'TotalLimit':
            this.pfiCreditLimit.totalRequstedLimitSGD = this.sponsorForm.total;
            break;
          case 'Inventory':
            this.pfiCreditLimit.inventoryTradeTxt = this.sponsorForm.invStockFinancing;
            break;
          case 'Structured':
            this.pfiCreditLimit.structuredWorkingCapTxt = this.sponsorForm.workingCapital;
            break;
          case 'Recourse':
            this.pfiCreditLimit.resourceFactoringTxt = this.sponsorForm.aRDiscount;
            break;
          case 'Overseas':
            this.pfiCreditLimit.overseaseWorkingTxt = this.sponsorForm.capitalLoan;
            break;
          case 'BG':
            this.pfiCreditLimit.bankersGuaranteeTxt = this.sponsorForm.bankerGuarantee;
            break;
        }
      }
    });
  }

  checkTotalAmount() {
    let addedAmountTotal: number = 0;
    let totalRequstedLimitSGD: number = this.pfiCreditLimit
      .totalRequstedLimitSGD;
    if (
      this.pfiCreditLimit.inventoryTradeTxt &&
      this.pfiCreditLimit.inventoryTradeTxt > 0
    ) {
      addedAmountTotal += this.pfiCreditLimit.inventoryTradeTxt;
    }

    if (
      this.pfiCreditLimit.structuredWorkingCapTxt &&
      this.pfiCreditLimit.structuredWorkingCapTxt > 0
    ) {
      addedAmountTotal += this.pfiCreditLimit.structuredWorkingCapTxt;
    }

    if (
      this.pfiCreditLimit.resourceFactoringTxt &&
      this.pfiCreditLimit.resourceFactoringTxt > 0
    ) {
      addedAmountTotal += this.pfiCreditLimit.resourceFactoringTxt;
    }

    if (
      this.pfiCreditLimit.overseaseWorkingTxt &&
      this.pfiCreditLimit.overseaseWorkingTxt > 0
    ) {
      addedAmountTotal += this.pfiCreditLimit.overseaseWorkingTxt;
    }

    if (
      this.pfiCreditLimit.bankersGuaranteeTxt &&
      this.pfiCreditLimit.bankersGuaranteeTxt > 0
    ) {
      addedAmountTotal += this.pfiCreditLimit.bankersGuaranteeTxt;
    }
    if (addedAmountTotal != totalRequstedLimitSGD) {
      const notificationOption = new NotificationOption();
      notificationOption.toastrConfig = {
        positionClass: 'toast-bottom-right',
        disableTimeOut: true
      };
      notificationOption.title = 'Error';
      notificationOption.message =
        'LIS 5 Trade facilities total to be different from the value available for PFI Total Requested limit total';
      notificationOption.type = 'error';

      this.notificationService.showNotification(notificationOption);
      return false;
    }
    return true;
  }

  checkRequestTypeAmount() {
    let requestedAmount = 0;
    const totalRequstedLimitSGD: number = this.pfiCreditLimit
      .totalRequstedLimitSGD;
    const primaryAmount: number = this.pfiCreditLimit.primary || 0;
    const autoTopUpAmount: number = this.pfiCreditLimit.autoTopUp || 0;
    const bgAmount: number = this.pfiCreditLimit.bg || 0;
    const lisPlusAmount: number = this.pfiCreditLimit.lisPlus || 0;
    if (this.pfiCreditLimit.requestLimit) {
      switch (this.pfiCreditLimit.requestLimit) {
        case 'afterTempIncrease':
          requestedAmount = this.pfiCreditLimit.afterTempIncreaseTxt;
          const percentageValue = (primaryAmount * 25) / 100;
          if (requestedAmount > percentageValue) {
            const notificationOption = new NotificationOption();
            notificationOption.toastrConfig = {
              positionClass: 'toast-bottom-right',
              disableTimeOut: true
            };
            notificationOption.title = 'Error';
            notificationOption.message =
              'Amount entered in Temp - Increase Limit should be equal or lesser than 25 % of Primary Approved limit';
            notificationOption.type = 'error';

            this.notificationService.showNotification(notificationOption);
            return false;
          }
          break;
        case 'afterMidTempIncrease':
          requestedAmount = this.pfiCreditLimit.afterMidTempIncreaseTxt;
          break;
        case 'afterMidTempDecrease':
          requestedAmount = this.pfiCreditLimit.afterMidTempDecreaseTxt;
          break;
        case 'beforeMidTempIncrease':
          requestedAmount = this.pfiCreditLimit.beforeMidTempIncreaseTxt;
          break;
        case 'beforeMidTempDecrease':
          requestedAmount = this.pfiCreditLimit.beforeMidTempDecreaseTxt;
          break;
      }
    }

    if (this.loanProcess.isMidTermIncrease) {
      requestedAmount =
        requestedAmount +
        primaryAmount +
        autoTopUpAmount +
        bgAmount +
        lisPlusAmount;
    } else {
      requestedAmount = Math.abs(
        primaryAmount +
          autoTopUpAmount +
          bgAmount +
          lisPlusAmount -
          requestedAmount
      );
    }

    if (requestedAmount !== totalRequstedLimitSGD) {
      const notificationOption = new NotificationOption();
      notificationOption.toastrConfig = {
        positionClass: 'toast-bottom-right',
        disableTimeOut: true
      };
      notificationOption.title = 'Error';
      notificationOption.message = `Current Mid term /Temp ${
        this.loanProcess.isMidTermIncrease ? 'Increase' : 'Decrease'
      } total limit to be different from the value available for PFI Total Requested limit total`;
      notificationOption.type = 'error';

      this.notificationService.showNotification(notificationOption);
      return false;
    }

    return true;
  }

  onChangeCurrency() {
    if (this.pfiCreditLimit.foreignCurrency == '-1') {
      this.pfiCreditLimit.foreignCurrencyAmount = null;
      this.pfiCreditLimit.exRate = null;
    }
  }

  changeRequestLimit() {
    this.clearRequestTypeText();
  }

  clearRequestTypeText() {
    this.pfiCreditLimit.afterTempIncreaseTxt = null;
    this.pfiCreditLimit.afterMidTempIncreaseTxt = null;
    this.pfiCreditLimit.beforeMidTempIncreaseTxt = null;
    this.pfiCreditLimit.afterMidTempDecreaseTxt = null;
    this.pfiCreditLimit.beforeMidTempDecreaseTxt = null;
  }

  manageDocPopup(type: string) {
    this.manageDoc = { name: '', documentType: '' };
    switch (type) {
      case 'preshipmentApproval':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'Pre shipment approval';
        break;
      case 'overseasCapital':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'Overseas working capital loans support';
        break;
      case 'companySearches':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'Company searches or individual searches';
        break;
      case 'pfiInternalCreditMemo':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'PFI’s internal Credit Memo Approval';
        break;
      case 'latestAudited':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'Latest Audited Financials from Borrower';
        break;
      case 'latestSigned':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'Latest signed Management Accounts';
        break;
      case 'additionalItems':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'Others';
        break;
      case 'borrowerGroup':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'Borrower Group';
        break;
    }
  }

  validateDocumentSubmit() {
    let supportingDocumentsModel = new SupportingDocuments();
    let supportingDocumentsArray: any[];

    supportingDocumentsModel.collection = this.collectionType;

    if (!this.loanProcess.isMidTerm) {
      supportingDocumentsArray = [
        { name: 'Overseas working capital loans support' },
        { name: 'Company searches or individual searches' },
        { name: 'PFI’s internal Credit Memo Approval' },
        { name: 'Latest Audited Financials from Borrower' },
        { name: 'Latest signed Management Accounts' }
      ];

      supportingDocumentsModel.refAppId = this.loanProcess.id;
    } else {
      supportingDocumentsArray = [];
      supportingDocumentsModel.refAppId = this.loanProcess.loanBaseId;
    }

    if (this.pfiCreditLimit.preshipmentApprovalChkBx) {
      supportingDocumentsArray.push({ name: 'Pre shipment approval' });
    }    
    
    return new Promise<any>((resolve, reject) => {
      supportingDocumentsModel.documents = supportingDocumentsArray;
      this.loanService.validateSupportingDocumentForSubmission(supportingDocumentsModel).subscribe(missingDocs => {
          const emptyArr: string[] = [];               
         
          if (missingDocs) {
              resolve(missingDocs['missingfiles']);
          } else {
              resolve(emptyArr);
          }
      });
  });
  }
}
