import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoanService } from '../loan.service';
import { LoanProcess } from '../loan.model';
import { Principal, Account } from '../../shared';
import { SponsorEFormService } from './sponsor-eform.service';
import { SponsorEForm } from './sponsor-eform.model';
import { CRRPremiumRate } from '../uob/uob-credit-limit.model';

@Component({
  selector: 'lis-sponsor-submitted-view',
  templateUrl: './sponsor.submitted-view.component.html',
  encapsulation: ViewEncapsulation.None
})
export class SponsorSubmittedViewComponent implements OnInit {
  
  loanProcess: LoanProcess;
  loanUserType:string;
  currentAccount: Account;
  //pfiData: any;
  pfiAckData: any;
  sponsoreform: SponsorEForm = new SponsorEForm();
  pfiCreditLimit: any;
  uobCreditLimit:any;
  cRRPremiumRateList: CRRPremiumRate[];
  
  constructor(
    private loanService: LoanService,
    private router: Router,
    private route: ActivatedRoute,
    private principal: Principal,
    public sponsorEFormService: SponsorEFormService
  ) {
    this.sponsorEFormService.springEForm$.subscribe((sponsorForm) => {
      this.sponsoreform = sponsorForm;
      if (this.sponsoreform.dateofIncorporation) {
        this.sponsoreform.dateofIncorporation = new Date(
          this.sponsoreform.dateofIncorporation
        );
      }
      // console.dir(this.sponsoreform);
    });

    this.loanService.loanProcess$.subscribe((loanProcess) => {
      this.loanProcess = Object.assign({}, loanProcess);
    });
  }

  ngOnInit() {
    this.loanService.isLoanForm=false;
    this.principal.identity().then((account) => {
      this.currentAccount = account;
      this.loanUserType = this.currentAccount.bank &&
        this.currentAccount.bank !== 'null' &&
        this.currentAccount.bank === 'UOB' ? 'uob-user' : 'pfi-user';

      if (this.loanUserType == 'uob-user') {
        if (this.loanService.uobData) {
          this.uobCreditLimit = this.loanService.uobData.creditInfo;          
          
          this.loanService.getCRRPremiumRate().subscribe((crrPremium) => {
            this.cRRPremiumRateList = crrPremium;
          });
        }
      } else if (this.loanUserType == 'pfi-user') {
        if (this.loanService.pfiData) {
          this.pfiCreditLimit = this.loanService.pfiData.creditInfo;          
        }
      }
    });
  }

  getCRRNonEditList() {
    if (this.cRRPremiumRateList) {
      return this.cRRPremiumRateList.filter(
        (data) => data.from > 0 && data.to > 0
      );
    }
    return [];
  }

  setCRRValue(item: number) {
    if (this.cRRPremiumRateList && this.cRRPremiumRateList[item]) {
      return this.cRRPremiumRateList[item]._id;
    } else {
      return '';
    }
  }

  setCRRLabel(item: number) {
    if (this.cRRPremiumRateList && this.cRRPremiumRateList[item]) {
      return this.cRRPremiumRateList[item].tierRatingDescription;
    } else {
      return '';
    }
  }

  viewApplication() {
    if (this.loanUserType === 'pfi-user') {
      this.router.navigate(['../sponsor-eform/pfi-user'], {
        relativeTo: this.route
      });
    } else if (this.loanUserType === 'uob-user') {
      this.router.navigate(['../sponsor-eform/uob-user'], {
        relativeTo: this.route
      });
    }
  }
}
