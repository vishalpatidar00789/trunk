import {
  Component,
  OnInit,
  OnDestroy,
  AfterViewChecked,
  ViewChild
} from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';

import { SponsorEForm, Subsideries, LoanProcess } from '../';
import { SponsorEFormService } from './sponsor-eform.service';
import { Principal, Account } from '../../shared';
import { error } from 'util';

import { LoanService } from '../loan.service';
import { DateUtil } from '../../shared/date-formatter/date-util';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'lis-sponsor-eform',
  templateUrl: './sponsor-eform.component.html'
})
export class SponsorEFormComponent {
  creditForm: NgForm;
  sponsoreform: SponsorEForm = new SponsorEForm();
  countries: Array<any> = [
    { id: 'MY', name: 'Malaysia' },
    { id: 'SG', name: 'Singapore' },
    { id: 'Other', name: 'Other' }
  ];

  eventSubscriber: Subscription;
  isSaving: Boolean;
  routeData: any;
  links: any;
  totalItems: any;
  queryCount: any;
  itemsPerPage: any;
  page: any;
  predicate: any;
  previousPage: any;
  reverse: any;
  ShowEditTable: boolean = false;
  shareHoldingEditRowId: any = '';
  subsidiariesEditRowId: any = '';
  currentShareholdingSub: any;

  _id: string;

  isInventoryChecked = false;
  UOBUser: boolean = false;
  PFIUser: boolean = true;
  currentAccount: Account;
  loanProcess: LoanProcess;
   hoverTextSubsidary="Details of subsidiaries, all levels down, must be completed."+"\n"+ "Level 1 = Immediate subsidiary(s) of applicant company."+"\n"+"Level 2 = Subsidiary(s) of company(s) entered in Subsidiary Level 1"

  constructor(
    private sponsorEFormService: SponsorEFormService,
    private parseLinks: JhiParseLinks,
    private jhiAlertService: JhiAlertService,
    private eventManager: JhiEventManager,
    private principal: Principal,
    private loanService: LoanService,
    private router: Router
  ) {
    this.sponsorEFormService.springEForm$.subscribe((sponsorForm) => {
      this.sponsoreform = sponsorForm;
      if (this.sponsoreform.dateofIncorporation) {
        this.sponsoreform.dateofIncorporation = new Date(
          this.sponsoreform.dateofIncorporation
        );
      }
      // console.dir(this.sponsoreform);
    });
    this.loanService.loanProcess$.subscribe((loanProcess) => {
      this.loanProcess = Object.assign({}, loanProcess);
    });
  }

  onActivate(componentRef) {
    this.creditForm = componentRef.creditForm;
  }
}
