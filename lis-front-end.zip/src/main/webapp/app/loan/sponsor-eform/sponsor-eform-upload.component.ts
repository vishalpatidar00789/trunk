import { Component, OnInit } from '@angular/core';
import { SponsorEForm } from '../';
import { SponsorEFormService } from './sponsor-eform.service';
import { Account, Principal } from '../../shared';
import { Router, ActivatedRoute } from '@angular/router';
import {
  NotificationService,
  NotificationOption
} from '../../shared/alert/notification.service';
import { LoanService } from '../loan.service';
import { LoanProcess, CompletedStep } from '../loan.model';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrConfig } from 'ngx-toastr';
import { MidTermService } from '../mid-term/mid-term.service';

@Component({
  selector: 'lis-sponsor-eform-upload',
  templateUrl: './sponsor-eform-upload.component.html'
})
export class SponsorEFormUploadComponent implements OnInit {
  userid: string;
  loanProcess: LoanProcess;
  fileData: Array<File> = [];
  tickVisible: boolean;
  displaySpinner = false;
  sponsorEForm: SponsorEForm = new SponsorEForm();
  currentAccount: Account;
  loanUserType = 'pfi-user';
  showError = false;
  requestTypeSelected: string;
  baseLoan: SponsorEForm;
  constructor(
    private loanService: LoanService,
    private sponsorEFormService: SponsorEFormService,
    private principal: Principal,
    private router: Router,
    private route: ActivatedRoute,
    private notificationService: NotificationService,
    private spinner: NgxSpinnerService
  ) {
    this.loanService.loanProcess$.subscribe((loanProcess) => {
      this.loanProcess = Object.assign({}, loanProcess);
    });
  }

  ngOnInit() {
    this.principal.identity().then((account) => {
      this.currentAccount = account;
      this.userid = this.currentAccount.login;
      this.loanUserType =
        this.currentAccount.bank &&
        this.currentAccount.bank !== 'null' &&
        this.currentAccount.bank === 'UOB'
          ? 'uob-user'
          : 'pfi-user';
    });
    if (
      this.loanProcess &&
      this.loanProcess.isMidTerm &&
      this.loanProcess.loanBaseId
    ) {
      this.loanService
        .getLoanById(this.loanProcess.loanBaseId)
        .subscribe((loanbaseResult: any) => {
          if (loanbaseResult) {
            if (loanbaseResult.sponsorForm.dateofIncorporation) {
              this.baseLoan = new SponsorEForm();
              this.baseLoan = loanbaseResult.sponsorForm;
            }
          }
        });
    }
  }

  sponsorFormUpload(fileInput: any) {
    this.tickVisible = false;
    this.fileData = <Array<File>>fileInput.target.files;
    const formData = new FormData();
    const files: Array<File> = this.fileData;
    if (files.length === 0) {
      this.showError = true;
      setTimeout(() => {
        this.showError = false;
      }, 3000);

      // alert('Please select file to upload..!');
      return;
    }
    const file: File = files[0];
    formData.append('file', file, file.name);
    formData.append("uploadedBy", this.userid);

    this.displaySpinner = true;
    this.spinner.show();

    this.sponsorEFormService
      .uploadFile(formData, this.loanProcess.id)
      .subscribe(
        (result) => {
          // debugger;
          console.dir(result);
          this.spinner.hide();
          this.displaySpinner = false;
          this.tickVisible = true;
          this.sponsorEForm = <SponsorEForm>result;
          if (this.loanProcess && this.loanProcess.isMidTerm && this.baseLoan) {
            let errorMessage;
            if (this.sponsorEForm.regComName !== this.baseLoan.regComName) {
              errorMessage = 'Borrower name';
            }
            if (this.sponsorEForm.ACRANo !== this.baseLoan.ACRANo) {
              errorMessage = errorMessage
                ? errorMessage + ' and UEN number'
                : 'UEN number';
            }
            if (errorMessage) {
              const notificationOption = new NotificationOption();
              notificationOption.title = '';
              notificationOption.message = `${errorMessage} entered is different from the borrower details of the main application`;
              notificationOption.type = 'error';
              notificationOption.toastrConfig = {
                positionClass: 'toast-bottom-right',
                disableTimeOut: true
              };
              this.notificationService.showNotification(notificationOption);
              this.tickVisible = false;
              this.displaySpinner = false;
              this.spinner.hide();
              return;
            }
          }
          this.checkBoxCheckUncheck();
          this.sponsorEFormService.setSponsorEForm(
            Object.assign({}, this.sponsorEForm)
          );
          const notificationOption = new NotificationOption();
          notificationOption.title = 'Notification';
          notificationOption.message = 'Sponsor Form Uploaded Successfully';
          this.notificationService.showNotification(notificationOption);
          if (!this.loanProcess.completedStep) {
            this.loanProcess.completedStep = CompletedStep.stepOne;
          }
          this.loanProcess.isSponsorUploaded = true;
          this.loanService.setLoanStepProcess(this.loanProcess);
          this.goToSponsorForm();
        },
        (error) => {
          const notificationOption = new NotificationOption();
          notificationOption.title = '';
          notificationOption.message =
            'Sponsor eForm has not been validated please validate and try again.';
          notificationOption.type = 'error';
          notificationOption.toastrConfig = {
            positionClass: 'toast-bottom-right',
            disableTimeOut: true
          };
          this.notificationService.showNotification(notificationOption);
          this.tickVisible = false;
          this.displaySpinner = false;
          this.spinner.hide();
        }
      );
  }
  getTickStyle(): any {
    return {
      visibility: this.tickVisible ? 'visible' : 'hidden'
    };
  }

  goToSponsorForm() {
    if (this.loanUserType === 'pfi-user') {
      this.router.navigate(['../sponsor-eform/pfi-user'], {
        relativeTo: this.route
      });
    } else if (this.loanUserType === 'uob-user') {
      this.router.navigate(['../sponsor-eform/uob-user'], {
        relativeTo: this.route
      });
    }
  }

  decreaseMidTerm() {
    if (!this.loanProcess.completedStep) {
      this.loanProcess.completedStep = CompletedStep.stepOne;
    }
    this.loanService.setLoanStepProcess(this.loanProcess);
    if (this.loanProcess && this.loanProcess.id) {
      this.loanService
        .getLoanById(this.loanProcess.loanBaseId)
        .subscribe((loanResult: any) => {
          if (loanResult) {
            if (loanResult.sponsorForm.dateofIncorporation) {
              this.sponsorEForm = <SponsorEForm>loanResult.sponsorForm;
              this.checkBoxCheckUncheck();
              this.sponsorEFormService.setSponsorEForm(
                Object.assign({}, this.sponsorEForm)
              );
            } else {
              this.sponsorEFormService.setSponsorEForm(
                Object.assign({}, new SponsorEForm())
              );
            }
          }
        });
    }
    this.goToSponsorForm();
  }

  checkBoxCheckUncheck() {
    if (this.sponsorEForm.invStockFinancing > 0) {
      this.sponsorEForm.invStockFinancingChecked = true;
    } else {
      this.sponsorEForm.invStockFinancing = null;
    }

    if (this.sponsorEForm.workingCapital > 0) {
      this.sponsorEForm.workingCapitalChecked = true;
    } else {
      this.sponsorEForm.workingCapital = null;
    }

    if (this.sponsorEForm.aRDiscount > 0) {
      this.sponsorEForm.aRDiscountChecked = true;
    } else {
      this.sponsorEForm.aRDiscount = null;
    }

    if (this.sponsorEForm.capitalLoan > 0) {
      this.sponsorEForm.capitalLoanChecked = true;
    } else {
      this.sponsorEForm.capitalLoan = null;
    }

    if (this.sponsorEForm.bankerGuarantee > 0) {
      this.sponsorEForm.bankerGuaranteeChecked = true;
    } else {
      this.sponsorEForm.bankerGuarantee = null;
    }
  }

  goToApplication() {
    this.loanProcess.isSponsorUploaded = false;
    this.loanService.setLoanStepProcess(this.loanProcess);
    this.router.navigate(['../sponsor-eform/' + this.loanUserType], {
      relativeTo: this.route
    });
  }
}
