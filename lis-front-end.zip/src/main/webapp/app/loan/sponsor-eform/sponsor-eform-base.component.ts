import { Component, OnInit, OnDestroy } from '@angular/core';
import {
  LoanProcess,
  LoanNew,
  Loan,
  CreditInfo,
  CompletedStep
} from '../loan.model';
import { LoanService } from '../loan.service';
import { ActivatedRoute, Router } from '@angular/router';
import { SponsorEForm } from '..';
import { Principal, LookupService, Bank } from '../../shared';
import {
  NotificationService,
  NotificationOption
} from '../../shared/alert/notification.service';
import { SponsorEFormService } from './sponsor-eform.service';
import { MidTermLoanNew } from '../mid-term/mid-term.model';
import { MidTermService } from '../mid-term/mid-term.service';

@Component({
  template: `<div class="container"><router-outlet></router-outlet></div>`
})
export class LoanBaseComponent implements OnInit, OnDestroy {
  // loan: Loan;
  loan: any;
  loanProcess: LoanProcess;
  tranche: any;
  loanRequestType: string;
  bank: Bank;
  constructor(
    private loanService: LoanService,
    private sponsorEFormService: SponsorEFormService,
    private midTermService: MidTermService,
    private lookupService: LookupService,
    private principal: Principal,
    private route: ActivatedRoute,
    private notificationService: NotificationService,
    private router: Router
  ) {
    this.loanService.loanProcess$.subscribe((loanProcess) => {
      this.loanProcess = Object.assign({}, loanProcess);
    });
    this.lookupService.getCurrentTranche().subscribe((tranche) => {
      if (tranche) {
        this.tranche = tranche;
      }
    });
  }

  ngOnInit() {
    const loanId = this.route.snapshot.paramMap.get('loanId');
    const midTermId = this.route.snapshot.paramMap.get('midTermId');
    this.loanRequestType = this.route.parent.snapshot.data['loanRequestType'];
    this.principal.identity().then((account) => {
      if (account && account.bank) {
        this.lookupService
          .getBankByCode(account.bank)
          .subscribe((bankDetails) => {
            this.bank = new Bank();
            if (bankDetails) {
              this.bank = bankDetails;
              if (this.bank && this.loanRequestType) {
                if (this.loanRequestType === 'base-loan') {
                  if (!loanId) {
                    // this.createNewLoan();
                  } else {
                    this.editLoan(loanId);
                  }
                } else {
                  if (!midTermId) {
                    this.createNewLoan();
                  } else {
                    this.editLoan(midTermId);
                  }
                }
              } else {
                // if error with loan application
                const notificationOption = new NotificationOption();
                notificationOption.title = 'Error';
                notificationOption.message = 'Oops! Something went wrong';
                notificationOption.type = 'error';
                notificationOption.toastrConfig = {
                  positionClass: 'toast-bottom-right',
                  disableTimeOut: true
                };
                this.notificationService.showNotification(notificationOption);
              }
            } else {
              // if bank is not there
              const notificationOption = new NotificationOption();
              notificationOption.title = 'Error';
              notificationOption.message =
                'NO BANK IS ASSIGNED TO THIS USER..!';
              notificationOption.type = 'error';
              notificationOption.toastrConfig = {
                positionClass: 'toast-bottom-right',
                disableTimeOut: true
              };
              this.notificationService.showNotification(notificationOption);
            }
          });
      }
    });
  }

  createNewLoan() {
    if (this.loanRequestType === 'base-loan') {
      this.loan = new LoanNew();
      this.loan.consortium = this.bank.consortiumid;
      this.loan.loanRequestSeqNo = 1;
      const creditInfo = new CreditInfo();
      creditInfo.pfiName = this.bank.bankName;
      creditInfo.pfiCode = this.bank.bankCode;
      this.loan.creditInfo = creditInfo;
      this.loanService.createLoan(this.loan).subscribe((loanResult) => {
        const loanProcess = new LoanProcess();
        loanProcess.id = loanResult._id;
        loanProcess.status = loanResult.status;
        if (this.tranche) {
          loanProcess.tranchName = this.tranche.trancheName;
        }
        this.loanProcess = Object.assign({}, loanProcess);
        this.loanService.setLoanStepProcess(this.loanProcess);
      });
    } else if (this.loanRequestType === 'mid-term') {
      const loanBaseId = this.route.snapshot.paramMap.get('loanBaseId');
      this.loan = new MidTermLoanNew();
      this.loan.loanBaseId = loanBaseId ? loanBaseId : '';
      this.loan.consortium = this.bank.consortiumid;
      this.loan.loanRequestSeqNo = 1;
      const creditInfo = new CreditInfo();
      creditInfo.pfiName = this.bank.bankName;
      creditInfo.pfiCode = this.bank.bankCode;
      this.loan.creditInfo = creditInfo;
      this.midTermService
        .createMidTermLoan(this.loan)
        .subscribe((loanResult) => {
          const loanProcess = new LoanProcess();
          loanProcess.id = loanResult._id;
          loanProcess.status = loanResult.status;
          loanProcess.isMidTerm = true;
          loanProcess.loanBaseId = loanBaseId;
          if (this.tranche) {
            loanProcess.tranchName = this.tranche.trancheName;
          }
          this.loanProcess = Object.assign({}, loanProcess);
          this.loanService.setLoanStepProcess(this.loanProcess);
        });
    }
  }

  editLoan(editLoanId: string) {
    if (this.loanRequestType === 'base-loan') {
      this.loanService.getLoanById(editLoanId).subscribe((loanResult: any) => {
        if (loanResult) {
          this.setEditProperties(loanResult);
        }
      });
    } else if (this.loanRequestType === 'mid-term') {
      this.midTermService
        .getMidTermLoanById(editLoanId)
        .subscribe((loanResult: any) => {
          if (loanResult) {
            this.setEditProperties(loanResult);
          }
        });
    }
  }

  setEditProperties(loanResult: any) {
    let routeURL;
    const loanProcess = new LoanProcess();
    loanProcess.id = loanResult._id;
    loanProcess.status = loanResult.status;
    loanProcess.tranchName = this.tranche.trancheName;
    if (this.loanRequestType === 'mid-term') {
      loanProcess.isMidTerm = true;
      loanProcess.loanBaseId = loanResult.loanBaseId;
    }
    if (loanResult.sponsorForm.dateofIncorporation) {
      loanProcess.completedStep = CompletedStep.stepOne;
      if (this.loanRequestType === 'mid-term') {
        loanProcess.isMidTermIncrease = loanResult.isMidTermIncrease;
      }
      this.loanService
        .getConsortiumById(loanResult.consortium)
        .subscribe((consortiumResult: any) => {
          this.sponsorEFormService.setSponsorEForm(
            Object.assign({}, loanResult.sponsorForm)
          );
          if (consortiumResult.consortiumName === '9PFI') {
            routeURL = 'sponsor-eform/pfi-user';
          } else if (consortiumResult.consortiumName === 'UOB') {
            routeURL = 'sponsor-eform/uob-user';
          }

          this.loanProcess = Object.assign({}, loanProcess);
          this.loanService.setLoanStepProcess(this.loanProcess);
          if (routeURL && routeURL !== '') {
            this.goToLoan(routeURL);
          }
        });
    } else {
      this.sponsorEFormService.setSponsorEForm(
        Object.assign({}, new SponsorEForm())
      );
      routeURL = 'sponsor-eform-upload';
      this.loanProcess = Object.assign({}, loanProcess);
      this.loanService.setLoanStepProcess(this.loanProcess);
      if (routeURL && routeURL !== '') {
        this.goToLoan(routeURL);
      }
    }
  }

  goToLoan(routeURL: string) {
    this.router.navigate([routeURL], {
      relativeTo: this.route
    });
  }

  ngOnDestroy(): void {
    this.loanService.setLoanStepProcess(Object.assign({}, new LoanProcess()));
    this.sponsorEFormService.setSponsorEForm(
      Object.assign({}, new SponsorEForm())
    );
  }
}
