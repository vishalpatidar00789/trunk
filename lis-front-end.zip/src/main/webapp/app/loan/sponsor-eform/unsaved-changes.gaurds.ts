import { CanDeactivate, Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { ConfirmationService } from 'primeng/components/common/api';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs';
import { SponsorEFormComponent } from '..';
import { NgxSpinnerService } from 'ngx-spinner';

@Injectable()
export class UnsavedChangesGuardService
  implements CanDeactivate<SponsorEFormComponent> {
  constructor(
    private confirmationService: ConfirmationService,
    private spinner: NgxSpinnerService
  ) {}

  canDeactivate(component: SponsorEFormComponent) {
    // Allow navigation if the form is unchanged
    console.dir(component.creditForm);
    if (component.creditForm.pristine) {
      return true;
    }

    return Observable.create((observer: Observer<boolean>) => {
      this.spinner.hide();
      this.confirmationService.confirm({
        header: 'Confirmation',
        icon: 'fa fa-times',
        message:
          'You have unsaved changes. Are you sure you want to discard your changes?',
        accept: () => {
          this.spinner.show();
          observer.next(true);
          observer.complete();
        },
        reject: () => {
          observer.next(false);
          observer.complete();
        }
      });
    });
  }
}
