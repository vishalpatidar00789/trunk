import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CheckboxModule } from 'primeng/checkbox';
import { RadioButtonModule } from 'primeng/radiobutton';
import { PFIAdhocComponent } from './pfi/pfi-adhoc.component';
import { PFIAdhocService } from './pfi/pfi-adhoc.service';
import { UobAdhocComponent } from './uob/uob-adhoc.component';
import { UobAdhocService } from './uob/uob-adhoc.service';
import { LoanAdhocRoute } from './adhoc.route';
import { LisAppSharedModule } from '../../shared';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { AdhocSubmittedViewComponent } from './adhoc.submitted-view.component';
import { AdhocSubmittedViewService } from './adhoc.submitted-view.service';
import { DialogModule } from 'primeng/dialog';

const PAGE_SET_STATES = [
    ...LoanAdhocRoute,
];

@NgModule({
    imports: [
        LisAppSharedModule,
        BsDatepickerModule,
        CurrencyMaskModule,
        CheckboxModule,
        RadioButtonModule,
        DialogModule,
        RouterModule.forRoot(PAGE_SET_STATES, { useHash: true })
    ],
    declarations: [
        PFIAdhocComponent,
        UobAdhocComponent,
        AdhocSubmittedViewComponent
    ],
    entryComponents: [
        PFIAdhocComponent,
        UobAdhocComponent
    ],
    providers: [
        PFIAdhocService,
        UobAdhocService,
        AdhocSubmittedViewService
    ],
    exports: [
        PFIAdhocComponent,
        UobAdhocComponent,
        AdhocSubmittedViewComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class LoanAdhocApplicationModule { }
