import { TYPED_NULL_EXPR } from "@angular/compiler/src/output/output_ast";

export class UobAdhoc {
    constructor(

        // public loanId?: string,
        public _id?: string,
        // loan application information for search
        public status?: string,
        public marshRefNo?: string,
        public baseLoanId?: string,
        public loanMarshRefNo?: string,
        public consortium?: string,
        public app?: string,

        // Autopopulated Section

        // uob additional

        // public nameOfStaff?: string, // requesterName

        // public submissionDate?: Date,

        // public submissionTxt?: string,

        // public pfiCode?: string,
        // public pfiName?: string,
        // public regName?: string,
        // public uenNumber?: string,
        // public primary?: number,
        // public autoTopUp?: number,
        // public bg?: number,
        // public lisPlus?: number,
        // public foreignCurrencyType?: string,
        // public foreignCurrency?: number,
        // public exRate?: number,


        // Section 1 not present in UOB
        // public cancellationSectionChkBx?: boolean,
        // public cancellationRadio?: string,
        // public cancellationReason?: string,
        // public loAcceptedDateRadio?: boolean,
        // public loAcceptedDate?: Date,
        // public otherRemarks?: string,

        // public cancellationOfAccepted?: string,
        // public cancellationOutstandingAmountSGD?: number,
        // public cancellationOutstandingAmountUSD?: number,
        // public otherRemarksAccepted?: string,

        // Section 2
        public expiryExtensionChkBx?: boolean,
        public facilityExpiryExtentsionChkBx?: boolean,
        public facilityExpiryDate?: Date,
        public eFacilityExpiryDate?: Date,

        // Section 3
        public dueDateExtensionChkBx?: boolean,
        public billDueDate?: Date,
        // public billDueTxt?: string,
        public eBillDueDate?: Date,
        // public eBillDueTxt?: string,
        public billInfoChkBx?: boolean,

        // Section 4
        public overseasBuyerChkBx?: boolean,
        public domesticBuyerChkBx?: boolean,
        //public overseasBuyer?: boolean,

        // Section 5 not present in UOB
        // public preShipmentChkBx?: boolean,
        // public insurersApprovalChkBx?: boolean,


        // Section 6
        public moreTimeLoChkBx?: boolean,
        public decisionDate?: Date,
        public calendarDays?: Date,
        public decisionDateLis?: Date,
        public calendarDaysLis?: Date,
        public extendedLoDate?: Date,
        public extensionReason?: string,

        // public adverseInformationChkBx?: boolean,
        // public adverseInformation?: string,
        // public decisionTxt?: string,
        // public calendarTxt?: string,
        // public extendedLoTxt?: string,
        // public approvedSupplier?: boolean,
        // public overdueDateMoreChkBx?: boolean,
        // public overdueDateLessChkBx?: boolean,
        // public overdueDisbursementsChkBx?: boolean,
        // public repaymentPlanChkBx?: boolean,
        // public overdueDateMore?: Date,
        // public overdueDateLess?: Date,

        // Section 7 commented out

        // Section 8 
        public newDisbursementsChkBx?: boolean,
        public internalCreditMemoChkBx?: boolean,

        // Section 9
        public reValidateInsuranceChkBx?: boolean,
        public reasonForBreachRadio?: string,
        public reasonForBreachRadio2Txt?: string,
        public reasonForBreachRadio3Txt?: string,
        public noAdverseInfoChkBx?: boolean,
        public outstandingAmountChkBx?: boolean,
        public borrwLoAcceptedDate?: Date,

        // Section 10 not present in UOB
        // public processRequestChkBx?: boolean,
        // public otherReason?: string,
        // public reviewDocChkBx?: boolean,


        public sponsorForm?: {
            regComName?: string, //regName done
            ACRANo?: string, //uenNumber done
        },
        public creditInfo?: {
            pfiCode?: string, // done
            pfiName?: string, // done
            totalRequstedLimitSGD?: number, // not mapped
            submissionDate?: Date, // not mapped
            primary?: number, // done
            autoTopUp?: number, // done
            bg?: number, // done
            lisPlus?: number, // done
            requesterName?: string, // not mapped
            foreignCurrency?: string, // done
            foreignCurrencyAmount?: number, // done
            exRate?: number, // done
        },

        public adverseInfo?: {
            adverseStatus?: string, // mapped to loan
            additionalInfo?: string, // mapped to loan
            overdue?: string, // mapped to loan
            overdueDate?: Date, // mapped to loan
            listOfOverdue?: boolean, // mapped to loan
            repaymentPlanAttached?: boolean, // mapped to loan
        },



        public supportingDocs?: any,
    ) {
        this.supportingDocs = [
            { name: 'Extension of Facility Expiry date', id: '', status: false, files: '' },
            { name: 'Extension of Due date of Bill', id: '', status: false, files: '' },
            { name: 'Overseas Inclusion of Byuers under CL', id: '', status: false, files: '' },
            { name: 'Extension of Acceptance of Letter of Offer', id: '', status: false, files: '' },
            { name: 'Reinstatement of Facility', id: '', status: false, files: '' },
            { name: 'Revalidation of Insurance coverage', id: '', status: false, files: '' }
        ]
        // this.programManager = "Marsh",
        // this.cancellationSectionChkBx = null,
        // this.cancellationRadio = " ",
        // this.loAcceptedDateRadio = null,
        this.expiryExtensionChkBx = null,
            this.dueDateExtensionChkBx = null,
            this.overseasBuyerChkBx = null,
            // this.preShipmentChkBx = null,
            // this.insurersApprovalChkBx = null,

            this.moreTimeLoChkBx = null,
            this.facilityExpiryExtentsionChkBx = null,
            this.billInfoChkBx = null,
            this.noAdverseInfoChkBx = null,
            this.newDisbursementsChkBx = null,
            this.internalCreditMemoChkBx = null,
            this.reValidateInsuranceChkBx = false;

        // this.outstandingAmountChkBx = null,
        // this.processRequestChkBx = null,
        // this.reviewDocChkBx = false;

        this.sponsorForm = {
            regComName: '',
            ACRANo: '',
        },

            this.creditInfo = {
                pfiCode: '',
                pfiName: '',
                totalRequstedLimitSGD: null,
                submissionDate: null,
                primary: null,
                autoTopUp: null,
                bg: null,
                lisPlus: null,
                requesterName: '',
                foreignCurrency: '',
                foreignCurrencyAmount: null,
                exRate: null,
            },

            this.adverseInfo = {
                adverseStatus: '',
                additionalInfo: '',
                overdue: '',
                overdueDate: null,
                listOfOverdue: null,
                repaymentPlanAttached: null,
            }
    }
}