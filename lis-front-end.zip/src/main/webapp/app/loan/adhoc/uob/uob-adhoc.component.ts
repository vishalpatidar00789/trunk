import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef, Input } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router, NavigationEnd, NavigationExtras } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';

import { UobAdhoc } from './uob-adhoc.model';
import { UobAdhocService } from './uob-adhoc.service';

import { Message, ConfirmationService } from 'primeng/components/common/api';
import { NotificationService, NotificationOption } from '../../../shared/alert/notification.service';
import { Principal, FileUploadComponent, LookupService, Bank } from '../../../shared';
import { NgxSpinnerService } from 'ngx-spinner';
import { LoanSearchResults } from '../../loan-search/loan-search-results/loan-search-results.model'
import { NgForm } from '@angular/forms';
import { LoanService } from '../../loan.service';

@Component({
    selector: 'lis-uob-adhoc',
    templateUrl: './uob-adhoc.component.html'
})
export class UobAdhocComponent implements OnInit, OnDestroy {

    @ViewChild('uobForm') uobForm: NgForm;
    @Input() adhocViewId: string;
    uobAdhoc: UobAdhoc = new UobAdhoc();
    currentAccount: any;
    eventSubscriber: Subscription;
    isSaving: Boolean;
    routeData: any;
    links: any;
    totalItems: any;
    queryCount: any;
    itemsPerPage: any;
    page: any;
    predicate: any;
    previousPage: any;
    reverse: any;
    bank: Bank;
    // loanExpiryDate: Date;
    // loAccpetedDateTemp: Date;
    borrwAcceptedDateTemp: Date;
    facilityExpiryDateTemp: Date;
    decisionDateTemp: Date;
    decisionDateLisTemp: Date;
    calendarDaysTemp: Date;
    calendarDaysLisTemp: Date;
    minRequestedExpiryDate: Date;
    maxRequestedExpiryDate: Date;
    showAdhocMarshRefNo: boolean = false;
    baseLoanId: string;
    disableForm: boolean = false;
    showManageDoc: boolean = false;
    popUp: boolean;
    dialogTitle: string;
    docType: string;
    userid: string;

    constructor(
        private cdr: ChangeDetectorRef,
        private uobAdhocService: UobAdhocService,
        private loanService: LoanService,
        private parseLinks: JhiParseLinks,
        private jhiAlertService: JhiAlertService,
        private eventManager: JhiEventManager,
        private router: Router,
        private lookup: LookupService,
        private principal: Principal,
        private notificationService: NotificationService,
        private spinner: NgxSpinnerService,
        private confirmationService: ConfirmationService,
        private route: ActivatedRoute) {
    }

    ngOnInit() {

        this.initAccount();
        this.router.events.subscribe((event) => {
            if (!(event instanceof NavigationEnd)) {
                return;
            }
            window.scrollTo(0, 0);
        });
        this.principal.identity().then((account) => {
            this.currentAccount = account;
        });
        this.route.queryParams.subscribe(params => {
            //Adding logic for auto populated section
            this.baseLoanId = params["_id"];
            this.uobAdhoc._id = params["adhocId"];
        });


        // Applied for fist time creation of other ad-hoc request
        if (this.baseLoanId) {
            this.loanService.getLoanById(this.baseLoanId).subscribe(loan => {
                // console.log("Loan: " + JSON.stringify(loan));

                this.uobAdhoc.baseLoanId = this.baseLoanId;
                this.populateDataFromBaseLoanApplication(loan);

                // console.log("First draft adhoc: " + JSON.stringify(this.uobAdhoc));
                this.uobAdhocService.createAdhoc(this.uobAdhoc).subscribe((adhocResult) => {
                    console.log("First draft created: " + JSON.stringify(adhocResult));
                    console.log("Adhoc result id of draft: " + adhocResult._id);
                    this.uobAdhoc._id = adhocResult._id;
                });
            })
        }
        this.uobAdhoc.status = "Draft";
        console.log("ngOnInit end : " + this.uobAdhoc._id)

        // Applied for already saved/submitted ad-hoc application
        if (this.uobAdhoc._id) {
            this.uobAdhocService.getAdhoc(this.uobAdhoc._id).subscribe((adhocResult: any) => {
                if (adhocResult.status !== 'Draft') {
                    this.showAdhocMarshRefNo = true;
                } else {
                    // Logic to populate data from base loan application if user return to edit draft application
                    console.log("adhocResult.baseLoanId: " + adhocResult.baseLoanId);
                    if (adhocResult.baseLoanId) {
                        this.loanService.getLoanById(adhocResult.baseLoanId).subscribe(loan => {
                            // console.log("Loan: " + JSON.stringify(loan));
                            this.populateDataFromBaseLoanApplication(loan);
                        });
                    }
                }

                this.uobAdhoc.status = adhocResult.status;
                this.uobAdhoc = adhocResult;

                if (this.uobAdhoc.creditInfo.submissionDate) {
                    this.uobAdhoc.creditInfo.submissionDate = new Date(this.uobAdhoc.creditInfo.submissionDate);
                }

                // if (this.uobAdhoc.loAcceptedDate) {
                //     this.uobAdhoc.loAcceptedDate = new Date(this.uobAdhoc.loAcceptedDate);
                // }

                if (this.uobAdhoc.facilityExpiryDate) {
                    this.uobAdhoc.facilityExpiryDate = new Date(this.uobAdhoc.facilityExpiryDate);
                }

                if (this.uobAdhoc.eFacilityExpiryDate) {
                    this.uobAdhoc.eFacilityExpiryDate = new Date(this.uobAdhoc.eFacilityExpiryDate);
                }

                if (this.uobAdhoc.borrwLoAcceptedDate) {
                    this.uobAdhoc.borrwLoAcceptedDate = new Date(this.uobAdhoc.borrwLoAcceptedDate);
                }

                if (this.uobAdhoc.decisionDate) {
                    this.uobAdhoc.decisionDate = new Date(this.uobAdhoc.decisionDate);
                }

                if (this.uobAdhoc.eFacilityExpiryDate) {
                    this.uobAdhoc.eFacilityExpiryDate = new Date(this.uobAdhoc.eFacilityExpiryDate);
                }

                if (this.uobAdhoc.decisionDate) {
                    this.uobAdhoc.decisionDate = new Date(this.uobAdhoc.decisionDate);
                }

                if (this.uobAdhoc.decisionDate) {
                    this.uobAdhoc.decisionDate = new Date(this.uobAdhoc.decisionDate);
                }

                if (this.uobAdhoc.decisionDateLis) {
                    this.uobAdhoc.decisionDateLis = new Date(this.uobAdhoc.decisionDateLis);
                }

                if (this.uobAdhoc.calendarDays) {
                    this.uobAdhoc.calendarDays = new Date(this.uobAdhoc.calendarDays);
                }

                if (this.uobAdhoc.calendarDaysLis) {
                    this.uobAdhoc.calendarDaysLis = new Date(this.uobAdhoc.calendarDaysLis);
                }

                if (this.uobAdhoc.extendedLoDate) {
                    this.uobAdhoc.extendedLoDate = new Date(this.uobAdhoc.extendedLoDate);
                }

                if (this.uobAdhoc.billDueDate) {
                    this.uobAdhoc.billDueDate = new Date(this.uobAdhoc.billDueDate);
                }

                if (this.uobAdhoc.eBillDueDate) {
                    this.uobAdhoc.eBillDueDate = new Date(this.uobAdhoc.eBillDueDate);
                }

                console.log("Adhoc Request: " + JSON.stringify(this.uobAdhoc));
                if (adhocResult && adhocResult.status != "Draft") {
                    this.disableForm = true;
                    this.uobForm.form.disable();
                    this.cdr.detectChanges();
                }
            });
        }

        if (this.adhocViewId) {
            this.uobAdhocService.getAdhoc(this.adhocViewId).subscribe((adhocResult: any) => {
                if (adhocResult.status != 'Draft') {
                    this.showAdhocMarshRefNo = true;
                }
                this.uobAdhoc.status = adhocResult.status;
                this.uobAdhoc = adhocResult;

                if (this.uobAdhoc.creditInfo.submissionDate) {
                    this.uobAdhoc.creditInfo.submissionDate = new Date(this.uobAdhoc.creditInfo.submissionDate);
                }

                // if (this.uobAdhoc.loAcceptedDate) {
                //     this.uobAdhoc.loAcceptedDate = new Date(this.uobAdhoc.loAcceptedDate);
                // }

                if (this.uobAdhoc.facilityExpiryDate) {
                    this.uobAdhoc.facilityExpiryDate = new Date(this.uobAdhoc.facilityExpiryDate);
                }

                if (this.uobAdhoc.eFacilityExpiryDate) {
                    this.uobAdhoc.eFacilityExpiryDate = new Date(this.uobAdhoc.eFacilityExpiryDate);
                }

                if (this.uobAdhoc.borrwLoAcceptedDate) {
                    this.uobAdhoc.borrwLoAcceptedDate = new Date(this.uobAdhoc.borrwLoAcceptedDate);
                }

                if (this.uobAdhoc.decisionDate) {
                    this.uobAdhoc.decisionDate = new Date(this.uobAdhoc.decisionDate);
                }

                if (this.uobAdhoc.eFacilityExpiryDate) {
                    this.uobAdhoc.eFacilityExpiryDate = new Date(this.uobAdhoc.eFacilityExpiryDate);
                }

                if (this.uobAdhoc.decisionDate) {
                    this.uobAdhoc.decisionDate = new Date(this.uobAdhoc.decisionDate);
                }

                if (this.uobAdhoc.decisionDate) {
                    this.uobAdhoc.decisionDate = new Date(this.uobAdhoc.decisionDate);
                }

                if (this.uobAdhoc.decisionDateLis) {
                    this.uobAdhoc.decisionDateLis = new Date(this.uobAdhoc.decisionDateLis);
                }

                if (this.uobAdhoc.calendarDays) {
                    this.uobAdhoc.calendarDays = new Date(this.uobAdhoc.calendarDays);
                }

                if (this.uobAdhoc.calendarDaysLis) {
                    this.uobAdhoc.calendarDaysLis = new Date(this.uobAdhoc.calendarDaysLis);
                }

                if (this.uobAdhoc.extendedLoDate) {
                    this.uobAdhoc.extendedLoDate = new Date(this.uobAdhoc.extendedLoDate);
                }

                if (this.uobAdhoc.billDueDate) {
                    this.uobAdhoc.billDueDate = new Date(this.uobAdhoc.billDueDate);
                }

                if (this.uobAdhoc.eBillDueDate) {
                    this.uobAdhoc.eBillDueDate = new Date(this.uobAdhoc.eBillDueDate);
                }

                console.log("Adhoc Request: " + JSON.stringify(this.uobAdhoc));
                this.uobForm.form.disable();
                this.cdr.detectChanges();
            });
        }
    }

    populateDataFromBaseLoanApplication(loan) {
        let element;
        element = loan;
        this.uobAdhoc.loanMarshRefNo = element.marshRefNo;
        // loanResult.status = element.status;
        // loanResult.marshSubmissionDate = this.datePipe.transform(element.createdAt, 'dd-MMM-yyy');
        this.uobAdhoc.app = element.app;
        this.uobAdhoc.consortium = element.consortium;

        let sponserForm = element.sponsorForm;
        if (sponserForm) {
            this.uobAdhoc.sponsorForm.regComName = sponserForm.regComName;
            this.uobAdhoc.sponsorForm.ACRANo = sponserForm.ACRANo;
        }

        let creditInfo = element.creditInfo;
        if (creditInfo) {
            this.uobAdhoc.creditInfo.pfiCode = creditInfo.pfiCode;
            this.uobAdhoc.creditInfo.pfiName = creditInfo.pfiName;
            // loanResult.totalRequstedLimitSGD = creditInfo.totalRequstedLimitSGD;

            // if (creditInfo.submissionDate)
            //     loanResult.submissionDate = this.datePipe.transform(creditInfo.submissionDate, 'dd-MMM-yyy');
            this.uobAdhoc.creditInfo.primary = creditInfo.primary;
            this.uobAdhoc.creditInfo.autoTopUp = creditInfo.autoTopUp;
            this.uobAdhoc.creditInfo.bg = creditInfo.bg;
            this.uobAdhoc.creditInfo.lisPlus = creditInfo.lisPlus;
            this.uobAdhoc.creditInfo.requesterName = creditInfo.requesterName;

            if (creditInfo.submissionDate)
                this.uobAdhoc.creditInfo.submissionDate = new Date(creditInfo.submissionDate);

            this.uobAdhoc.creditInfo.foreignCurrency = creditInfo.foreignCurrency;
            this.uobAdhoc.creditInfo.foreignCurrencyAmount = creditInfo.foreignCurrencyAmount;
            this.uobAdhoc.creditInfo.exRate = creditInfo.exRate;

            // if (creditInfo.loAcceptanceDate)
            // this.loAccpetedDateTemp = new Date(creditInfo.loAcceptanceDate);

            if (creditInfo.loanExpiryDate)
                this.facilityExpiryDateTemp = new Date(creditInfo.loanExpiryDate);

            if (creditInfo.loAcceptanceDate)
                // this.borrwAcceptedDateTemp = new Date(creditInfo.borrwLoAcceptedDate);
                this.borrwAcceptedDateTemp = new Date(creditInfo.loAcceptanceDate);


            if (creditInfo.lISPlusApprovedDate)
                this.decisionDateLisTemp = new Date(creditInfo.lISPlusApprovedDate);

            if (creditInfo.insurersApprovalDate)
                this.decisionDateTemp = new Date(creditInfo.insurersApprovalDate);
        }

        let adverseInfo = element.adverseInfo;
        if (adverseInfo) {
            this.uobAdhoc.adverseInfo.adverseStatus = adverseInfo.adverseStatus;
            this.uobAdhoc.adverseInfo.additionalInfo = adverseInfo.additionalInfo;
            this.uobAdhoc.adverseInfo.overdueDate = adverseInfo.overdueDate;
            this.uobAdhoc.adverseInfo.listOfOverdue = adverseInfo.listOfOverdue;
            this.uobAdhoc.adverseInfo.overdue = adverseInfo.overdue;
            this.uobAdhoc.adverseInfo.repaymentPlanAttached = adverseInfo.repaymentPlanAttached;
        }
    }

    initAccount() {
        this.principal.identity().then((account) => {
            if (account) {
                this.currentAccount = account;
                this.userid = this.currentAccount.login;
            }
        });
    }

    autoPopulateDates(dateType: string[]) {
        console.log("DateType: " + dateType);
        dateType.forEach(element => {
            switch (element) {
                // case "loAcceptedDate":
                //     console.log("Populating loAcceptedDate");
                //     this.uobAdhoc.loAcceptedDate = this.loAccpetedDateTemp;
                //     break;

                case "facilityExpiryDate":
                    console.log("Populating loanExpiryDate");
                    if (typeof this.facilityExpiryDateTemp !== 'undefined') {
                        this.uobAdhoc.facilityExpiryDate = this.facilityExpiryDateTemp;
                        console.log(this.facilityExpiryDateTemp);
                        this.minRequestedExpiryDate = new Date(this.facilityExpiryDateTemp);
                        this.maxRequestedExpiryDate = new Date(this.facilityExpiryDateTemp);
                        this.maxRequestedExpiryDate.setDate(this.maxRequestedExpiryDate.getDate() + 90);
                        console.log(this.maxRequestedExpiryDate);
                    } else {

                    }
                    break;

                case "borrwLoAcceptedDate":
                    console.log("Populating borrwLoAcceptedDate");
                    if (typeof this.borrwAcceptedDateTemp !== 'undefined') {
                        this.uobAdhoc.borrwLoAcceptedDate = this.borrwAcceptedDateTemp;
                    }
                    break;

                case "decisionDate":
                    console.log("Populating decisionDate: lisPlusApprovedDate");
                    if (typeof this.decisionDateTemp != 'undefined') {
                        this.uobAdhoc.decisionDate = this.decisionDateTemp;
                        this.calendarDaysTemp = this.uobAdhoc.decisionDate;
                        this.calendarDaysTemp = new Date(this.calendarDaysTemp);
                        this.calendarDaysTemp.setDate(this.calendarDaysTemp.getDate() + 90);
                        this.uobAdhoc.calendarDays = this.calendarDaysTemp
                    }
                    break;

                case "decisionDateLis":
                    console.log("Populating decisionDateLis");
                    if (typeof this.decisionDateLisTemp != 'undefined') {
                        this.uobAdhoc.decisionDateLis = this.decisionDateLisTemp;
                        this.calendarDaysLisTemp = this.uobAdhoc.decisionDateLis;
                        this.calendarDaysLisTemp = new Date(this.calendarDaysLisTemp);
                        this.calendarDaysLisTemp.setDate(this.calendarDaysLisTemp.getDate() + 60);
                        this.uobAdhoc.calendarDaysLis = this.calendarDaysLisTemp;
                    }
                    break;

                default:
                    console.log("can't update the non existing date");
            }
        });

    }

    ngAfterViewChecked() {
        if (this.uobAdhoc.status === 'Processing' || this.uobAdhoc.status === 'Answered' || this.disableForm) {
            this.uobForm.form.disable();
            this.cdr.detectChanges();
        }
    }

    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0 || event.charCode == 46 || event.charCode == 44) ? null : event.charCode >= 48 && event.charCode <= 57;
    }

    saveAsDraft() {
        this.updateAdhoc();
    }

    updateAdhoc(status?: string) {
        this.spinner.show();
        console.log("initial id" + this.uobAdhoc._id);
        this.uobAdhocService.uobAdhoc = this.uobAdhoc;
        const notificationOption = new NotificationOption();
        notificationOption.toastrConfig = { positionClass: 'toast-top-right' };
        notificationOption.title = 'Notification';
        if (status === 'Processing') {
            console.log('Submitting...');
            this.uobAdhoc.status = status;
            this.showAdhocMarshRefNo = true;

            notificationOption.message = 'Application Submitted Successfully.';
            if (this.uobAdhoc._id) {
                console.log('Submitting adhoc request with id');

                this.uobAdhocService.updateAdhoc(this.uobAdhoc).subscribe((adhocResult) => {
                    this.uobAdhoc._id = adhocResult._id;
                    this.uobAdhoc.status = adhocResult.status;
                    this.uobAdhoc.marshRefNo = adhocResult.marshRefNo;
                    console.log("Adhoc Result" + JSON.stringify(adhocResult));
                    const navigationExtras: NavigationExtras = {
                        queryParams: {
                            relativeTo: this.route,
                            "adhocRefNo": this.uobAdhoc.marshRefNo,
                            "adhocId": this.uobAdhoc._id
                        }
                    }

                    this.spinner.hide();
                    this.notificationService.showNotification(notificationOption);

                    this.uobForm.form.disable();
                    this.cdr.detectChanges();
                    this.router.navigate(['../adhoc/submitted'], navigationExtras);
                    // this.spinner.hide();
                });
            }
            else {
                console.log('Submitting adhoc request without id');
                this.uobAdhocService.createAdhoc(this.uobAdhoc).subscribe((adhocResult) => {

                    // console.log("Adhoc Result" + JSON.stringify(adhocResult));
                    console.log("Adhoc result id created submission: " + adhocResult._id);
                    this.uobAdhoc._id = adhocResult._id;
                    const navigationExtras: NavigationExtras = {
                        queryParams: {
                            relativeTo: this.route,
                            "adhocRefNo": this.uobAdhoc.marshRefNo,
                            "adhocId": this.uobAdhoc._id
                        }
                    }
                    this.spinner.hide();
                    this.notificationService.showNotification(notificationOption);

                    this.uobForm.form.disable();
                    this.cdr.detectChanges();
                    this.router.navigate(['../adhoc/submitted'], navigationExtras);

                });
            }
            // this.notificationService.showNotification(notificationOption);

            // this.pfiForm.form.disable();
            // this.cdr.detectChanges();
            // this.router.navigate(['../adhoc/submitted'], navigationExtras);

        } else {
            console.log('Saving..');
            notificationOption.message = 'Save completed.';
            if (this.uobAdhoc._id) {
                console.log('Saving with id');

                this.uobAdhocService.updateAdhoc(this.uobAdhoc).subscribe((adhocResult) => {
                    this.uobAdhoc._id = adhocResult._id;
                    console.log("Adhoc Result" + JSON.stringify(adhocResult));

                    this.spinner.hide();
                    // this.notificationService.showNotification(notificationOption);
                });
            }
            else {
                console.log('Saving without id');
                this.uobAdhocService.createAdhoc(this.uobAdhoc).subscribe((adhocResult) => {

                    console.log("Adhoc Result" + JSON.stringify(adhocResult));
                    console.log("Adhoc result id created saving: " + adhocResult._id);
                    this.uobAdhoc._id = adhocResult._id;
                    this.spinner.hide();

                    // this.notificationService.showNotification(message);
                    // this.router.navigate(['../../submitted'], {
                    //     relativeTo: this.route
                    // });
                });
            }
            this.notificationService.showNotification(notificationOption);
        }
    }

    submitAdhoc() {
        if (!this.isValidate()) {
            return;
        }
        this.updateAdhoc('Processing');
    }

    ngOnDestroy() {

    }

    reset(fields: string[]) {
        fields.forEach(element => {
            this.uobAdhoc[element] = null;
        });
    }

    updateStack(event, supportDoc) {

        if (this.uobAdhoc.supportingDocs) {
            this.uobAdhoc.supportingDocs.forEach((element) => {
                if (element.name === supportDoc) {
                    element.status = true;
                    if (element.files && element.files != '') {
                        element.files += ', ' + event.filename;
                    } else {
                        element.files = event.filename + ' ';
                    }
                }
            });
        }

        this.isValidate();
    }

    isValidate() {

        let errorDoc = false;
        const notificationOption = new NotificationOption();
        notificationOption.title = '';
        notificationOption.clear = false;
        notificationOption.type = 'error';
        notificationOption.toastrConfig = {
            positionClass: 'toast-bottom-right',
            disableTimeOut: true
        };

        if (!this.isDocumentValid()) {
            notificationOption.message = 'Please select and complete atleast one section.'
            this.notificationService.showNotification(notificationOption);
            return false;
        }

        if (this.uobAdhoc.facilityExpiryExtentsionChkBx === true) {
            if (!this.uobAdhoc.facilityExpiryDate) {
                notificationOption.message = 'We are unable to process this request.Value for Original Facility expiry date is not available.';
                this.notificationService.showNotification(notificationOption);
                return false;
            } else if (this.uobAdhoc.facilityExpiryDate && (this.uobAdhoc.eFacilityExpiryDate.getTime() - this.uobAdhoc.facilityExpiryDate.getTime() / (1000 * 3600 * 24) > 90)) {
                notificationOption.message = 'Requested Expiry date is more than 3 months from Original Expiry date.';
                this.notificationService.showNotification(notificationOption);
                return false;
            }
        }

        let errorMessage = 'Please upload document for ';
        this.notificationService.clearNotification();

        if (this.uobAdhoc.supportingDocs) {
            this.uobAdhoc.supportingDocs.forEach(element => {
                let field = element.name;
                switch (field) {

                    // case "expiryExtensionDocs":
                    //     if (!element.status && this.uobAdhoc.expiryExtensionChkBx) {
                    //         // uploadDocumentFor += '\n -Extension of Facility Expiry date.';
                    //         notificationOption.message =
                    //             errorMessage +
                    //             'Extension of Facility Expiry date.';
                    //         this.notificationService.showNotification(notificationOption);
                    //         errorDoc = true;
                    //     }
                    //     break;

                    // case "dueDateExtensionDocs":
                    //     if (!element.status && this.uobAdhoc.billInfoChkBx) {
                    //         // uploadDocumentFor += '\n -Extension of Due date of Bill.';
                    //         notificationOption.message =
                    //             errorMessage +
                    //             'Extension of Due date of Bill.';
                    //         this.notificationService.showNotification(notificationOption);
                    //         errorDoc = true;
                    //     }
                    //     break;

                    case "Overseas Inclusion of Byuers under CL":
                        if (!element.status && this.uobAdhoc.overseasBuyerChkBx) {
                            notificationOption.message =
                                errorMessage +
                                'Overseas Inclusion of Byuers under CL.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;

                        }
                        break;

                    // case "preshipmentApprovalDocs":
                    //     if (!element.status && this.uobAdhoc.preShipmentChkBx) {
                    //         uploadDocumentFor += '\n -Pre-Shipment Financing Approval.';
                    //     }
                    //     break;

                    // case "letterOfOfferDocs":
                    //     if (!element.status && this.uobAdhoc.moreTimeLoChkBx) {
                    //         // uploadDocumentFor += '\n -Extension of Acceptance of Letter of Offer.';
                    //         notificationOption.message =
                    //             errorMessage +
                    //             'Extension of Acceptance of Letter of Offer.';
                    //         this.notificationService.showNotification(notificationOption);
                    //         errorDoc = true;
                    //     }
                    //     break;

                    case "Reinstatement of Facility":
                        if (!element.status && this.uobAdhoc.internalCreditMemoChkBx) {
                            notificationOption.message =
                                errorMessage +
                                'Reinstatement of Facility.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    // case "insuranceCoverageDocs":
                    //     if (!element.status && this.uobAdhoc.outstandingAmountChkBx) {
                    //         // uploadDocumentFor += '\n -Revalidation of Insurance coverage.';
                    //         notificationOption.message =
                    //             errorMessage +
                    //             'Revalidation of Insurance coverage.';
                    //         this.notificationService.showNotification(notificationOption);
                    //         errorDoc = true;
                    //     }
                    //     break;

                    default:
                        break;
                }
            });
        }
        if (errorDoc) {
            return false;
        } else return true;
    }

    isDocumentValid() {
        // TODO: Update the logic as per mandatory fields
        let sectionChecked = (this.uobAdhoc.expiryExtensionChkBx || this.uobAdhoc.dueDateExtensionChkBx
            || this.uobAdhoc.overseasBuyerChkBx || this.uobAdhoc.moreTimeLoChkBx
            || this.uobAdhoc.newDisbursementsChkBx || this.uobAdhoc.reValidateInsuranceChkBx
        );

        if (sectionChecked === true) {
            return true;
        } else {
            return false;
        }
    }

    goToTop() {
        window.scrollTo(0, 0);
    }

    clearOutSection(event, fields, datesToPopulate?: string[]) {
        if (!event) {
            this.reset(fields);
        } else {
            if (datesToPopulate && datesToPopulate.length > 0) {
                this.autoPopulateDates(datesToPopulate);
            }
        }
    }

    onChangeCurrency() {
        if (this.uobAdhoc.creditInfo && this.uobAdhoc.creditInfo.foreignCurrency == '-1') {
            this.uobAdhoc.creditInfo.foreignCurrency == null;
            this.uobAdhoc.creditInfo.foreignCurrencyAmount = null;
            this.uobAdhoc.creditInfo.exRate = null;
        }
    }

    onManageDocClick(documentType) {
        this.dialogTitle = "Manage Documents";
        this.docType = documentType;
        this.popUp = true;
        this.showManageDoc = true;
    }

    hidePopup(event) {
        this.popUp = false;
        this.showManageDoc = false;
    }

    fromManageDoc(file) {
        if (file.metadata.documentType) {
            this.updateStack(file, file.metadata.documentType);
        }
    }
}
