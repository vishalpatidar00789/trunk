import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { SERVER_API_URL } from '../../../app.constants';

import { JhiDateUtils } from 'ng-jhipster';

import { UobAdhoc } from './uob-adhoc.model';
import { createRequestOption } from '../../../shared';

export type UobAdhocResponseType = HttpResponse<UobAdhoc>;
export type UobAdhocArrayResponseType = HttpResponse<UobAdhoc[]>;

@Injectable()
export class UobAdhocService {

    // private resourceUrl = SERVER_API_URL + 'api/loan/uob-credit-limit';
    private resourceUrl = SERVER_API_URL;
    public uobAdhoc:any;    
    constructor(private http: HttpClient, private dateUtils: JhiDateUtils) { }

    getAdhoc(id: string) {
        return <any>this.http.get(this.resourceUrl + 'adhoc/info/' + id); 
    }
    
    createAdhoc(adhocData) {
        // console.log(JSON.stringify(adhocData));
        return <any>this.http.post(this.resourceUrl + 'adhoc', adhocData);
    }

    updateAdhoc(adhoc: any) {
        const id = adhoc._id;
        delete adhoc['_id'];
        delete adhoc['__v'];
        // console.log(JSON.stringify(adhoc));
        return <any>this.http.put(this.resourceUrl + 'adhoc/updateAdhoc/' + id, adhoc);
    }
}
