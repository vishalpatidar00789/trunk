import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { JhiPaginationUtil } from 'ng-jhipster';
import { PFIAdhocComponent } from './pfi/pfi-adhoc.component';
import { UobAdhocComponent } from './uob/uob-adhoc.component'
import { AdhocSubmittedViewComponent } from './adhoc.submitted-view.component';


export const LoanAdhocRoute: Routes = [
    {
        path: 'adhoc-pfiuser',
        component: PFIAdhocComponent,
        canActivate: [UserRouteAccessService],
        data: {
            authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN'],
            pageTitle: 'Adhoc Request'
        },
        // children: [
        //     {
        //         path: 'submitted',
        //         component: AdhocSubmittedViewComponent,
        //         data: {
        //             pageTitle: 'Adhoc Request'
        //         },
        //     },
        // ]
    },
    {
        path: 'adhoc/submitted',
        component: AdhocSubmittedViewComponent,
        data: {
            pageTitle: 'Adhoc Request'
        },
    },
    {
        path: 'adhoc-uobuser',
        component: UobAdhocComponent,
        data: {
            //authorities: ['ROLE_USER'],
            pageTitle: 'Adhoc Request'
        },
        //canActivate: [UserRouteAccessService]
    },
    {
        path: 'adhoc-pfiuser/:adhocId',
        component: PFIAdhocComponent,
        data: {
            //authorities: ['ROLE_USER'],
            pageTitle: 'Adhoc Request'
        },
        //canActivate: [UserRouteAccessService]
    },
    {
        path: 'adhoc-uobuser/:adhocId',
        component: UobAdhocComponent,
        data: {
            //authorities: ['ROLE_USER'],
            pageTitle: 'Adhoc Request'
        },
        //canActivate: [UserRouteAccessService]
    }
];
