import { Component, OnInit, Input, style } from '@angular/core';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { LoanService } from '../loan.service';
import { LoanProcess } from '../loan.model';
import { Principal, Account, MasterdataService } from '../../shared';
import { UobAdhocService, PFIAdhocService, PFIAdhoc, UobAdhoc } from '.';
import { AdhocSubmittedViewService } from './adhoc.submitted-view.service';

@Component({
  selector: 'lis-adhoc-submitted-view',
  templateUrl: './adhoc.submitted-view.component.html'  
})
export class AdhocSubmittedViewComponent {
  @Input() adhocViewId: string;
  @Input() pfiCode: string;
  
  // userType = 'pfi-user';
  loanUserType:string;
  currentAccount: Account;
  adhocRefNo: String;
  adhocId: String;
  pfiAdhoc:PFIAdhoc;
  uobAdhoc:UobAdhoc;

  constructor(
    // private loanService: LoanService,
    private router: Router,
    private route: ActivatedRoute,
    private principal: Principal,
    private pfiAdhocService:PFIAdhocService,
    private uobAdhocService:UobAdhocService,
    private adhocSubmittedViewService: AdhocSubmittedViewService
  ) {
  }

  ngOnInit() {
    this.principal.identity().then((account) => {
      this.currentAccount = account;
      this.loanUserType = this.currentAccount.bank &&
        this.currentAccount.bank !== 'null' &&
        this.currentAccount.bank === 'UOB' ? 'uob-user' : 'pfi-user';
      if (this.loanUserType == 'uob-user') {
        if (this.uobAdhocService.uobAdhoc) {
          this.uobAdhoc = this.uobAdhocService.uobAdhoc;
        }

      } else if (this.loanUserType == 'pfi-user') {
        
        if (this.pfiAdhocService.pfiAdhoc) {
          this.pfiAdhoc = this.pfiAdhocService.pfiAdhoc;
        }
        console.log(this.pfiAdhoc)
      }
    });
    // Check if the below logic is required or not
    this.route.queryParams.subscribe(params => {
      //Adding logic for auto populated section
      this.adhocRefNo = params["adhocRefNo"];
      this.adhocId = params["adhocId"];
    });
  }

  viewApplication() {
    const navigationExtras: NavigationExtras = {
      queryParams: {
        "adhocId": this.adhocId,
        // "adhocId": this.adhocViewId,
      },
      queryParamsHandling: 'preserve'
      // relativeTo: this.route
    }
    console.log("Adhoc id in view from query params: " + this.adhocId);
    console.log("Adhoc id in view from input variable adhocViewId: " + this.adhocViewId);
    if (this.pfiCode === 'UOB') {
      this.router.navigate(['/adhoc-uobuser'], navigationExtras);
    } else if (this.pfiCode !== 'UOB') {
      this.router.navigate(['/adhoc-pfiuser'], navigationExtras);
    }
  }

  printAcknowledgment(){
    let printableContent;
    if(this.loanUserType == 'pfi-user')
     printableContent=document.getElementById('pfiUser').innerHTML;
    else
     printableContent=document.getElementById('uobUser').innerHTML;

    var restorePage=document.body.innerHTML;    
    document.body.innerHTML=printableContent;
    window.print();
    document.body.innerHTML=restorePage;
  }
}
