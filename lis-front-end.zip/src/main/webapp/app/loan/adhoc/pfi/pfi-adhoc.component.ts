import { Component, OnInit, OnDestroy, Input, ChangeDetectorRef, ViewChild } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router, NavigationEnd, NavigationExtras } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';
import { Message, ConfirmationService } from 'primeng/components/common/api';
import { NotificationService, NotificationOption } from '../../../shared/alert/notification.service';
import { PFIAdhoc } from './pfi-adhoc.model';
import { PFIAdhocService } from './pfi-adhoc.service';
import { Principal, FileUploadComponent, LookupService, Bank } from '../../../shared';
import { NgxSpinnerService } from 'ngx-spinner';
import { LoanSearchResults } from '../../loan-search/loan-search-results/loan-search-results.model';
import { NgForm } from '@angular/forms';
import { LoanService } from '../../loan.service';
import { eventNames } from 'cluster';

@Component({
    selector: 'lis-pfi-adhoc',
    templateUrl: './pfi-adhoc.component.html'
})
export class PFIAdhocComponent implements OnInit, OnDestroy {

    @ViewChild('pfiForm') pfiForm: NgForm;
    @Input() adhocViewId: string;
    filesToUpload: Array<File> = [];
    pfiAdhoc: PFIAdhoc = new PFIAdhoc();
    selectedLoanResult: LoanSearchResults = new LoanSearchResults();
    currentAccount: any;
    eventSubscriber: Subscription;
    isSaving: Boolean;
    routeData: any;
    links: any;
    totalItems: any;
    queryCount: any;
    itemsPerPage: any;
    page: any;
    predicate: any;
    previousPage: any;
    reverse: any;
    bank: Bank;
    // loanExpiryDateTemp: Date;
    loAccpetedDateTemp: Date;
    borrwAcceptedDateTemp: Date;
    facilityExpiryDateTemp: Date;
    decisionDateTemp: Date;
    decisionDateLisTemp: Date;
    calendarDaysTemp: Date;
    calendarDaysLisTemp: Date;
    showAdhocMarshRefNo: boolean = false;
    minRequestedExpiryDate: Date;
    maxRequestedExpiryDate: Date;
    baseLoanId: string;
    disableForm: boolean = false;
    showManageDoc: boolean = false;
    popUp: boolean;
    dialogTitle: string;
    docType: string;
    userid: string;

    constructor(
        private cdr: ChangeDetectorRef,
        private pfiAdhocService: PFIAdhocService,
        private loanService: LoanService,
        private parseLinks: JhiParseLinks,
        private jhiAlertService: JhiAlertService,
        private eventManager: JhiEventManager,
        private router: Router,
        private lookup: LookupService,
        private principal: Principal,
        private notificationService: NotificationService,
        private spinner: NgxSpinnerService,
        private confirmationService: ConfirmationService,
        private route: ActivatedRoute) {
    }

    initAccount() {
        this.principal.identity().then((account) => {
            if (account) {
                this.currentAccount = account;
                this.userid = this.currentAccount.login;
            }
        });
    }

    ngOnInit() {

        console.log("ngOnInit start: " + this.baseLoanId);

        this.initAccount();
        const adhocId = this.route.snapshot.paramMap.get('adhocId');
        console.log("Navigating id: " + adhocId);

        this.router.events.subscribe((event) => {
            if (!(event instanceof NavigationEnd)) {
                return;
            }
            window.scrollTo(0, 0);
        });
        this.route.queryParams.subscribe(params => {
            //Adding logic for auto populated section
            this.baseLoanId = params["_id"];
            this.pfiAdhoc._id = params["adhocId"];
        });

        // Applied for fist time creation of other ad-hoc request
        if (this.baseLoanId) {
            this.loanService.getLoanById(this.baseLoanId).subscribe(loan => {
                console.log("Loan: " + JSON.stringify(loan));

                this.pfiAdhoc.baseLoanId = this.baseLoanId;
                this.populateDataFromBaseLoanApplication(loan);

                console.log("First draft adhoc: " + JSON.stringify(this.pfiAdhoc));
                this.pfiAdhocService.createAdhoc(this.pfiAdhoc).subscribe((adhocResult) => {
                    console.log("First draft created: " + JSON.stringify(adhocResult));
                    console.log("Adhoc result id of draft: " + adhocResult._id);
                    this.pfiAdhoc._id = adhocResult._id;
                });
            })
        }
        this.pfiAdhoc.status = 'Draft';
        console.log("ngOnInit end : " + this.baseLoanId)
        // const adhocId2 = this.route.snapshot.paramMap.get('adhocId');
        // console.log("Navigating id2: " + this.pfiAdhoc);
        console.log("ngOnInit end: adhoc:" + this.pfiAdhoc._id + "this.adhocViewId" + this.adhocViewId);

        // Applied for already saved/submitted ad-hoc application
        if (this.pfiAdhoc._id) {
            this.pfiAdhocService.getAdhoc(this.pfiAdhoc._id).subscribe((adhocResult: any) => {
                if (adhocResult.status !== 'Draft') {
                    this.showAdhocMarshRefNo = true;
                } else {
                    // Logic to populate data from base loan application if user return to edit draft application
                    console.log("adhocResult.baseLoanId: " + adhocResult.baseLoanId);
                    if (adhocResult.baseLoanId) {
                        this.loanService.getLoanById(adhocResult.baseLoanId).subscribe(loan => {
                            // console.log("Loan: " + JSON.stringify(loan));

                            this.populateDataFromBaseLoanApplication(loan);
                        });
                    }
                }
                this.pfiAdhoc.status = adhocResult.status;
                this.pfiAdhoc = adhocResult;
                console.log("Adhoc Request: " + JSON.stringify(this.pfiAdhoc));

                console.log("Populating loAcceptedDate");
                if (this.pfiAdhoc.loAcceptedDate) {
                    this.pfiAdhoc.loAcceptedDate = new Date(this.pfiAdhoc.loAcceptedDate);
                }

                if (this.pfiAdhoc.facilityExpiryDate) {
                    this.pfiAdhoc.facilityExpiryDate = new Date(this.pfiAdhoc.facilityExpiryDate);
                }

                if (this.pfiAdhoc.eFacilityExpiryDate) {
                    this.pfiAdhoc.eFacilityExpiryDate = new Date(this.pfiAdhoc.eFacilityExpiryDate);
                }

                if (this.pfiAdhoc.borrwLoAcceptedDate) {
                    this.pfiAdhoc.borrwLoAcceptedDate = new Date(this.pfiAdhoc.borrwLoAcceptedDate);
                }

                if (this.pfiAdhoc.decisionDate) {
                    this.pfiAdhoc.decisionDate = new Date(this.pfiAdhoc.decisionDate);
                }

                if (this.pfiAdhoc.eFacilityExpiryDate) {
                    this.pfiAdhoc.eFacilityExpiryDate = new Date(this.pfiAdhoc.eFacilityExpiryDate);
                }

                if (this.pfiAdhoc.decisionDate) {
                    this.pfiAdhoc.decisionDate = new Date(this.pfiAdhoc.decisionDate);
                }

                if (this.pfiAdhoc.decisionDate) {
                    this.pfiAdhoc.decisionDate = new Date(this.pfiAdhoc.decisionDate);
                }

                if (this.pfiAdhoc.decisionDateLis) {
                    this.pfiAdhoc.decisionDateLis = new Date(this.pfiAdhoc.decisionDateLis);
                }

                if (this.pfiAdhoc.calendarDays) {
                    this.pfiAdhoc.calendarDays = new Date(this.pfiAdhoc.calendarDays);
                }

                if (this.pfiAdhoc.calendarDaysLis) {
                    this.pfiAdhoc.calendarDaysLis = new Date(this.pfiAdhoc.calendarDaysLis);
                }

                if (this.pfiAdhoc.extendedLoDate) {
                    this.pfiAdhoc.extendedLoDate = new Date(this.pfiAdhoc.extendedLoDate);
                }

                if (this.pfiAdhoc.billDueDate) {
                    this.pfiAdhoc.billDueDate = new Date(this.pfiAdhoc.billDueDate);
                }

                if (this.pfiAdhoc.eBillDueDate) {
                    this.pfiAdhoc.eBillDueDate = new Date(this.pfiAdhoc.eBillDueDate);
                }

                console.log("Adhoc Result Status" + adhocResult.status);
                if (adhocResult && adhocResult.status != "Draft") {
                    this.disableForm = true;
                    this.pfiForm.form.disable();
                    this.cdr.detectChanges();
                }

            });
        } else if (this.adhocViewId) {
            this.pfiAdhocService.getAdhoc(this.adhocViewId).subscribe((adhocResult: any) => {

                console.log("Inside ad-hoc view");

                if (adhocResult.status !== 'Draft') {
                    this.showAdhocMarshRefNo = true;
                }
                this.pfiAdhoc.status = adhocResult.status;
                this.pfiAdhoc = adhocResult;
                console.log("Adhoc Request: " + JSON.stringify(this.pfiAdhoc));


                console.log("Populating loAcceptedDate");
                if (this.pfiAdhoc.loAcceptedDate) {
                    this.pfiAdhoc.loAcceptedDate = new Date(this.pfiAdhoc.loAcceptedDate);
                }

                if (this.pfiAdhoc.facilityExpiryDate) {
                    this.pfiAdhoc.facilityExpiryDate = new Date(this.pfiAdhoc.facilityExpiryDate);
                }

                if (this.pfiAdhoc.eFacilityExpiryDate) {
                    this.pfiAdhoc.eFacilityExpiryDate = new Date(this.pfiAdhoc.eFacilityExpiryDate);
                }

                if (this.pfiAdhoc.borrwLoAcceptedDate) {
                    this.pfiAdhoc.borrwLoAcceptedDate = new Date(this.pfiAdhoc.borrwLoAcceptedDate);
                }

                if (this.pfiAdhoc.decisionDate) {
                    this.pfiAdhoc.decisionDate = new Date(this.pfiAdhoc.decisionDate);
                }

                if (this.pfiAdhoc.eFacilityExpiryDate) {
                    this.pfiAdhoc.eFacilityExpiryDate = new Date(this.pfiAdhoc.eFacilityExpiryDate);
                }

                if (this.pfiAdhoc.decisionDate) {
                    this.pfiAdhoc.decisionDate = new Date(this.pfiAdhoc.decisionDate);
                }

                if (this.pfiAdhoc.decisionDate) {
                    this.pfiAdhoc.decisionDate = new Date(this.pfiAdhoc.decisionDate);
                }

                if (this.pfiAdhoc.decisionDateLis) {
                    this.pfiAdhoc.decisionDateLis = new Date(this.pfiAdhoc.decisionDateLis);
                }

                if (this.pfiAdhoc.calendarDays) {
                    this.pfiAdhoc.calendarDays = new Date(this.pfiAdhoc.calendarDays);
                }

                if (this.pfiAdhoc.calendarDaysLis) {
                    this.pfiAdhoc.calendarDaysLis = new Date(this.pfiAdhoc.calendarDaysLis);
                }

                if (this.pfiAdhoc.extendedLoDate) {
                    this.pfiAdhoc.extendedLoDate = new Date(this.pfiAdhoc.extendedLoDate);
                }

                if (this.pfiAdhoc.billDueDate) {
                    this.pfiAdhoc.billDueDate = new Date(this.pfiAdhoc.billDueDate);
                }

                if (this.pfiAdhoc.eBillDueDate) {
                    this.pfiAdhoc.eBillDueDate = new Date(this.pfiAdhoc.eBillDueDate);
                }

                this.pfiForm.form.disable();
                this.cdr.detectChanges();
            });
        }
    }

    populateDataFromBaseLoanApplication(loan) {
        let element;
        element = loan;
        this.pfiAdhoc.loanMarshRefNo = element.marshRefNo;
        // loanResult.status = element.status;
        // loanResult.marshSubmissionDate = this.datePipe.transform(element.createdAt, 'dd-MMM-yyy');
        this.pfiAdhoc.app = element.app;
        this.pfiAdhoc.consortium = element.consortium;

        let sponsorForm = element.sponsorForm;
        if (sponsorForm) {
            this.pfiAdhoc.sponsorForm.regComName = sponsorForm.regComName;
            this.pfiAdhoc.sponsorForm.ACRANo = sponsorForm.ACRANo;
        }

        let creditInfo = element.creditInfo;
        if (creditInfo) {
            this.pfiAdhoc.creditInfo.pfiCode = creditInfo.pfiCode;
            this.pfiAdhoc.creditInfo.pfiName = creditInfo.pfiName;
            // loanResult.totalRequstedLimitSGD = creditInfo.totalRequstedLimitSGD;
            // if (creditInfo.submissionDate)
            //     loanResult.submissionDate = this.datePipe.transform(creditInfo.submissionDate, 'dd-MMM-yyy');
            this.pfiAdhoc.creditInfo.primary = creditInfo.primary;
            this.pfiAdhoc.creditInfo.autoTopUp = creditInfo.autoTopUp;
            this.pfiAdhoc.creditInfo.bg = creditInfo.bg;
            this.pfiAdhoc.creditInfo.lisPlus = creditInfo.lisPlus;
            // this.pfiAdhoc.requesterName = creditInfo.requesterName;
            this.pfiAdhoc.creditInfo.foreignCurrency = creditInfo.foreignCurrency;
            this.pfiAdhoc.creditInfo.foreignCurrencyAmount = creditInfo.foreignCurrencyAmount;
            this.pfiAdhoc.creditInfo.exRate = creditInfo.exRate;

            if (creditInfo.loAcceptanceDate)
                this.loAccpetedDateTemp = new Date(creditInfo.loAcceptanceDate);

            if (creditInfo.loanExpiryDate)
                this.facilityExpiryDateTemp = new Date(creditInfo.loanExpiryDate);

            if (creditInfo.loAcceptanceDate)
                // this.borrwAcceptedDateTemp = new Date(creditInfo.borrwLoAcceptedDate);
                this.borrwAcceptedDateTemp = new Date(creditInfo.loAcceptanceDate);

            if (creditInfo.lISPlusApprovedDate)
                this.decisionDateLisTemp = new Date(creditInfo.lISPlusApprovedDate)

            if (creditInfo.insurersApprovalDate)
                this.decisionDateTemp = new Date(creditInfo.insurersApprovalDate)

            // if (creditInfo.loAcceptanceDate)
            //     this.loAccpetedDateTemp = new Date(creditInfo.loAcceptanceDate);
            // if (creditInfo.loanExpiryDateFromLoAcceptanceDate)
            //     this.facilityExpiryDateTemp = new Date(creditInfo.loanExpiryDateFromLoAcceptanceDate);
        }

        let adverseInfo = element.adverseInfo;
        if (adverseInfo) {
            this.pfiAdhoc.adverseInfo.adverseStatus = adverseInfo.adverseStatus;
            this.pfiAdhoc.adverseInfo.additionalInfo = adverseInfo.additionalInfo;
            this.pfiAdhoc.adverseInfo.overdueDate = adverseInfo.overdueDate;
            this.pfiAdhoc.adverseInfo.listOfOverdue = adverseInfo.listOfOverdue;
            this.pfiAdhoc.adverseInfo.overdue = adverseInfo.overdue;
            this.pfiAdhoc.adverseInfo.repaymentPlanAttached = adverseInfo.repaymentPlanAttached;
        }
    }

    ngAfterViewChecked() {
        if (this.pfiAdhoc.status === 'Processing' || this.pfiAdhoc.status === 'Answered' || this.disableForm) {
            this.pfiForm.form.disable();
            this.cdr.detectChanges();
        }
    }

    autoPopulateDates(dateType: string[]) {
        console.log("DateType: " + dateType);
        dateType.forEach(element => {
            switch (element) {
                case "loAcceptedDate":
                    console.log("Populating loAcceptedDate");
                    this.pfiAdhoc.loAcceptedDate = this.loAccpetedDateTemp;
                    break;

                case "facilityExpiryDate":
                    console.log("Populating loanExpiryDate");
                    if (typeof this.facilityExpiryDateTemp !== 'undefined') {
                        this.pfiAdhoc.facilityExpiryDate = this.facilityExpiryDateTemp;
                        console.log(this.facilityExpiryDateTemp);
                        this.minRequestedExpiryDate = new Date(this.facilityExpiryDateTemp);
                        this.maxRequestedExpiryDate = new Date(this.facilityExpiryDateTemp);
                        this.maxRequestedExpiryDate.setDate(this.maxRequestedExpiryDate.getDate() + 90);
                        console.log(this.maxRequestedExpiryDate);
                    }
                    break;

                case "borrwLoAcceptedDate":
                    console.log("Populating borrwLoAcceptedDate");
                    if (typeof this.borrwAcceptedDateTemp !== 'undefined') {
                        this.pfiAdhoc.borrwLoAcceptedDate = this.borrwAcceptedDateTemp;
                    }
                    break;

                case "decisionDate":
                    console.log("Populating decisionDate: lisPlusApprovedDate");
                    if (typeof this.decisionDateTemp != 'undefined') {
                        this.pfiAdhoc.decisionDate = this.decisionDateTemp;
                        this.calendarDaysTemp = this.pfiAdhoc.decisionDate;
                        this.calendarDaysTemp = new Date(this.calendarDaysTemp);
                        this.calendarDaysTemp.setDate(this.calendarDaysTemp.getDate() + 60);
                        this.pfiAdhoc.calendarDays = this.calendarDaysTemp
                    }
                    break;

                case "decisionDateLis":
                    console.log("Populating decisionDateLis");
                    if (typeof this.decisionDateLisTemp != 'undefined') {
                        this.pfiAdhoc.decisionDateLis = this.decisionDateLisTemp;
                        this.calendarDaysLisTemp = this.pfiAdhoc.decisionDateLis;
                        this.calendarDaysLisTemp = new Date(this.calendarDaysLisTemp);
                        this.calendarDaysLisTemp.setDate(this.calendarDaysLisTemp.getDate() + 60);
                        this.pfiAdhoc.calendarDaysLis = this.calendarDaysLisTemp;
                    }
                    break;

                default:
                    console.log("can't update the non existing date");
            }
        });

    }

    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0 || event.charCode == 46 || event.charCode == 44) ? null : event.charCode >= 48 && event.charCode <= 57;
    }

    saveAsDraft() {

        this.updateAdhoc();
    }

    updateAdhoc(status?: string) {
        this.spinner.show();
        console.log("initial id" + this.pfiAdhoc._id);
        this.pfiAdhocService.pfiAdhoc = this.pfiAdhoc;
        const notificationOption = new NotificationOption();
        notificationOption.toastrConfig = { positionClass: 'toast-top-right' };
        notificationOption.title = 'Notification';
        if (status === 'Processing') {
            console.log('Submitting...');
            this.pfiAdhoc.status = status;
            this.showAdhocMarshRefNo = true;

            notificationOption.message = 'Application Submitted Successfully.';
            if (this.pfiAdhoc._id) {
                console.log('Submitting adhoc request with id');

                this.pfiAdhocService.updateAdhoc(this.pfiAdhoc).subscribe((adhocResult) => {
                    // console.log("Adhoc Result: " + JSON.stringify(adhocResult));
                    this.pfiAdhoc._id = adhocResult._id;
                    this.pfiAdhoc.status = adhocResult.status;
                    this.pfiAdhoc.marshRefNo = adhocResult.marshRefNo;
                    const navigationExtras: NavigationExtras = {
                        queryParams: {
                            relativeTo: this.route,
                            "adhocRefNo": this.pfiAdhoc.marshRefNo,
                            "adhocId": this.pfiAdhoc._id
                        }
                    }
                    this.spinner.hide();
                    this.notificationService.showNotification(notificationOption);

                    this.pfiForm.form.disable();
                    this.cdr.detectChanges();
                    this.router.navigate(['../adhoc/submitted'], navigationExtras);
                    // this.spinner.hide();
                });
            }
            else {
                console.log('Submitting adhoc request without id');
                this.pfiAdhocService.createAdhoc(this.pfiAdhoc).subscribe((adhocResult) => {

                    // console.log("Adhoc Result" + JSON.stringify(adhocResult));
                    // console.log("Adhoc result id created submission: " + adhocResult._id);
                    this.pfiAdhoc._id = adhocResult._id;
                    const navigationExtras: NavigationExtras = {
                        queryParams: {
                            relativeTo: this.route,
                            "adhocRefNo": this.pfiAdhoc.marshRefNo,
                            "adhocId": this.pfiAdhoc._id
                        }
                    }
                    this.spinner.hide();
                    this.notificationService.showNotification(notificationOption);

                    this.pfiForm.form.disable();
                    this.cdr.detectChanges();
                    this.router.navigate(['../adhoc/submitted'], navigationExtras);

                });
            }
        } else {
            if (this.pfiAdhoc._id) {

                this.pfiAdhocService.updateAdhoc(this.pfiAdhoc).subscribe((adhocResult) => {
                    this.pfiAdhoc._id = adhocResult._id;
                    this.spinner.hide();
                });
            }
            else {
                console.log('Saving without id');
                this.pfiAdhocService.createAdhoc(this.pfiAdhoc).subscribe((adhocResult) => {

                    // console.log("Adhoc Result" + JSON.stringify(adhocResult));
                    console.log("Adhoc result id created saving: " + adhocResult._id);
                    this.pfiAdhoc._id = adhocResult._id;
                    this.spinner.hide();

                    // this.notificationService.showNotification(message);
                    // this.router.navigate(['../../submitted'], {
                    //     relativeTo: this.route
                    // });
                });
            }
            this.notificationService.showNotification();
        }
    }

    submitAdhoc() {
        if (!this.isValidate()) {
            return;
        }
        this.updateAdhoc('Processing');
    }

    ngOnDestroy() {

    }

    reset(fields: string[]) {
        fields.forEach(element => {
            this.pfiAdhoc[element] = null;
        });
    }

    updateStack(event, supportDoc) {
        if (this.pfiAdhoc.supportingDocs) {
            this.pfiAdhoc.supportingDocs.forEach((element) => {
                if (element.name === supportDoc) {
                    element.status = true;
                    if (element.files && element.files != '') {
                        element.files += ', ' + event.filename;
                    } else {
                        element.files = event.filename + ' ';
                    }
                }
            });
        }
        this.isValidate();
    }

    isValidate() {

        let errorDoc = false;
        const notificationOption = new NotificationOption();
        notificationOption.title = '';
        notificationOption.clear = false;
        notificationOption.type = 'error';
        notificationOption.toastrConfig = {
            positionClass: 'toast-bottom-right',
            disableTimeOut: true
        };
        if (!this.isDocumentValid()) {
            notificationOption.message = 'Please select and complete at-least one section.'
            this.notificationService.showNotification(notificationOption);
            return false;
        }

        if (this.pfiAdhoc.facilityExpiryExtentsionChkBx === true) {
            if (!this.pfiAdhoc.facilityExpiryDate) {
                    notificationOption.message = 'We are unable to process this request.Value for Original Facility expiry date is not available';
                    this.notificationService.showNotification(notificationOption);
                    return false;
            }
            else if (this.pfiAdhoc.facilityExpiryDate && (this.pfiAdhoc.eFacilityExpiryDate.getTime() - this.pfiAdhoc.facilityExpiryDate.getTime() / (1000 * 3600 * 24) > 90)) {
                notificationOption.message = 'Requested Expiry date is more than 3 months from Original Expiry date.';
                this.notificationService.showNotification(notificationOption);
                return false;
            }
        }

        let errorMessage = 'Please upload document for ';
        this.notificationService.clearNotification();

        if (this.pfiAdhoc.supportingDocs) {
            this.pfiAdhoc.supportingDocs.forEach(element => {
                let field = element.name;
                switch (field) {

                    // case "Extension of Facility Expiry date":
                    //     if (!element.status && this.pfiAdhoc.expiryExtensionChkBx) {
                    //         // uploadDocumentFor += '\n -Extension of Facility Expiry date.';
                    //         notificationOption.message =
                    //             errorMessage +
                    //             'Extension of Facility Expiry date.';
                    //         this.notificationService.showNotification(notificationOption);
                    //         errorDoc = true;
                    //     }
                    //     break;

                    // case "Extension of Due date of Bill":
                    //     if (!element.status && this.pfiAdhoc.billInfoChkBx) {
                    //         // uploadDocumentFor += '\n -Extension of Due date of Bill.';
                    //         notificationOption.message =
                    //             errorMessage +
                    //             'Extension of Due date of Bill.';
                    //         this.notificationService.showNotification(notificationOption);
                    //         errorDoc = true;
                    //     }
                    //     break;

                    case "Overseas Inclusion of Byuers under CL":
                        if (!element.status && this.pfiAdhoc.overseasBuyerChkBx) {
                            // uploadDocumentFor += '\n -Overseas Inclusion of Byuers under CL.';
                            notificationOption.message =
                                errorMessage +
                                'Overseas Inclusion of Byuers under CL.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;

                        }
                        break;

                    case "Pre-Shipment Financing Approval":
                        if (!element.status && this.pfiAdhoc.preShipmentChkBx) {
                            // uploadDocumentFor += '\n -Pre-Shipment Financing Approval.';
                            notificationOption.message =
                                errorMessage +
                                'Pre-Shipment Financing Approval.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    // case "Extension of Acceptance of Letter of Offer":
                    //     if (!element.status && this.pfiAdhoc.moreTimeLoChkBx) {
                    //         // uploadDocumentFor += '\n -Extension of Acceptance of Letter of Offer.';
                    //         notificationOption.message =
                    //             errorMessage +
                    //             'Extension of Acceptance of Letter of Offer.';
                    //         this.notificationService.showNotification(notificationOption);
                    //         errorDoc = true;
                    //     }
                    //     break;

                    case "Reinstatement of Facility":
                        if (!element.status && this.pfiAdhoc.internalCreditMemoChkBx) {
                            // uploadDocumentFor += '\n -Reinstatement of Facility.';
                            notificationOption.message =
                                errorMessage +
                                'Reinstatement of Facility.';
                            this.notificationService.showNotification(notificationOption);
                            errorDoc = true;
                        }
                        break;

                    // case "Revalidation of Insurance coverage":
                    //     if (!element.status && this.pfiAdhoc.outstandingAmountChkBx) {
                    //         // uploadDocumentFor += '\n -Revalidation of Insurance coverage.';
                    //         notificationOption.message =
                    //             errorMessage +
                    //             'Revalidation of Insurance coverage.';
                    //         this.notificationService.showNotification(notificationOption);
                    //         errorDoc = true;
                    //     }
                    //     break;

                    // case "Others":
                    //     if (!element.status && this.pfiAdhoc.reviewDocChkBx) {
                    //         // uploadDocumentFor += '\n -Others.';
                    //         notificationOption.message =
                    //             errorMessage +
                    //             'Others.';
                    //         this.notificationService.showNotification(notificationOption);
                    //         errorDoc = true;
                    //     }
                    //     break;

                    default:
                        break;
                }
            });
        }
        if (errorDoc) {
            return false;
        } else return true;
    }

    isDocumentValid() {
        // TODO: Update the logic as per mandatory fields
        let sectionChecked = (this.pfiAdhoc.cancellationSectionChkBx || this.pfiAdhoc.expiryExtensionChkBx || this.pfiAdhoc.dueDateExtensionChkBx
            || this.pfiAdhoc.overseasBuyerChkBx || this.pfiAdhoc.preShipmentChkBx || this.pfiAdhoc.moreTimeLoChkBx
            || this.pfiAdhoc.newDisbursementsChkBx || this.pfiAdhoc.reValidateInsuranceChkBx
            || this.pfiAdhoc.processRequestChkBx);

        if (sectionChecked === true) {
            return true;
        } else {
            return false;
        }
    }

    goToTop() {
        window.scrollTo(0, 0);
    }

    clearOutSection(event, fields, datesToPopulate?: string[]) {
        if (!event) {
            this.reset(fields);

        } else {
            if (datesToPopulate && datesToPopulate.length > 0) {
                this.autoPopulateDates(datesToPopulate);
            }
        }
    }

    onChangeCurrency() {
        if (this.pfiAdhoc.creditInfo && this.pfiAdhoc.creditInfo.foreignCurrency == '-1') {
            this.pfiAdhoc.creditInfo.foreignCurrency = null;
            this.pfiAdhoc.creditInfo.foreignCurrencyAmount = null;
            this.pfiAdhoc.creditInfo.exRate = null;
        }
    }

    onManageDocClick(documentType) {
        this.dialogTitle = "Manage Documents";
        this.docType = documentType;
        this.popUp = true;
        this.showManageDoc = true;
    }

    hidePopup(event) {
        this.popUp = false;
        this.showManageDoc = false;
    }

    fromManageDoc(file) {
        if (file.metadata.documentType) {
            this.updateStack(file, file.metadata.documentType);
        }
    }
}
