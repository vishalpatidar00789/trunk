import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { SERVER_API_URL } from '../../../app.constants';

import { JhiDateUtils } from 'ng-jhipster';

import { PFIAdhoc } from './pfi-adhoc.model';
import { createRequestOption } from '../../../shared';

export type PFIAdhocResponseType = HttpResponse<PFIAdhoc>;
export type PFIAdhocArrayResponseType = HttpResponse<PFIAdhoc[]>;

@Injectable()
export class PFIAdhocService {

    // private resourceUrl = SERVER_API_URL + 'api/loan/pfiuser';
    private resourceUrl = SERVER_API_URL;
    public pfiAdhoc:any;    
    constructor(private http: HttpClient, private dateUtils: JhiDateUtils) { }

    getAdhoc(id: string) {
        return <any>this.http.get(this.resourceUrl + 'adhoc/info/' + id); 
    }

    createAdhoc(adhocData) {
        // console.log("UI create adhoc" + JSON.stringify(adhocData));
        return <any>this.http.post(this.resourceUrl + 'adhoc', adhocData); 
    }

    updateAdhoc(adhoc: any) {
        const id = adhoc._id;
        delete adhoc['_id'];
        delete adhoc['__v'];
        // console.log("UI update adhoc" + JSON.stringify(adhoc));
        return <any>this.http.put(this.resourceUrl + 'adhoc/updateAdhoc/' + id, adhoc);
    }

}
