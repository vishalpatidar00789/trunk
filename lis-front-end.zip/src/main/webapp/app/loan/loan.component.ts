import { Component, OnInit } from '@angular/core';
import { LoanService } from './loan.service';
import { Router, NavigationEnd } from '@angular/router';
import { Account, Principal } from '../shared';
import { SponsorEFormService } from './sponsor-eform/sponsor-eform.service';
import { PFICreditLimit } from './pfi/pfi-credit-limit.model';
import { UobCreditLimit } from './uob/uob-credit-limit.model';
import { SponsorEForm } from './sponsor-eform/sponsor-eform.model';
import { PFICreditLimitService } from './pfi/pfi-credit-limit.service';
import { UobCreditLimitService } from './uob/uob-credit-limit.service';
import { LoanProcess, Loan } from './loan.model';

@Component({
  selector: 'lis-loan',
  templateUrl: './loan.component.html',
  styles: []
})
export class LoanComponent implements OnInit {
  currentAccount: Account;
  loanUserType = 'pfi-user';
  loan: Loan;
  loanProcess: LoanProcess;
  status: any;
  trancheNo: string;  

  constructor(
    private loanService: LoanService,
    private router: Router,
    private principal: Principal,
    private sponsorEFormService: SponsorEFormService,
    private pfiCreditLimitService: PFICreditLimitService,
    private uobCreditLimitService: UobCreditLimitService
  ) {
    this.loanService.status.subscribe((res) => {
      this.status = res;
    });
    this.loanService.loanProcess$.subscribe((loanProcess) => {
      this.loanProcess = Object.assign({}, loanProcess);
      this.changeTrancheNo();
    });
    this.clearLoanApplication();
  }

  ngOnInit() {
    this.status = 'Draft';
    this.loanService.isLoanForm=true;
    this.principal.identity().then((account) => {
      this.currentAccount = account;
      this.loanUserType =
        this.currentAccount.bank &&
        this.currentAccount.bank !== 'null' &&
        this.currentAccount.bank === 'UOB'
          ? 'uob-user'
          : 'pfi-user';
    });

    this.router.events.subscribe((event) => {
      if (!(event instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
  }

  isLoanForm() {
    return this.loanService.isLoanForm;
  }

  changeTrancheNo() {
    if (this.loanProcess.tranchName) {
      switch (this.loanProcess.tranchName) {
        case 'LIS5':
          this.trancheNo = '5';
          break;
        case 'LIS6':
          this.trancheNo = '6';
          break;
        case 'LIS7':
          this.trancheNo = '7';
          break;
        default:
          this.trancheNo = '5';
          break;
      }
    }
  }

  public clearLoanApplication() {
    this.loanService.loanId = '';
    this.sponsorEFormService.setSponsorEForm(new SponsorEForm());
    //this.loanService.changeAdditionalFields(new AdditionalFields());
  }
}
