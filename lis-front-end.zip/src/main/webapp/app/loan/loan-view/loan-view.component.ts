import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { LoanService } from '../loan.service';
import { PFICreditLimitService } from '../pfi/pfi-credit-limit.service';
import { UobCreditLimitService } from '../uob/uob-credit-limit.service';
import {
  LoanProcess,
  CompletedStep,
  PFICreditLimit,
  UobCreditLimit,
  SponsorEForm
} from '..';
import { SponsorEFormService } from '../sponsor-eform/sponsor-eform.service';
import { LookupService } from '../../shared';
import { MidTermService } from '../mid-term/mid-term.service';

@Component({
  selector: 'lis-loan-view',
  templateUrl: 'loan-view.component.html'
})
export class LoanViewComponent implements OnInit, OnDestroy {
  @Input() loanViewId: string;
  @Input() isMidTerm: boolean;
  loanProcess: LoanProcess;
  loanType: string;
  tranche: any;
  constructor(
    private loanService: LoanService,
    private midTermService: MidTermService,
    private sponsorEFormService: SponsorEFormService,
    private pfiCreditService: PFICreditLimitService,
    private uobCreditLimitService: UobCreditLimitService,
    private lookupService: LookupService
  ) {
    this.lookupService.getCurrentTranche().subscribe((tranche) => {
      if (tranche) {
        this.tranche = tranche;
      }
    });
  }

  ngOnInit() {
    if (this.isMidTerm) {
      this.midTermService
      .getMidTermLoanById(this.loanViewId)
      .subscribe((loanResult: any) => {
        if (loanResult) {
          const loanProcess = new LoanProcess();
          loanProcess.id = loanResult._id;
          loanProcess.status = loanResult.status;
          loanProcess.loanBaseId = loanResult.loanBaseId;
          loanProcess.isMidTerm = true;
          loanProcess.isMidTermIncrease = loanResult.isMidTermIncrease;
          loanProcess.marshRefNo = loanResult.marshRefNo;
          loanProcess.isViewLoan = true;
          loanProcess.completedStep = CompletedStep.stepCompleted;
          if (this.tranche) {
            loanProcess.tranchName = this.tranche.trancheName;
          }
          this.loanService.setLoanStepProcess(loanProcess);
          this.sponsorEFormService.setSponsorEForm(
            Object.assign({}, loanResult.sponsorForm)
          );
          if (loanResult.consortium) {
            this.loanService
              .getConsortiumById(loanResult.consortium)
              .subscribe((consortiumResult: any) => {
                if (consortiumResult.consortiumName === '9PFI') {
                  this.loanType = '9PFI';
                } else if (consortiumResult.consortiumName === 'UOB') {
                  this.loanType = 'UOB';
                }
              });
          }
        }
      });
    } else {
      this.loanService
        .getLoanById(this.loanViewId)
        .subscribe((loanResult: any) => {
          if (loanResult) {
            const loanProcess = new LoanProcess();
            loanProcess.id = loanResult._id;
            loanProcess.status = loanResult.status;
            loanProcess.marshRefNo = loanResult.marshRefNo;
            loanProcess.isViewLoan = true;
            loanProcess.completedStep = CompletedStep.stepCompleted;
            if (this.tranche) {
              loanProcess.tranchName = this.tranche.trancheName;
            }
            this.loanService.setLoanStepProcess(loanProcess);
            this.sponsorEFormService.setSponsorEForm(
              Object.assign({}, loanResult.sponsorForm)
            );
            if (loanResult.consortium) {
              this.loanService
                .getConsortiumById(loanResult.consortium)
                .subscribe((consortiumResult: any) => {
                  if (consortiumResult.consortiumName === '9PFI') {
                    this.loanType = '9PFI';
                  } else if (consortiumResult.consortiumName === 'UOB') {
                    this.loanType = 'UOB';
                  }
                });
            }
          }
        });
    }
  }

  ngOnDestroy(): void {
    this.loanService.setLoanStepProcess(Object.assign({}, new LoanProcess()));
    this.sponsorEFormService.setSponsorEForm(
      Object.assign({}, new SponsorEForm())
    );
  }
}
