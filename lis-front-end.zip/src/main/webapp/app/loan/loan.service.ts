import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, Subject } from 'rxjs/Rx';
import { SERVER_API_URL } from '../app.constants';

import { JhiDateUtils } from 'ng-jhipster';

import { createRequestOption } from '../shared';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Loan, LoanProcess,SupportingDocuments } from './loan.model';
import { CRRPremiumRate } from '.';

@Injectable()
export class LoanService {
  private resourceUrl = SERVER_API_URL;

  public pfiData: any;
  public uobData: any;
  public isLoanForm: boolean;
  // Observable Laon Step Process form sources
  loanStepProcessSource = new BehaviorSubject<LoanProcess>(new LoanProcess());

  // Observable Laon Step Process form streams
  loanProcess$ = this.loanStepProcessSource.asObservable();

  loanId: string;
  status = new Subject();

  public setId(id) {
    this.loanId = id;
  }
  public getId() {
    return this.loanId;
  }

  public setStatus(status) {
    this.status.next(status);
  }

  public getStatus() {
    return this.status;
  }
  //private resourceUrl = SERVER_API_URL + 'api/loan/uob-credit-limit';

  constructor(private http: HttpClient, private dateUtils: JhiDateUtils) { }

  setLoanStepProcess(loanProcess: LoanProcess) {
    this.loanStepProcessSource.next(loanProcess);
  }

  createLoan(loanData) {
    return <any>this.http.post(this.resourceUrl + 'loanform', loanData); //change url
  }

  // Save As Draft Loan
  updateLoan(loan: any) {
    const id = loan._id;
    delete loan._id;
    //console.log(JSON.stringify(loan));   
    return <any>(
      this.http.put(SERVER_API_URL + 'loanform/saveAsDraft/' + id, loan)
    );
  }

  // Submit Loan Application
  submitLoan(loan: any) {
    const id = loan._id;
    delete loan['_id'];
    // console.log(JSON.stringify(loan));
    return <any>this.http.put(this.resourceUrl + 'loanform/submit/' + id, loan);
  }

  getLoanById(loanId: string) {
    return <any>this.http.get(this.resourceUrl + 'loanform/loan/' + loanId);
  }

  getCRRPremiumRate(): Observable<CRRPremiumRate[]> {
    return this.http.get<CRRPremiumRate[]>(
      this.resourceUrl + 'master-data/consortium/tier-rating'
    );
    //     /master-data/consortium/tier-rating
    // return Observable.of([
    //   {
    //     tierRatingDescription: 'CRR 1 to 6 : 1.35%',
    //     from: 1,
    //     to: 6,
    //     premiumRatePercentage: 1.35
    //   },
    //   {
    //     tierRatingDescription: 'CRR 7 to 10 : 1.65%',
    //     from: 7,
    //     to: 10,
    //     premiumRatePercentage: 1.65
    //   },
    //   {
    //     tierRatingDescription: 'CRR 11 to 13 : 1.925%',
    //     from: 11,
    //     to: 13,
    //     premiumRatePercentage: 1.925
    //   },
    //   {
    //     tierRatingDescription: 'CRR 14 to 15 : 1.925%',
    //     from: 14,
    //     to: 15,
    //     premiumRatePercentage: 2.2
    //   },
    //   {
    //     tierRatingDescription: 'No CRR : 1.925%',
    //     from: 0,
    //     to: 0,
    //     premiumRatePercentage: 1.9251
    //   },
    //   {
    //     tierRatingDescription: 'Exceptional Pricing',
    //     from: 0,
    //     to: 0,
    //     premiumRatePercentage: 0
    //   }
    // ]);
  }

  getConsortiumById(Id: string) {
    return <any>this.http.get(this.resourceUrl + 'master-data/consortium/' + Id);
  }

  dlValidation(loan: Loan, loanType: any) {

    delete loan['_id'];
    // console.log(JSON.stringify(loan));
    //delete loan['sponsorForm']['dateofIncorporation'];
    if (loanType === "LOAN") {
      // console.log("loanType:"+loanType);
      return <any>(this.http.post(SERVER_API_URL + 'loanform/dlValidation', loan));
    } else {
      // console.log("loanType:"+loanType);
      return <any>(this.http.post(SERVER_API_URL + 'mid-term/dlValidation', loan));
    }
  }

  bgValidation(loan: Loan, loanType: any) {

    delete loan['_id'];
    // console.log(JSON.stringify(loan));
    //delete loan['sponsorForm']['dateofIncorporation'];
    if (loanType === "LOAN") {
      // console.log("loanType:"+loanType);
      return <any>(this.http.post(SERVER_API_URL + 'loanform/bgValidation', loan));
    } else {
      // console.log("loanType:"+loanType);
      return <any>(this.http.post(SERVER_API_URL + 'mid-term/bgValidation', loan));
    }
  }

  validateSupportingDocumentForSubmission(payload: SupportingDocuments) {
    console.log('payload::', JSON.stringify(payload));
    return this.http.post(this.resourceUrl + 'supporting-documents/validate-supporting-document-for-submission', payload);
  }

}
