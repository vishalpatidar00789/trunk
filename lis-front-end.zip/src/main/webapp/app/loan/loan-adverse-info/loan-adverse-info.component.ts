import { Component, OnInit, Input, OnChanges, Output, EventEmitter, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotificationService,NotificationOption } from '../../shared/alert/notification.service';
import { LoanAdverseInfo, LoanAdverseInfo_ } from './loan-adverse-info.model';
import { LoanSearchResults } from '../loan-search/loan-search-results/loan-search-results.model';
import { LoanAdverseInfoService } from './loan-adverse-info.service';
import { DateUtil } from '../../shared';
import { RadioButtonModule } from 'primeng/radiobutton';
import { JhiEventManager } from 'ng-jhipster';

@Component({
    selector: 'loan-adverse-info',
    templateUrl: './loan-adverse-info.component.html'
})
export class LoanAdverseInfoComponent implements OnInit, OnChanges, OnDestroy {

    displayMessage: boolean;
    userMessage: string;
    adverseStatus: any[];
    moreOverdueDate: any;
    lessOverdueDate: any;
    adverseInfoModel: LoanAdverseInfo;
    adverseInfoModel_: LoanAdverseInfo_;
    documentUploadFlag1:boolean;
    documentUploadFlag2:boolean;
    collectionType:string;    

    @Input() userid: string;
    @Input() selectedLoanResult: LoanSearchResults;
    @Output() closePopUp = new EventEmitter<boolean>();
    @Output() updateAdverseInfo = new EventEmitter<LoanAdverseInfo>();


    constructor(
        private loanAdverseInfoService: LoanAdverseInfoService,
        private notificationService: NotificationService,
        private spinner: NgxSpinnerService,
        private eventManager: JhiEventManager) {
    }

    ngOnChanges() {
        if (this.selectedLoanResult) {
            this.adverseInfoModel_ = new LoanAdverseInfo_();
            this.adverseInfoModel_._id = this.selectedLoanResult._id;
            this.adverseInfoModel_.marshRefNo = this.selectedLoanResult.marshRefNo;
            this.adverseInfoModel_.uenNumber = this.selectedLoanResult.aCRArefNo;
            this.adverseInfoModel_.borrowerRegName = this.selectedLoanResult.borrowerRegName;
            this.adverseInfoModel_.pfiName = this.selectedLoanResult.pfiName;
            this.adverseInfoModel_.status = this.selectedLoanResult.status;
            this.adverseInfoModel_._id = this.selectedLoanResult._id;
            this.adverseInfoModel_.typeOfRequest = this.selectedLoanResult.typeOfRequest;
        }
    }

    ngOnInit() {

        console.log(this.selectedLoanResult);
        this.adverseInfoModel = new LoanAdverseInfo();
        this.displayMessage = false;
        this.adverseStatus = [
            { label: 'Yes', value: 'Yes' },
            { label: 'No', value: 'No' }
        ];
        if (this.selectedLoanResult) {
            switch (this.selectedLoanResult.typeOfRequest) {
                case 'loan':
                    this.collectionType ='LOAN';
                    break;
                case 'midterm':
                    this.collectionType ='MIDTERM';
                    break;
               case 'adhoc':
                    this.collectionType ='ADHOC';
                    break;
            }
            this.adverseInfoModel.adverseInfo.adverseStatus = this.selectedLoanResult.adverseStatus;
            this.adverseInfoModel.adverseInfo.additionalInfo = this.selectedLoanResult.additionalInfo;
            this.adverseInfoModel.adverseInfo.listOfOverdue = this.selectedLoanResult.listOfOverdue;
            this.adverseInfoModel.adverseInfo.overdue = this.selectedLoanResult.overdue;
            this.adverseInfoModel.adverseInfo.overdueDate = new Date(this.selectedLoanResult.overdueDate);
            this.adverseInfoModel.adverseInfo.repaymentPlanAttached = this.selectedLoanResult.repaymentPlanAttached;
            // this.adverseInfoModel.adverseInfo.typeOfRequest = this.selectedLoanResult.typeOfRequest;            

            if (this.adverseInfoModel.adverseInfo.overdue == 'less') {
                this.lessOverdueDate = this.adverseInfoModel.adverseInfo.overdueDate;
            }
            else if (this.adverseInfoModel.adverseInfo.overdue == 'more') {
                this.moreOverdueDate = this.adverseInfoModel.adverseInfo.overdueDate;
            }

            if(this.adverseInfoModel.adverseInfo.listOfOverdue){
                this.documentUploadFlag1=true;
            }
            if(this.adverseInfoModel.adverseInfo.repaymentPlanAttached){
                this.documentUploadFlag2=true;
            }
        }
    }

    ngOnDestroy() {
        this.adverseInfoModel = null;
        this.adverseInfoModel_ = null;
        console.log('destroy');
    }

    cancel() {
        this.closePopUp.emit(true);
    }

    clearDate() {
        if (this.adverseInfoModel.adverseInfo.overdue == 'less') {
            this.lessOverdueDate = null;
        }
        else if (this.adverseInfoModel.adverseInfo.overdue == 'more') {
            this.moreOverdueDate = null;
        }
    }

    save() {
        
        if(this.adverseInfoModel.adverseInfo.listOfOverdue && !this.documentUploadFlag1){
            alert('Upload document for listOverdue.');
            return false;
        }
        if(this.adverseInfoModel.adverseInfo.repaymentPlanAttached && !this.documentUploadFlag2){
            alert('Upload document for repayment plan attached.');
            return false;
        }
        
        this.spinner.show();

        if (this.lessOverdueDate)
            this.adverseInfoModel.adverseInfo.overdueDate = this.lessOverdueDate;
        else if (this.moreOverdueDate)
            this.adverseInfoModel.adverseInfo.overdueDate = this.moreOverdueDate;

        this.updateAdverseInfo.emit(this.adverseInfoModel);

        if(this.adverseInfoModel_.typeOfRequest==='loan'){
        this.loanAdverseInfoService.upldateLoanAdverseInfo(this.adverseInfoModel, this.selectedLoanResult._id).subscribe((res) => {
            console.log(res);
            this.spinner.hide();
            const notificationOption = new NotificationOption();            
            notificationOption.title = 'Notification';
            notificationOption.message = 'Adverse Information Saved Successfully';
            this.notificationService.showNotification(notificationOption);
        });
    }else if(this.adverseInfoModel_.typeOfRequest==='midterm'){
        this.loanAdverseInfoService.upldateMidTermAdverseInfo(this.adverseInfoModel, this.selectedLoanResult._id).subscribe((res) => {
            console.log(res);
            this.spinner.hide();
            const notificationOption = new NotificationOption();            
            notificationOption.title = 'Notification';
            notificationOption.message = 'Adverse Information Saved Successfully';
            this.notificationService.showNotification(notificationOption);
        });
    }
    else{

        this.loanAdverseInfoService.upldateAdHocAdverseInfo(this.adverseInfoModel, this.selectedLoanResult._id).subscribe((res) => {
            console.log(res);
            this.spinner.hide();
            const notificationOption = new NotificationOption();
            notificationOption.title = 'Notification';
            notificationOption.message = 'Adverse Information Saved Successfully';
            this.notificationService.showNotification(notificationOption);
        });

    }

        this.cancel();
    }

    afterUpload(uploadedFile:any,flag:string){
        if(flag=='1')
        this.documentUploadFlag1=true
        else if(flag=='2')
        this.documentUploadFlag2=true       

        this.eventManager.broadcast({
            name: 'adverseInfoFileUploaded',
            content: uploadedFile
          });
    }   

}