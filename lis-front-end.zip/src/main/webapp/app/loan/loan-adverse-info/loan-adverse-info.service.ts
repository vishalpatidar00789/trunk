import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { SERVER_API_URL } from '../../app.constants';

@Injectable()
export class LoanAdverseInfoService {

    private resourceUrl = SERVER_API_URL;
    constructor(private http: HttpClient) { }

    upldateLoanAdverseInfo(adverseInfo: any, id) {
        console.log(JSON.stringify(adverseInfo));
        return <any>this.http.put(this.resourceUrl + 'loanform/adverseInfo/' + id, adverseInfo);
    }
    
    upldateMidTermAdverseInfo(adverseInfo: any, id) {
        console.log(JSON.stringify(adverseInfo));
        return <any>this.http.put(this.resourceUrl + 'mid-term/adverseInfo/' + id, adverseInfo);
    }

    upldateAdHocAdverseInfo(adverseInfo: any, id) {
       // delete adverseInfo['typeOfRequest'];
        console.log(JSON.stringify(adverseInfo));
        return <any>this.http.put(this.resourceUrl + 'adhoc/adhocAdverseInfo/' + id, adverseInfo);
    }

 }