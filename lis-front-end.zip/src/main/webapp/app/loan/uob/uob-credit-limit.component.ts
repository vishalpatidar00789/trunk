import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  ElementRef,
  ChangeDetectorRef,
  AfterViewChecked
} from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';
import { LoanService } from '../loan.service';

import { UobCreditLimit, CRRPremiumRate } from './uob-credit-limit.model';
import { UobCreditLimitService } from './uob-credit-limit.service';
import { Principal, LookupService, Currencies, Bank } from '../../shared';
import { SponsorEForm } from '../sponsor-eform/sponsor-eform.model';
import { DateUtil } from '../../shared/date-formatter/date-util';
import { SponsorEFormService } from '../sponsor-eform/sponsor-eform.service';
import { ConfirmationService } from 'primeng/components/common/api';
import {
  NotificationService,
  NotificationOption
} from '../../shared/alert/notification.service';
import { UOBLoan, LoanProcess, CompletedStep } from '../loan.model';
import { NgxSpinnerService } from 'ngx-spinner';
import { NgForm } from '@angular/forms';
import {
  UOBMidTermCreditLimit,
  UOBMidTermLoan
} from '../mid-term/mid-term.model';
import { MidTermService } from '../mid-term/mid-term.service';

@Component({
  selector: 'lis-uob-credit-limit',
  templateUrl: './uob-credit-limit.component.html'
})
export class UobCreditLimitComponent
  implements OnInit, OnDestroy, AfterViewChecked {
  @ViewChild('creditForm') creditForm: NgForm;
  loanProcess: LoanProcess;
  uobCreditLimit: any;
  sponsorForm: SponsorEForm = new SponsorEForm();
  currentAccount: any;
  eventSubscriber: Subscription;
  routeData: any;
  links: any;
  totalItems: any;
  queryCount: any;
  itemsPerPage: any;
  page: any;
  predicate: any;
  previousPage: any;
  reverse: any;
  loanId = '';
  successMessage: boolean;
  errorMessage: boolean;
  isExceptionalCrrRate: boolean;
  crrRate: number;
  currencyList: Currencies[];
  uobLoan: any;
  disableFutureDate = new Date();
  cRRPremiumRateList: CRRPremiumRate[];
  cRRNonEditList: CRRPremiumRate[];
  cRREditList: CRRPremiumRate[];
  userid: string;
  bank: Bank;
  baseLoan: UOBLoan;
  collectionType: string;
  manageDoc = { name: '', documentType: '' };
  popUp: boolean;

  constructor(
    private cdr: ChangeDetectorRef,
    private sponsorEFormService: SponsorEFormService,
    private uobCreditLimitService: UobCreditLimitService,
    private midTermService: MidTermService,
    private parseLinks: JhiParseLinks,
    private jhiAlertService: JhiAlertService,
    private eventManager: JhiEventManager,
    private principal: Principal,
    private loanService: LoanService,
    private lookup: LookupService,
    private router: Router,
    private route: ActivatedRoute,
    private _eref: ElementRef,
    private notificationService: NotificationService,
    private spinner: NgxSpinnerService,
    private confirmationService: ConfirmationService
  ) {
    this.isExceptionalCrrRate = false;
    this.loanService.loanProcess$.subscribe(loanProcess => {
      this.loanProcess = Object.assign({}, loanProcess);
    });
    this.sponsorEFormService.springEForm$.subscribe(sponsorForm => {
      this.sponsorForm = sponsorForm;
    });

    this.principal.identity().then(account => {
      if (account) {
        this.currentAccount = account;
        this.userid = this.currentAccount.login;
      }
    });
  }

  ngAfterViewChecked() {
    // console.dir(this.pfIForm.form);
    if (this.loanProcess.isViewLoan) {
      this.creditForm.form.disable();
      this.cdr.detectChanges();
    }
  }

  ngOnInit() {
    this.popUp = false;
    if (this.loanProcess) {
      if (this.loanProcess.isMidTerm) {
        this.collectionType = 'MIDTERM';
        this.uobCreditLimit = new UOBMidTermCreditLimit();
        if (this.loanProcess && this.loanProcess.id) {
          this.midTermService
            .getMidTermLoanById(this.loanProcess.id)
            .subscribe((loanResult: any) => {
              if (loanResult) {
                if (loanResult.sponsorForm.dateofIncorporation) {
                  this.uobCreditLimit = loanResult.creditInfo;
                  this.setDateFormat();
                }
                this.baseLoan = new UOBLoan();
                if (this.loanProcess.loanBaseId) {
                  this.loanService
                    .getLoanById(this.loanProcess.loanBaseId)
                    .subscribe((loanbaseResult: any) => {
                      if (loanbaseResult) {
                        this.baseLoan = loanbaseResult;
                        if (!loanResult.sponsorForm.dateofIncorporation) {
                          this.autoPopulateBaseLoan();
                        }
                      }
                    });
                }
                this.uobCreditLimit.pfiName = loanResult.creditInfo.pfiName;
                this.uobCreditLimit.pfiCode = loanResult.creditInfo.pfiCode;
              }
            });
        }
      } else {
        this.collectionType = 'LOAN';
        this.uobCreditLimit = new UobCreditLimit();
        if (this.loanProcess && this.loanProcess.id) {
          this.loanService
            .getLoanById(this.loanProcess.id)
            .subscribe((loanResult: any) => {
              if (loanResult) {
                if (loanResult.sponsorForm.dateofIncorporation) {
                  this.uobCreditLimit = loanResult.creditInfo;
                  this.setDateFormat();
                }
                this.uobCreditLimit.pfiName = loanResult.creditInfo.pfiName;
                this.uobCreditLimit.pfiCode = loanResult.creditInfo.pfiCode;
              }
            });
        }
      }
    }

    // this.uobCreditLimitService.uobCreditLimit$.subscribe((uobForm) => {
    //   this.uobCreditLimit = uobForm;
    // });

    this.lookup.getCurrencyList().subscribe(data => {
      this.currencyList = data;
    });

    this.loanService.getCRRPremiumRate().subscribe(crrPremium => {
      this.cRRPremiumRateList = crrPremium;
    });

    if (
      this.loanProcess.isSponsorUploaded &&
      this.loanProcess.completedStep !== CompletedStep.stepCompleted
    ) {
      this.autoPopulateFromSponserForm();
    }
  }

  setDateFormat() {
    if (this.uobCreditLimit.submissionDate) {
      this.uobCreditLimit.submissionDate = new Date(
        this.uobCreditLimit.submissionDate
      );
    }
    if (this.uobCreditLimit.latestSignedDt) {
      this.uobCreditLimit.latestSignedDt = new Date(
        this.uobCreditLimit.latestSignedDt
      );
    }
    if (this.uobCreditLimit.latestAuditedDt) {
      this.uobCreditLimit.latestAuditedDt = new Date(
        this.uobCreditLimit.latestAuditedDt
      );
    }
  }

  sort() {
    const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
    if (this.predicate !== 'id') {
      result.push('id');
    }
    return result;
  }

  private onError(error) {
    this.jhiAlertService.error(error.message, null, null);
  }

  ngOnDestroy() {
    this.notificationService.clearNotification();
  }

  autoPopulateFromSponserForm() {
    if (this.sponsorForm) {
      this.uobCreditLimit.borrowerRegName = this.sponsorForm.regComName;
      this.uobCreditLimit.rocRefNo = this.sponsorForm.ACRANo;
      this.uobCreditLimit.sgdCurrency = this.sponsorForm.total;

      this.uobCreditLimit.inventorySGDTxt = this.sponsorForm.invStockFinancing;
      this.uobCreditLimit.inventoryStockChkBx = this.sponsorForm.invStockFinancingChecked;

      this.uobCreditLimit.structuredWorkingCapitalSGDTxt = this.sponsorForm.workingCapital;
      this.uobCreditLimit.structuredWorkingCapitalChkBx = this.sponsorForm.workingCapitalChecked;

      this.uobCreditLimit.withRecourseSGDTxt = this.sponsorForm.aRDiscount;
      this.uobCreditLimit.recourseFactoringBillChkBx = this.sponsorForm.aRDiscountChecked;

      this.uobCreditLimit.overseaseCapitalSGDTxt = this.sponsorForm.capitalLoan;
      this.uobCreditLimit.overseasWorkingCapitalChkBx = this.sponsorForm.capitalLoanChecked;

      this.uobCreditLimit.bankersGuaranteeAmountSGDTxt = this.sponsorForm.bankerGuarantee;
      this.uobCreditLimit.bankersGuaranteeAmountChkBx = this.sponsorForm.bankerGuaranteeChecked;
    }
  }

  autoPopulateBaseLoan() {
    if (this.baseLoan && this.baseLoan.creditInfo) {
      this.uobCreditLimit.foreignCurrency = this.baseLoan.creditInfo.foreignCurrency;
      this.uobCreditLimit.usdCurrency = this.baseLoan.creditInfo.usdCurrency;
      this.uobCreditLimit.currencyExchangeRate = this.baseLoan.creditInfo.currencyExchangeRate;
      this.uobCreditLimit.usdCurrencyCurrent = this.baseLoan.creditInfo.usdCurrencyCurrent;
      this.uobCreditLimit.sgdCurrencyCurrent = this.baseLoan.creditInfo.sgdCurrencyCurrent;
      this.uobCreditLimit.usdCurrencyCurrentLIS = this.baseLoan.creditInfo.usdCurrencyCurrentLIS;
      this.uobCreditLimit.sgdCurrencyCurrentLIS = this.baseLoan.creditInfo.sgdCurrencyCurrentLIS;
      this.uobCreditLimit.usdCurrencyCurrentLISP = this.baseLoan.creditInfo.usdCurrencyCurrentLISP;
      this.uobCreditLimit.sgdCurrencyCurrentLISP = this.baseLoan.creditInfo.sgdCurrencyCurrentLISP;
      this.uobCreditLimit.borrowersCrr = this.baseLoan.creditInfo.borrowersCrr;
      this.uobCreditLimit.crrRate = this.baseLoan.creditInfo.crrRate;
      this.uobCreditLimit.exceptionalCrrRate = this.baseLoan.creditInfo.exceptionalCrrRate;

      if (!this.loanProcess.isMidTermIncrease) {
        this.uobCreditLimit.borrowerRegName = this.baseLoan.creditInfo.borrowerRegName;
        this.uobCreditLimit.rocRefNo = this.baseLoan.creditInfo.rocRefNo;
        this.uobCreditLimit.sgdCurrency = this.baseLoan.creditInfo.sgdCurrency;

        this.uobCreditLimit.inventorySGDTxt = this.baseLoan.creditInfo.inventorySGDTxt;
        this.uobCreditLimit.inventoryStockChkBx = this.baseLoan.creditInfo.inventoryStockChkBx;

        this.uobCreditLimit.structuredWorkingCapitalSGDTxt = this.baseLoan.creditInfo.structuredWorkingCapitalSGDTxt;
        this.uobCreditLimit.structuredWorkingCapitalChkBx = this.baseLoan.creditInfo.structuredWorkingCapitalChkBx;

        this.uobCreditLimit.withRecourseSGDTxt = this.baseLoan.creditInfo.withRecourseSGDTxt;
        this.uobCreditLimit.recourseFactoringBillChkBx = this.baseLoan.creditInfo.recourseFactoringBillChkBx;

        this.uobCreditLimit.overseaseCapitalSGDTxt = this.baseLoan.creditInfo.overseaseCapitalSGDTxt;
        this.uobCreditLimit.overseasWorkingCapitalChkBx = this.baseLoan.creditInfo.overseasWorkingCapitalChkBx;

        this.uobCreditLimit.bankersGuaranteeAmountSGDTxt = this.baseLoan.creditInfo.bankersGuaranteeAmountSGDTxt;
        this.uobCreditLimit.bankersGuaranteeAmountChkBx = this.baseLoan.creditInfo.bankersGuaranteeAmountChkBx;
      }
    }
  }

  // changeCrr() {
  //   if (this.uobCreditLimit.crrRate == 0) {
  //     this.isExceptionalCrrRate = true;
  //     //this.uobCreditLimit.crrRate=this.crrRate;
  //   } else {
  //     this.isExceptionalCrrRate = false;
  //     this.crrRate = null;
  //   }
  // }

  changeLisType() {
    if (this.uobCreditLimit.lisType) {
      switch (this.uobCreditLimit.lisType) {
        case 'new':
          this.uobCreditLimit.renewalFromSGDTxt = null;
          this.uobCreditLimit.renewalFromUSDTxt = null;
          this.uobCreditLimit.renewalToSGDTxt = null;
          this.uobCreditLimit.renewalToUSDTxt = null;
          this.uobCreditLimit.increaseLimitToSGD = null;
          this.uobCreditLimit.increaseLimitToUSD = null;
          this.uobCreditLimit.decreaseLimitToSGD = null;
          this.uobCreditLimit.decreaseLimitToUSD = null;
          break;
        case 'renewalAtSameAmount':
          this.uobCreditLimit.renewalFromSGDTxt = null;
          this.uobCreditLimit.renewalFromUSDTxt = null;
          this.uobCreditLimit.renewalToSGDTxt = null;
          this.uobCreditLimit.renewalToUSDTxt = null;
          this.uobCreditLimit.increaseLimitToSGD = null;
          this.uobCreditLimit.increaseLimitToUSD = null;
          this.uobCreditLimit.decreaseLimitToSGD = null;
          this.uobCreditLimit.decreaseLimitToUSD = null;
          break;
        case 'renewalFrom':
          this.uobCreditLimit.increaseLimitToSGD = null;
          this.uobCreditLimit.increaseLimitToUSD = null;
          this.uobCreditLimit.decreaseLimitToSGD = null;
          this.uobCreditLimit.decreaseLimitToUSD = null;
          break;
        case 'increaseLimitTo':
          this.uobCreditLimit.renewalFromSGDTxt = null;
          this.uobCreditLimit.renewalFromUSDTxt = null;
          this.uobCreditLimit.renewalToSGDTxt = null;
          this.uobCreditLimit.renewalToUSDTxt = null;
          this.uobCreditLimit.decreaseLimitToSGD = null;
          this.uobCreditLimit.decreaseLimitToUSD = null;
          break;
        case 'decreaseLimitTo':
          this.uobCreditLimit.renewalFromSGDTxt = null;
          this.uobCreditLimit.renewalFromUSDTxt = null;
          this.uobCreditLimit.renewalToSGDTxt = null;
          this.uobCreditLimit.renewalToUSDTxt = null;
          this.uobCreditLimit.increaseLimitToSGD = null;
          this.uobCreditLimit.increaseLimitToUSD = null;
          break;
        default:
          return true;
      }
    } else {
    }
  }

  add() {
    if (this.uobCreditLimit.borrowersGroup) {
      if (this.uobCreditLimit.borrowersGroup.length < 99) {
        this.uobCreditLimit.borrowersGroup.push({ name: '', limit: null });
      } else {
        alert('99 Borrowers Group can bee added.!');
      }
    }
  }

  remove() {
    if (this.uobCreditLimit.borrowersGroup) {
      this.uobCreditLimit.borrowersGroup.pop();
    }
  }

  removeMe(me) {
    for (var i = 0; this.uobCreditLimit.borrowersGroup.length; i++) {
      let borrower = this.uobCreditLimit.borrowersGroup[i];
      if (borrower['name'] === me.name) {
        this.uobCreditLimit.borrowersGroup.splice(i, 1);
        return;
      }
    }
  }

  updateStack(uploadedFile, supportDoc) {
    if (supportDoc === 'borrowerGroup') {
      return;
    }
    this.uobCreditLimit.supportingDocs.forEach(element => {
      if (element.name === supportDoc) {
        element.status = true;
        if (element.files && element.files != '') {
          element.files += ', ' + uploadedFile.filename;
        } else {
          element.files = uploadedFile.filename + ' ';
        }
      }
    });
  }

  isSupportingDocValidate() {
    let errorDoc = false;
    const notificationOption = new NotificationOption();
    notificationOption.title = '';
    notificationOption.clear = false;
    notificationOption.type = 'error';
    notificationOption.toastrConfig = {
      positionClass: 'toast-bottom-right',
      disableTimeOut: true
    };
    let errorMessage = 'Please upload document for ';
    this.notificationService.clearNotification();

    this.uobCreditLimit.supportingDocs.forEach(element => {
      let field = element.name;
      switch (field) {
        case 'sponsersApplication':
          if (!element.status && this.uobCreditLimit.lisSponsersApplChkBx) {
            notificationOption.message =
              errorMessage + 'Sponsors’ Application Form';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;

        case 'companySearches':
          if (!element.status && this.uobCreditLimit.companySearchesChkBx) {
            notificationOption.message =
              errorMessage + 'Company searches and/or individual searches';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;

        case 'pfiInternalCreditMemo':
          if (!element.status && this.uobCreditLimit.pfiInternalCreditChkBx) {
            notificationOption.message =
              errorMessage + 'PFI’s internal Credit Memo Approval';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;

        case 'latestAudited':
          if (!element.status && this.uobCreditLimit.latestAuditedChkBx) {
            notificationOption.message =
              errorMessage + 'Latest Audited Financials from Borrower';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;

        case 'latestSigned':
          if (!element.status && this.uobCreditLimit.latestSignedChkBx) {
            notificationOption.message =
              errorMessage + 'Latest signed Management Accounts from Borrower';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;

        case 'additionalItems':
          if (!element.status && this.uobCreditLimit.additionalItemChkBx) {
            notificationOption.message = errorMessage + 'Additional Items';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;

        case 'overseasCapital':
          if (
            !element.status &&
            this.uobCreditLimit.overseasWorkingCapitalChkBx
          ) {
            notificationOption.message =
              errorMessage + 'Oversease working capital';
            this.notificationService.showNotification(notificationOption);
            errorDoc = true;
          }
          break;

        default:
          break;
      }
    });

    if (errorDoc) {
      return false;
    } else return true;
  }

  // isSupportingDocValidate() {
  //   let uploadDocumentFor = '';
  //   this.uobCreditLimit.supportingDocs.forEach((element) => {
  //     let field = element.name;
  //     switch (field) {
  //       case 'sponsersApplication':
  //         if (!element.status && this.uobCreditLimit.lisSponsersApplChkBx) {
  //           uploadDocumentFor += '\n -Sponsors’ Application Form.';
  //         }
  //         break;

  //       case 'companySearches':
  //         if (!element.status && this.uobCreditLimit.companySearchesChkBx) {
  //           uploadDocumentFor +=
  //             '\n -Company searches and/or individual searches.';
  //         }
  //         break;

  //       case 'pfiInternalCreditMemo':
  //         if (!element.status && this.uobCreditLimit.pfiInternalCreditChkBx) {
  //           uploadDocumentFor += '\n -PFI’s internal Credit Memo Approval.';
  //         }
  //         break;

  //       case 'latestAudited':
  //         if (!element.status && this.uobCreditLimit.latestAuditedChkBx) {
  //           uploadDocumentFor += '\n -Latest Audited Financials from Borrower.';
  //         }
  //         break;

  //       case 'latestSigned':
  //         if (!element.status && this.uobCreditLimit.latestSignedChkBx) {
  //           uploadDocumentFor +=
  //             '\n -Latest signed Management Accounts from Borrower';
  //         }
  //         break;

  //       case 'additionalItems':
  //         if (!element.status && this.uobCreditLimit.additionalItemChkBx) {
  //           uploadDocumentFor += '\n -Additional Items.';
  //         }
  //         break;

  //       case 'overseasCapital':
  //         if (!element.status && this.uobCreditLimit.forOverseasChkBx) {
  //           uploadDocumentFor += '\n -Oversease working capital.';
  //         }
  //         break;

  //       default:
  //         break;
  //     }
  //   });

  //   if (uploadDocumentFor && uploadDocumentFor != '') {
  //     const notificationOption = new NotificationOption();
  //     notificationOption.title = 'Error';
  //     notificationOption.message = 'Please upload document for' + uploadDocumentFor;
  //     notificationOption.type = 'error';
  //     this.notificationService.showNotification(notificationOption);
  //     return false;
  //   } else return true;
  // }

  validateExchangeCurrency() {
    if (
      this.uobCreditLimit.usdCurrency &&
      !this.uobCreditLimit.currencyExchangeRate
    ) {
      const notificationOption = new NotificationOption();
      notificationOption.title = 'Error';
      notificationOption.message =
        'Please enter currency exchange rate as well.';
      notificationOption.type = 'error';
      this.notificationService.showNotification(notificationOption);
      return false;
    } else if (
      !this.uobCreditLimit.usdCurrency &&
      this.uobCreditLimit.currencyExchangeRate
    ) {
      const notificationOption = new NotificationOption();
      notificationOption.title = 'Error';
      notificationOption.message =
        'Please enter Foreign Currency Amount to endorse.';
      notificationOption.type = 'error';
      this.notificationService.showNotification(notificationOption);
      return false;
    }
    return true;
  }

  validateLisType() {
    this.notificationService.clearNotification();
    if (this.uobCreditLimit.lisType) {
      switch (this.uobCreditLimit.lisType) {
        case 'new':
          return true;
        case 'renewalAtSameAmount':
          return true;
        case 'renewalFrom':
          if (
            !this.uobCreditLimit.renewalFromSGDTxt &&
            !this.uobCreditLimit.renewalToSGDTxt
          ) {
            const notificationOption = new NotificationOption();
            notificationOption.toastrConfig = { disableTimeOut: true };
            notificationOption.title = 'Error';
            notificationOption.message =
              'Please enter renewal amount for Type of Application';
            notificationOption.type = 'error';
            this.notificationService.showNotification(notificationOption);
            return false;
          } else if (
            this.uobCreditLimit.renewalFromSGDTxt &&
            !this.uobCreditLimit.renewalToSGDTxt
          ) {
            const notificationOption = new NotificationOption();
            notificationOption.toastrConfig = { disableTimeOut: true };
            notificationOption.title = 'Error';
            notificationOption.message =
              'Please enter amount for renewal to SGD.';
            notificationOption.type = 'error';
            this.notificationService.showNotification(notificationOption);
            return false;
          } else if (
            !this.uobCreditLimit.renewalFromSGDTxt &&
            this.uobCreditLimit.renewalToSGDTxt
          ) {
            const notificationOption = new NotificationOption();
            notificationOption.toastrConfig = { disableTimeOut: true };
            notificationOption.title = 'Error';
            notificationOption.message =
              'Please enter amount for renewal From SGD.';
            notificationOption.type = 'error';
            this.notificationService.showNotification(notificationOption);
            return false;
          } else return true;
        default:
          return true;
      }
    } else {
      const notificationOption = new NotificationOption();
      notificationOption.toastrConfig = { disableTimeOut: true };
      notificationOption.title = 'Error';
      notificationOption.message = 'Please select type of Application.';
      notificationOption.type = 'error';
      this.notificationService.showNotification(notificationOption);
      return false;
    }
  }

  onlyNumberKey(event) {
    return event.charCode == 8 || event.charCode == 0 || event.charCode == 46
      ? null
      : event.charCode >= 48 && event.charCode <= 57;
    //|| event.charCode == 44
  }

  onlyNumberKeyValue(event) {
    return event.charCode >= 48 && event.charCode <= 57;
  }

  goToUploadForm() {
    this.router.navigate(['../../sponsor-eform-upload'], {
      relativeTo: this.route
    });
  }

  saveAsDraft() {
    this.updateLoan();
  }

  submitLoan() {
    this.updateLoan('Processing');
  }

  updateLoan(status?: string) {
    this.setValidSponsorValue();

    if (this.loanProcess.isMidTerm) {
      this.uobLoan = new UOBMidTermLoan();
      this.uobLoan.isMidTermIncrease = this.loanProcess.isMidTermIncrease;
    } else {
      this.uobLoan = new UOBLoan();
    }

    this.uobLoan._id = this.loanProcess.id;
    this.uobLoan.creditInfo = this.uobCreditLimit;
    this.uobLoan.sponsorForm = this.sponsorForm;
    this.loanService.uobData = this.uobLoan;
    console.log('UOB:-', this.uobLoan);
    // if (this.crrRate && this.isExceptionalCrrRate) {
    //   const crrRate = parseFloat(this.crrRate.toString()).toFixed(3);
    //   this.uobLoan.creditInfo.crrRate = parseInt(crrRate, 10);
    //   //this.uobCreditLimit.crrRate = parseFloat(this.crrRate.toString());
    // }
    // TODO: Need to add logic for app
    //this.uobLoan.app = 3;

    if (this.loanProcess.id) {
      if (status) {
        if (!this.loanProcess.isMidTerm) {
          if (!this.validateLisType()) {
            return false;
          }
        }

        // if (!this.validateExchangeCurrency()) {
        //   this.spinner.hide();
        //   return false;
        // }

        if (!this.isSupportingDocValidate()) {
          return false;
        }

        if (!this.checkSGDTotalAmount()) {
          return false;
        }

        if (!this.checkForeignTotalAmount()) {
          return false;
        }

        if (this.loanProcess.isMidTerm) {
          if (!this.checkRequestTypeAmount()) {
            return;
          }
        }

        this.uobLoan.status = status;
        this.spinner.show();
        if (this.loanProcess.isMidTerm) {
          let marshRefNoSubpart;
          if (this.baseLoan.marshRefNo) {
            marshRefNoSubpart = this.baseLoan.marshRefNo.split('/');
          }
          const masrshRefNo = parseInt(marshRefNoSubpart[1], 10) + 1;
          if (masrshRefNo < 10) {
            this.uobLoan.marshRefNo = marshRefNoSubpart[0] + '/0' + masrshRefNo;
          } else {
            this.uobLoan.marshRefNo = marshRefNoSubpart[0] + '/' + masrshRefNo;
          }
          if (!this.uobLoan.createdDate) {
            this.uobLoan.createdDate = new Date();
          }
          this.midTermService
            .submitMidTermLoan(this.uobLoan)
            .subscribe(loanResult => {
              if (loanResult) {
                this.submitConfig(loanResult);
              }
            });
        } else {
          this.loanService.submitLoan(this.uobLoan).subscribe(loanResult => {
            if (loanResult) {
              this.submitConfig(loanResult);
            }
          });
        }
      } else {
        if (this.loanProcess.isMidTerm) {
          this.midTermService.updateMidTermLoan(this.uobLoan).subscribe(
            res => {
              //this.creditForm.form.markAsPristine();
              this.notificationService.showNotification();
            },
            error => {}
          );
        } else {
          this.loanService.updateLoan(this.uobLoan).subscribe(
            res => {
              this.notificationService.showNotification();
              //this.creditForm.form.markAsPristine();
            },
            error => {}
          );
        }
      }
    }
    //this.sponsorForm.dateofIncorporation = dateofIncorporation;
  }

  submitConfig(loanResult: any) {
    const loanProcess = this.loanProcess;
    loanProcess.status = loanResult.status;
    loanProcess.completedStep = CompletedStep.stepCompleted;
    loanProcess.marshRefNo = loanResult.marshRefNo;
    loanProcess.isViewLoan = true;
    this.loanProcess = Object.assign({}, loanProcess);
    this.loanService.setLoanStepProcess(this.loanProcess);
    //this.loanService.setStatus(loanResult.status);
    //window.scrollTo(0, 0);
    this.spinner.hide();
    const notificationOption = new NotificationOption();
    notificationOption.toastrConfig = {
      positionClass: 'toast-top-right'
    };
    notificationOption.title = 'Notification';
    notificationOption.message = 'Application Submitted Successfully';

    this.notificationService.showNotification(notificationOption);
    //this.creditForm.form.markAsPristine();
    this.router.navigate(['../../submitted'], {
      relativeTo: this.route
    });
  }

  setValidSponsorValue() {
    this.sponsorForm.invStockFinancing =
      this.sponsorForm.invStockFinancing == null
        ? 0
        : this.sponsorForm.invStockFinancing;
    this.sponsorForm.workingCapital =
      this.sponsorForm.workingCapital == null
        ? 0
        : this.sponsorForm.workingCapital;
    this.sponsorForm.aRDiscount =
      this.sponsorForm.aRDiscount == null ? 0 : this.sponsorForm.aRDiscount;
    this.sponsorForm.capitalLoan =
      this.sponsorForm.capitalLoan == null ? 0 : this.sponsorForm.capitalLoan;
    this.sponsorForm.bankerGuarantee =
      this.sponsorForm.bankerGuarantee == null
        ? 0
        : this.sponsorForm.bankerGuarantee;
  }

  changeCRR() {
    this.isExceptionalCrrRate = false;
    this.uobCreditLimit.exceptionalCrrRate = null;
    let crrRateValue = this.uobCreditLimit.borrowersCrr;
    if (
      crrRateValue &&
      crrRateValue % 1 == 0 &&
      crrRateValue > 0 &&
      crrRateValue <= 15
    ) {
      if (this.cRRPremiumRateList) {
        this.cRRPremiumRateList.forEach(crrData => {
          let fromLimit = crrData.from;
          let toLimit = crrData.to;
          //if (fromLimit || fromLimit < 0 || toLimit || toLimit < 0) { return; }
          if (crrRateValue >= fromLimit && crrRateValue <= toLimit) {
            this.uobCreditLimit.crrRate = crrData._id;
          }
        });
      }

      // if (crrRateValue >= 0 && crrRateValue <= 6) {
      //   this.uobCreditLimit.crrRate = this.cRRPremiumRateList[0]._id;
      // } else if (crrRateValue <= 10) {
      //   this.uobCreditLimit.crrRate = this.cRRPremiumRateList[1]._id;
      // } else if (crrRateValue <= 13) {
      //   this.uobCreditLimit.crrRate = this.cRRPremiumRateList[2]._id;
      // } else if (crrRateValue <= 15) {
      //   this.uobCreditLimit.crrRate = this.cRRPremiumRateList[3]._id;
      // }
    } else {
      this.uobCreditLimit.borrowersCrr = null;
      this.uobCreditLimit.crrRate = null;
    }
  }

  changeNoCRR() {
    this.isExceptionalCrrRate = false;
    this.uobCreditLimit.borrowersCrr = 0;
    this.uobCreditLimit.exceptionalCrrRate = null;
  }

  getCRRNonEditList() {
    if (this.cRRPremiumRateList) {
      return this.cRRPremiumRateList.filter(
        data => data.from > 0 && data.to > 0
      );
    }
    return [];
  }

  getCRREditList() {
    if (this.cRRPremiumRateList) {
      return this.cRRPremiumRateList.find(data => data.from <= 0);
    }
    return [];
  }

  setCRRValue(item: number) {
    if (this.cRRPremiumRateList && this.cRRPremiumRateList[item]) {
      return this.cRRPremiumRateList[item]._id;
    } else {
      return '';
    }
  }

  setCRRLabel(item: number) {
    if (this.cRRPremiumRateList && this.cRRPremiumRateList[item]) {
      return this.cRRPremiumRateList[item].tierRatingDescription;
    } else {
      return '';
    }
  }

  exceptionalCrrRateChange() {
    this.isExceptionalCrrRate = true;
    this.uobCreditLimit.borrowersCrr = null;
  }

  confirmChange(mode: string) {
    let messageText: string;
    let detailsText: string;

    switch (mode) {
      case 'TotalLimit':
        if (this.uobCreditLimit.sgdCurrency === this.sponsorForm.total) {
          return;
        }
        messageText =
          'Total Requested limit amount entered is different from total limits mentioned in Sponsor form section. Do you still want to continue?';
        detailsText = 'Total Request Limit amount will be saved';
        break;
      case 'Inventory':
        if (
          this.uobCreditLimit.inventorySGDTxt ===
          this.sponsorForm.invStockFinancing
        ) {
          return;
        }
        messageText =
          'Inventory / Stock Financing entered is different from Sponsor form section. Do you still want to continue?';
        detailsText = 'Inventory / Stock Financing amount will be saved';
        break;
      case 'Structured':
        if (
          this.uobCreditLimit.structuredWorkingCapitalSGDTxt ===
          this.sponsorForm.workingCapital
        ) {
          return;
        }
        messageText =
          'Structured Pre-delivery Working Capital entered is different from Sponsor form section. Do you still want to continue?';
        detailsText =
          'Structured Pre-delivery Working Capital amount will be saved';
        break;
      case 'Recourse':
        if (
          this.uobCreditLimit.withRecourseSGDTxt === this.sponsorForm.aRDiscount
        ) {
          return;
        }
        messageText = `With Recourse for: Factoring / Bill or Invoice / AR Discounting entered is different from Sponsor 
          form section. Do you still want to continue?`;
        detailsText =
          'Recourse for: Factoring / Bill or Invoice / AR Discounting amount will be saved';
        break;
      case 'Overseas':
        if (
          this.uobCreditLimit.overseaseCapitalSGDTxt ===
          this.sponsorForm.capitalLoan
        ) {
          return;
        }
        messageText =
          'Overseas Working Capital Loans Support entered is different from Sponsor form section. Do you still want to continue?';
        detailsText =
          'Overseas Working Capital Loans Support amount will be saved';
        break;
      case 'BG':
        if (
          this.uobCreditLimit.bankersGuaranteeAmountSGDTxt ===
          this.sponsorForm.bankerGuarantee
        ) {
          return;
        }
        messageText =
          'Banker’s Guarantee entered is different from Sponsor form section. Do you still want to continue?';
        detailsText = 'Banker’s Guarantee amount will be saved';
        break;
    }

    this.confirmationService.confirm({
      message: messageText,
      header: 'Confirmation',
      icon: 'fa fa-times',
      accept: () => {
        const notificationOption = new NotificationOption();
        notificationOption.title = 'Notification';
        notificationOption.message = detailsText;
        notificationOption.type = 'info';
        this.notificationService.showNotification(notificationOption);
      },
      reject: () => {
        switch (mode) {
          case 'TotalLimit':
            this.uobCreditLimit.sgdCurrency = this.sponsorForm.total;
            break;
          case 'Inventory':
            this.uobCreditLimit.inventorySGDTxt = this.sponsorForm.invStockFinancing;
            break;
          case 'Structured':
            this.uobCreditLimit.structuredWorkingCapitalSGDTxt = this.sponsorForm.workingCapital;
            break;
          case 'Recourse':
            this.uobCreditLimit.withRecourseSGDTxt = this.sponsorForm.aRDiscount;
            break;
          case 'Overseas':
            this.uobCreditLimit.overseaseCapitalSGDTxt = this.sponsorForm.capitalLoan;
            break;
          case 'BG':
            this.uobCreditLimit.bankersGuaranteeAmountSGDTxt = this.sponsorForm.bankerGuarantee;
            break;
        }
      }
    });
  }

  checkSGDTotalAmount() {
    let addedAmountTotal: number = 0;
    let totalRequstedLimitSGD: number = this.uobCreditLimit.sgdCurrency;
    if (
      this.uobCreditLimit.inventorySGDTxt &&
      this.uobCreditLimit.inventorySGDTxt > 0
    ) {
      addedAmountTotal += this.uobCreditLimit.inventorySGDTxt;
    }

    if (
      this.uobCreditLimit.structuredWorkingCapitalSGDTxt &&
      this.uobCreditLimit.structuredWorkingCapitalSGDTxt > 0
    ) {
      addedAmountTotal += this.uobCreditLimit.structuredWorkingCapitalSGDTxt;
    }

    if (
      this.uobCreditLimit.withRecourseSGDTxt &&
      this.uobCreditLimit.withRecourseSGDTxt > 0
    ) {
      addedAmountTotal += this.uobCreditLimit.withRecourseSGDTxt;
    }

    if (
      this.uobCreditLimit.overseaseCapitalSGDTxt &&
      this.uobCreditLimit.overseaseCapitalSGDTxt > 0
    ) {
      addedAmountTotal += this.uobCreditLimit.overseaseCapitalSGDTxt;
    }

    if (
      this.uobCreditLimit.bankersGuaranteeAmountSGDTxt &&
      this.uobCreditLimit.bankersGuaranteeAmountSGDTxt > 0
    ) {
      addedAmountTotal += this.uobCreditLimit.bankersGuaranteeAmountSGDTxt;
    }
    if (addedAmountTotal != totalRequstedLimitSGD) {
      const notificationOption = new NotificationOption();
      notificationOption.toastrConfig = {
        positionClass: 'toast-bottom-right',
        disableTimeOut: true
      };
      notificationOption.title = 'Error';
      notificationOption.message =
        'LIS 5 Trade facilities SGD total to be different from the value available for UOB SGD Total Requested limit total';
      notificationOption.type = 'error';
      this.notificationService.showNotification(notificationOption);

      return false;
    }
    return true;
  }

  checkForeignTotalAmount() {
    let addedAmountTotal: number = 0;
    let totalRequstedLimitForeign: number = this.uobCreditLimit.usdCurrency;
    if (
      this.uobCreditLimit.inventoryUSDTxt &&
      this.uobCreditLimit.inventoryUSDTxt > 0
    ) {
      addedAmountTotal += this.uobCreditLimit.inventoryUSDTxt;
    }

    if (
      this.uobCreditLimit.structuredWorkingCapitalUSDTxt &&
      this.uobCreditLimit.structuredWorkingCapitalUSDTxt > 0
    ) {
      addedAmountTotal += this.uobCreditLimit.structuredWorkingCapitalUSDTxt;
    }

    if (
      this.uobCreditLimit.withRecourseUSDTxt &&
      this.uobCreditLimit.withRecourseUSDTxt > 0
    ) {
      addedAmountTotal += this.uobCreditLimit.withRecourseUSDTxt;
    }

    if (
      this.uobCreditLimit.overseaseCapitalUSDTxt &&
      this.uobCreditLimit.overseaseCapitalUSDTxt > 0
    ) {
      addedAmountTotal += this.uobCreditLimit.overseaseCapitalUSDTxt;
    }

    if (
      this.uobCreditLimit.bankersGuaranteeAmountUSDTxt &&
      this.uobCreditLimit.bankersGuaranteeAmountUSDTxt > 0
    ) {
      addedAmountTotal += this.uobCreditLimit.bankersGuaranteeAmountUSDTxt;
    }
    console.dir(this.uobCreditLimit);
    if (!totalRequstedLimitForeign && addedAmountTotal <= 0) {
      return true;
    }
    if (addedAmountTotal != totalRequstedLimitForeign) {
      const notificationOption = new NotificationOption();
      notificationOption.toastrConfig = {
        positionClass: 'toast-bottom-right',
        disableTimeOut: true
      };
      notificationOption.title = 'Error';
      notificationOption.message =
        'LIS 5 Trade facilities Foreign Currency total to be different from the value available for UOB Foreign Currency Total Requested limit total';
      notificationOption.type = 'error';
      this.notificationService.showNotification(notificationOption);
      return false;
    }
    return true;
  }

  checkRequestTypeAmount() {
    const totalRequstedLimitSGD: number = this.uobCreditLimit.sgdCurrency;
    const totalRequstedLimitForeign: number = this.uobCreditLimit.usdCurrency;
    const sgdCurrencyCurrent: number = this.uobCreditLimit.sgdCurrencyCurrent;
    const usdCurrencyCurrent: number = this.uobCreditLimit.usdCurrencyCurrent;
    let requestLimitValue = this.uobCreditLimit.requestLimitValue;
    let requestLimitForeignValue = this.uobCreditLimit.requestLimitForeignValue;

    if (this.loanProcess.isMidTermIncrease) {
      requestLimitValue = requestLimitValue + sgdCurrencyCurrent;
      requestLimitForeignValue = requestLimitForeignValue + usdCurrencyCurrent;
    } else {
      requestLimitValue = Math.abs(requestLimitValue - sgdCurrencyCurrent);
      requestLimitForeignValue = Math.abs(
        requestLimitForeignValue - usdCurrencyCurrent
      );
    }

    if (requestLimitValue !== totalRequstedLimitSGD) {
      const notificationOption = new NotificationOption();
      notificationOption.toastrConfig = {
        positionClass: 'toast-bottom-right',
        disableTimeOut: true
      };
      notificationOption.title = 'Error';
      notificationOption.message = `Current Mid term /Temp ${
        this.loanProcess.isMidTermIncrease ? 'Increase' : 'Decrease'
      } SGD total limit to be different from the value available for UOB Total Requested limit total`;
      notificationOption.type = 'error';

      this.notificationService.showNotification(notificationOption);
      return false;
    }

    if (
      this.uobCreditLimit.foreignCurrency !== '-1' &&
      requestLimitForeignValue !== totalRequstedLimitForeign
    ) {
      const notificationOption = new NotificationOption();
      notificationOption.toastrConfig = {
        positionClass: 'toast-bottom-right',
        disableTimeOut: true
      };
      notificationOption.title = 'Error';
      notificationOption.message = `Current Mid term /Temp ${
        this.loanProcess.isMidTermIncrease ? 'Increase' : 'Decrease'
      } Foreign total limit to be different from the value available for UOB Total Requested limit total`;
      notificationOption.type = 'error';

      this.notificationService.showNotification(notificationOption);
      return false;
    }

    return true;
  }

  onChangeCurrency() {
    if (this.uobCreditLimit.foreignCurrency == '-1') {
      this.uobCreditLimit.usdCurrency = null;
      this.uobCreditLimit.currencyExchangeRate = null;
      if (this.loanProcess.isMidTerm) {
        this.uobCreditLimit.requestLimitForeignValue = null;
      }
    }
  }

  manageDocPopup(type: string) {
    this.manageDoc = { name: '', documentType: '' };
    switch (type) {
      case 'overseasCapital':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'Overseas working capital loans support';
        break;
      case 'overseasCapital':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'Overseas working capital loans support';
        break;
      case 'companySearches':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'Company searches or individual searches';
        break;
      case 'pfiInternalCreditMemo':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'PFI’s internal Credit Memo Approval';
        break;
      case 'latestAudited':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'Latest Audited Financials from Borrower';
        break;
      case 'latestSigned':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'Latest signed Management Accounts';
        break;
      case 'additionalItems':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'Others';
        break;
      case 'borrowerGroup':
        this.manageDoc.name = type;
        this.manageDoc.documentType = 'Borrower Group';
        break;
    }
  }
}
