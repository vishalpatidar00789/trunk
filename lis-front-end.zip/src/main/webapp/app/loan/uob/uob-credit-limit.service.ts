import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs/Rx';
import { SERVER_API_URL } from '../../app.constants';

import { JhiDateUtils } from 'ng-jhipster';

import { UobCreditLimit } from './uob-credit-limit.model';
import { createRequestOption } from '../../shared';

export type UobCreditLimitResponseType = HttpResponse<UobCreditLimit>;
export type UobCreditLimitArrayResponseType = HttpResponse<UobCreditLimit[]>;

@Injectable()
export class UobCreditLimitService {
  private resourceUrl = SERVER_API_URL + 'Loan-Form';

  // Observable UOB Credit form sources
  uobCreditLimitSource = new BehaviorSubject<UobCreditLimit>(
    new UobCreditLimit()
  );

  // Observable UOB Credit form streams
  uobCreditLimit$ = this.uobCreditLimitSource.asObservable();

  constructor(private http: HttpClient, private dateUtils: JhiDateUtils) {}

  setUOBCreditLimit(uobCreditLimit: UobCreditLimit) {
    this.uobCreditLimitSource.next(uobCreditLimit);
  }

  // create(uobdata): Observable<any> {
  //     //this.resourceUrl= "http://localhost:5000/Loan-Form";
  //      //console.log(uobCreditLimit);
  //      console.log(this.resourceUrl);
  //     //const copy = this.convert(uobCreditLimit);
  //     return this.http.post<UobCreditLimit>(this.resourceUrl, uobdata, { observe: 'response' })
  //         .map((res: UobCreditLimitResponseType) => this.convertResponse(res));
  // }
  create(uobData) {
    return <any>this.http.post(SERVER_API_URL + 'UOB-Form', uobData); //change url
  }

  update(uobData) {
    return <any>(
      this.http.put(
        SERVER_API_URL + 'UOB-Form/' + uobData['uob']['_id'],
        uobData
      )
    ); //change url
  }

  // update(uobCreditLimit: UobCreditLimit): Observable<UobCreditLimitResponseType> {
  //     const copy = this.convert(uobCreditLimit);
  //     return this.http.put<UobCreditLimit>(this.resourceUrl, copy, { observe: 'response' })
  //         .map((res: UobCreditLimitResponseType) => this.convertResponse(res));
  // }

  private convertResponse(
    res: UobCreditLimitResponseType
  ): UobCreditLimitResponseType {
    const body: UobCreditLimit = this.convertItemFromServer(res.body);
    return res.clone({ body });
  }

  private convertArrayResponse(
    res: UobCreditLimitArrayResponseType
  ): UobCreditLimitArrayResponseType {
    const jsonResponse: UobCreditLimit[] = res.body;
    const body: UobCreditLimit[] = [];
    for (let i = 0; i < jsonResponse.length; i++) {
      body.push(this.convertItemFromServer(jsonResponse[i]));
    }
    return res.clone({ body });
  }

  /**
   * Convert a returned JSON object to UobCreditLimit.
   */
  private convertItemFromServer(json: any): UobCreditLimit {
    const copy: UobCreditLimit = Object.assign(new UobCreditLimit(), json);
    copy.submissionDate = this.dateUtils.convertLocalDateFromServer(
      json.submissionDate
    );

    return copy;
  }

  /**
   * Convert a UobCreditLimit to a JSON which can be sent to the server.
   */
  // private convert(uobCreditLimit: UobCreditLimit): UobCreditLimit {
  //   const copy: UobCreditLimit = Object.assign({}, uobCreditLimit);
  //   copy.submissionDate = this.dateUtils.convertLocalDateToServer(
  //     uobCreditLimit.submissionDate
  //   );

  //   return copy;
  // }
}
