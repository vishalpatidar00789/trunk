
export class UobCreditLimit {
    constructor(
        public _id?: string,
        //uobPolicyNo?:string,
        public pfiCode?: string,
        public pfiName?: string,
        public requesterName?: string,
        public submissionDate?: Date,
        public discretiolaryLimitDL?: boolean,
        public creditLimitCL?: boolean,
        public borrowersCrr?: number,
        public crrRate?: string,
        public currencyExchangeRate?: number,
        public borrowerRegName?: string,
        public rocRefNo?: string,
        public lisType?: string,
        public increaseLimitToSGD?: number,
        public increaseLimitToUSD?: number,
        public decreaseLimitToSGD?: number,
        public decreaseLimitToUSD?: number,
        public renewalFromSGDTxt?: number,
        public renewalFromUSDTxt?: number,
        public renewalToUSDTxt?: number,
        public renewalToSGDTxt?: number,
        public sgdCurrency?: number,
        public usdCurrency?: number,
        public usdCurrencyCurrent?: number,
        public sgdCurrencyCurrent?: number,
        public sgdCurrencyCurrentLIS?: number,
        public usdCurrencyCurrentLIS?: number,
        public usdCurrencyCurrentLISP?: number,
        public sgdCurrencyCurrentLISP?: number,
        public lisSponsersApplChkBx?: boolean,
        public companySearchesChkBx?: boolean,
        public uobInternalCreditChkBx?: boolean,
        public latestAuditedChkBx?: boolean,
        public latestAuditedDt?: Date,
        public latestSignedChkBx?: boolean,
        public latestSignedDt?: Date,
        public additionalItemChkBx?: boolean,
        public additionalItemTxt?: string,
        public forOverseasChkBx?: boolean,
        public pfiInternalCreditChkBx?: boolean,
        public bankersGuaranteeAmountChkBx?: boolean,
        public inventoryStockChkBx?: boolean,
        public structuredWorkingCapitalChkBx?: boolean,
        public recourseFactoringBillChkBx?: boolean,
        public overseasWorkingCapitalChkBx?: boolean,
        public bankersGuarantee?: boolean,
        public tenureMonths?: number,
        public inventoryUSDTxt?: number,
        public inventorySGDTxt?: number,
        public withRecourseUSDTxt?: number,
        public withRecourseSGDTxt?: number,
        public structuredWorkingCapitalUSDTxt?: number,
        public structuredWorkingCapitalSGDTxt?: number,
        public overseaseCapitalSGDTxt?: number,
        public overseaseCapitalUSDTxt?: number,
        public bankersGuaranteeAmountSGDTxt?: number,
        public bankersGuaranteeAmountUSDTxt?: number,
        public supportingDocs?: any,
        public typeOfLimit?: any,
        public TypeOfLISPlusLimit?: string,
        public natureOfApplication?: any,
        public borrowersGroup?: [{ 'name': string, 'limit': number }],
        public foreignCurrency?: string,
        public exceptionalCrrRate?: number,
        public insurersApprovalDate?: Date,
        public loAcceptanceDate?: Date,
        public loanExpiryDate?: Date,
        public dateSentForLISPlus?: Date,
        public lISPlusApprovedDate?: Date,
        public totalRequstedLimitSGD?: number,
        public totalAppliedLimitForLIS5?: number,
        public approvedPrimaryLayer?: number,
        public approvedAutoTopUpLayer?: number,
        public approvedBgLayer?: number,
        public approvedSGDLimitLISPlus?: number,
        public lis5TotalApprovedLimit?: number,
        public totalApprovedLimitincludingLISPLUS?: number,
        public totalApprovedPrimaryLimitInForce?: number,
        public totalApprovedAutoTopUpLimitInForce?: number,
        public totalApprovedBGlimitInForce?: number,
        public totalApprovedLISPlusLimitInForce?: number,
        public totalApprovedLimitInForce?: number,
        public totalAppliedLimitForLIS5ForeignCurrency?: number,
        public totalRequstedLimitSGDForeignCurrency?: number,
        public approvedPrimaryLayerForeignCurrency?: number,
        public approvedAutoTopUpLayerForeignCurrency?: number,
        public approvedBgLayerForeignCurrency?: number,
        public approvedSGDLimitLISPlusForeignCurrency?: number,
        public lis5TotalApprovedLimitForeignCurrency?: number,
        public approvedlimitPrimaryLayerForeignCurrency?: number,
        public approvedLimitAutoTopUpLayerForeignCurrency?: number,
        public approvedLimitBGLayerForeignCurrency?: number,
        public totalApprovedLimitincludingLISPLUSForeignCurrency?: number,
        public totalApprovedPrimaryLimitInForceForeignCurrency?: number,
        public totalApprovedAutoTopUpLimitInForceForeignCurrency?: number,
        public totalApprovedBGlimitInForceForeignCurrency?: number,
        public totalApprovedLISPlusLimitInForceForeignCurrency?: number,
        public totalApprovedLimitInForceForeignCurrency?: number,
        public LIS5ApprovalRatio?: number,
        public approvalRatioWithLISPLUS?: number,
        public LIS5TurnaroundDays?: number,
        public turnaroundWithLISPLUSDays?: number,
        public utilization?: string,
        public reportedMonth?: number,
        public internalRemark?: string,
        public loanApplicationNumber?: string
) {
        this.pfiName = 'United Overseas Insurance Limited';

        this.requesterName = '';

        this.borrowersGroup = [{ name: '', limit: null }];

        this.foreignCurrency = '-1';

        this.supportingDocs = [
            { name: 'sponsersApplication', id: '', status: false, files: '' },
            { name: 'companySearches', id: '', status: false, files: '' },
            { name: 'pfiInternalCreditMemo', id: '', status: false, files: '' },
            { name: 'latestAudited', id: '', status: false, files: '' },
            { name: 'latestSigned', id: '', status: false, files: '' },
            { name: 'additionalItems', id: '', status: false, files: '' },
            { name: 'overseasCapital', id: '', status: false, files: '' }
        ];
    }
}

// export class CRRPremiumRate {
//     tierRatingDescription: string;
//     from: number;
//     to: number;
//     premiumRatePercentage: number;
// }

export class CRRPremiumRate {
    _id: string;
    trancheId: number;
    consortiumId: number;
    tierRatingDescription: string;
    from: number;
    to: number;
    premiumRatePercentage: number;
    activated: boolean;
    createdBy: string;
    createdDate: Date;
    lastModifiedBy: string;
    lastModifiedDate: Date;

}
