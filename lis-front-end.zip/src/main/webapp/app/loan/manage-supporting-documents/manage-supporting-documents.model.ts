export class ManageSupportingDocuments {
    constructor(
        public _id?: string,
        public marshRefNo?: string,
        public status?: string,
        public borrowerName?: string,
        public pfiCode?: string,
        public staffName?: string,
        public uenNumber?: string,
        public typeOfRequest?: string
    ) {
    }
}
