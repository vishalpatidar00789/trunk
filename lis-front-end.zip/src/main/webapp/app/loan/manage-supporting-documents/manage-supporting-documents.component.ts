import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { TitleCasePipe, DatePipe } from '@angular/common';
import { NgForm } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotificationService } from '../../shared/alert/notification.service';
import { AdhcoDocumentTypes,LoanDocumentTypes } from '../../shared/constants/documents-type.constants';
import { ManageSupportingDocuments } from './manage-supporting-documents.model';
import { ManageSupportingDocumentsService } from './manage-supporting-documents.service';
import { LoanSearchResults } from '../loan-search/loan-search-results/loan-search-results.model';
import { Document } from '../../shared/document-list/documents.model'

@Component({
    selector: 'manage-supporting-documents',
    templateUrl: './manage-supporting-documents.component.html',
    providers: [TitleCasePipe, DatePipe]
})
export class ManageSupportingDocumentsComponent implements OnInit, OnChanges {

    collectionType: string;
    displayMessage: boolean;
    userMessage: string;
    docType: string;
    documentTypes: any[];
    model: ManageSupportingDocuments;
    documentList: Document[];
    @Input() userid: string;
    @Input() isMarshUser: boolean;
    @Input() selectedLoanResult: LoanSearchResults;
    @Output() closePopUp = new EventEmitter<boolean>();

    constructor(
        private manageSupportingDoc: ManageSupportingDocumentsService,
        private notificationService: NotificationService,
        private supportingDocservice: ManageSupportingDocumentsService,
        private spinner: NgxSpinnerService, private datePipe: DatePipe,
        private titlePipe: TitleCasePipe) {
    }

    ngOnChanges() {
        if (this.selectedLoanResult) {
            this.model = new ManageSupportingDocuments();
            this.model.marshRefNo = this.selectedLoanResult.marshRefNo;
            this.model.uenNumber = this.selectedLoanResult.aCRArefNo;
            this.model.borrowerName = this.selectedLoanResult.borrowerRegName;
            this.model.staffName = this.selectedLoanResult.requesterName;
            this.model.pfiCode = this.selectedLoanResult.pfiName;
            this.model.status = this.selectedLoanResult.status;
            this.model._id = this.selectedLoanResult._id;
            this.model.typeOfRequest=this.selectedLoanResult.typeOfRequest;
        }
    }

    ngOnInit() {
        console.log(this.selectedLoanResult);
        this.displayMessage = false;
        this.docType = '';
        if (this.selectedLoanResult) {
            switch (this.selectedLoanResult.typeOfRequest) {
                case 'loan':
                    this.collectionType ='LOAN';
                    break;
                case 'midterm':
                    this.collectionType ='MIDTERM';
                    break;
               case 'adhoc':
                    this.collectionType ='ADHOC';
                    break;
            }
        }
        if(this.model.typeOfRequest === 'loan' || this.model.typeOfRequest === 'midterm'){
        this.documentTypes= LoanDocumentTypes;
        }
        else {
           this.documentTypes=AdhcoDocumentTypes
        }
        this.supportingDocservice.getDocumentsByAppRefId(this.model._id).subscribe(files => {
            if (files) {
                this.documentList = [];
                let file: Document;
                files.forEach(element => {
                    if (element) {
                        file = new Document();
                        file._id = element._id;
                        file.filename = element.metadata.fileName;
                        file.uploadDate = this.datePipe.transform(element.uploadDate, 'dd-MMM-yyy,h:mm:ss a');
                        file.documentType = element.metadata.documentType;
                        file.uploadedBy = element.metadata.uploadedBy;
                        this.documentList.push(file);
                    }
                });
                
                this.sort();
            }
        })
    }

    cancel() {
        this.closePopUp.emit(true);
    }

    afterUpload(uploadedFile: any) {
        let file: Document;
        file = new Document();
        file._id = uploadedFile._id;
        file.filename = uploadedFile.filename;
        file.uploadDate = this.datePipe.transform(new Date(), 'dd-MMM-yyy,h:mm:ss a');
        file.documentType = uploadedFile.metadata.documentType;
        file.uploadedBy = this.userid;
        this.documentList.push(file);
        this.sort();
    }

    sort(){
        this.documentList.sort(function (b, a) {                    
            //return +new Date(a.uploadDate).getTime() - +new Date(b.uploadDate).getTime()
            // return +new Date(a.uploadDate) - +new Date(b.uploadDate);
            if (a.uploadDate < b.uploadDate) return -1;
            if (a.uploadDate > b.uploadDate) return 1;
            return 0;
        });
    }

}