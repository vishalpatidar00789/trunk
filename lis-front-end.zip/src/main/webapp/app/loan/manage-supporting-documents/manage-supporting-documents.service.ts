import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { SERVER_API_URL } from '../../app.constants';
import { FileData } from '../../shared/document-list/documents.model';

@Injectable()
export class ManageSupportingDocumentsService {
    private files: FileData [];
    private resourceUrl = SERVER_API_URL + 'supporting-documents/';
    constructor(private http: HttpClient) { }

    getDocumentsByAppRefId(refId: string): Observable<FileData[]> {        
        return this.http.get<FileData[]>(this.resourceUrl+'document-list/' + refId );
    }
    // deleteDocumentByFileId(fileId:string):Observable<string>{
    //     return this.http.delete<string>(this.resourceUrl+'delete-document/' + fileId);
    // }

    // downloadDocumentByFileId(fileId:string){
    //     return this.http.get(this.resourceUrl+'document-by-id/' + fileId,{
    //         responseType:"blob",
    //         headers:new HttpHeaders().append('Content-Type','application/json')
    //     });
    // } 
    
}