import { Component, OnInit, Input } from '@angular/core';
import { Principal } from '../../shared';

@Component({
    selector: 'jhi-footer',
    templateUrl: './footer.component.html'
})
export class FooterComponent implements OnInit {
    public securityMsg: string;
    public compatibilityMsg: string;
    public copyRightsYear: number;
    isTOU: boolean = false;
    constructor(private principal: Principal) {}

    ngOnInit() {
        this.securityMsg = 'This is a secure application & access is restricted to authorized users.';
        this.compatibilityMsg = 'Best viewed with the following: Internet Explorer 11 and Firefox';
        this.copyRightsYear = 2018;
    }

    isAuthenticated() {
        return this.principal.isAuthenticated();
    }

    showDialog() {
        this.isTOU = true;
    }
}
