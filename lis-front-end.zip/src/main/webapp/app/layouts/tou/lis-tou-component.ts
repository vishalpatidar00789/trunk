import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'lis-tou',
    templateUrl: 'lis-tou-component.html'
})
export class TOUComponent implements OnInit {
    // isTOU: boolean = false;
    constructor() {}

    ngOnInit() {}

}
