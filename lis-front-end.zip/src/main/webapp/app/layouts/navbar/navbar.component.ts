import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

import { ProfileService } from '../profiles/profile.service';
import {
  Account,
  Principal,
  LoginModalService,
  LoginService,
  Bank,
  LookupService
} from '../../shared';

import { VERSION } from '../../app.constants';
import { LoanService } from '../../loan/loan.service';
import {
  Loan,
  LoanProcess,
  PFICreditLimit,
  UobCreditLimit,
  SponsorEForm,
  LoanNew
} from '../../loan';
import { SponsorEFormService } from '../../loan/sponsor-eform/sponsor-eform.service';
import { CreditInfo } from '../../loan/mid-term/mid-term.model';

@Component({
  selector: 'jhi-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['navbar.scss']
})
export class NavbarComponent implements OnInit {
  inProduction: boolean;
  isNavbarCollapsed: boolean;
  languages: any[];
  swaggerEnabled: boolean;
  modalRef: NgbModalRef;
  version: string;
  UOBUser = false;
  PFIUser = true;
  currentAccount: Account;
  loan: LoanNew;
  bank: Bank;
  tranche: any;
  loanProcess: LoanProcess;

  constructor(
    private loginService: LoginService,
    private principal: Principal,
    private loginModalService: LoginModalService,
    private profileService: ProfileService,
    private router: Router,
    private loanService: LoanService,
    private lookupService: LookupService,
    private sponsorEFormService: SponsorEFormService
  ) {
    this.version = VERSION ? 'v' + VERSION : '';
    this.isNavbarCollapsed = true;
  }

  ngOnInit() {
    /* this.profileService.getProfileInfo().then((profileInfo) => {
            this.inProduction = profileInfo.inProduction;
            this.swaggerEnabled = profileInfo.swaggerEnabled;
        }); */

    this.lookupService.getCurrentTranche().subscribe((tranche) => {
      if (tranche) {
        this.tranche = tranche;
      }
    });
  }

  collapseNavbar() {
    this.isNavbarCollapsed = true;
  }

  isAuthenticated() {
    if(this.principal.isAuthenticated()) {
      return !this.isForcePasswordReset();
    } else {
      return false;
    }
  }

  isForcePasswordReset() {
    return this.principal.isForcePasswordResetFunc();
  }

  login() {
    this.modalRef = this.loginModalService.open();
  }

  logout() {
    this.collapseNavbar();
    this.loginService.logout();
    this.router.navigate(['']);
  }

  toggleNavbar() {
    this.isNavbarCollapsed = !this.isNavbarCollapsed;
  }

  getImageUrl() {
    return this.isAuthenticated() ? this.principal.getImageUrl() : null;
  }

  newLoanApplication() {
    this.collapseNavbar();
    this.loanService.setLoanStepProcess(Object.assign({}, new LoanProcess()));
    this.sponsorEFormService.setSponsorEForm(
      Object.assign({}, new SponsorEForm())
    );
    this.createNewLoan();
  }

  createNewLoan() {
    this.loan = new LoanNew();
    this.principal.identity().then((account) => {
      if (account && account.bank) {
        this.lookupService
          .getBankByCode(account.bank)
          .subscribe((bankDetails) => {
            this.bank = new Bank();
            if (bankDetails) {
              this.bank = bankDetails;
              this.loan.consortium = this.bank.consortiumid;
              this.loan.loanRequestSeqNo = 1;
              const creditInfo = new CreditInfo();
              creditInfo.pfiName = this.bank.bankName;
              creditInfo.pfiCode = this.bank.bankCode;
              this.loan.creditInfo = creditInfo;
              this.loanService.createLoan(this.loan).subscribe((loanResult) => {
                const loanProcess = new LoanProcess();
                loanProcess.id = loanResult._id;
                loanProcess.status = loanResult.status;
                if (this.tranche) {
                  loanProcess.tranchName = this.tranche.trancheName;
                }
                this.loanProcess = Object.assign({}, loanProcess);
                this.loanService.setLoanStepProcess(loanProcess);
              });
            }
          });
      }
    });
  }
}
