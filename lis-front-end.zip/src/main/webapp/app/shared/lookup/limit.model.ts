export class Limit {
  _id?: any;
  trancheId: string;
  consortiumId: string;
  applicationType: string;
  maximumLimit: number;
  activated: boolean;
  createdBy: string;
  createdDate: string;
  lastModifiedBy: string;
  lastModifiedDate: string;
}
