export class Bank {
  public _id?: any;
  public bankCode?: string;
  public bankName?: string;
  public activated?: Boolean;
  public createdBy?: string;
  public createdDate?: Date;
  public lastModifiedBy?: string;
  public lastModifiedDate?: Date;
  public consortiumid?: string;
  constructor(
    _id?: any,
    bankCode?: string,
    bankName?: string,
    activated?: Boolean,
    createdBy?: string,
    createdDate?: Date,
    lastModifiedBy?: string,
    lastModifiedDate?: Date
  ) {
    this._id = _id ? _id : null;
    this.bankCode = bankCode ? bankCode : null;
    this.bankName = bankName ? bankName : null;
    this.activated = activated ? activated : true;
    this.createdBy = createdBy ? createdBy : null;
    this.createdDate = createdDate ? createdDate : null;
    this.lastModifiedBy = lastModifiedBy ? lastModifiedBy : null;
    this.lastModifiedDate = lastModifiedDate ? lastModifiedDate : null;
  }
}

export class BankDetails {
  
}
