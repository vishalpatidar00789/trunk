export class Department {
    public _id?: any;
    public departmentName?: string;
    public departmentCode?: string;
    public activated?: Boolean;
    public createdBy?: string;
    public createdDate?: Date;
    public lastModifiedBy?: string;
    public lastModifiedDate?: Date;
    constructor(
        _id?: any,
        departmentName?: string,
        departmentCode?: string,
        activated?: Boolean,
        createdBy?: string,
        createdDate?: Date,
        lastModifiedBy?: string,
        lastModifiedDate?: Date
    ) {
        this._id = _id ? _id : null;
        this.departmentName = departmentName ? departmentName : null;
        this.departmentCode = departmentCode ? departmentCode : null;
        this.activated = activated ? activated : true;
        this.createdBy = createdBy ? createdBy : null;
        this.createdDate = createdDate ? createdDate : null;
        this.lastModifiedBy = lastModifiedBy ? lastModifiedBy : null;
        this.lastModifiedDate = lastModifiedDate ? lastModifiedDate : null;
    }
}
