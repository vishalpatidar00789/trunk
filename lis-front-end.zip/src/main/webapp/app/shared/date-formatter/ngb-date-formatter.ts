import { Injectable } from '@angular/core';
import { NgbDateParserFormatter, NgbDateStruct } from "@ng-bootstrap/ng-bootstrap";
import * as moment from 'moment';

function padNumber(value: number) {
    if (isNumber(value)) {
        return `0${value}`.slice(-2);
    } else {
        return "";
    }
}

function isNumber(value: any): boolean {
    return !isNaN(toInteger(value));
}

function toInteger(value: any): number {
    return parseInt(`${value}`, 10);
}

function toMonth(value: number): string {
    switch (value) {
        case 1:
            return 'JAN';
        case 2:
            return 'FEB';
        case 3:
            return 'MAR';
        case 4:
            return 'APR';
        case 5:
            return 'MAY';
        case 6:
            return 'JUN';
        case 7:
            return 'JUL';
        case 8:
            return 'AUG';
        case 9:
            return 'SEP';
        case 10:
            return 'OCT';
        case 11:
            return 'NOV';
        case 12:
            return 'DEC';
        default:

    }
    return 'Invalid month';
}

export class NgbDateMomentParserFormatter extends NgbDateParserFormatter {
    constructor(private momentFormat: string) {
        super();
    };

    format(date: NgbDateStruct): string {

        if (date) {

            let d = moment({
                year: date.year,
                month: date.month - 1,
                date: date.day
            });

            return d.isValid() ? d.format("DD-MMM-YYYY") : '';
        } else {
            return '';
        }
    }

    parse(value: string): NgbDateStruct {
        if (!value) {
            return null;
        }
        const d = moment(value, this.momentFormat);
        return d.isValid() ? {
            year: d.year(),
            month: d.month() + 1,
            day: d.date()
        } : null;
    }



}
