
import { Component } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { SERVER_API_URL } from '../../app.constants';
import { JhiEventManager } from 'ng-jhipster';
import { NotificationOption, NotificationService } from '../alert/notification.service';

@Component({
    selector: 'jhi-forgot-password-modal',
    templateUrl: './forgot-password.html'
})
export class ForgotPasswordDialogComponent {
    userId: string;
    successmsg: string;
    errormsg: string;

    constructor(private http: HttpClient, private eventManager: JhiEventManager, private notificationService: NotificationService) {

    }

    resetPassword() {
        // console.log("resetting password::");
        this.reset().subscribe((result) => {
            // console.log("result from server:: " + JSON.stringify(result));
            const msgObj = result.body;

            const notificationOption = new NotificationOption();
            notificationOption.title = 'Notification';
            if (msgObj && msgObj['success']) {
                notificationOption.type = 'success';
                notificationOption.message = msgObj['success'];
                this.eventManager.broadcast({
                    name: 'resetPasswordSuccess',
                    content: 'Sending Reset Success'
                });
            } else if (msgObj && msgObj['error']) {
                notificationOption.type = 'error';
                notificationOption.toastrConfig = {
                    positionClass: 'toast-bottom-right'
                };
                notificationOption.message = msgObj['error'];
            }
            this.notificationService.showNotification(notificationOption);
        }, (error) => {
            this.successmsg = null;
        });
    }

    reset(): Observable<HttpResponse<any>> {
        const who = 'PFI_USER';
        return this.http.post(SERVER_API_URL + `users/reset-password/${who}`, { userId: this.userId }, { observe: 'response' });
    }
}