export const ITEMS_PER_PAGE = 20;

export const LOAN_SEARCH_RESULT_ITEMS_PER_PAGE = 10;
