
export const natureOfApplication = [
    { label: 'NEW', value: 'New' },
    { label: 'CANCEL UTILISED', value: 'Cancel Utilised' },
    { label: 'CANCEL UN-UTILISED', value: 'Cancel Un-Utilised' },
    { label: 'DECREASE UN-UTILISED', value: 'Decrease Un-Utilised' },
    { label: 'RENEWAL', value: 'Renewal' },
    { label: 'MID-TERM INCR - UN-UTILISED', value: 'Mid-Term INCR Un-Utilised' },
    { label: 'DECREASE UTILISED', value: 'Decrease Utilised' },
    { label: 'MID-TERM INCR - UTILISED', value: 'Mid-Term INCR Utilised' },
    { label: 'TEMPORARY INCREASE', value: 'Temporary Increase' }
];