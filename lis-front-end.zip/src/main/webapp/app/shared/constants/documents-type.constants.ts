export const LoanDocumentTypes = [
    { label: 'Sponsor form', value: 'Sponsor form' },
    { label: 'Pre shipment approval', value: 'Pre shipment approval' },
    { label: 'Borrower Group', value: 'Borrower Group' },
    { label: 'Overseas working capital loans support', value: 'Overseas working capital loans support' },
    { label: 'Company searches or individual searches', value: 'Company searches or individual searches' },
    { label: 'PFI’s internal Credit Memo Approval', value: 'PFI’s internal Credit Memo Approval' },
    { label: 'Latest Audited Financials from Borrower', value: 'Latest Audited Financials from Borrower' },
    { label: 'Latest signed Management Accounts', value: 'Latest signed Management Accounts' },
    { label: 'LO Acceptance', value: 'LO Acceptance' },
    { label: 'Internal Remarks', value: 'Internal Remarks' },
    { label: 'Adverse information', value: 'Adverse information' },
    { label: 'Others', value: 'Others' }
];

export const AdhcoDocumentTypes = [
    { label: 'Cancellation of Non-utilised', value: 'Cancellation of Non-utilised' },
    { label: 'Cancellation of Accepted and Utilised', value: 'Cancellation of Accepted and Utilised' },
    { label: 'Extension of Facility Expiry date', value: 'Extension of Facility Expiry date' },
    { label: 'Extension of Due date of Bill', value: 'Extension of Due date of Bill' },
    { label: 'Overseas Inclusion o Byuers under CL', value: 'Overseas Inclusion o Byuers under CL' },
    { label: 'Pre-Shipment Financing Approval', value: 'Pre-Shipment Financing Approval' },
    { label: 'Extension of Acceptance of Letter of Offer', value: 'Extension of Acceptance of Letter of Offer' },
    { label: 'Reinstatement of Facility', value: 'Reinstatement of Facility' },
    { label: 'Revalidation of Insurance coverage', value: 'Revalidation of Insurance coverage' },
    { label: 'Other Ad-hoc requests', value: 'Other Ad-hoc requests' },
    { label: 'Internal Remarks', value: 'Internal Remarks' },
    { label: 'Adverse information', value: 'Adverse information' },
    { label: 'Others', value: 'Others' }
]