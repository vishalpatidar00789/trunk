import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormControl } from '@angular/forms';
import { InputValidationModel } from '../input/input-validation.model';

@Component({
  selector: 'jhi-input-currency',
  templateUrl: './input-currency.component.html',
  styles: []
})
export class InputCurrencyComponent implements OnInit {
  @Input() labelTxt: string;
  @Input() currency: string;
  @Input() value: string;
  @Input() currencyFormControl: FormControl;
  @Input() inputValidation: InputValidationModel;
  @Input() disabled: boolean;
  @Input() min: number;
  @Input() max: number;
  @Output() blurEvent = new EventEmitter();
  @Output() changeEvent = new EventEmitter();

  constructor() {}

  ngOnInit() {}

  onBlur(event: any) {
    this.blurEvent.emit({ value: this.value, eventArgs: event });
  }
  onChange(event: any) {
    this.changeEvent.emit({ value: this.value, eventArgs: event });
  }
}
