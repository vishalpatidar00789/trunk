export class Consortium {
    public _id?: any;    
    public consortiumName?: string;
    public activated?: Boolean;
    // public createdBy?: string;
    // public createdDate?: Date;
    // public lastModifiedBy?: string;
    // public lastModifiedDate?: Date;
    constructor(
        _id?: any,        
        consortiumName?: string,
        activated?: Boolean,
        // createdBy?: string,
        // createdDate?: Date,
        // lastModifiedBy?: string,
        // lastModifiedDate?: Date
    ) {
        this._id = _id;
        this.consortiumName = consortiumName ? consortiumName : null;
        this.activated = activated ? activated : true;
        // this.createdBy = createdBy ? createdBy : null;
        // this.createdDate = createdDate ? createdDate : null;
        // this.lastModifiedBy = lastModifiedBy ? lastModifiedBy : null;
        // this.lastModifiedDate = lastModifiedDate ? lastModifiedDate : null;
    }
}
