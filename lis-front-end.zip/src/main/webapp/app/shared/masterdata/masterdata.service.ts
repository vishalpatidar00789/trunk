import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

import { SERVER_API_URL } from '../../app.constants';
import {Consortium,App} from '..';
import { AnimationKeyframesSequenceMetadata } from '@angular/animations';

@Injectable()
export class MasterdataService {
    private resourceUrl = SERVER_API_URL+ 'master-data/';

    constructor(private http: HttpClient) { }
    
    consortiums(): Observable<Consortium[]> {
        return this.http.get<Consortium[]>(this.resourceUrl + 'consortium');
    }

    app(): Observable<App[]> {
        return this.http.get<App[]>(this.resourceUrl + 'app-management');
    }

    // TODO: Write a Tranche model and replace any with that
    tranches (): Observable<any[]> {
        return this.http.get<any[]>(this.resourceUrl + 'tranch');
    }
}
