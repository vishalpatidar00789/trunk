import { Injectable } from '@angular/core';

import { Principal } from '../auth/principal.service';
import { AuthServerProvider } from '../auth/auth-jwt.service';

@Injectable()
export class LoginService {

    constructor(
        private principal: Principal,
        private authServerProvider: AuthServerProvider
    ) { }

    login(credentials, callback?) {
        const cb = callback || function() { };

        return new Promise((resolve, reject) => {
            this.authServerProvider.login(credentials).subscribe((data) => {
                // this.principal.identity(true).then((account) => {
                //     resolve(data);
                // });
                console.log('data from server :: ' + JSON.stringify(data));
                resolve(data);
                return cb();
            }, (err) => {
                this.logout();
                reject(err);
                return cb(err);
            });
        });
    }

    loginWithToken(jwt, rememberMe) {
        return this.authServerProvider.loginWithToken(jwt, rememberMe);
    }

    logout() {
        this.authServerProvider.logout().subscribe();
        this.principal.authenticate(null);
    }

    generateToken(userdata: any) {
        console.log('inside service generateToken');
        return new Promise((resolve, reject) => {
            this.authServerProvider.generateToken(userdata).subscribe((data) => {
                console.log('auth service provided data:: ' + JSON.stringify(data));
                resolve(data);
            }, (err) => {
                console.log(err);
                reject(err);
            });
        });
    }

    verify(data: any) {
        return new Promise((resolve, reject) => {
            this.authServerProvider.verify(data).subscribe((result) => {
                console.log('auth service provided data:: ' + JSON.stringify(result));
                resolve(result);
            }, (err) => {
                console.log(err);
                reject(err);
            });
        });
    }

    getIpAddress() {
        return new Promise((resolve, reject) => {
            this.authServerProvider.getIpAddress().subscribe((data) => {
                console.log('ipaddress from server :: ' + JSON.stringify(data));
                resolve(data);
            }, (err) => {
                reject(err);
            });
        });
    }
}
