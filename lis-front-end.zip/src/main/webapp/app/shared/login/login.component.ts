import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { JhiEventManager } from 'ng-jhipster';
import { LoginService } from './login.service';
import { StateStorageService } from '../auth/state-storage.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
    selector: 'jhi-login-modal',
    templateUrl: './login.component.html'
})
export class JhiLoginModalComponent implements OnInit {
    authenticationError: boolean;
    password: string;
    rememberMe: boolean;
    username: string;
    credentials: any;
    errormsg: string;
    forgotPassModel: boolean;
    isVerify: boolean;
    userdata: any;
    otp: string;
    data: any;
    constructor(
        private eventManager: JhiEventManager,
        private loginService: LoginService,
        private stateStorageService: StateStorageService,
        private router: Router
    ) {
        this.credentials = {};
    }

    ngOnInit() {
        this.forgotPassModel = false;
        this.isVerify = false;
        this.registerResetPasswordSuccess();
    }

    cancel() {
        this.credentials = {
            username: null,
            password: null,
            rememberMe: true
        };
        this.authenticationError = false;
        // this.activeModal.dismiss('cancel');
    }

    // login() {
    //     this.loginService
    //         .login({
    //             username: this.username,
    //             password: this.password
    //             // rememberMe: this.rememberMe
    //         })
    //         .then(() => {
    //             this.authenticationError = false;
    //             // this.activeModal.dismiss('login success');
    //             if (
    //                 this.router.url === '/register' ||
    //                 /^\/activate\//.test(this.router.url) ||
    //                 /^\/reset\//.test(this.router.url)
    //             ) {
    //                 this.router.navigate(['']);
    //             }

    //             this.eventManager.broadcast({
    //                 name: 'authenticationSuccess',
    //                 content: 'Sending Authentication Success'
    //             });

    //             // // previousState was set in the authExpiredInterceptor before being redirected to login modal.
    //             // // since login is succesful, go to stored previousState and clear previousState
    //             const redirect = this.stateStorageService.getUrl();
    //             if (redirect) {
    //                 this.stateStorageService.storeUrl(null);
    //                 this.router.navigate([redirect]);
    //             }
    //         })
    //         .catch((response) => {
    //             this.authenticationError = true;
    //             this.errormsg = response.error.message;
    //             console.log(JSON.stringify(response.error));
    //         });
    // }

    login() {
        this.loginService
            .login({
                username: this.username,
                password: this.password
                // rememberMe: this.rememberMe
            })
            .then(() => {
                // this.authenticationError = false;
                // this.activeModal.dismiss('login success');
                console.log("before generateToken");
                this.generateToken();
            })
            .catch((response) => {
                this.authenticationError = true;
                this.errormsg = response.error.message;
                console.log(JSON.stringify(response.error));
            });
    }

    register() {
        // this.activeModal.dismiss('to state register');
        this.router.navigate(['/register']);
    }

    requestResetPassword() {
        this.forgotPassModel = true;
    }

    registerResetPasswordSuccess() {
        this.eventManager.subscribe('resetPasswordSuccess', (message) => {
            console.log('reset event');
            this.forgotPassModel = false;
        });
    }

    verify() {
        this.data.body.otp = this.otp;
        this.loginService
            .verify(this.data)
            .then((data) => {
                this.authenticationError = false;
                // this.activeModal.dismiss('login success');
                console.log(JSON.stringify(data));
                this.isVerify = false;
                if (
                    this.router.url === '/register' ||
                    /^\/activate\//.test(this.router.url) ||
                    /^\/reset\//.test(this.router.url)
                ) {
                    this.router.navigate(['']);
                }

                this.eventManager.broadcast({
                    name: 'authenticationSuccess',
                    content: 'Sending Authentication Success'
                });

                // // previousState was set in the authExpiredInterceptor before being redirected to login modal.
                // // since login is succesful, go to stored previousState and clear previousState
                const redirect = this.stateStorageService.getUrl();
                if (redirect) {
                    this.stateStorageService.storeUrl(null);
                    this.router.navigate([redirect]);
                }
            })
            .catch((response) => {
                this.authenticationError = true;
                this.errormsg = response.error.message;
                console.log(JSON.stringify(response.error));
            });


    }
    generateToken() {
        console.log("inside generateToken");
        const userdata: any = {
            username: this.username,
            userEmail: this.username,
            ipAddress: '1.1.1.1',
            clientGenCookie: 'someencdata'
        }
        this.loginService
            .generateToken(userdata)
            .then((data) => {
                this.data = data;
                console.log(JSON.stringify(data));
                this.userdata = data;
                this.isVerify = true;
            })
            .catch((response) => {
                this.authenticationError = true;
                this.errormsg = response.error.message;
                this.isVerify = false;
                console.log(JSON.stringify(response.error));
            });
    }
}
