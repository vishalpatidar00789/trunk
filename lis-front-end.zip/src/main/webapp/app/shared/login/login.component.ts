import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { JhiEventManager } from 'ng-jhipster';
import { LoginService } from './login.service';
import { StateStorageService } from '../auth/state-storage.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
    selector: 'jhi-login-modal',
    templateUrl: './login.component.html'
})
export class JhiLoginModalComponent implements OnInit {
    authenticationError: boolean;
    password: string;
    rememberMe: boolean;
    username: string;
    credentials: any;
    errormsg: string;
    forgotPassModel: boolean;
    isVerify: boolean;
    userdata: any;
    otp: string;
    data: any;
    ip: any;
    constructor(
        private eventManager: JhiEventManager,
        private loginService: LoginService,
        private stateStorageService: StateStorageService,
        private router: Router
    ) {
        this.credentials = {};
    }

    ngOnInit() {
        this.forgotPassModel = false;
        this.isVerify = false;
        this.registerResetPasswordSuccess();
        // this.loginService.getIpAddress().then((ipadd) => {
        //     console.log('ip add:: ' + JSON.stringify(ipadd));
        //     console.log('ip add:: ' + ipadd);
        //     this.ip = ipadd;
        //   }).catch((response) => {
        //     console.log(JSON.stringify(response.error));
        //   });
    }

    cancel() {
        this.credentials = {
            username: null,
            password: null,
            // ipaddress: this.ip
        };
        this.authenticationError = false;
        // this.activeModal.dismiss('cancel');
    }

    // login() {
    //     this.loginService
    //         .login({
    //             username: this.username,
    //             password: this.password
    //             // rememberMe: this.rememberMe
    //         })
    //         .then(() => {
    //             this.authenticationError = false;
    //             // this.activeModal.dismiss('login success');
    //             if (
    //                 this.router.url === '/register' ||
    //                 /^\/activate\//.test(this.router.url) ||
    //                 /^\/reset\//.test(this.router.url)
    //             ) {
    //                 this.router.navigate(['']);
    //             }

    //             this.eventManager.broadcast({
    //                 name: 'authenticationSuccess',
    //                 content: 'Sending Authentication Success'
    //             });

    //             // // previousState was set in the authExpiredInterceptor before being redirected to login modal.
    //             // // since login is succesful, go to stored previousState and clear previousState
    //             const redirect = this.stateStorageService.getUrl();
    //             if (redirect) {
    //                 this.stateStorageService.storeUrl(null);
    //                 this.router.navigate([redirect]);
    //             }
    //         })
    //         .catch((response) => {
    //             this.authenticationError = true;
    //             this.errormsg = response.error.message;
    //             console.log(JSON.stringify(response.error));
    //         });
    // }

    login() {
        this.loginService
            .login({
                username: this.username,
                password: this.password,
                ipaddress: this.ip ? this.ip : '1.2.1.2'
            })
            .then((data) => {
                // this.authenticationError = true;
                // this.activeModal.dismiss('login success');
                console.log('before generateToken ;; ' + JSON.stringify(data));
                const result = data['body'];
                console.log('data from auth :: ' + JSON.stringify(data['body']));
                if (result.opCode === 200) {
                    // this.authenticationError = true;
                    this.redirect();
                } else if (result.opCode === 201) {
                    // this.authenticationError = true;
                    console.log('otp recieved :: ' + result['otpdata'].otp );
                    this.isVerify = true;
                    // this.userdata = result['userdata'];
                    console.log('data recieved :: ' + result['userdata'] + ' ' + result['otpdata'].sessionId);
                    this.data['userData'] = result['userdata'];
                    this.data['sessionId'] = result['otpdata'].sessionId;
                    this.data['TransactionId'] = result['otpdata'].transactionId;
                } else if (data['body'].opCode === 423) {
                    this.isVerify = false;
                    this.authenticationError = true;
                    this.errormsg = result.msg;
                } else if (data['body'].opCode === 500) {
                    this.isVerify = false;
                    this.authenticationError = true;
                    this.errormsg = result.msg;
                }
            })
            .catch((response) => {
                this.authenticationError = true;
                this.errormsg = response.error.message;
                console.log(JSON.stringify(response.error));
            });
    }

    register() {
        // this.activeModal.dismiss('to state register');
        this.router.navigate(['/register']);
    }

    requestResetPassword() {
        this.forgotPassModel = true;
    }

    registerResetPasswordSuccess() {
        this.eventManager.subscribe('resetPasswordSuccess', (message) => {
            console.log('reset event');
            this.forgotPassModel = false;
        });
    }

    verify() {
        this.data.otp = this.otp;
        this.loginService
            .verify(this.data)
            .then((response) => {
                console.log('result from verfy :: ' + JSON.stringify(response));
                const result  = response['body'];
                if  ( result['userStatus'] === 'Invalid/Expired/Reset Session Id Error') {
                        console.log('MFAAnalyzeAndChallenge :: Authenticate :: Session Timed out Redirecting to Login Page');
                        this.isVerify = false;
                        this.errormsg = 'Session Timed out';
                    } else if  ((result['userStatus'] === 'LOCKOUT') || (result['userStatus'] === 'DELETE')) {
                        console.log('MFAOTPValidate :: User Locked Out or Deleted');
                        this.isVerify = false;
                        this.errormsg = 'User Locked Out or Deleted';
                    } else if  (result['statusCode'] === 'FAIL') {
                        console.log(`MFAOTPValidate :: OTP doesn't match`);
                        this.isVerify = false;
                        this.errormsg = `OTP doesn't match`;
                    } else if  (result['statusCode'] === 'SUCCESS') {
                        console.log('MFAOTPValidate :: OTP matches');
                        // redirect to home
                        this.redirect();
                    }
            })
            .catch((response) => {
                this.authenticationError = true;
                this.errormsg = response.error.message;
                console.log(JSON.stringify(response.error));
            });

    }

    redirect() {
        this.authenticationError = false;
                this.isVerify = false;
                if (
                    this.router.url === '/register' ||
                    /^\/activate\//.test(this.router.url) ||
                    /^\/reset\//.test(this.router.url)
                ) {
                    this.router.navigate(['']);
                }

                this.eventManager.broadcast({
                    name: 'authenticationSuccess',
                    content: 'Sending Authentication Success'
                });

                // // previousState was set in the authExpiredInterceptor before being redirected to login modal.
                // // since login is succesful, go to stored previousState and clear previousState
                const redirect = this.stateStorageService.getUrl();
                if (redirect) {
                    this.stateStorageService.storeUrl(null);
                    this.router.navigate([redirect]);
                }
    }

    public async generateToken(): Promise<any> {
        console.log('inside generateToken');
        const userdata: any = {
            username: this.username,
            userEmail: this.username,
            ipAddress: '1.1.1.1',
            clientGenCookie: 'someencdata'
        };

        return new Promise<any> ((resolve, reject) => {
            this.loginService
            .generateToken(userdata)
            .then((response) => {
                console.log('result from generate token ;;' + JSON.stringify(response));
                const result = response['body'];
                if (result['opCode'] === 200) {
                    // redirect to home
                    this.isVerify = false;
                    resolve(200);
                } else if (result['opCode'] === 201) {
                    console.log('otp recieved :: ' + result['otpdata'].otp );
                    this.isVerify = true;
                    // this.userdata = result['userdata'];
                    console.log('data recieved :: ' + result['userdata'] + ' ' + result['otpdata'].sessionId);
                    this.data['userData'] = result['userdata'];
                    this.data['sessionId'] = result['otpdata'].sessionId;
                    this.data['TransactionId'] = result['otpdata'].transactionId;
                    resolve(200);
                } else if (result['opCode'] === 423) {
                    this.isVerify = false;
                    this.errormsg = result['msg'];
                    resolve(423);
                }
            })
            .catch((response) => {
                this.authenticationError = true;
                this.errormsg = response.error.message;
                this.isVerify = false;
                console.log(JSON.stringify(response.error));
                reject(401);
            });
        });
    }
}
