import { NgModule, LOCALE_ID } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { registerLocaleData } from '@angular/common';
import locale from '@angular/common/locales/en';
import { DropdownModule } from 'primeng/dropdown';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import {
  BsDatepickerModule,
  BsDatepickerConfig
} from 'ngx-bootstrap/datepicker';

import {
  LisAppSharedLibsModule,
  JhiAlertComponent,
  JhiAlertErrorComponent
} from './';
import { DropDownComponent } from './drop-down/drop-down.component';
import { InputComponent } from './input/input.component';
import { DatePickerComponent } from './date-picker/date-picker.component';
import { InputCurrencyComponent } from './input-currency/input-currency.component';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import {
  CurrencyMaskConfig,
  CURRENCY_MASK_CONFIG
} from 'ng2-currency-mask/src/currency-mask.config';

export const CustomCurrencyMaskConfig: CurrencyMaskConfig = {
  align: 'left',
  allowNegative: false,
  decimal: '.',
  precision: 2,
  prefix: ' ',
  suffix: '',
  thousands: ','
};

@NgModule({
  imports: [
    LisAppSharedLibsModule,
    DropdownModule,
    FormsModule,
    ReactiveFormsModule,
    CurrencyMaskModule,
    BsDatepickerModule.forRoot()
  ],
  declarations: [
    JhiAlertComponent,
    JhiAlertErrorComponent,
    DropDownComponent,
    InputComponent,
    DatePickerComponent,
    InputCurrencyComponent
  ],
  providers: [
    Title,
    {
      provide: LOCALE_ID,
      useValue: 'en'
    },
    { provide: CURRENCY_MASK_CONFIG, useValue: CustomCurrencyMaskConfig }
  ],
  exports: [
    LisAppSharedLibsModule,
    JhiAlertComponent,
    JhiAlertErrorComponent,
    DropDownComponent,
    InputComponent,
    DatePickerComponent,
    InputCurrencyComponent
  ]
})
export class LisAppSharedCommonModule {
  constructor() {
    registerLocaleData(locale);
  }
}

export function getDatepickerConfig(): BsDatepickerConfig {
  return Object.assign(new BsDatepickerConfig(), {
    dateInputFormat: 'DD-MMM-YYYY',
    containerClass: 'theme-dark-blue',
    showWeekNumbers: false
  });
}
