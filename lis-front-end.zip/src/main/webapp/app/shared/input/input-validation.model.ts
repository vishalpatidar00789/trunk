export class InputValidationModel {
  requiredText: string;
  patternText: string;
  maxText: string;
  minText: string;
}
