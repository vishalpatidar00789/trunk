import { InputValidationModel } from './input-validation.model';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'jhi-input',
  templateUrl: './input.component.html',
  styles: []
})
export class InputComponent implements OnInit {
  @Input() labelTxt: string;
  @Input() labelPosition = 'top';
  @Input() value: string;
  @Input() inputFormControl: FormControl;
  @Input() inputValidation: InputValidationModel;
  @Input() readOnly: boolean;
  @Output() blurEvent = new EventEmitter();
  @Output() changeEvent = new EventEmitter();

  constructor() {}

  ngOnInit() {}

  onBlur(event: any) {
    this.blurEvent.emit(event);
  }
  onChange(event: any) {
    this.changeEvent.emit(event);
  }
}
