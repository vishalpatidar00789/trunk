export class Document {
    constructor(
        public _id?: string,
        public filename?: string,
        public uploadDate?: any,
        public documentType?: string,
        public uploadedBy?: string
    ) {
    }
}


export class FileData {
    constructor(  
        public _id:string,     
        public uploadDate?: any,
        public metadata?: {
            documentType?: string,
            uploadedBy?: string,
            fileName?:string
        }
    ) {
        this.metadata = { documentType: '', uploadedBy: '' };
    }
}