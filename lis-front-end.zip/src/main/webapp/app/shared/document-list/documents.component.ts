import { Component, OnInit, Input, OnChanges, Output, EventEmitter, ViewChild, IterableDiffers, DoCheck } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { Table } from 'primeng/table';
import { Document } from './documents.model';
import { DocumentsService } from './documents.service';
import { ConfirmationService } from 'primeng/api';
import * as FileSaver from 'file-saver';
import { error } from 'util';
import { NotificationService, NotificationOption } from '../alert/notification.service';

@Component({
    selector: 'lis-documents',
    templateUrl: './documents.component.html'
})
export class DocumentComponent implements OnInit, OnChanges, DoCheck {

    @Input() isMarshUser: boolean;
    @Input() documentList: Document[];
    @ViewChild('documentListTable') documentListTable: Table;

    public documentList2: Document[];
    public cols: any[];
    differ: any;

    constructor(private documentService: DocumentsService,
        private confirmationService: ConfirmationService,
        private notificationService: NotificationService,
        differs: IterableDiffers) {
        this.differ = differs.find([]).create(null);
    }

    ngOnInit() {
        console.log(this.documentList2);
        this.cols = [
            { field: 'documentType', header: 'Document Type' },
            { field: 'filename', header: 'Uploaded Document Name' },
            { field: 'uploadDate', header: 'Date Of Upload' },
            { field: 'uploadedBy', header: 'Uploaded By' }
        ];
    }

    ngOnChanges() {
        this.documentList2 = [];
        setTimeout(() => {
            this.documentList2 = this.documentList;
        }, 100);
    }

    ngDoCheck() {
        const change = this.differ.diff(this.documentList);        
        if(change){
            this.documentList2 = [];
            setTimeout(() => {
                this.documentList2 = this.documentList;
            }, 100);
        }
    }

    delete(rowData: Document) {
        let fileId = rowData._id;
        if (fileId) {            
            const r = confirm("Do you want to delete this document?");
            if (r === true) {
                this.documentService.deleteDocumentByFileId(fileId).subscribe(res => {
                    this.documentList2.forEach((item, index) => {
                        if (item._id === fileId) {
                            this.documentList2.splice(index, 1);
                            return;
                        }
                    });
                });
            } else {
            }
        }
    }

    download(rowData: Document) {
        const fileId = rowData._id;
        const filename = rowData.filename;
        if (fileId) {
            this.documentService.downloadDocumentByFileId(fileId).subscribe(
                data => {
                    FileSaver.saveAs(data, filename);
                },
                error => {
                    console.error(error);
                }
            );
        }
    }
}
