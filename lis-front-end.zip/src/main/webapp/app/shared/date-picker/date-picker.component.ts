import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'jhi-date-picker',
  templateUrl: './date-picker.component.html',
  styles: []
})
export class DatePickerComponent implements OnInit {
  @Input() label: string;
  @Input() value: Date;
  @Input() outsideClick: boolean;
  @Input() readOnly: boolean;
  @Input() container = 'body';
  @Input() placeholder = 'Please select';
  @Output() blurEvent = new EventEmitter();
  @Output() changeEvent = new EventEmitter();
  @Input() hideButton: boolean;

  constructor() {}

  ngOnInit() {}

  onBlur(event: any) {
    this.blurEvent.emit(event);
  }
  onChange(event: any) {
    this.changeEvent.emit(event);
  }
}
