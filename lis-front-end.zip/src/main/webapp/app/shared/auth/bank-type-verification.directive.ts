import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { Principal } from './principal.service';
import { Account } from '../../shared';

/**
 * @whatItDoes Conditionally includes an HTML element if current user has any
 * of the authorities passed as the `expression`.
 *
 * @howToUse
 * ```
 *     <some-element *jhiBankTypeVerification='9PFI'>...</some-element>
 *
 *     <some-element *jhiBankTypeVerification='UOB'>...</some-element>
 * ```
 */
@Directive({
    selector: '[jhiBankTypeVerification]'
})
export class BankTypeVerificationDirective {

    private bankType: string;
    currentAccount: Account;
    private userBankType: string;
    constructor(private principal: Principal, private templateRef: TemplateRef<any>, private viewContainerRef: ViewContainerRef) {
    }

    @Input()
    set jhiBankTypeVerification(value: string) {
        if (typeof value === 'string') {
            this.bankType = value;
        }
        this.updateView();
        // Get notified each time authentication state changes.
        // this.principal.getAuthenticationState().subscribe((identity) => this.updateView());
    }

    private updateView(): void {

        this.principal.identity().then((account) => {
            this.viewContainerRef.clear();
            this.currentAccount = account;
            if (this.currentAccount && (typeof this.currentAccount.bank === 'string') && this.currentAccount.bank != 'null') {
                if (this.currentAccount.bank !== 'UOB') {
                    this.userBankType = '9PFI';
                } else {
                    this.userBankType = 'UOB';
                }
                if (this.userBankType === this.bankType) {
                    this.viewContainerRef.createEmbeddedView(this.templateRef);
                }
            }
        });
    }
}
