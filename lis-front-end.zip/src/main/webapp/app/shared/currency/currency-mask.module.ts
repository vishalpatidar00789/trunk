import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { LISCurrencyMaskDirective } from './currency-mask.directive';
import { LISCurrencyMaskService } from './currency-mask.service';

@NgModule({
  imports: [CommonModule, FormsModule],
  exports: [LISCurrencyMaskDirective],
  declarations: [LISCurrencyMaskDirective],
  providers: [LISCurrencyMaskService]
})
export class LISCurrencyMaskModule {}
