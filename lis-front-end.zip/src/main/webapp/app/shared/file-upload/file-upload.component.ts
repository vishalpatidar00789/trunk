import { Component, EventEmitter, Output, Input, OnInit } from '@angular/core';
import { FileUploadService } from './file-upload.service';


@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html'
})
export class FileUploadComponent implements OnInit {

  @Input() public collection: string;
  @Input() public documentType: string;
  @Input() public uploadedBy: string;
  @Input() public refAppId: string;
  @Output() public uploadEvent = new EventEmitter();

  tickVisible: boolean;
  fileUploadResult: any;
  filename: string;
  filesToUpload: Array<File>;

  constructor(private fuService: FileUploadService) {
  }

  ngOnInit() {
    this.tickVisible = false;
    this.filename = "";
    this.filesToUpload = [];
  }

  BrowseAndUpload(fileInput: any) {
    this.filesToUpload = <Array<File>>fileInput.target.files;
    this.filename = this.filesToUpload[0].name;
    this.upload();
  }

  fileChangeEvent(fileInput: any, input: any) {
    this.tickVisible = false;
    this.filesToUpload = <Array<File>>fileInput.target.files;    
    if (this.filesToUpload.length == 1) {
      input.value = this.filesToUpload[0].name;
      this.filename = this.filesToUpload[0].name;
    }
    else input.value = this.filesToUpload.length + ' files';
  }

  upload() {
    let fileSize: any;
    const formData = new FormData();
    const files: Array<File> = this.filesToUpload;

    if (files.length == 0) {
      alert("Please select file to upload..!")
      return;
    }

    fileSize = (files[0].size / 1024);
    if ((fileSize / 1024) > 20) {
      alert("File size must be less than 20 MB.");
      return;
    }

    for (let i = 0; i < files.length; i++) {
      formData.append("uploads", files[i]);
      formData.append("fileName", this.filename);
      formData.append("collection", this.collection);
      formData.append("documentType", this.documentType);
      formData.append("uploadedBy", this.uploadedBy);
    }

    this.fuService.uploadFile(formData, this.refAppId).
      subscribe(result => {
        this.fileUploadResult = result;        
        this.tickVisible = true;
        this.afterFileUploaded();
      });
  }

  afterFileUploaded() {    
    if(this.fileUploadResult)
    this.uploadEvent.emit(this.fileUploadResult);
  }

  getStyle(): any {
    return {
      'visibility': this.tickVisible ? 'visible' : 'hidden'
    };
  }
}