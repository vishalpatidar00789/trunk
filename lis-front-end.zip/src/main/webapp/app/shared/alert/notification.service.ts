import { Injectable } from '@angular/core';
import { ToastrService, ToastrConfig } from 'ngx-toastr';

@Injectable()
export class NotificationService {
  constructor(private toastrService: ToastrService) { }

  showNotification(notificationOption?: NotificationOption) {
    if (!notificationOption) {
      notificationOption = new NotificationOption();
    }

    if (notificationOption.clear) {
      this.clearNotification();
    }

    switch (notificationOption.type) {
      case 'success':
        this.toastrService.success(notificationOption.message, notificationOption.title, notificationOption.toastrConfig);
        break;
      case 'error':
        this.toastrService.error(notificationOption.message, notificationOption.title, notificationOption.toastrConfig);
        break;
      case 'info':
        this.toastrService.info(notificationOption.message, notificationOption.title, notificationOption.toastrConfig);
        break;
      case 'warning':
        this.toastrService.warning(notificationOption.message, notificationOption.title, notificationOption.toastrConfig);
        break;
    }

  }

  clearNotification() {
    this.toastrService.clear();
  }
}

export class NotificationOption {
  title: string;
  message: string;
  type: string;
  clear: boolean;
  toastrConfig?: Partial<ToastrConfig>;
  constructor() {
    this.type = 'success';
    this.title = 'Notification';
    this.message = 'Data Saved Successfully';
    this.clear = true;
  }
}
