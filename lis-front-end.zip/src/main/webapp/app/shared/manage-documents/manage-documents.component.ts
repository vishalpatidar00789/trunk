import { Component, OnInit, Input, OnChanges, Output, EventEmitter, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { Table } from 'primeng/table';
import { TitleCasePipe, DatePipe } from '@angular/common';
import { ManageDocument } from './manage-documents.model';
import { ManageDocumentsService } from './manage-documents.service';
import { ConfirmationService } from 'primeng/api';
import { NotificationService, NotificationOption } from '../../shared/alert/notification.service';
import * as FileSaver from 'file-saver';
import { error } from 'util';
import { Document } from '../document-list/documents.model';
import { JhiEventManager } from 'ng-jhipster';

@Component({
    selector: 'manage-documents',
    templateUrl: './manage-documents.component.html',
    providers: [TitleCasePipe, DatePipe]
})
export class ManageDocumentsComponent implements OnInit, OnChanges {

    @Input() refAppId: string;
    @Input() documentType: string;
    @Input() isMarshUser: boolean;
    @Input() userid: string;
    @Input() collection: string;
    @Output() public afterUploadEvent = new EventEmitter();    

    cols: any[];
    public documentList: ManageDocument[];
    @ViewChild('manageDoc') manageDocTable: Table;

    constructor(private manageDocService: ManageDocumentsService,
        private confirmationService: ConfirmationService,
        private notificationService: NotificationService,
        private titlePipe: TitleCasePipe, private datePipe: DatePipe,
        private eventManager: JhiEventManager) {
    }

    ngOnInit() {
        this.getFiles();
        this.cols = [
            { field: 'documentType', header: 'Document Type' },
            { field: 'filename', header: 'Uploaded Document Name' },
            { field: 'uploadDate', header: 'Date Of Upload' },
            { field: 'uploadedBy', header: 'Uploaded By' }
        ];
        this.registerFileUpload();
    }

    registerFileUpload() {
        this.eventManager.subscribe('adverseInfoFileUploaded', (message) => {
            if(message.content){
                this.afterUpload(message.content);
            }
        });
    }

    ngOnChanges() {        
    }

    getFiles() {
        let payload = { docType: this.documentType, refAppId: this.refAppId };
        this.manageDocService.getDocumentsByDocTypeAndAppRefId(payload).subscribe(files => {
            if (files) {
                this.documentList = [];
                let file: ManageDocument;
                files.forEach(element => {
                    if (element) {
                        file = new ManageDocument();
                        file._id = element._id;
                        file.filename = element.metadata.fileName;
                        file.uploadDate = this.datePipe.transform(element.uploadDate, 'dd-MMM-yyyy,h:mm:ss a');
                        file.documentType = element.metadata.documentType;
                        file.uploadedBy = element.metadata.uploadedBy;
                        this.documentList.push(file);
                    }
                });                
                this.sort();
            }
        })
    }

    // delete(rowData: ManageDocument) {
    //     let fileId = rowData._id;
    //     if (fileId) {
    //         var r = confirm("Do you want to delete this document?");
    //         if (r == true) {
    //             this.manageDocService.deleteDocumentByFileId(fileId).subscribe(res => {
    //                 this.documentList.forEach((item, index) => {
    //                     if (item._id === fileId) {
    //                         this.documentList.splice(index, 1);
    //                         return;
    //                     }
    //                 });
    //             });
    //         } else {
    //         }
    //     }       
    // }   

    // download(rowData: Document) {
    //     let fileId = rowData._id;
    //     let filename = rowData.filename;
    //     if (fileId) {
    //         this.manageDocService.downloadDocumentByFileId(fileId).subscribe(
    //             data => {
    //                 FileSaver.saveAs(data, filename);
    //             },
    //             error => {
    //                 console.error(error);
    //             }
    //         );
    //     }
    // }

    afterUpload(uploadedFile: any) {
        let file: Document;
        file = new Document();
        file._id = uploadedFile._id;
        file.filename = uploadedFile.filename;
        file.uploadDate = this.datePipe.transform(new Date(), 'dd-MMM-yyy,h:mm:ss a');
        file.documentType = uploadedFile.metadata.documentType;
        file.uploadedBy = this.userid;
        this.documentList.push(file);
        this.afterUploadEvent.emit(uploadedFile);
        this.sort();       
    }

    sort(){
        this.documentList.sort(function (b, a) {                    
            //return new Date(a.uploadDate).getTime() - new Date(b.uploadDate).getTime();
            if (a.uploadDate < b.uploadDate) return -1;
            if (a.uploadDate > b.uploadDate) return 1;
            return 0;
        });
    }
}