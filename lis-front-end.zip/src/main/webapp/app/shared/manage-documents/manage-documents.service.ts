import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { SERVER_API_URL } from '../../app.constants';
import { FileData } from '../document-list/documents.model';

@Injectable()
export class ManageDocumentsService {
    private files: FileData [];
    private resourceUrl = SERVER_API_URL + 'supporting-documents/';
    constructor(private http: HttpClient) { }

    getDocumentsByDocTypeAndAppRefId(payload: any): Observable<FileData[]> {        
        return this.http.post<FileData[]>(this.resourceUrl+'document-by-id-and-docType',payload);
    }

    // deleteDocumentByFileId(fileId:string):Observable<string>{
    //     return this.http.delete<string>(this.resourceUrl+'delete-document/' + fileId);
    // }
    
    // downloadDocumentByFileId(fileId:string){
    //     return this.http.get(this.resourceUrl+'document-by-id/' + fileId,{
    //         responseType:"blob",
    //         headers:new HttpHeaders().append('Content-Type','application/json')
    //     });
    // } 
    
}