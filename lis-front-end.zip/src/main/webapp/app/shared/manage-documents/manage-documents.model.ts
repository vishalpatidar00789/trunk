export class ManageDocument {
    constructor(
        public _id?: string,
        public filename?: string,
        public uploadDate?: any,
        public documentType?: string,
        public uploadedBy?: string
    ) {
    }
}
