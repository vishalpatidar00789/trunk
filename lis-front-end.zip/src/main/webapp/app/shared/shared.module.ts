import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { FileUploadService } from './file-upload/file-upload.service';
import { NgbDateMomentParserFormatter } from './date-formatter/ngb-date-formatter';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import {
  LisAppSharedLibsModule,
  LisAppSharedCommonModule,
  CSRFService,
  AuthServerProvider,
  AccountService,
  UserService,
  StateStorageService,
  LoginService,
  LoginModalService,
  JhiLoginModalComponent,
  Principal,
  HasAnyAuthorityDirective,
  BankTypeVerificationDirective,
  LookupService,
  ForgotPasswordDialogComponent
} from './';
import { MasterdataService } from './masterdata/masterdata.service';
import { NotificationService } from './alert/notification.service';
import { ManageDocumentsComponent } from './manage-documents/manage-documents.component';
import { ManageDocumentsService } from './manage-documents/manage-documents.service';
import { DialogModule } from 'primeng/dialog';
import { TableModule } from 'primeng/table';
import { DocumentComponent } from './document-list/documents.component';
import { DocumentsService } from './document-list/documents.service';

@NgModule({
  imports: [
    LisAppSharedLibsModule,
    LisAppSharedCommonModule,
    DialogModule,
    TableModule
  ],
  declarations: [
    JhiLoginModalComponent,
    HasAnyAuthorityDirective,
    BankTypeVerificationDirective,
    FileUploadComponent,
    ManageDocumentsComponent,
    ForgotPasswordDialogComponent,
    DocumentComponent
  ],
  providers: [
    LoginService,
    LoginModalService,
    AccountService,
    StateStorageService,
    Principal,
    CSRFService,
    AuthServerProvider,
    UserService,
    DatePipe,
    LookupService,
    MasterdataService,
    FileUploadService,
    NotificationService,
    ManageDocumentsService,
    DocumentsService,
    {
      // provide: NgbDateParserFormatter,
      // useClass: NgbDateFRParserFormatter
      provide: NgbDateParserFormatter,
      useFactory: () => {
        return new NgbDateMomentParserFormatter('DD-MMM-YY');
      }
    }
  ],
  entryComponents: [JhiLoginModalComponent, FileUploadComponent],
  exports: [
    LisAppSharedCommonModule,
    JhiLoginModalComponent,
    HasAnyAuthorityDirective,
    BankTypeVerificationDirective,
    DatePipe,
    FileUploadComponent,
    ManageDocumentsComponent,
    ForgotPasswordDialogComponent,
    TableModule,
    DialogModule,
    DocumentComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class LisAppSharedModule {}
