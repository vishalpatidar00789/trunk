import { Component, OnInit, Input, EventEmitter } from '@angular/core';

@Component({
  selector: 'jhi-drop-down',
  templateUrl: './drop-down.component.html',
  styles: []
})
export class DropDownComponent implements OnInit {
  @Input() labelTxt: string;
  @Input() dataSource: any;
  @Input() selectedValue: string;
  @Input() showClear = true;
  @Input() readOnly: boolean;
  @Input() placeHolder = 'Please Select';
  @Input() selectedValueChange = new EventEmitter();
  @Input() width: string;
  constructor() {}

  ngOnInit() {}

  onSelectedValueChange(event) {
    this.selectedValueChange.emit(this.selectedValue);
  }
}
