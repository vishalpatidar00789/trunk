import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { UserModalService } from './user-modal.service';
import { User, UserService, LookupService, Principal, Account } from '../../shared';

@Component({
    selector: 'jhi-user-mgmt-dialog',
    templateUrl: './user-management-dialog.component.html'
})
export class UserMgmtDialogComponent implements OnInit {
    currentAdminRole: string;
    user: User;
    languages: any[];
    authorities: any[];
    isSaving: Boolean;
    banks: any[];
    currentAccount: Account;
    departments: any[];

    constructor(
        public activeModal: NgbActiveModal,
        private userService: UserService,
        private eventManager: JhiEventManager,
        private lookupService: LookupService,
        private principal: Principal,
    ) { }

    ngOnInit() {
        this.authorities = [];
        let query = 'INT';
        if (this.user && this.user.userType === 'INT') {
            query = 'INT';
        } else if (this.user && this.user.userType === 'EXT') {
            query = 'EXT';
        } else {
            this.user.userType = 'EXT';
            query = 'EXT';
        }
        this.principal.identity().then((account) => {
            this.currentAccount = account;
            // console.log('current logged in account:: ' + JSON.stringify(this.currentAccount));
            if (this.currentAccount.authorities.includes('PFI_ADMIN')) {
                this.currentAdminRole = 'PFI_ADMIN';
                this.user.bank = this.currentAccount.bank;
                query = 'EXT';
            } else if (this.currentAccount.authorities.includes('USER_ADMIN')) {
                // query = 'INT';
                this.currentAdminRole = 'USER_ADMIN';
            }
            this.lookupService.authorities(query).subscribe((authorities) => {
                if (authorities) {
                    // this.prepareAuthorities(authorities);
                    this.authorities = authorities;
                }
            });
        });
        this.isSaving = false;
        // this.authorities = [];
        this.lookupService.banks().subscribe((banks) => {
            this.banks = banks;
        });

        this.lookupService.departments().subscribe((departments) => {
            this.departments = departments;
        });
    }

    prepareAuthorities(authorities) {
        for (let i = 0; i < authorities.length; i++) {
            this.authorities.push({ label: authorities[i]['authority'], value: authorities[i]['authority'] });
        }
    }

    onSelectionChange() {
        let query = 'INT';
        this.user.bank = null;
        this.user.department = null;
        if (this.user.userType === 'INT') {
            query = 'INT';
        } else if (this.user.userType === 'EXT') {
            query = 'EXT';
        }
        this.lookupService.authorities(query).subscribe((authorities) => {
            if (authorities) {
                // this.prepareAuthorities(authorities);
                this.authorities = authorities;
            }
        });
    }

    clear() {
        this.activeModal.dismiss('cancel');
    }

    save() {
        this.isSaving = true;
        this.user.langKey = 'en';

        if (this.user.userType === 'EXT') {
            this.user.email = this.user.login;
        }
        if (this.user._id !== null) {
            this.user.lastModifiedBy = this.currentAccount.login;
            this.user.lastModifiedDate = null;
            delete this.user.createdBy;
            delete this.user.createdDate;
            delete this.user._id;
            this.userService.update(this.user).subscribe((response) => this.onSaveSuccess(response), () => this.onSaveError());
        } else {
            delete this.user._id;
            this.user.createdBy = this.currentAccount.login;
            this.userService.create(this.user).subscribe((response) => this.onSaveSuccess(response), () => this.onSaveError());
        }
    }

    private onSaveSuccess(result) {
        this.eventManager.broadcast({ name: 'userListModification', content: 'OK' });
        this.isSaving = false;
        this.activeModal.dismiss(result.body);
    }

    private onSaveError() {
        this.isSaving = false;
        this.activeModal.dismiss('cancel');
    }
}

@Component({
    selector: 'jhi-user-dialog',
    template: ''
})
export class UserDialogComponent implements OnInit, OnDestroy {

    routeSub: any;

    constructor(
        private route: ActivatedRoute,
        private userModalService: UserModalService
    ) { }

    ngOnInit() {
        this.routeSub = this.route.params.subscribe((params) => {
            if (params['login']) {
                this.userModalService.open(UserMgmtDialogComponent as Component, params['login']);
            } else {
                this.userModalService.open(UserMgmtDialogComponent as Component);
            }
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
