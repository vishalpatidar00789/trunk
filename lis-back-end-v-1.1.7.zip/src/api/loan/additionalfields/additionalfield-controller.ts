import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IAdditionalField } from "./additionalfield";
import { ILoan } from "../loan";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IaddFields, IRequest, ILoginRequest } from "../../../interfaces/request";

export default class AdditionalFieldController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }

  private generateToken(additionalfield: IAdditionalField, loan: ILoan) {
    const jwtSecret = this.configs.jwtSecret;
    const jwtExpiration = this.configs.jwtExpiration;
    const payload = { id: additionalfield._id };

    return Jwt.sign(payload, jwtSecret, { expiresIn: jwtExpiration });
  }


  public async createAdditionalField(request: IRequest, h: Hapi.ResponseToolkit) {

    console.log(request.payload);

    try {
      let additionalfield: any = await this.database.loanModel.create(request.payload);
      //return h.response(additionalfield).code(201);
      return h.response({ "_id": additionalfield._id }).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateAdditionalField(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;

    try {
      let loan: ILoan = await this.database.loanModel.findOneAndUpdate(
        id,
        { $set: request.payload },
        { new: true }
      );
      return loan;
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteAdditionalField(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.auth.credentials.id;
    let additionalfield: IAdditionalField = await this.database.additionalfieldModel.findByIdAndRemove(id);

    return additionalfield;
  }

  public async infoAdditionalField(request: IRequest, h: Hapi.ResponseToolkit) {
    let id = request.query["id"];
    let additionalfield: IAdditionalField = await this.database.additionalfieldModel.findById(id);
    return { "additionalfield": encodeURIComponent(request.params.id) };
  }
}
