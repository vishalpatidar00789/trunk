import * as Mongoose from "mongoose";
import * as Bcrypt from "bcryptjs";

export interface IAdditionalField extends Mongoose.Document {
  _id: string;
  pfi: string;
  marshReferenceNumber: string;
  borrowerName: string;
  applicationStatus: string;
  acraRefNo: string;
  typeoflimit: string;
  applicationDate: string;
  purposeofLoan: string;
  domesticPercent: number;
  exportPercent: number;
  loanType: string;
  totalAppliedLimit: string;
  foreignCurrencyRequestedLimits: string;
  foreignCurrencyType: string;
  foreignCurrencyExchangeRate: string;
  adverseInformation: string;
  additionalInformationforAdverseStatus: string;
  loanApplicationNumber: string;
  reportedMonth: string;
  grossSgdPremiumPrimary: number;
  grossSgdPremiumAuto: number;
  grossSgdPremiumBg: number;
  grossSgdPremiumLisPlus: number;
  natureofApplication: string;
  noOfApp: string;
  loAcceptanceDate: string;
  insurersApprovalDate: string;
  loanExpiryDateFromLoAcceptanceDate: string;
  approvedSgdLimitPrimaryLayer: number;
  approvedSgdLimitAutoTopup: number;
  approvedSgdLimitBgLayer: number;
  approvedForeignCurrencyLimitPrimaryLayer: number;
  approvedForeignCurrencyPrimaryLayerType: string;
  approvedForeignCurrencyPrimaryLayerExchangeRate: number;
  approvedForeignCurrencyLimitAutoTopup: number;
  approvedForeignCurrencyAutoTopupType: string;
  approvedForeignCurrencyAutoTopupExchangeRate: number;
  approvedForeignCurrencyLimitBgLayer: number;
  approvedForeignCurrencyBgLayerType: string;
  approvedForeignCurrencyBgLayerExchangeRate: number;
  dateSentForLisPlus: string;
  lisPlusApprovedDate: string;
  lisPlusApprovedLimit: number;
  approvedForeignCurrencyLimitLISPlusLayer: number;
  approvedForeignCurrencyLISPlusType: string;
  approvedForeignCurrencyLISPlusExchangeRate: number;
  typeOfLimitLisplus: string;
  lisTotalApprovedLimit: number;
  lisApprovalRatioPrecent: number;
  lisTurnAroundDays: number;
  totalApprovedLimitIncludingLisPlus: number;
  approvalRatioWithLisPlus: number;
  turnAroundWithLisPlus: number;
  utilization: string;
  internalRemarks: string;
}

export const AdditionalFieldSchema = new Mongoose.Schema(
  {

    _id: { type: String },
    pfi: { type: String },
    marshReferenceNumber: { type: String },
    borrowerName: { type: String },
    applicationStatus: { type: String },
    acraRefNo: { type: String },
    typeoflimit: { type: String },
    applicationDate: { type: String },
    purposeofLoan: { type: String },
    domesticPercent: { type: Number },
    exportPercent: { type: Number },
    loanType: { type: String },
    totalAppliedLimit: { type: String },
    foreignCurrencyRequestedLimits: { type: String },
    foreignCurrencyType: { type: String },
    foreignCurrencyExchangeRate: { type: String },
    adverseInformation: { type: String },
    additionalInformationforAdverseStatus: { type: String },
    loanApplicationNumber: { type: String },
    reportedMonth: { type: String },
    grossSgdPremiumPrimary: { type: Number },
    grossSgdPremiumAuto: { type: Number },
    grossSgdPremiumBg: { type: Number },
    grossSgdPremiumLisPlus: { type: Number },
    natureofApplication: { type: String },
    noOfApp: { type: String },
    loAcceptanceDate: { type: String },
    insurersApprovalDate: { type: String },
    loanExpiryDateFromLoAcceptanceDate: { type: String },
    approvedSgdLimitPrimaryLayer: { type: Number },
    approvedSgdLimitAutoTopup: { type: Number },
    approvedSgdLimitBgLayer: { type: Number },
    approvedForeignCurrencyLimitPrimaryLayer: { type: Number },
    approvedForeignCurrencyPrimaryLayerType: { type: String },
    approvedForeignCurrencyPrimaryLayerExchangeRate: { type: Number },
    approvedForeignCurrencyLimitAutoTopup: { type: Number },
    approvedForeignCurrencyAutoTopupType: { type: String },
    approvedForeignCurrencyAutoTopupExchangeRate: { type: Number },
    approvedForeignCurrencyLimitBgLayer: { type: Number },
    approvedForeignCurrencyBgLayerType: { type: String },
    approvedForeignCurrencyBgLayerExchangeRate: { type: Number },
    dateSentForLisPlus: { type: String },
    lisPlusApprovedDate: { type: String },
    lisPlusApprovedLimit: { type: Number },
    approvedForeignCurrencyLimitLISPlusLayer: { type: Number },
    approvedForeignCurrencyLISPlusType: { type: String },
    approvedForeignCurrencyLISPlusExchangeRate: { type: Number },
    typeOfLimitLisplus: { type: String },
    lisTotalApprovedLimit: { type: Number },
    lisApprovalRatioPrecent: { type: Number },
    lisTurnAroundDays: { type: Number },
    totalApprovedLimitIncludingLisPlus: { type: Number },
    approvalRatioWithLisPlus: { type: Number },
    turnAroundWithLisPlus: { type: Number },
    utilization: { type: String },
    internalRemarks: { type: String },



  },
  {
    timestamps: true
  }
);


export const AdditionalFieldModel = Mongoose.model<IAdditionalField>("AdditionalField", AdditionalFieldSchema);
