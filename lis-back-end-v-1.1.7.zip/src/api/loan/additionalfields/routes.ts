import * as Hapi from "hapi";
import * as Joi from "joi";
import AdditionalFieldController from "./additionalfield-controller";
import { AdditionalFieldModel } from "./additionalfield";
import * as AdditionalFieldValidator from "./additionalfield-validator";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import * as LoanValidator from "../loan-validator";


export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const additionalfieldController = new AdditionalFieldController(serverConfigs, database);
  server.bind(additionalfieldController);

  server.route({
    method: "GET",
    path: "/additionalfields/{id}",
    options: {
      handler: additionalfieldController.infoAdditionalField,
      auth: false,
      tags: ["api", "additionalfields"],
      description: "Get additionalfield info.",
      // validate: {
      //   headers: AdditionalFieldValidator.jwtValidator
      // },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "AdditionalField founded."
            },
            "401": {
              description: "Please login."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/additionalfields",
    options: {
      handler: additionalfieldController.deleteAdditionalField,
      auth: "jwt",
      tags: ["api", "additionalfields"],
      description: "Delete current additionalfield.",
      validate: {
        headers: AdditionalFieldValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "AdditionalField deleted."
            },
            "401": {
              description: "AdditionalField does not have authorization."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/additionalfields/{id}",
    options: {
      handler: additionalfieldController.updateAdditionalField,
      auth: false ,
      tags: ["api", "additionalfields"],
      description: "Update current additionalfield info.",
      validate: {
        payload:  LoanValidator.createLoanModel,
        headers: AdditionalFieldValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated info."
            },
            "401": {
              description: "AdditionalField does not have authorization."
            }
          }
        }
      }
    }
  });

  server.route({
    method:"POST",
    path: "/additionalfields",
    options: {
      handler: additionalfieldController.createAdditionalField,
      auth: false,
      tags: ["api", "additionalfields"],
      description: "Create a additionalfield.",
      validate: {
        payload:  LoanValidator.createLoanModel
        //headers: AdditionalFieldValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "AdditionalField created."
            }
          }
        }
      }
    }
  });

  // server.route({
  //   method: "POST",
  //   path: "/additionalfields/login",
  //   options: {
  //     handler: additionalfieldController.loginAdditionalField,
  //     auth: false,
  //     tags: ["api", "additionalfields"],
  //     description: "Login a additionalfield.",
  //     validate: {
  //       payload: AdditionalFieldValidator.loginAdditionalFieldModel
  //     },
  //     plugins: {
  //       "hapi-swagger": {
  //         responses: {
  //           "200": {
  //             description: "AdditionalField logged in."
  //           }
  //         }
  //       }
  //     }
  //   }
  // });
}
