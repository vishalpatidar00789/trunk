import * as Mongoose from "mongoose";
import * as Bcrypt from "bcryptjs";
import { IPFI, PFISchema } from "./pfi/pfi";
import { IUOB, UOBSchema } from "./uob/uob";

export interface ILoan extends Mongoose.Document {
  _id: string;
  marshRefNo: string;
  status: string;

  pfi: {
    _id: string;
    lisCoinsurer: string;
    pfiName: string;
    requestorName: string;
    aCRArefNo: string;
    borrowerRegName: string;
    totalReqLimit: number;
    preshipmentApprovalChkBx: boolean;
    exRate: number;
    foreignCurrencyAmount: number;
    primary: number;
    autoTopUp: number;
    bg: number;
    lisPlus: number;
    inventoryChkBx: boolean;
    workingCapChkBx: boolean;
    overseaseWorkingChkBx: boolean;
    bankersGuaranteeChkBx: boolean;
    tempIncreaseLimitChkBx: boolean;
    midTermIncreaseLimitChkBx: boolean;
    decreaseLimitChkBx: boolean;
    beforeMidTermIncreaseLimitChkBx: boolean;
    beforeDecreaseLimitChkBx: boolean;
    resourceFactoringChkBx: boolean;
    loanQuantumChkBx: boolean;
    operatongTrackChkBx: boolean;
    latestAuditedChkBx: boolean;
    auditedFinanceChkBx: boolean;
    applicationChkBx: boolean;
    bankersGuaranteeBChkBx: boolean;
    guaranteeAmountChkBx: boolean;
    guaranteeAmount2ChkBx: boolean;
    bankersGuaranteeB2ChkBx: boolean;
    principalChkBx: boolean;
    lisSponsersApplChkBx: boolean;
    companySearchesChkBx: boolean;
    pfiInternalCreditChkBx: boolean;
    latestSignedChkBx: boolean;
    additionalItemChkBx: boolean;
    forOverseasChkBx: boolean;
    inventoryTxt: number;
    structuredWorkingCapTxt: number;
    inventoryTradeTxt: number;
    resourceFactoringTxt: number;
    additionalItemTxt: string;
    beforeMidTermIncreaseLimitTxt: number;
    decreaseLimitTxt: number;
    beforeDecreaseLimitTxt: number;
    tempIncreaseLimitTxt: number;
    midTermIncreaseLimitTxt: number;
    bankersGuaranteeTxt: number;
    latestSignedDt: string;
    latestAuditedDt: string;
    latestAuditFinanceChkBx: boolean,
    foreignCurrency: string;
    documentUploadList: [{
      _id: boolean,
      preshipmentApprovalDoc: string,
      overseasCapitalDoc: string,
      sponserApplicationDoc: string,
      comapnySearchesDoc: string,
      pfiInternalCreditDoc: string,
      latestAuditedDoc: string,
      latestSignedDoc: string,
      additionalItemsDoc: string,
      overseaseDoc: string
    }],
    documentUploadList_Flag: [{
      _id: boolean,
      preshipmentApprovalDoc: boolean,
      overseasCapitalDoc: boolean,
      sponserApplicationDoc: boolean,
      comapnySearchesDoc: boolean,
      pfiInternalCreditDoc: boolean,
      latestAuditedDoc: boolean,
      latestSignedDoc: boolean,
      additionalItemsDoc: boolean,
      overseaseDoc: boolean
    }]

  };

  uob: {
    _id: string;
    uobPolicyNo: string;
    toLIS5Insurer: string;
    requesterName: string;
    submissionDate: string;
    borrowerRegName: string;
    discretiolaryLimitDL: boolean;
    creditLimitCL: boolean;
    borrowersCrr: number;
    crrRate: number;
    lisType: string;
    // newLIS: boolean;
    // renewalAtSameAmount: boolean;
    // renewalFrom: boolean;
    // increaseLimitTo: boolean;
    // decreaseLimitTo: boolean;
    inventoryStockChkBx: boolean;
    structuredWorkingCapitalChkBx: boolean;
    recourseFactoringBillChkBx: boolean;
    overseasWorkingCapitalChkBx: boolean;
    structuredWorkingCapTxt: number;
    bankersGuarantee: boolean;
    renewalToUSDTxt: number;
    renewalToSGDTxt: number;
    increaseLimitToSGD: number;
    increaseLimitToUSD: number;
    decreaseLimitToSGD: number;
    decreaseLimitToUSD: number;
    renewalFromSGDTxt: number;
    renewalFromUSDTxt: number;
    sgdCurrencyCurrentLIS: number;
    usdCurrencyCurrentLIS: number;
    lisSponsersApplChkBx: boolean;
    companySearchesChkBx: boolean;
    uobInternalCreditChkBx: boolean;
    latestAuditedChkBx: boolean;
    latestAuditedDt: string;
    latestSignedChkBx: boolean;
    latestSignedDt: string;
    additionalItemChkBx: boolean;
    additionalItemTxt: string;
    forOverseasChkBx: boolean;
    pfiInternalCreditChkBx: boolean;
    usdCurrency: number;
    sgdCurrency: number;
    currencyExchangeRate: number;
    usdCurrencyCurrent: number;
    sgdCurrencyCurrent: number;
    usdCurrencyCurrentLISP: number;
    sgdCurrencyCurrentLISP: number;
    bankersGuaranteeAmountChkBx: boolean;
    inventoryUSDTxt: number;
    inventorySGDTxt: number;
    withRecourseUSDTxt: number;
    withRecourseSGDTxt: number,
    structuredWorkingCapitalSGDTxt: number,
    overseaseCapitalSGDTxt: number,
    overseaseCapitalUSDTxt: number,
    bankersGuaranteeAmountSGDTxt: number,
    bankersGuaranteeAmountUSDTxt: number,
    rocRefNo: string,
    tenureMonths: number,
    foreignCurrency: string;
    documentUploadList: [{
      _id: boolean,
      overseasCapitalDoc: string,
      sponserApplicationDoc: string,
      comapnySearchesDoc: string,
      pfiInternalCreditDoc: string,
      latestAuditedDoc: string,
      latestSignedDoc: string,
      additionalItemsDoc: string
    }],
    documentUploadList_Flag: [{
      _id: boolean,
      overseasCapitalDoc: boolean,
      sponserApplicationDoc: boolean,
      comapnySearchesDoc: boolean,
      pfiInternalCreditDoc: boolean,
      latestAuditedDoc: boolean,
      latestSignedDoc: boolean,
      additionalItemsDoc: boolean
    }]

  };

  aFields: {
    _id: string;
    pfi: string;
    marshReferenceNumber: string;
    borrowerName: string;
    applicationStatus: string;
    acraRefNo: string;
    typeoflimit: string;
    applicationDate: string;
    purposeofLoan: string;
    domesticPercent: string;
    exportPercent: string;
    loanType: string;
    totalAppliedLimit: string;
    foreignCurrencyRequestedLimits: string;
    foreignCurrencyType: string;
    foreignCurrencyExchangeRate: string;
    adverseInformation: string;
    additionalInformationforAdverseStatus: string;
    loanApplicationNumber: string;
    reportedMonth: string;
    grossSgdPremiumPrimary: string;
    grossSgdPremiumAuto: string;
    grossSgdPremiumBg: string;
    grossSgdPremiumLisPlus: string;
    natureofApplication: string;
    noOfApp: string;
    loAcceptanceDate: string;
    insurersApprovalDate: string;
    loanExpiryDateFromLoAcceptanceDate: string;
    approvedSgdLimitPrimaryLayer: string;
    approvedSgdLimitAutoTopup: string;
    approvedSgdLimitBgLayer: string;
    approvedForeignCurrencyLimitPrimaryLayer: string;
    approvedForeignCurrencyPrimaryLayerType: string;
    approvedForeignCurrencyPrimaryLayerExchangeRate: string;
    approvedForeignCurrencyLimitAutoTopup: string;
    approvedForeignCurrencyAutoTopupType: string;
    approvedForeignCurrencyAutoTopupExchangeRate: string;
    approvedForeignCurrencyLimitBgLayer: string;
    approvedForeignCurrencyBgLayerType: string;
    approvedForeignCurrencyBgLayerExchangeRate: string;
    dateSentForLisPlus: string;
    lisPlusApprovedDate: string;
    lisPlusApprovedLimit: string;
    approvedForeignCurrencyLimitLISPlusLayer: string;
    approvedForeignCurrencyLISPlusType: string;
    approvedForeignCurrencyLISPlusExchangeRate: string;
    typeOfLimitLisplus: string;
    lisTotalApprovedLimit: string;
    lisApprovalRatioPrecent: string;
    lisTurnAroundDays: string;
    totalApprovedLimitIncludingLisPlus: string;
    approvalRatioWithLisPlus: string;
    turnAroundWithLisPlus: string;
    utilization: string;
    internalRemarks: string;
    approvedForeignCurrencyExchangeRate: string;

  };

  springeform: {
    _id: string;
    registeredCompanyName: string;
    uniqueEntityNumber: string;
    correspondenceAddress: string;
    contactPersonDesignation: string;
    phoneNumber: string;
    contactEmail: string;
    numberofStaff: number;
    dateofIncorporation: any;
    dateOfSingature: any;
    contactPersonNo: string;
    ACRANo: string;
    regComName: string;
    corrAddress1: string;
    corrAddress2: string;
    corrAddress3: string;
    contactPerson: string;
    contactPersonEmail: string;
    businessActivity: string;
    numStaff: string;
    dateOfIncorporation: string;
    appLFY: string;
    appSubLFY: string;
    appSales: number;
    appSubSales: number;
    appNetProfit: number;
    appNetProfitsubsidiaries: number;
    appSubNetProfit: number;
    //shareholdingSub: subsideries[];
    level: number;
    name: string;
    aCRA: string;
    type: string;
    country: string;
    share: number;
    parentUEN: string;
    turnover: number;
    noOfStaff: number;
    //subsidiaries: subsideries[];
    invStockFinancing: number;
    workingCapital: number;
    aRDiscount: number;
    capitalLoan: number;
    bankerGuarantee: number;
    total: number;
    loanDomesticTrade1: number;
    loanDomesticTrade2: number;
    invStockFinancingChecked: boolean;
    workingCapitalChecked: boolean;
    aRDiscountChecked: boolean;
    capitalLoanChecked: boolean;
    bankerGuaranteeChecked: boolean;
  };

}

export const LoanSchema = new Mongoose.Schema(
  {
    status: { type: String },
    marshRefNo: { type: String },

    springeform: {
      _id: { type: String },
      registeredCompanyName: { type: String },
      uniqueEntityNumber: { type: String },
      correspondenceAddress: { type: String },
      contactPersonDesignation: { type: String },
      phoneNumber: { type: String },
      contactEmail: { type: String },
      numberofStaff: { type: Number },
      dateofIncorporation: { type: String },
      dateOfSingature: { type: String },
      contactPersonNo: { type: String },
      ACRANo: { type: String },
      regComName: { type: String },
      corrAddress1: { type: String },
      corrAddress2: { type: String },
      corrAddress3: { type: String },
      contactPerson: { type: String },
      contactPersonEmail: { type: String },
      businessActivity: { type: String },
      numStaff: { type: String },
      dateOfIncorporation: { type: String },
      appLFY: { type: String },
      appSubLFY: { type: String },
      appSales: { type: Number },
      appSubSales: { type: Number },
      appNetProfit: { type: Number },
      appNetProfitsubsidiaries: { type: Number },
      appSubNetProfit: { type: Number },
      shareholdingSub: [{
        level: { type: String },
        name: { type: String },
        aCRA: { type: String },
        type: { type: String },
        country: { type: String },
        share: { type: String },
        parentUEN: { type: String },
        turnover: { type: String },
        noOfStaff: { type: String }
      }],
      level: { type: Number },
      name: { type: String },
      aCRA: { type: String },
      type: { type: String },
      country: { type: String },
      share: { type: Number },
      parentUEN: { type: String },
      turnover: { type: Number },
      noOfStaff: { type: Number },
      subsidiaries: { type: Array },
      invStockFinancing: { type: Number },
      workingCapital: { type: Number },
      aRDiscount: { type: Number },
      capitalLoan: { type: Number },
      bankerGuarantee: { type: Number },
      total: { type: Number },
      loanDomesticTrade1: { type: Number },
      loanDomesticTrade2: { type: Number },
      invStockFinancingChecked: { type: Boolean },
      workingCapitalChecked: { type: Boolean },
      aRDiscountChecked: { type: Boolean },
      capitalLoanChecked: { type: Boolean },
      bankerGuaranteeChecked: { type: Boolean }
    },

    pfi: {
      _id: { type: String },
      lisCoinsurer: { type: String },
      pfiName: { type: String },
      requestorName: { type: String },
      aCRArefNo: { type: String },
      borrowerRegName: { type: String },
      submissionDate: { type: String },
      totalRequstedLimitSGD: { type: Number },
      preshipmentApprovalChkBx: { type: Boolean },
      exRate: { type: Number },
      foreignCurrencyAmount: { type: Number },
      primary: { type: Number },
      autoTopUp: { type: Number },
      bg: { type: Number },
      lisPlus: { type: Number },
      inventoryChkBx: { type: Boolean },
      workingCapChkBx: { type: Boolean },
      overseaseWorkingChkBx: { type: Boolean },
      bankersGuaranteeChkBx: { type: Boolean },
      tempIncreaseLimitChkBx: { type: Boolean },
      midTermIncreaseLimitChkBx: { type: Boolean },
      decreaseLimitChkBx: { type: Boolean },
      beforeMidTermIncreaseLimitChkBx: { type: Boolean },
      beforeDecreaseLimitChkBx: { type: Boolean },
      resourceFactoringChkBx: { type: Boolean },
      loanQuantumChkBx: { type: Boolean },
      operatongTrackChkBx: { type: Boolean },
      latestAuditedChkBx: { type: Boolean },
      auditedFinanceChkBx: { type: Boolean },
      applicationChkBx: { type: Boolean },
      bankersGuaranteeBChkBx: { type: Boolean },
      guaranteeAmountChkBx: { type: Boolean },
      guaranteeAmount2ChkBx: { type: Boolean },
      bankersGuaranteeB2ChkBx: { type: Boolean },
      principalChkBx: { type: Boolean },
      lisSponsersApplChkBx: { type: Boolean },
      companySearchesChkBx: { type: Boolean },
      pfiInternalCreditChkBx: { type: Boolean },
      inventoryTradeChkBx: { type: Boolean },
      latestSignedChkBx: { type: Boolean },
      additionalItemChkBx: { type: Boolean },
      forOverseasChkBx: { type: Boolean },
      inventoryTxt: { type: Number },
      overseaseWorkingTxt: { type: Number },
      tempIncreaseLimitTxt: { type: Number },
      inventoryTradeTxt: { type: Number },
      resourceFactoringTxt: { type: Number },
      additionalItemTxt: { type: String },
      beforeMidTermIncreaseLimitTxt: { type: Number },
      structuredWorkingCapTxt: { type: Number },
      decreaseLimitTxt: { type: Number },
      beforeDecreaseLimitTxt: { type: Number },
      midTermIncreaseLimitTxt: { type: Number },
      bankersGuaranteeTxt: { type: Number },
      latestSignedDt: { type: String },
      latestAuditedDt: { type: String },
      latestAuditFinanceChkBx: { type: Boolean },
      foreignCurrency: { type: String },
      borrowersGroup: [{
        _id: false,
        name: { type: String }
      }],
      documentUploadList: [{
        _id: false,
        preshipmentApprovalDoc: { type: String },
        overseasCapitalDoc: { type: String },
        sponserApplicationDoc: { type: String },
        comapnySearchesDoc: { type: String },
        pfiInternalCreditDoc: { type: String },
        latestAuditedDoc: { type: String },
        latestSignedDoc: { type: String },
        additionalItemsDoc: { type: String },
        overseaseDoc: { type: String }
      }],
      documentUploadList_Flag: [{
        _id: false,
        preshipmentApprovalDoc: { type: Boolean },
        overseasCapitalDoc: { type: Boolean },
        sponserApplicationDoc: { type: Boolean },
        comapnySearchesDoc: { type: Boolean },
        pfiInternalCreditDoc: { type: Boolean },
        latestAuditedDoc: { type: Boolean },
        latestSignedDoc: { type: Boolean },
        additionalItemsDoc: { type: Boolean },
        overseaseDoc: { type: Boolean },
      }]
    },

    uob: {
      _id: { type: String },
      uobPolicyNo: { type: String },
      toLIS5Insurer: { type: String },
      requesterName: { type: String },
      borrowerRegName: { type: String },
      submissionDate: { type: String },
      discretiolaryLimitDL: { type: Boolean },
      creditLimitCL: { type: Boolean },
      borrowersCrr: { type: Number },
      crrRate: { type: Number },
      lisType: { type: String },
      // newLIS: { type: Boolean },
      // renewalAtSameAmount: { type: Boolean },
      // renewalFrom: { type: Boolean },
      // increaseLimitTo: { type: Boolean },
      // decreaseLimitTo: { type: Boolean },
      inventoryStockChkBx: { type: Boolean },
      structuredWorkingCapitalChkBx: { type: Boolean },
      recourseFactoringBillChkBx: { type: Boolean },
      overseasWorkingCapitalChkBx: { type: Boolean },
      bankersGuarantee: { type: Boolean },
      foreignCurrency: { type: String },
      borrowersGroup: [{
        _id: false,
        name: { type: String },
        limit: { type: Number }
      }],
      inventoryUSDTxt: { type: Number },
      inventorySGDTxt: { type: Number },
      withRecourseUSDTxt: { type: Number },
      withRecourseSGDTxt: { type: Number },
      structuredWorkingCapitalUSDTxt: { type: Number },
      structuredWorkingCapitalSGDTxt: { type: Number },
      overseaseCapitalSGDTxt: { type: Number },
      overseaseCapitalUSDTxt: { type: Number },
      bankersGuaranteeAmountSGDTxt: { type: Number },
      bankersGuaranteeAmountUSDTxt: { type: Number },
      increaseLimitToSGD: { type: Number },
      increaseLimitToUSD: { type: Number },
      decreaseLimitToSGD: { type: Number },
      decreaseLimitToUSD: { type: Number },
      renewalFromSGDTxt: { type: Number },
      renewalFromUSDTxt: { type: Number },
      renewalToUSDTxt: { type: Number },
      renewalToSGDTxt: { type: Number },
      sgdCurrencyCurrentLIS: { type: Number },
      usdCurrencyCurrentLIS: { type: Number },
      lisSponsersApplChkBx: { type: Boolean },
      companySearchesChkBx: { type: Boolean },
      uobInternalCreditChkBx: { type: Boolean },
      latestAuditedChkBx: { type: Boolean },
      latestAuditedDt: { type: String },
      latestSignedChkBx: { type: Boolean },
      latestSignedDt: { type: String },
      additionalItemChkBx: { type: Boolean },
      additionalItemTxt: { type: String },
      forOverseasChkBx: { type: Boolean },
      pfiInternalCreditChkBx: { type: Boolean },
      usdCurrency: { type: Number },
      sgdCurrency: { type: Number },
      currencyExchangeRate: { type: Number },
      usdCurrencyCurrent: { type: Number },
      sgdCurrencyCurrent: { type: Number },
      usdCurrencyCurrentLISP: { type: Number },
      sgdCurrencyCurrentLISP: { type: Number },
      bankersGuaranteeAmountChkBx: { type: Boolean },
      rocRefNo: { type: String },
      tenureMonths: { type: Number },
      documentUploadList: [{
        _id: false,
        overseasCapitalDoc: { type: String },
        sponserApplicationDoc: { type: String },
        comapnySearchesDoc: { type: String },
        pfiInternalCreditDoc: { type: String },
        latestAuditedDoc: { type: String },
        latestSignedDoc: { type: String },
        additionalItemsDoc: { type: String }
      }],
      documentUploadList_Flag: [{
        _id: false,
        overseasCapitalDoc: { type: Boolean },
        sponserApplicationDoc: { type: Boolean },
        comapnySearchesDoc: { type: Boolean },
        pfiInternalCreditDoc: { type: Boolean },
        latestAuditedDoc: { type: Boolean },
        latestSignedDoc: { type: Boolean },
        additionalItemsDoc: { type: Boolean }
      }]
    },

    aFields: {
      _id: { type: String },
      pfi: { type: String },
      marshReferenceNumber: { type: String },
      borrowerName: { type: String },
      applicationStatus: { type: String },
      acraRefNo: { type: String },
      typeoflimit: { type: String },
      applicationDate: { type: String },
      purposeofLoan: { type: String },
      domesticPercent: { type: String },
      exportPercent: { type: String },
      loanType: { type: String },
      totalAppliedLimit: { type: String },
      foreignCurrencyRequestedLimits: { type: String },
      foreignCurrencyType: { type: String },
      foreignCurrencyExchangeRate: { type: String },
      adverseInformation: { type: String },
      additionalInformationforAdverseStatus: { type: String },
      loanApplicationNumber: { type: String },
      reportedMonth: { type: String },
      grossSgdPremiumPrimary: { type: String },
      grossSgdPremiumAuto: { type: String },
      grossSgdPremiumBg: { type: String },
      grossSgdPremiumLisPlus: { type: String },
      natureofApplication: { type: String },
      noOfApp: { type: String },
      loAcceptanceDate: { type: String },
      insurersApprovalDate: { type: String },
      loanExpiryDateFromLoAcceptanceDate: { type: String },
      approvedSgdLimitPrimaryLayer: { type: String },
      approvedSgdLimitAutoTopup: { type: String },
      approvedSgdLimitBgLayer: { type: String },
      approvedForeignCurrencyLimitPrimaryLayer: { type: String },
      approvedForeignCurrencyPrimaryLayerType: { type: String },
      approvedForeignCurrencyPrimaryLayerExchangeRate: { type: String },
      approvedForeignCurrencyLimitAutoTopup: { type: String },
      approvedForeignCurrencyAutoTopupType: { type: String },
      approvedForeignCurrencyAutoTopupExchangeRate: { type: String },
      approvedForeignCurrencyLimitBgLayer: { type: String },
      approvedForeignCurrencyBgLayerType: { type: String },
      approvedForeignCurrencyBgLayerExchangeRate: { type: String },
      dateSentForLisPlus: { type: String },
      lisPlusApprovedDate: { type: String },
      lisPlusApprovedLimit: { type: String },
      approvedForeignCurrencyLimitLISPlusLayer: { type: String },
      approvedForeignCurrencyLISPlusType: { type: String },
      approvedForeignCurrencyLISPlusExchangeRate: { type: String },
      typeOfLimitLisplus: { type: String },
      lisTotalApprovedLimit: { type: String },
      lisApprovalRatioPrecent: { type: String },
      lisTurnAroundDays: { type: String },
      totalApprovedLimitIncludingLisPlus: { type: String },
      approvalRatioWithLisPlus: { type: String },
      turnAroundWithLisPlus: { type: String },
      utilization: { type: String },
      internalRemarks: { type: String },
      approvedForeignCurrencyExchangeRate: { type: String }
    }
  },
  {
    timestamps: true
  }
);

function hashPassword(password: string): string {
  if (!password) {
    return null;
  }

  return Bcrypt.hashSync(password, Bcrypt.genSaltSync(8));
}
LoanSchema.pre("save", function (next) {
  const test = this;

  console.log("inside pre");
  return next();
});
export const LoanModel = Mongoose.model<ILoan>("loan", LoanSchema);