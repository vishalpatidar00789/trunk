import * as Hapi from "hapi";
import * as Joi from "joi";
import PFIController from "./pfi-controller";
import { PFIModel } from "./pfi";
import * as PFIValidator from "./pfi-validator";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { LoanModel } from "../loan";
import * as LoanValidator from "../loan-validator";

export default function(
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const pfiController = new PFIController(serverConfigs, database);
  server.bind(pfiController);

  server.route({
    method: "GET",
    path: "/PFI-Form/info",
    options: {
      handler: pfiController.infoPFI,
      //auth: "jwt",
      tags: ["api", "pfi"],
      description: "Get PFI info.",
      validate: {
        headers: PFIValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "PFI founded."
            },
            "401": {
              description: "Please login."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/PFI-Form",
    options: {
      handler: pfiController.deletePFI,
      //auth: "jwt",
      tags: ["api", "pfi"],
      description: "Delete current PFI.",
      validate: {
        headers: PFIValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "PFI deleted."
            },
            "401": {
              description: "User does not have authorization."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/PFI-Form/{id}",
    options: {
      handler: pfiController.updatePFI,
     // auth: "jwt",
      tags: ["api", "pfi"],
      description: "Update current user info.",
      validate: {
        payload:  LoanValidator.createLoanModel
        //headers: PFIValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated PFI info."
            },
            "401": {
              description: "User does not have authorization."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/PFI-Form",
    options: {
      handler: pfiController.createPFI,
      auth: false,
      tags: ["api", "pfi"],
      description: "Create a PFI.",
      validate: {
         payload: LoanValidator.createLoanModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "PFI created."
            }
          }
        }
      }
    }
  });


}
