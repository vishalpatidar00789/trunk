import * as Mongoose from "mongoose";
import * as Bcrypt from "bcryptjs";

export interface IPFI extends Mongoose.Document {
  pfi: {
    _id: string;
    lisCoinsurer: string;
    pfiName: string;
    requestorName: string;
    submissionDate: Date;
    aCRArefNo: string;
    regName: string;
    totalReqLimit: number;
    preshipmentApprovalChkBx: boolean;
    exRate: number;
    foreignCurrency: number;
    primary: number;
    autoTopUp: number;
    bg: number;
    lisPlus: number;
    inventoryChkBx: boolean;
    workingCapChkBx: boolean;
    factoringChkBx: boolean;
    overseaseWorkingChkBx: boolean;
    bankersGuaranteeChkBx: boolean;
    tempIncreaseLimitChkBx: boolean;
    midTermIncreaseLimitChkBx: boolean;
    decreaseLimitChkBx: boolean;
    beforeMidTermIncreaseLimitChkBx: boolean;
    beforeDecreaseLimitChkBx: boolean;
    resourceFactoringChkBx: boolean;
    loanQuantumChkBx: boolean;
    operatongTrackChkBx: boolean;
    latestAuditedChkBx: boolean;
    auditedFinanceChkBx: boolean;
    applicationChkBx: boolean;
    bankersGuaranteeBChkBx: boolean;
    guaranteeAmountChkBx: boolean;
    guaranteeAmount2ChkBx: boolean;
    bankersGuaranteeB2ChkBx: boolean;
    principalChkBx: boolean;
    lisSponsersApplChkBx: boolean;
    companySearchesChkBx: boolean;
    pfiInternalCreditChkBx: boolean;
    latestSignedChkBx: boolean;
    additionalItemChkBx: boolean;
    forOverseasChkBx: boolean;
    inventoryTxt: string;
    workingCapTxt: string;
    inventoryTradeTxt: string;
    resourceFactoringTxt: string;
    additionalItemTxt: string;
    beforeMidTermIncreaseLimitTxt: string;
    decreaseLimitTxt: string;
    beforeDecreaseLimitTxt: string;
    borrowersGroup1Txt: string;
    borrowersGroup2Txt: string;
    tempIncreaseLimitChkBxTxt: string;
    midTermIncreaseLimitTxt: string;
    bankersGuaranteeTxt: string;
    latestSignedDt: Date;
    latestAuditedDt: Date;
    borrowersGroup: [String];
  };
}

export const PFISchema = new Mongoose.Schema(
  {
    pfi: {
      _id: { type: String },
      lisCoinsurer: { type: String },
      pfiName: { type: String },
      requestorName: { type: String },
      submissionDate: { type: Date },
      aCRArefNo: { type: String },
      regName: { type: String },
      totalReqLimit: { type: Number },
      preshipmentApprovalChkBx: { type: Boolean },
      exRate: { type: Number },
      foreignCurrency: { type: Number },
      primary: { type: Number },
      autoTopUp: { type: Number },
      bg: { type: Number },
      lisPlus: { type: Number },
      inventoryChkBx: { type: Boolean },
      workingCapChkBx: { type: Boolean },
      overseaseWorkingChkBx: { type: Boolean },
      bankersGuaranteeChkBx: { type: Boolean },
      tempIncreaseLimitChkBx: { type: Boolean },
      midTermIncreaseLimitChkBx: { type: Boolean },
      decreaseLimitChkBx: { type: Boolean },
      beforeMidTermIncreaseLimitChkBx: { type: Boolean },
      beforeDecreaseLimitChkBx: { type: Boolean },
      resourceFactoringChkBx: { type: Boolean },
      loanQuantumChkBx: { type: Boolean },
      operatongTrackChkBx: { type: Boolean },
      latestAuditedChkBx: { type: Boolean },
      auditedFinanceChkBx: { type: Boolean },
      applicationChkBx: { type: Boolean },
      bankersGuaranteeBChkBx: { type: Boolean },
      guaranteeAmountChkBx: { type: Boolean },
      guaranteeAmount2ChkBx: { type: Boolean },
      bankersGuaranteeB2ChkBx: { type: Boolean },
      principalChkBx: { type: Boolean },
      lisSponsersApplChkBx: { type: Boolean },
      companySearchesChkBx: { type: Boolean },
      pfiInternalCreditChkBx: { type: Boolean },
      latestSignedChkBx: { type: Boolean },
      additionalItemChkBx: { type: Boolean },
      forOverseasChkBx: { type: Boolean },
      inventoryTxt: { type: String },
      workingCapTxt: { type: String },
      inventoryTradeTxt: { type: String },
      resourceFactoringTxt: { type: String },
      additionalItemTxt: { type: String },
      beforeMidTermIncreaseLimitTxt: { type: String },
      decreaseLimitTxt: { type: String },
      beforeDecreaseLimitTxt: { type: String },
      borrowersGroup1Txt: { type: String },
      borrowersGroup2Txt: { type: String },
      tempIncreaseLimitChkBxTxt: { type: String },
      midTermIncreaseLimitTxt: { type: String },
      bankersGuaranteeTxt: { type: String },
      latestSignedDt: { type: Date },
      latestAuditedDt: { type: Date },
      borrowersGroup: [String],
    }
  },
  {
    timestamps: true
  }
);

function hashPassword(password: string): string {
  if (!password) {
    return null;
  }

  return Bcrypt.hashSync(password, Bcrypt.genSaltSync(8));
}


PFISchema.pre("save", function (next) {
  const test = this;

  console.log("inside pre");
  return next();
});

export const PFIModel = Mongoose.model<IPFI>("PFI", PFISchema);
