import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { ILoan } from "./loan";
import { IDatabase } from "../../database";
import { IServerConfigurations } from "../../configurations";
import { IRequest, ILoginRequest } from "../../interfaces/request";

let seqNo: number = 0;
let txSeqNum: string;
let transNo: number = 0;
let txTransNo: string;

export default class LoanController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }

  public async createLoan(request: IRequest, h: Hapi.ResponseToolkit) {
    try {

      let requestPayload: any = request["payload"];
      let marshRefNo = await this.generateMarshNumber('DBS');
      requestPayload["marshRefNo"] = marshRefNo;
      console.log('*****' + marshRefNo + '*****');

      let loan: any = await this.database.loanModel.create(requestPayload);
      return h.response({ "_id": loan._id, "marshRefNo": marshRefNo }).code(201); //, "marshRefNo": marshRefNo
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  private generateMarshNumber(bankCode) {

    seqNo = seqNo++;
    transNo = transNo++;
    let trancheNo = '05';
    let seqNoPrefix = "";

    if (seqNo.toString().length === 1) {
      seqNoPrefix = "0000";
    } else if (seqNo.toString().length === 2) {
      seqNoPrefix = "000";
    } else if (seqNo.toString().length === 3) {
      seqNoPrefix = "00";
    } else if (seqNo.toString().length === 4) {
      seqNoPrefix = "0";
    }
    txSeqNum = seqNoPrefix + seqNo.toString();

    let transNoPrefix = "";
    if (seqNo.toString().length === 1) {
      transNoPrefix = "0";
    }
    txTransNo = transNoPrefix + transNo.toString();

    const txDate: Date = new Date();

    let date = txDate.getDate();
    let month: number = txDate.getMonth() + 1;
    let year = txDate.getFullYear().toString();
    console.log('## date::' + date + '#' + month + '#' + year);

    let marshRefNumber: string = 'LO' + trancheNo + bankCode + date + month + year + txSeqNum + '/' + txTransNo;
    console.log('MarshRefNo::' + marshRefNumber);

    return marshRefNumber;

  }

  public async updateLoan(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params["id"];
    try {
      let requestPayload: any = request["payload"];
      let marshRefNo = await this.generateMarshNumber('DBS');
      requestPayload["marshRefNo"] = marshRefNo;
      console.log('######' + marshRefNo + '######');

      let loan: ILoan = await this.database.loanModel.findByIdAndUpdate(
        { _id: id },
        { $set: requestPayload },
        { new: true }
      );
      return loan;
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteLoan(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.auth.credentials.id;
    let loan: ILoan = await this.database.loanModel.findByIdAndRemove(id);

    return loan;
  }

  public async infoLoan(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.auth.credentials.id;
    let loan: ILoan = await this.database.loanModel.findById(id);

    return loan;
  }
}
