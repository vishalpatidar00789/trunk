import * as Mongoose from "mongoose";
import * as Bcrypt from "bcryptjs";

export interface IUOB extends Mongoose.Document {
  uob: {
    _id: string;
    toLIS5Insurer: string;
    requesterName: string;
    //submissionDate: Date;
    discretiolaryLimitDL: boolean;
    creditLimitCL: boolean;
    crrRate: number;
    forBorrowerGroup: boolean;
    nameOfEntity: string;
    newLIS: boolean;
    renewalAtSameAmount: boolean;
    renewalFromSGD: boolean;
    increaseLimitTo: boolean;
    decreaseLimitTo: boolean;
    inventoryStockFinancing: boolean;
    structuredPredeliveryWorkingCapital: boolean;
    withRecourseFactoringBill: boolean;
    overseasWorkingCapitalLoansSupport: boolean;
    bankersGuarantee: boolean;
    renewalFromUSD: boolean;
  };
  /* toLIS5Insurer: string;
   requesterName: string;
   submissionDate: Date;
   discretiolaryLimitDL: boolean;
   creditLimitCL: boolean;
   crrRate:number;
   forBorrowerGroup: boolean;
   nameOfEntity: string;
   currentFacilityLimitAmount: number;
   nameOfEntity2: string;
   currentFacilityLimitAmount2: number;
   newLIS: boolean;
   renewalAtSameAmount: boolean;
   renewalFromSGD: boolean;
   renewalFromUSD: boolean;
   increaseLimitTo: boolean;
   decreaseLimitTo: boolean;
   inventoryStockFinancing: boolean;
   structuredPredeliveryWorkingCapital: boolean;
   withRecourseFactoringBill: boolean;
   overseasWorkingCapitalLoansSupport: boolean;
   bankersGuarantee: boolean;
   increaseLimitToSGD:number;
   increaseLimitToUSD:number;
   decreaseLimitToSGD:number;
   decreaseLimitToUSD:number;
   renewalFromSGDTxt:number;
   renewalFromUSDTxt:number;
   sgdCurrencyCurrentLIS:number;
   usdCurrencyCurrentLIS:number;
   lisSponsersApplChkBx: boolean;
   companySearchesChkBx: boolean;
   uobInternalCreditChkBx: boolean;
   latestAuditedChkBx: boolean;
   latestAuditedDt:Date;
   latestSignedChkBx: boolean;
   latestSignedDt:Date;
   additionalItemChkBx: boolean;
   additionalItemTxt:string;
   forOverseasChkBx: boolean;
   pfiInternalCreditChkBx:boolean;
   borrowersGroup:Date; */
}
export const UOBSchema = new Mongoose.Schema(
  {
    uob: {
      _id: { type: String },
      toLIS5Insurer: { type: String },
      requesterName: { type: String },
      //submissionDate: { type: Date},
      discretiolaryLimitDL: { type: Boolean },
      creditLimitCL: { type: Boolean },
      crrRate: { type: Number },
      forBorrowerGroup: { type: Boolean },
      nameOfEntity: { type: String },
      newLIS: { type: Boolean },
      renewalAtSameAmount: { type: Boolean },
      renewalFromSGD: { type: Boolean },
      increaseLimitTo: { type: Boolean },
      decreaseLimitTo: { type: Boolean },
      inventoryStockFinancing: { type: Boolean },
      structuredPredeliveryWorkingCapital: { type: Boolean },
      withRecourseFactoringBill: { type: Boolean },
      overseasWorkingCapitalLoansSupport: { type: Boolean },
      bankersGuarantee: { type: Boolean },
      renewalFromUSD: { type: Boolean },
    },
    /* toLIS5Insurer: { type: String },
      requesterName: { type: String },
      submissionDate: { type: Date},
      discretiolaryLimitDL: { type:Boolean},
      creditLimitCL: { type: Boolean},
      crrRate:{ type: Number},
      forBorrowerGroup: { type: Boolean},
      nameOfEntity: { type: String },
      currentFacilityLimitAmount: { type: Number},
      nameOfEntity2: { type: String },
      currentFacilityLimitAmount2: { type: Number},
      newLIS: { type: Boolean},
      renewalAtSameAmount: { type: Boolean},
      renewalFromSGD: { type: Boolean},
      renewalFromUSD: { type: Boolean},
      increaseLimitTo: { type: Boolean},
      decreaseLimitTo: { type: Boolean},
      inventoryStockFinancing: { type: Boolean},
      structuredPredeliveryWorkingCapital: { type: Boolean},
      withRecourseFactoringBill: { type: Boolean},
      overseasWorkingCapitalLoansSupport: { type: Boolean},
      bankersGuarantee: { type: Boolean},
      increaseLimitToSGD:{ type: Number},
      increaseLimitToUSD:{ type: Number},
      decreaseLimitToSGD:{ type: Number},
      decreaseLimitToUSD:{ type: Number},
      renewalFromSGDTxt:{ type: Number},
      renewalFromUSDTxt:{ type: Number},
      sgdCurrencyCurrentLIS:{ type: Number},
      usdCurrencyCurrentLIS:{ type: Number},
      lisSponsersApplChkBx: { type: Boolean},
      companySearchesChkBx: { type: Boolean},
      uobInternalCreditChkBx: { type: Boolean},
      latestAuditedChkBx: { type: Boolean},
      latestAuditedDt:{ type: Date},
      latestSignedChkBx: { type: Boolean},
      latestSignedDt:{ type: Date},
      additionalItemChkBx: { type: Boolean},
      additionalItemTxt:{ type: String },
      forOverseasChkBx: { type: Boolean},
      pfiInternalCreditChkBx:{ type: Boolean},
      borrowersGroup:{ type: Date},*/
  },
  {
    timestamps: true
  }
);

function hashPassword(password: string): string {
  if (!password) {
    return null;
  }

  return Bcrypt.hashSync(password, Bcrypt.genSaltSync(8));
}


UOBSchema.pre("save", function (next) {
  const test = this;

  console.log("inside pre");
  return next();
});

export const UOBModel = Mongoose.model<IUOB>("UOB", UOBSchema);
