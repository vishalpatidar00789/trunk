import * as Hapi from "hapi";
import * as Joi from "joi";
import UOBController from "./uob-controller";
import { UOBModel } from "./uob";
import * as UOBValidator from "./uob-validator";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { LoanModel } from "../loan";
import * as LoanValidator from "../loan-validator";

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const uobController = new UOBController(serverConfigs, database);
  server.bind(uobController);

  server.route({
    method: "GET",
    path: "/UOB-Form/info",
    options: {
      handler: uobController.infoUOB,
      //auth: "jwt",
      tags: ["api", "uob"],
      description: "Get UOB info.",
      validate: {
        headers: UOBValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "UOB founded."
            },
            "401": {
              description: "Please login."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/UOB-Form",
    options: {
      handler: uobController.deleteUOB,
      //auth: "jwt",
      tags: ["api", "uob"],
      description: "Delete current UOB.",
      validate: {
        headers: UOBValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "UOB deleted."
            },
            "401": {
              description: "User does not have authorization."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/UOB-Form/{_id}",
    options: {
      handler: uobController.updateUOB,
       auth: false,
      tags: ["api", "uob"],
      description: "Update current user info.",
      validate: {
        payload: LoanValidator.createLoanModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated UOB info."
            },
            "401": {
              description: "User does not have authorization."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/UOB-Form",
    options: {
      handler: uobController.createUOB,
      auth: false,
      tags: ["api", "uob"],
      description: "Create a UOB.",
      validate: {
        payload: LoanValidator.createLoanModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "UOB created."
            }
          }
        }
      }
    }
  });


}
