import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IDatabase } from "../../database";
import { IServerConfigurations } from "../../configurations";
import { IRequest } from "../../interfaces/request";
import * as Path from "path";
import * as fs from "fs";
//import * as Gridfs from "gridfs-stream";
import * as Configs from "../../configurations";

var mongoose = require('mongoose');
var Gridfs = require('gridfs-stream');
const dbConfigs = Configs.getDatabaseConfig();

let conn = mongoose.connection;
Gridfs.mongo = mongoose.mongo;
let gfs;

conn.once("open", () => {
  gfs = Gridfs(conn.db);
});
var dbURI = process.env.DB_LINK || dbConfigs.connectionString;

mongoose.connect(dbURI)
  .then(() => {
    console.log(`[*] Connected to Database`);
  })
  .catch(err => {
    console.log(`[*] Error while connecting to DB, with error: ${err}`);
  });

export default class FileUploadController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  constructor(configs: IServerConfigurations, database: IDatabase) {
    // this.database = database;
    // this.configs = configs;
  }
  public async upload(request, h: Hapi.ResponseToolkit) {
    var file = [request.payload["uploads"]];
    let writeStream = gfs.createWriteStream({
      filename: 'file_' + file[0].hapi.filename,
      mode: 'w',
      content_type: file[0].hapi.headers.content_type
    });
    let result = writeStream.write(file[0]._data);
    console.log(result);
    writeStream.end();
    return { 'message': "success" };
  }
}