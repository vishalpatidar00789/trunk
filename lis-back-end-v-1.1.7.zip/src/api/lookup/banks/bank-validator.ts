import * as Joi from "joi";

export const createBankModel = Joi.object().keys({
    bankCode: Joi.string().trim().required(),
    bankName: Joi.string().required(),
    createdBy: Joi.string().required(),
    activated: Joi.boolean().optional(),
    createdDate: Joi.any().allow(null).optional(),
    lastModifiedBy: Joi.any().allow(null).optional(),
    lastModifiedDate: Joi.any().allow(null).optional()
});

export const jwtValidator = Joi.object({'authorization': Joi.string().required()}).unknown();