import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IDepartment } from "./department";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest } from "../../../interfaces/request";
export default class DepartmentController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }

  public async getAllDepartments(request: IRequest, h: Hapi.ResponseToolkit) {
    let departments: IDepartment[] = await this.database.departmentModel.find({ activated: true }).lean(true);
    if (departments) {
      return departments;
    } else {
      return Boom.notFound();
    }
  }
}