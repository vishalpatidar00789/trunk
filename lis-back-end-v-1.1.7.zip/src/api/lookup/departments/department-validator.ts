import * as Joi from "joi";

export const createDepartmentModel = Joi.object().keys({
    departmentName: Joi.string().required(),
    createdBy: Joi.string().required(),
    activated: Joi.boolean().optional(),
    createdDate: Joi.any().allow(null).optional(),
    lastModifiedBy: Joi.any().allow(null).optional(),
    lastModifiedDate: Joi.any().allow(null).optional()
});

export const jwtValidator = Joi.object({'authorization': Joi.string().required()}).unknown();