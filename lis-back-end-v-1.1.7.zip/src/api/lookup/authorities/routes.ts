import * as Hapi from "hapi";
import * as Joi from "joi";
import AuthorityController from "./authority-controller";
import { AuthorityModel } from "./authority";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";

export default function(
    server: Hapi.Server,
    serverConfigs: IServerConfigurations,
    database: IDatabase
  ) {
    const authorityController = new AuthorityController(serverConfigs, database);
    server.bind(authorityController);
    // routes starts from here
    server.route({
    method: "GET",
    path: "/lookup/authorities",
    options: {
        handler: authorityController.getAllAuthorities,
        auth: false,
        tags: ["api", "authorities"],
        description: "Get list of all active authorities",
        plugins: {
            "hapi-swagger": {
                responses: {
                    "201": {
                        description: "active authorities list is fetched"
                    }
                }
            }
        }
    }
    });
}