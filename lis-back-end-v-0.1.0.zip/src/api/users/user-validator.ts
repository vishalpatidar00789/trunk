import * as Joi from "joi";

export const createUserModel = Joi.object().keys({
    login: Joi.string().trim().required(),
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    email: Joi.string().email().trim().required(),
    langKey: Joi.string().default("en"),
    password: Joi.string().trim().required(),
    authorities: Joi.array().items(Joi.string()),
    createdBy: Joi.string().required(),
    bank: Joi.string().allow(null).optional(),
    createdDate: Joi.any().allow(null).optional(),
    lastModifiedBy: Joi.any().allow(null).optional(),
    lastModifiedDate: Joi.any().allow(null).optional()
});
// lastName: Joi.string().optional(), activated: Joi.boolean().optional(), authorities: Joi.array().items(Joi.string())
export const updateUserModel = Joi.object().keys({
    email: Joi.string().email().trim().required(),
    firstName: Joi.string().required(),
    password: Joi.string().trim().required()
});

export const loginUserModel = Joi.object().keys({
    login: Joi.string().trim().required(),
    password: Joi.string().trim().required()
});

export const jwtValidator = Joi.object({'authorization': Joi.string().required()}).unknown();