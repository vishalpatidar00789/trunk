import * as Mongoose from "mongoose";
import * as Bcrypt from "bcryptjs";

export interface IUser extends Mongoose.Document {
  login: string;
  firstName: string;
  lastName: string;
  email: string;
  activated: Boolean;
  langKey: string;
  authorities: string[];
  createdBy: string;
  createdDate: Date;
  lastModifiedBy: string;
  lastModifiedDate: Date;
  password: string;
  bank: string;
  validatePassword(requestPassword): boolean;
}

export const UserSchema = new Mongoose.Schema(
{
    login: {type: String, unique: true, required: true },
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, unique: true, required: true },
    activated: { type: Boolean, required: false },
    langKey: { type: String, required: false },
    authorities: { type: [], required: false },
    createdBy: { type: String, required: false },
    createdDate: { type: Date, required: true },
    lastModifiedBy: { type: String, required: false },
    lastModifiedDate: { type: Date, required: false },
    password: { type: String, required: true },
    bank: { type: String, required: false }
  }
);

function hashPassword(password: string): string {
  if (!password) {
    return null;
  }

  return Bcrypt.hashSync(password, Bcrypt.genSaltSync(8));
}

UserSchema.methods.validatePassword = function(requestPassword) {
  return Bcrypt.compareSync(requestPassword, this.password);
};

UserSchema.pre("save", function(next) {
  const user = this;

  if (!user.isModified("password")) {
    return next();
  }

  user["password"] = hashPassword(user["password"]);

  return next();
});

UserSchema.pre("findOneAndUpdate", function() {
  const password = hashPassword(this.getUpdate().$set.password);

  if (!password) {
    return;
  }

  this.findOneAndUpdate({}, { password: password });
});

export const UserModel = Mongoose.model<IUser>("User", UserSchema);
