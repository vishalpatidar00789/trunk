import * as Hapi from "hapi";

export interface ICredentials extends Hapi.AuthCredentials {
  id: string;
}

export interface IRequestAuth extends Hapi.RequestAuth {
  credentials: ICredentials;
}

export interface IRequest extends Hapi.Request {
  auth: IRequestAuth;
}

export interface IUserCreate extends Hapi.Request {
  payload: {
    login: string;
    firstName: string;
    lastName: string;
    email: string;
    activated: Boolean;
    authorities: string[];
    createdBy: string;
    password: string;
    bank: string;
    createdDate: Date;
  };
}

export interface ILoginRequest extends IRequest {
  payload: {
    email: string;
    password: string;
  };
}
