import * as Database from "../src/database";

export function createUserDummy(email?: string) {
  var user = {
    login: "superadmin",
    firstName: "superadmin",
    lastName: "superadmin",
    email: "vishalpatidar00789@gmail.com",
    activated: true,
    langKey: "en",
    authorities: ["ROLE_USER","ROLE_ADMIN"],
    createdBy: "system",
    createdDate: new Date(),
    lastModifiedBy: null,
    lastModifiedDate: new Date(),
    password: "welcome@1",
    bank: null
  };

  return user;
}

export function clearDatabase(database: Database.IDatabase, done: MochaDone) {
  var promiseUser = database.userModel.remove({});
  Promise.all([promiseUser])
    .then(() => {
      done();
    })
    .catch(error => {
      console.log(error);
    });
}


export function createSeedUserData(database: Database.IDatabase, done: MochaDone) {
  database.userModel
    .create(createUserDummy())
    .then(user => {
      done();
    })
    .catch(error => {
      console.log(error);
    });
}

export async function login(server, config, user) {
  if (!user) {
    user = createUserDummy();
  }

  return server.inject({
    method: "POST",
    url: config.routePrefix + "/users/login",
    payload: { email: user.email, password: user.password }
  });
}
