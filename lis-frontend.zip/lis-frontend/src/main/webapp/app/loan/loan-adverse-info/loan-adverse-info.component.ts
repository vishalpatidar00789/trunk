import { Component, OnInit, Input, OnChanges, Output, EventEmitter, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotificationService } from '../../shared/alert/notification.service';
import { LoanAdverseInfo, LoanAdverseInfo_ } from './loan-adverse-info.model';
import { LoanSearchResults } from '../loan-search/loan-search-results/loan-search-results.model';
import { LoanAdverseInfoService } from './loan-adverse-info.service';
import { DateUtil } from '../../shared';
import {RadioButtonModule} from 'primeng/radiobutton';

@Component({
    selector: 'loan-adverse-info',
    templateUrl: './loan-adverse-info.component.html'
})
export class LoanAdverseInfoComponent implements OnInit, OnChanges,OnDestroy {

    displayMessage: boolean;
    userMessage: string;
    adverseStatus: any[];
    moreOverdueDate:any;
    lessOverdueDate:any;
    adverseInfoModel: LoanAdverseInfo;
    adverseInfoModel_: LoanAdverseInfo_;
    @Input() selectedLoanResult: LoanSearchResults;
    @Output() closePopUp = new EventEmitter<boolean>();

    constructor(
        private loanAdverseInfoService: LoanAdverseInfoService,
        private notificationService: NotificationService,
        private spinner: NgxSpinnerService) {
    }

    ngOnChanges() {
        if (this.selectedLoanResult) {
            this.adverseInfoModel_ = new LoanAdverseInfo_();
            this.adverseInfoModel_.marshRefNo = this.selectedLoanResult.marshRefNo;
            this.adverseInfoModel_.uenNumber = this.selectedLoanResult.aCRArefNo;
            this.adverseInfoModel_.borrowerRegName = this.selectedLoanResult.borrowerRegName;
            this.adverseInfoModel_.pfiName = this.selectedLoanResult.pfiName;
            this.adverseInfoModel_.status = this.selectedLoanResult.status;            
        }
    }

    ngOnInit() {
        console.log(this.selectedLoanResult);
        this.adverseInfoModel = new LoanAdverseInfo();
        this.displayMessage = false;
        this.adverseStatus = [
            { label: 'Yes', value: 'Yes' },
            { label: 'No', value: 'No' }
        ];
        if(this.selectedLoanResult.adverseStatus)
            this.adverseInfoModel.adverseInfo.adverseStatus=this.selectedLoanResult.adverseStatus;
            
    }

    ngOnDestroy(){
        this.adverseInfoModel=null;
        this.adverseInfoModel_=null;
        console.log('destroy');
    }

    cancel() {
        this.closePopUp.emit(true);
    }

    clearDate(){
        if(this.adverseInfoModel.adverseInfo.overdue=='less'){
            this.lessOverdueDate=null;
        }
        else  if(this.adverseInfoModel.adverseInfo.overdue=='more'){
            this.moreOverdueDate=null;
        }
    }

    save() {
        this.spinner.show();

     if(this.lessOverdueDate)
     this.adverseInfoModel.adverseInfo.overdueDate=this.lessOverdueDate;
     else  if(this.moreOverdueDate)
     this.adverseInfoModel.adverseInfo.overdueDate=this.moreOverdueDate;

        this.loanAdverseInfoService.upldateLoanAdverseInfo(this.adverseInfoModel, this.selectedLoanResult.marshRefNo).subscribe((res) => {
            console.log(res);
            this.spinner.hide();
            this.notificationService.showNotification();
        });
     
        this.cancel();
    }

}