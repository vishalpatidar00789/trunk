import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { SERVER_API_URL } from '../../app.constants';

@Injectable()
export class LoanAdverseInfoService {
    
    private resourceUrl = SERVER_API_URL + 'loanform/';
    constructor(private http: HttpClient) { }

    upldateLoanAdverseInfo(adverseInfo:any,marshRefNo){
        console.log(JSON.stringify(adverseInfo));
        marshRefNo=marshRefNo.replace('/','_')
        return <any>this.http.put(this.resourceUrl +'adverseInfo/'+ marshRefNo, adverseInfo);
    }

}