export class LoanAdverseInfo{
    constructor(    
    public adverseInfo?: 
        { 
        adverseStatus: string,
        additionalInfo :string,       
        overdue?:string,
        overdueDate?:any,
        listOfOverdue?:boolean,
        repaymentPlanAttached?:boolean
        }
    ){  
        this.adverseInfo=  {
            adverseStatus: '',
            additionalInfo:'',
            overdue:'',
            listOfOverdue:false,
            repaymentPlanAttached:false
        } 
    }
}

export class LoanAdverseInfo_{
    constructor(
    public marshRefNo?:string,
    public status?: string,
    public borrowerRegName?:string,
    public pfiName?: string,
    public uenNumber?: string    
    ){          
    }
}