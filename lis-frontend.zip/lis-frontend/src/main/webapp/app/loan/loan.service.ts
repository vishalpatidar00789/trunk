import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, Subject } from 'rxjs/Rx';
import { SERVER_API_URL } from '../app.constants';

import { JhiDateUtils } from 'ng-jhipster';

import { AdditionalFields } from './additional-fields/additionalfields.model';
import { createRequestOption } from '../shared';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Loan, LoanProcess } from './loan.model';

@Injectable()
export class LoanService {
  private resourceUrl = SERVER_API_URL;

  // Observable Laon Step Process form sources
  loanStepProcessSource = new BehaviorSubject<LoanProcess>(
    new LoanProcess()
  );

  // Observable Laon Step Process form streams
  loanProcess$ = this.loanStepProcessSource.asObservable();

  private additionalFields: AdditionalFields = new AdditionalFields();
  loanId: string;
  status = new Subject();

  public setId(id) {
    this.loanId = id;
  }
  public getId() {
    return this.loanId;
  }

  public setStatus(status) {
    this.status.next(status);
  }

  public getStatus() {
    return this.status;
  }
  //private resourceUrl = SERVER_API_URL + 'api/loan/uob-credit-limit';

  private additionalFieldsFormSource = new BehaviorSubject<AdditionalFields>(
    this.additionalFields
  );
  currentAdditionalFields = this.additionalFieldsFormSource.asObservable();

  constructor(private http: HttpClient, private dateUtils: JhiDateUtils) {}

  setLoanStepProcess(loanProcess: LoanProcess) {
    this.loanStepProcessSource.next(loanProcess);
  }

  changeAdditionalFields(additionalFields: AdditionalFields) {
    this.additionalFieldsFormSource.next(additionalFields);
  }

  createLoan(loanData) {
    return <any>this.http.post(this.resourceUrl + 'loanform', loanData); //change url
  }

  // Save As Draft Loan
  updateLoan(loan: any) {
    console.log(loan);
    const id = loan._id;
    // console.log(LoanService
    delete loan._id;

    return <any>(
      this.http.put(SERVER_API_URL + 'loanform/saveAsDraft/' + id, loan)
    );
  }

  // Submit Loan Application
  submitLoan(loan: any) {
    const id = loan._id;
    delete loan['_id'];
    console.log(JSON.stringify(loan));
    return <any>this.http.put(this.resourceUrl + 'loanform/submit/' + id, loan);
  }
}
