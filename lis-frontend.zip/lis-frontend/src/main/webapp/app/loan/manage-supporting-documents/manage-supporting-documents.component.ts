import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotificationService } from '../../shared/alert/notification.service';
import { ManageSupportingDocuments  } from './manage-supporting-documents.model';
import { ManageSupportingDocumentsService } from './manage-supporting-documents.service';
import { LoanSearchResults } from '../loan-search/loan-search-results/loan-search-results.model';

@Component({
    selector: 'manage-supporting-documents',
    templateUrl: './manage-supporting-documents.component.html'
})
export class ManageSupportingDocumentsComponent implements OnInit, OnChanges {

    displayMessage: boolean;
    userMessage: string;
    model:ManageSupportingDocuments;
    
    @Input() selectedLoanResult: LoanSearchResults;
    @Output() closePopUp = new EventEmitter<boolean>();

    constructor(  
        private manageLOService:ManageSupportingDocumentsService,
        private notificationService: NotificationService,
        private spinner: NgxSpinnerService) {
    }

    ngOnChanges() {
        if (this.selectedLoanResult) {
            this.model = new ManageSupportingDocuments();
            this.model.marshRefNo = this.selectedLoanResult.marshRefNo;
            this.model.uenNumber = this.selectedLoanResult.aCRArefNo;
            this.model.borrowerName = this.selectedLoanResult.borrowerRegName;
            this.model.staffName=this.selectedLoanResult.requesterName;
            this.model.pfiName = this.selectedLoanResult.pfiName;
            this.model.status = this.selectedLoanResult.status
        }
    }

    ngOnInit() {
        console.log(this.selectedLoanResult);        
        this.displayMessage = false;
       
    }

    cancel() {
        this.closePopUp.emit(true);
    }

}