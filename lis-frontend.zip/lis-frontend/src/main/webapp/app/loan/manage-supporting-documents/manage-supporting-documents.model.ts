export class ManageSupportingDocuments{
    constructor(
    public marshRefNo?:string,
    public status?: string,
    public borrowerName?:string,
    public pfiName?: string,
    public staffName?:string,
    public uenNumber?: string    
    ){          
    }
}