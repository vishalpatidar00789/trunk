
export class AdditionalFields {
    constructor(
        //
        public _id?: string,
        // 
        public pfi?: string,

        // string
        public marshReferenceNumber?: string,

        //
        public borrowerName?: string,

        //
        public applicationStatus?: string,

        //
        public acraRefNo?: string,

        //drowpdown
        public typeoflimit?: string,

        // date
        public applicationDate?: string,

        // 
        public purposeofLoan?: string,

        //number
        public domesticPercent?: string,

        // number
        public exportPercent?: string,

        // Multi-value list taking string as of now
        public loanType?: string,

        //  currency(number)
        public totalAppliedLimit?: string,

        //currency(number)
        public foreignCurrencyRequestedLimits?: string,

        // currency drop down
        public foreignCurrencyType?: string,

        // number 
        public foreignCurrencyExchangeRate?: string,

        // text
        public adverseInformation?: string,

        // text area
        public additionalInformationforAdverseStatus?: string,

        //text
        public loanApplicationNumber?: string,

        //
        public reportedMonth?: string,

        //currency(number)
        public grossSgdPremiumPrimary?: string,

        //currency(number)
        public grossSgdPremiumAuto?: string,

        //currency(number)
        public grossSgdPremiumBg?: string,

        //currency(number)
        public grossSgdPremiumLisPlus?: string,

        //
        public natureofApplication?: string,

        //
        public noOfApp?: string,

        //date
        public loAcceptanceDate?: string,

        //date
        public insurersApprovalDate?: string,

        //date
        public loanExpiryDateFromLoAcceptanceDate?: string,

        //currency(number)
        public approvedSgdLimitPrimaryLayer?: string,

        //currency(number)
        public approvedSgdLimitAutoTopup?: string,

        //currency(number)
        public approvedSgdLimitBgLayer?: string,

        //currency(number)
        public approvedForeignCurrencyLimitPrimaryLayer?: string,

        // currency drop down
        public approvedForeignCurrencyPrimaryLayerType?: string,

        // number 
        public approvedForeignCurrencyPrimaryLayerExchangeRate?: string,

        //currency(number)
        public approvedForeignCurrencyLimitAutoTopup?: string,

        // currency drop down
        public approvedForeignCurrencyAutoTopupType?: string,

        // number 
        public approvedForeignCurrencyAutoTopupExchangeRate?: string,

        //currency(number)
        public approvedForeignCurrencyLimitBgLayer?: string,

        // currency drop down
        public approvedForeignCurrencyBgLayerType?: string,

        // number 
        public approvedForeignCurrencyBgLayerExchangeRate?: string,

        //date
        public dateSentForLisPlus?: string,

        //date
        public lisPlusApprovedDate?: string,

        //currency(number)
        public lisPlusApprovedLimit?: string,

        //number
        public approvedForeignCurrencyLimitLISPlusLayer?: string,

        //currency drop down
        public approvedForeignCurrencyLISPlusType?: string,

        //number
        public approvedForeignCurrencyLISPlusExchangeRate?: string,

        //string
        public typeOfLimitLisplus?: string,

        // currency(number)
        public lisTotalApprovedLimit?: string,

        //number
        public lisApprovalRatioPrecent?: string,

        //number
        public lisTurnAroundDays?: string,

        //currency(number)
        public totalApprovedLimitIncludingLisPlus?: string,

        //number
        public approvalRatioWithLisPlus?: string,
        //number
        public turnAroundWithLisPlus?: string,
        //number
        public utilization?: string,
        //string
        public internalRemarks?: string,
    ) {
        this.applicationStatus = "Draft";
    }
}
