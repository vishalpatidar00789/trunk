import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { catchError, map, tap } from 'rxjs/operators';
import { SERVER_API_URL } from '../../../app.constants';
import { LoanSearchResults } from './loan-search-results.model';

@Injectable()
export class LoanSearchResultsService {

    private resultUrl: string;
    constructor(private http: HttpClient) {
        // this.resultUrl = SERVER_API_URL + './loan-search-results.json';
        this.resultUrl = 'https://jsonplaceholder.typicode.com/todos';
    }

    /** GET heroes from the server */
    getLoanSearchResults(): Observable<LoanSearchResults> {
        return this.http.get<LoanSearchResults>(this.resultUrl);
    }
}
