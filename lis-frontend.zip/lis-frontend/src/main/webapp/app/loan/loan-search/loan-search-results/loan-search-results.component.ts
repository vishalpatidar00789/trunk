import { Component, OnInit, OnDestroy, ViewChild, Input, OnChanges } from '@angular/core';
import { LOAN_SEARCH_RESULT_ITEMS_PER_PAGE } from './../../../shared/constants/pagination.constants';
import { TableModule } from 'primeng/table';
import { PaginatorModule } from 'primeng/paginator';
import { TieredMenuModule, TieredMenu } from 'primeng/tieredmenu';
import { DialogModule } from 'primeng/dialog';
import { MenuItem } from 'primeng/api';
import { LoanSearchResults } from './loan-search-results.model';
import { LoanSearchResultsService } from './loan-search-results.service';
import { Observable } from 'rxjs/Rx';
import { LoanSearchCriteriaService } from '../loan-search-criteria/loan-search-criteria.service';

@Component({
    selector: 'lis-loan-search-results',
    templateUrl: './loan-search-results.component.html',
})
export class LoanSearchResultsComponent implements OnInit, OnDestroy, OnChanges {

    @Input() loanResultList: LoanSearchResults[];
    @Input() isMarshUser: boolean;
    @Input() totalRecords: number;

    public items: MenuItem[];
    public cols: any[];
    public frozenCols: any[];
    public itemsPerPage: number;
    public display: boolean = false;
    public adverseInfoModel: boolean = false;
    public loAcceptanceModel: boolean = false;
    public manageSupportingDocModel: boolean = false;
    public rowDataLoan: LoanSearchResults;
    public loanResultList2: LoanSearchResults[];

    @ViewChild('tieredMenu') tieredMenu: TieredMenu;
    constructor(
        private loanSearchResultsService: LoanSearchResultsService,
        private loanSearchCriteriaService: LoanSearchCriteriaService
    ) { }

    ngOnChanges() {

        setTimeout(() => {
            this.loanResultList2 = this.loanResultList;
        }, 500);

        this.itemsPerPage = LOAN_SEARCH_RESULT_ITEMS_PER_PAGE;
        this.cols = [
            { field: 'marshRefNo', header: 'Marsh Reference Number' },
            { field: 'borrowerRegName', header: 'Borrower Name' },
            { field: 'aCRArefNo', header: 'UEN Number' },
            { field: 'pfiName', header: 'PFI' },
            { field: 'natureOfApplication', header: 'Nature of Application' },
            { field: 'marshSubmissionDate', header: 'Marsh Submission  Date' },
            { field: 'submissionDate', header: 'COFANET Submission Date ' },
            { field: 'loAcceptanceDate', header: 'LO Acceptance Date ' },
            { field: 'loanExpiryDate', header: 'Loan Expiry Date' },
            { field: 'status', header: 'Marsh Loan Application Status' },
            { field: 'adverseStatus', header: 'Adverse Status' },
            { field: 'app', header: 'APP' },
            { field: 'totalRequstedLimitSGD', header: 'Total Applied Limit (S$)' },
            { field: 'primary', header: 'Approved Limit(Primary) S$' },
            { field: 'autoTopUp', header: 'Approved Limit(Top-up) S$' },
            { field: 'bg', header: 'Approved Limit(BG) S$' },
            { field: 'lisPlus', header: 'Approved Limit(LIS+) S$' }
        ];

        console.log('ng-on-change');
    }

    ngOnInit() {

    }

    adverseInfoDialog(result) {
        this.adverseInfoModel = true;
        this.rowDataLoan = result;
    }

    loAcceptanceDialog(result) {
        this.loAcceptanceModel = true;
        this.rowDataLoan = result;
    }

    manageSupportingDocDialog(result) {
        this.manageSupportingDocModel = true;
        this.rowDataLoan = result;
    } 

    ngOnDestroy() {

    }
}
