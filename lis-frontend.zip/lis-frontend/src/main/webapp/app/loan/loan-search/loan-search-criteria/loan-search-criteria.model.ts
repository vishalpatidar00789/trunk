export class LoanSearchCriteria {
    constructor(
            public marshRefNo?:string,
            public borrowerName?:string,
            public uenNumber?:string,
            public pfiName?:any [],
            public consortium?:string,
            public adverseStatus?:string,
            public typeOfDate?:string,
            public fromDate?:string,
            public toDate?:string,
            public natureOfApplication?:any [],
            public marshLoanApplicationStatus?:any [],
            public excludeExpiredApplications?:string,
            public app?:any [],
    ){ 
       this.typeOfDate=null;
    }
}
