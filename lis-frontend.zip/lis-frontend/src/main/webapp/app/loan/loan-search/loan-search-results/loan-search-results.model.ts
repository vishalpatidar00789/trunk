export class LoanSearchResults {
    public marshRefNo: string;
    public status: string;
    public borrowerRegName: string;
    public aCRArefNo: string;
    public pfiName: string;
    public requesterName:string;
    public natureOfApplication: string;
    public submissionDate: string;
    public marshSubmissionDate: string;
    public loAcceptanceDate: string;
    public loanExpiryDate: string;
    public adverseStatus: string;
    public app: string;
    public totalRequstedLimitSGD: string;
    public primary: number;
    public autoTopUp: number;
    public bg: number;
    public lisPlus: number
    constructor(
    ) { }
}
