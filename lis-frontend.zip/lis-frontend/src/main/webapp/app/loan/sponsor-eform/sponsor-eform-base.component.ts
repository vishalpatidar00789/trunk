import { Component, OnInit } from '@angular/core';
import { Loan, LoanProcess } from '../loan.model';
import { LoanService } from '../loan.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  template: `<router-outlet></router-outlet>`
})
export class LoanBaseComponent implements OnInit {
  loan: Loan;
  loanProcess: LoanProcess;
  constructor(private loanService: LoanService, private route: ActivatedRoute) {
    this.loanService.loanProcess$.subscribe((loanProcess) => {
      this.loanProcess = Object.assign({}, loanProcess);
    });
  }

  ngOnInit() {
    const loanId = this.route.snapshot.paramMap.get('loanId');
    if (!loanId) {
      this.loan = new Loan();
      this.loanService.createLoan(this.loan).subscribe((loanResult) => {
        const loanProcess = new LoanProcess();
        loanProcess.id = loanResult._id;
        loanProcess.status = loanResult.status;
        this.loanProcess = Object.assign({}, loanProcess);
        this.loanService.setLoanStepProcess(this.loanProcess);
      });
    }
  }
}
