import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpResponse,
  HttpRequest,
  HttpHeaders
} from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs/Rx';
import { SERVER_API_URL } from '../../app.constants';
import { JhiDateUtils } from 'ng-jhipster';

import { SponsorEForm } from './sponsor-eform.model';
import { createRequestOption } from '../../shared';

export type SponsorEFormResponseType = HttpResponse<SponsorEForm>;
export type SponsorEFormArrayResponseType = HttpResponse<SponsorEForm[]>;

@Injectable()
export class SponsorEFormService {
  private resourceUrl = SERVER_API_URL + 'springforms';

  // Observable sponsor form sources
  sponsorEFormSource = new BehaviorSubject<SponsorEForm>(new SponsorEForm());

  // Observable sponsor form streams
  springEForm$ = this.sponsorEFormSource.asObservable();

  constructor(private http: HttpClient, private dateUtils: JhiDateUtils) {}

  setSponsorEForm(sponsorEForm: SponsorEForm) {
    this.sponsorEFormSource.next(sponsorEForm);
  }

  create(sponsorData) {
    console.log(JSON.stringify(sponsorData));
    return <any>this.http.post(this.resourceUrl, sponsorData); //change url
  }

  update(sponsorData) {
    let id = sponsorData.sponsoreform._id;
    return <any>this.http.put(this.resourceUrl + '/' + id, sponsorData); //change url
  }

  // create(sponsoreform: SponsorEForm): Observable<any> {
  //     const copy = this.convert(sponsoreform);
  //     console.log("my sponsoreform" + sponsoreform);
  //     return this.http.post<SponsorEForm>(this.resourceUrl, copy, { observe: 'response' })
  //         .map((res: SponsorEFormResponseType) => this.convertResponse(res));
  // }

  // update(sponsoreform: SponsorEForm): Observable<SponsorEFormResponseType> {
  //     const copy = this.convert(sponsoreform);
  //     return this.http.put<SponsorEForm>(this.resourceUrl, copy, { observe: 'response' })
  //         .map((res: SponsorEFormResponseType) => this.convertResponse(res));
  // }

  private convertResponse(
    res: SponsorEFormResponseType
  ): SponsorEFormResponseType {
    const body: SponsorEForm = this.convertItemFromServer(res.body);
    return res.clone({ body });
  }

  private convertArrayResponse(
    res: SponsorEFormArrayResponseType
  ): SponsorEFormArrayResponseType {
    const jsonResponse: SponsorEForm[] = res.body;
    const body: SponsorEForm[] = [];
    for (let i = 0; i < jsonResponse.length; i++) {
      body.push(this.convertItemFromServer(jsonResponse[i]));
    }
    return res.clone({ body });
  }

  /**
   * Convert a returned JSON object to SponsorEForm.
   */
  private convertItemFromServer(json: any): SponsorEForm {
    const copy: SponsorEForm = Object.assign(new SponsorEForm(), json);
    copy.dateofIncorporation = this.dateUtils.convertLocalDateFromServer(
      json.dateofIncorporation
    );
    copy.dateOfSingature = this.dateUtils.convertLocalDateFromServer(
      json.dateOfSingature
    );
    return copy;
  }

  /**
   * Convert a SponsorEForm to a JSON which can be sent to the server.
   */
  private convert(sponsoreform: SponsorEForm): SponsorEForm {
    const copy: SponsorEForm = Object.assign({}, sponsoreform);
    copy.dateofIncorporation = this.dateUtils.convertLocalDateToServer(
      sponsoreform.dateofIncorporation
    );
    copy.dateOfSingature = this.dateUtils.convertLocalDateToServer(
      sponsoreform.dateOfSingature
    );
    return copy;
  }

  uploadFile(fileData) {
    let headers = new HttpHeaders();
    headers.append('Access-Control-Allow-Origin', '*');

    return <any>this.http.post(
      this.resourceUrl + '/uploadspringeform',
      // ,
      //     { headers: { 'Access-Control-Allow-Origin': '*' } }
      fileData,
      { headers: headers }
    );
  }

  /*
    uploadFile(formData){
        console.log("---------------------------");
        // console.log(this.resourceUrl + '/upload');
        console.log("---------------------------");
        console.log(formData);
        console.log("---------------------------");        
        this.http.post("http://AUMLBCVDIF00068:5000/sponsorforms" , formData) ; 
        const copy = this.convert(formData);
        console.log("my sponsoreform"+formData);
        return this.http.post<SponsorEForm>(this.resourceUrl, copy, { observe: 'response' })
            .map((res: SponsorEFormResponseType) => this.convertResponse(res));
    }*/
}
