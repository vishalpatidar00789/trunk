import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';

import { SponsorEForm, Subsideries } from '../';
import { SponsorEFormService } from './sponsor-eform.service';
import { Principal, Account } from '../../shared';
import { error } from 'util';

import { LoanService } from '../loan.service';
import { DateUtil } from '../../shared/date-formatter/date-util';

@Component({
  selector: 'lis-sponsor-eform',
  templateUrl: './sponsor-eform.component.html'
})
export class SponsorEFormComponent implements OnInit, OnDestroy {
  sponsoreform: SponsorEForm = new SponsorEForm();
  countries: Array<any> = [
    { id: 'MY', name: 'Malaysia' },
    { id: 'SG', name: 'Singapore' },
    { id: 'Other', name: 'Other' }
  ];

  eventSubscriber: Subscription;
  isSaving: Boolean;
  routeData: any;
  links: any;
  totalItems: any;
  queryCount: any;
  itemsPerPage: any;
  page: any;
  predicate: any;
  previousPage: any;
  reverse: any;
  ShowEditTable: boolean = false;
  shareHoldingEditRowId: any = '';
  subsidiariesEditRowId: any = '';
  currentShareholdingSub: any;

  _id: string;

  isInventoryChecked = false;
  UOBUser: boolean = false;
  PFIUser: boolean = true;
  currentAccount: Account;

  constructor(
    private sponsorEFormService: SponsorEFormService,
    private parseLinks: JhiParseLinks,
    private jhiAlertService: JhiAlertService,
    private eventManager: JhiEventManager,
    private principal: Principal,
    private loanService: LoanService,
    private router: Router
  ) {
    this.sponsorEFormService.springEForm$.subscribe((sponsorForm) => {
      this.sponsoreform = sponsorForm;
    });
  }

  shareHoldingEditRowIdValidated = true;

  addRowShareholdingSub(obj) {
    this.shareHoldingEditRowIdValidated = true;
    if (!this.sponsoreform.shareholdingSub) {
      this.sponsoreform.shareholdingSub = [];
    }

    let subsideries: Subsideries = {
      level: '0',
      name: '',
      aCRA: '',
      type: '',
      country: '',
      share: 0.0,
      parentUEN: '',
      turnover: 0.0,
      noOfStaff: 0
    };

    if (this.sponsoreform.shareholdingSub.length < 50) {
      this.sponsoreform.shareholdingSub.push(subsideries);
      this.shareHoldingEditRowId = this.sponsoreform.shareholdingSub.length - 1;
    } else {
      alert('Maximum of 50 Records would be allowed.');
    }
  }

  edit(val) {
    this.shareHoldingEditRowId = val;

    // this.isValidate(this.shareHoldingEditRowId);

    // if (this.shareHoldingEditRowId) {
    //     if (this.shareHoldingEditRowIdValidated) {
    //         this.shareHoldingEditRowId = val;
    //     } else {
    //         this.shareHoldingEditRowId = this.shareHoldingEditRowId;

    //     }
    // }
    // alert("not validated");
  }

  isValidate(shareHoldingEditRowId) {
    this.shareHoldingEditRowIdValidated = false;
    let currentElement: Subsideries = this.sponsoreform.shareholdingSub[
      shareHoldingEditRowId
    ];

    //    if(false){
    //     this.shareHoldingEditRowIdValidated = true;
    //    }

    return this.shareHoldingEditRowIdValidated;
  }

  editSubsidiariesEditRowId(val) {
    this.subsidiariesEditRowId = val;
  }

  setValidValues() {
    this.sponsoreform.invStockFinancing =
      this.sponsoreform.invStockFinancing == null
        ? 0
        : this.sponsoreform.invStockFinancing;
    this.sponsoreform.workingCapital =
      this.sponsoreform.workingCapital == null
        ? 0
        : this.sponsoreform.workingCapital;
    this.sponsoreform.aRDiscount =
      this.sponsoreform.aRDiscount == null ? 0 : this.sponsoreform.aRDiscount;
    this.sponsoreform.capitalLoan =
      this.sponsoreform.capitalLoan == null ? 0 : this.sponsoreform.capitalLoan;
    this.sponsoreform.bankerGuarantee =
      this.sponsoreform.bankerGuarantee == null
        ? 0
        : this.sponsoreform.bankerGuarantee;
  }

  saveAsDraft() {
    this.isSaving = true;

    console.log(JSON.stringify(this.sponsoreform));

    this.subscribeToSaveResponse(
      this.sponsorEFormService.create(this.sponsoreform)
    );
  }

  private subscribeToSaveResponse(result: Observable<SponsorEForm>) {
    result.subscribe(
      (res: SponsorEForm) => this.onSaveSuccess(res),
      (res: Response) => this.onSaveError()
    );
  }

  private onSaveSuccess(result: SponsorEForm) {
    this.eventManager.broadcast({
      name: 'sponsoreformListModification',
      content: 'OK'
    });
    this.isSaving = false;
  }

  private onSaveError() {
    this.isSaving = false;
  }

  ngOnInit() {
    // this.loanService.currentSponsorEForm.subscribe((Result) => {
    //   this.sponsoreform = Result;
    //   this.checkBoxCheckUncheck();
    // });
    // this.sponsoreform.subsidiaries = [];
    // this.sponsoreform.shareholdingSub = [];
    // this.sponsoreform.dateofIncorporation = "";

    // this.addRowShareholdingSub();
    // this.addRowSubsidiaries();

    // this.principal.identity().then((account) => {
    //     this.currentAccount = account;
    // }),

    this.principal.identity().then((account) => {
      this.currentAccount = account;
      if (
        this.currentAccount.bank &&
        this.currentAccount.bank !== 'null' &&
        this.currentAccount.bank === 'UOB'
      ) {
        this.UOBUser = true;
        this.PFIUser = false;
      } else if (
        this.currentAccount.bank &&
        this.currentAccount.bank !== 'null' &&
        this.currentAccount.bank !== 'UOB'
      ) {
        this.PFIUser = true;
        this.UOBUser = false;
      }
    });
  }

  ngOnDestroy() {}

  sort() {
    const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
    if (this.predicate !== 'id') {
      result.push('id');
    }
    return result;
  }
  private onError(error) {
    this.jhiAlertService.error(error.message, null, null);
  }

  public restrictNumeric(event, obj) {
    return true;
  }

  public sumTotal() {
    // this.sponsoreform.total = 0;
    let total: number = 0;

    if (this.sponsoreform.invStockFinancing) {
      total += parseFloat(this.sponsoreform.invStockFinancing.toString());
    }

    if (this.sponsoreform.workingCapital) {
      total += parseFloat(this.sponsoreform.workingCapital.toString());
    }

    if (this.sponsoreform.aRDiscount) {
      total += parseFloat(this.sponsoreform.aRDiscount.toString());
    }

    if (this.sponsoreform.capitalLoan) {
      total += parseFloat(this.sponsoreform.capitalLoan.toString());
    }

    if (this.sponsoreform.bankerGuarantee) {
      total += parseFloat(this.sponsoreform.bankerGuarantee.toString());
    }

    this.sponsoreform.total = total;
  }

  addRowSubsidiaries() {
    if (!this.sponsoreform.subsidiaries) {
      this.sponsoreform.subsidiaries = [];
    }
    var addSubsideries = {
      subsidLevel: '',
      name: '',
      sharePercent: '',
      noStaff: ''
    };

    if (this.sponsoreform.subsidiaries.length < 50) {
      this.sponsoreform.subsidiaries.push(addSubsideries);
      this.subsidiariesEditRowId = this.sponsoreform.subsidiaries.length - 1;
    } else {
      alert('Maximum of 50 Records would be allowed.');
    }
  }

  removeCurrentsubsidiaries(currentsubsidiaries) {
    this.sponsoreform.subsidiaries.splice(
      this.sponsoreform.subsidiaries.indexOf(currentsubsidiaries),
      1
    );
  }

  removeShareholdingSub(shareholdingSub) {
    console.log(this.sponsoreform.shareholdingSub);
    //this.sponsoreform.shareholdingSub.splice(this.sponsoreform.subsidiaries.indexOf(shareholdingSub), 1);
    this.sponsoreform.shareholdingSub.splice(shareholdingSub, 1);

    console.log(this.sponsoreform.shareholdingSub);
  }

  changeAmountFinance(changeValue) {
    if (changeValue == 'invStockFinancing') {
      if (!this.sponsoreform.invStockFinancingChecked) {
        this.sponsoreform.invStockFinancing = null;
      }
    }

    if (changeValue == 'workingCapital') {
      if (!this.sponsoreform.workingCapitalChecked) {
        this.sponsoreform.workingCapital = null;
      }
    }

    if (changeValue == 'aRDiscount') {
      if (!this.sponsoreform.aRDiscountChecked) {
        this.sponsoreform.aRDiscount = null;
      }
    }

    if (changeValue == 'capitalLoan') {
      if (!this.sponsoreform.capitalLoanChecked) {
        this.sponsoreform.capitalLoan = null;
      }
    }

    if (changeValue == 'bankerGuarantee') {
      if (!this.sponsoreform.bankerGuaranteeChecked) {
        this.sponsoreform.bankerGuarantee = null;
      }
    }

    this.sumTotal();
  }

  checkBoxCheckUncheck() {
    if (this.sponsoreform.invStockFinancing > 0) {
      this.sponsoreform.invStockFinancingChecked = true;
    } else {
      this.sponsoreform.invStockFinancing = null;
    }

    if (this.sponsoreform.workingCapital > 0) {
      this.sponsoreform.workingCapitalChecked = true;
    } else {
      this.sponsoreform.workingCapital = null;
    }

    if (this.sponsoreform.aRDiscount > 0) {
      this.sponsoreform.aRDiscountChecked = true;
    } else {
      this.sponsoreform.aRDiscount = null;
    }

    if (this.sponsoreform.capitalLoan > 0) {
      this.sponsoreform.capitalLoanChecked = true;
    } else {
      this.sponsoreform.capitalLoan = null;
    }

    if (this.sponsoreform.bankerGuarantee > 0) {
      this.sponsoreform.bankerGuaranteeChecked = true;
    } else {
      this.sponsoreform.bankerGuarantee = null;
    }
  }

  onlyNumberKey(event) {
    return event.charCode == 8 || event.charCode == 0 || event.charCode == 46
      ? null
      : event.charCode >= 48 && event.charCode <= 57;
    //|| event.charCode == 44
  }
}
