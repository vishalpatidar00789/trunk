import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoanService } from '../loan.service';
import { LoanProcess } from '../loan.model';

@Component({
  selector: 'lis-sponsor-submitted-view',
  templateUrl: './sponsor.submitted-view.component.html'
})
export class SponsorSubmittedViewComponent {
  loanProcess: LoanProcess;

  constructor(
    private loanService: LoanService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.loanService.loanProcess$.subscribe((loanProcess) => {
      this.loanProcess = Object.assign({}, loanProcess);
    });
  }
}
