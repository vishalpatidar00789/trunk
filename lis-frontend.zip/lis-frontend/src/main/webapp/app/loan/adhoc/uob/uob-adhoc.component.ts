import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';

import { UobAdhoc } from './uob-adhoc.model';
import { UobAdhocService } from './uob-adhoc.service';
import { Principal } from '../../../shared';

@Component({
    selector: 'jhi-uob-adhoc',
    templateUrl: './uob-adhoc.component.html'
})
export class UobAdhocComponent implements OnInit, OnDestroy {

    userMessage: string;
    displayMessage: boolean = false;
    adhocApplicationStatus: string;

    currencies = ['AUD', 'CNY', 'EUR', 'HKD', 'IDR', 'INR', 'JPY', 'KRW', 'MYR', 'NOK', 'PHP', 'THB', 'TWD', 'USD'];
    uobAdhoc: UobAdhoc = new UobAdhoc();

    currentAccount: any;
    eventSubscriber: Subscription;
    isSaving: Boolean;
    routeData: any;
    links: any;
    totalItems: any;
    queryCount: any;
    itemsPerPage: any;
    page: any;
    predicate: any;
    previousPage: any;
    reverse: any;

    constructor(
        private uobAdhocService: UobAdhocService,
        private parseLinks: JhiParseLinks,
        private jhiAlertService: JhiAlertService,
        private eventManager: JhiEventManager,
        private router: Router,
        private principal: Principal) {
    }

    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0 || event.charCode == 46 || event.charCode == 44) ? null : event.charCode >= 48 && event.charCode <= 57;
    }

    saveAsDraft() {
        window.scrollTo(0, 0);
        this.displayMessage = true;
        this.adhocApplicationStatus = "Draft";
        this.userMessage = "Additional information saved succesfully."
        setTimeout(() => { this.displayMessage = false; }, 4000);
    }

    save() {
        if (!this.isValidate()) {
            return;
        }
        window.scrollTo(0, 0);
        this.displayMessage = true;
        this.userMessage = "Application submitted successfully";
        setTimeout(() => { this.displayMessage = false; }, 4000);
    }

    clear() {
        if (confirm("Are you sure, you want to cancel?")) {
            this.uobAdhoc = new UobAdhoc();
            this.router.navigateByUrl('/');
        }
    }

    private subscribeToSaveResponse(result: Observable<UobAdhoc>) {
        result.subscribe((res: UobAdhoc) =>
            this.onSaveSuccess(res), (res: Response) => this.onSaveError());
    }

    private onSaveSuccess(result: UobAdhoc) {
        this.eventManager.broadcast({ name: 'uobAdhocListModification', content: 'OK' });
        this.isSaving = false;
    }

    private onSaveError() {
        this.isSaving = false;
    }

    ngOnInit() {
        this.principal.identity().then((account) => {
            this.currentAccount = account;
        });

    }

    ngOnDestroy() {

    }

    sort() {
        const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
        if (this.predicate !== 'id') {
            result.push('id');
        }
        return result;
    }

    private onError(error) {
        this.jhiAlertService.error(error.message, null, null);
    }

    //this.uobAdhoc.borrowersGroup = [{name: '',limit:''}];

    add() {
        // this.uobAdhoc.borrowersGroup.push({name: '',limit:''});    
    }

    remove() {
        // this.uobAdhoc.borrowersGroup.pop();
    }

    reset(field: string) {
        this.uobAdhoc[field] = null;
    }

    updateStack(event, supportDoc) {
        if (event.status == "success") {
            this.uobAdhoc.supportingDocs.forEach(element => {
                if (element.name == supportDoc) {
                    element.status = true;
                    element.files += event.filename;
                    console.log(element.files);
                }
            });
        }
    }

    isValidate() {

        let uploadDocumentFor = '';
        this.uobAdhoc.supportingDocs.forEach(element => {
            let field = element.name;
            switch (field) {
                case "billInformation":
                    if (!element.status && this.uobAdhoc.billInfoChkBx) {
                        uploadDocumentFor += '\n -Extension of Due Date of Bill.';
                    }
                    break;

                default:
                    break;
            }
        });

        if (uploadDocumentFor) {
            alert("Please upload document for" + uploadDocumentFor);
            return false;
        } else
            return true;
    }
}
