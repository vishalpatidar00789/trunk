import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotificationService } from '../../shared/alert/notification.service';
import { ManageLOAcceptance,  } from './manage-LO-acceptance.model';
import { ManageLOAcceptanceService } from './manage-LO-acceptance.service';
import { LoanSearchResults } from '../loan-search/loan-search-results/loan-search-results.model';

@Component({
    selector: 'manage-LO-acceptance',
    templateUrl: './manage-LO-acceptance.component.html'
})
export class ManageLOAcceptanceComponent implements OnInit, OnChanges {

    displayMessage: boolean;
    userMessage: string;
    model:ManageLOAcceptance;
    
    @Input() selectedLoanResult: LoanSearchResults;
    @Output() closePopUp = new EventEmitter<boolean>();

    constructor(  
        private manageLOService:ManageLOAcceptanceService,
        private notificationService: NotificationService,
        private spinner: NgxSpinnerService) {
    }

    ngOnChanges() {
        if (this.selectedLoanResult) {
            this.model = new ManageLOAcceptance();
            this.model.marshRefNo = this.selectedLoanResult.marshRefNo;
            this.model.uenNumber = this.selectedLoanResult.aCRArefNo;
            this.model.borrowerName = this.selectedLoanResult.borrowerRegName;
            this.model.staffName=this.selectedLoanResult.requesterName;
            this.model.pfiName = this.selectedLoanResult.pfiName;
            this.model.status = this.selectedLoanResult.status
        }
    }

    ngOnInit() {
        console.log(this.selectedLoanResult);        
        this.displayMessage = false;
       
    }

    cancel() {
        this.closePopUp.emit(true);
    }

}