
export class Additional {
    constructor(
        public pfiName?: string,
        public nameOfBorrower?: string,
        public businessActivity?: string,
        public uen?: string,
        public claimNumber?: string,
        public status?: string,
        public tranche?: string,
        public app?: string,
        public acceptanceDate?: Date,
        public primaryLimit?: Number,
        public topupLimit?: Number,
        public bgLimit?: Number,
        public plusLimit?: Number,
        public outstandingPrincipal?: Number,
        public interest?: Number,
        public legalFees?: Number,
        public reportingDate?: Date,
        public paidDate?: Date,
        public remarks?: String,
    ) {
        
    }
}
