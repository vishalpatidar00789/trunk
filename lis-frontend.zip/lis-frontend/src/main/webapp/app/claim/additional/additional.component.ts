import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';

import { Additional } from './additional.model';
import { Principal } from '../../shared';

@Component({
    selector: 'jhi-additional',
    templateUrl: './additional.component.html'
})
export class AdditionalComponent implements OnInit, OnDestroy {

    additional: Additional = new Additional();
    currentAccount: any;
    eventSubscriber: Subscription;
    isSaving: Boolean;
    routeData: any;
    links: any;
    totalItems: string;
    queryCount: number;
    itemsPerPage: any;
    page: any;
    predicate: any;
    previousPage: any;
    reverse: any;
    additionalApplicationStatus: String;
    displaySuccessMessage: boolean = false;

    constructor(
        private parseLinks: JhiParseLinks,
        private jhiAlertService: JhiAlertService,
        private eventManager: JhiEventManager,
        private principal: Principal,
        private router: Router
    ) {
    }

    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0 || event.charCode == 46 || event.charCode == 44) ? null : event.charCode >= 48 && event.charCode <= 57;
    }

    clear() {
        if (confirm("Are you sure, you want to cancel?")) {
            this.additional = new Additional();
            this.router.navigateByUrl('/');
        }
    }

    private subscribeToSaveResponse(result: Observable<Additional>) {
        result.subscribe((res: Additional) =>
            this.onSaveSuccess(res), (res: Response) => this.onSaveError());
    }

    private onSaveSuccess(result: Additional) {
        this.eventManager.broadcast({ name: 'additionalModification', content: 'OK' });
        this.isSaving = false;
    }

    private onSaveError() {
        this.isSaving = false;
    }

    ngOnInit() {
        this.additionalApplicationStatus = 'In Progress';
        this.principal.identity().then((account) => {
            this.currentAccount = account;
        });
    }

    ngOnDestroy() {

    }

    sort() {
        const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
        if (this.predicate !== 'id') {
            result.push('id');
        }
        return result;
    }

    saveAsDraft() {
        this.additionalApplicationStatus = 'Draft';
        window.scrollTo(0, 0);
        this.displaySuccessMessage = true;
        setTimeout(() => { this.displaySuccessMessage = false; }, 2000);
        // alert('Additional information has been successfully saved as draft');
    }

    private onError(error) {
        this.jhiAlertService.error(error.message, null, null);
    }
}