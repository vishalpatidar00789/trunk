import { Component, OnInit, Input } from '@angular/core';
import { LoanProcess, CompletedStep } from '../../loan';
import { LoanService } from '../../loan/loan.service';

@Component({
  selector: 'lis-loan-navbar',
  templateUrl: './loan-nabar.component.html'
})
export class LoanNavBarComponent implements OnInit {
  @Input() loanUserType: string;
  loanProcess: LoanProcess;
  completedStep = CompletedStep;
  disableStepOne: boolean;
  disableStepTwo: boolean;
  disableStepCompleted: boolean;
  disabled = true;
  constructor(private loanService: LoanService) {
    this.loanService.loanProcess$.subscribe((loanProcess) => {
      this.loanProcess = Object.assign({}, loanProcess);
      this.stepNavigationConfig();
    });
  }

  ngOnInit() {
    this.stepNavigationConfig();
  }

  disableStepNavigation(step: number) {
    switch (step) {
      // Step One
      case 1:
        this.disableStepOne = true;
        if (
          this.loanProcess.completedStep >= this.completedStep.stepOne &&
          this.loanProcess.completedStep !== this.completedStep.stepCompleted
        ) {
          this.disableStepOne = false;
        }
        break;
      // Step Two
      case 2:
        this.disableStepTwo = true;
        if (
          this.loanProcess.completedStep >= this.completedStep.stepTwo &&
          this.loanProcess.completedStep !== this.completedStep.stepCompleted
        ) {
          this.disableStepTwo = false;
        }
        break;
      // Step Completed
      case 3:
        this.disableStepCompleted = true;
        if (
          this.loanProcess.completedStep >= this.completedStep.stepCompleted
        ) {
          this.disableStepCompleted = false;
        }
        break;
    }
  }

  stepNavigationConfig() {
    this.disableStepNavigation(1); // Step One
    this.disableStepNavigation(2); // Step Two
    this.disableStepNavigation(3); // Step Completed
  }
}
