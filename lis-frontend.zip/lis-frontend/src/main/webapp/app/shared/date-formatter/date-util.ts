
export class DateUtil {

    uiDate:any={ day: '' ,month:'',year:''};

    // public getDBDate(date: any): string {
    //     return  date.month+ '-' + date.day + '-' + date.year;
    // }

    public getDBDate(date: any): string {
        //return date.day + '-' + date.month + '-' + date.year;
       
       let dateFromUI;
        if((parseInt(date.day)==31)){
           dateFromUI = new Date(parseInt(date.month) + '/ ' + 31 + '/' + parseInt(date.year));   
        }else{
          dateFromUI = new Date(parseInt(date.month) + '/ ' + (parseInt(date.day) + 1) + '/' + parseInt(date.year));
        }
        return dateFromUI.toISOString();
    }

    public setUIDate(date:string): any {
        let date1=date.split('T');
        let date2=date1[0].split('-');
        this.uiDate={day:parseInt(date2[2]), month:parseInt(date2[1]),year:parseInt(date2[0])};
        return this.uiDate;
    }

    public setUISting(date:string): string {
        let date1 = date.split('T');
        let date2 = date1[0].split('-');        
        return date2[2]+'-'+date2[1]+'-'+date2[0];
    }

}