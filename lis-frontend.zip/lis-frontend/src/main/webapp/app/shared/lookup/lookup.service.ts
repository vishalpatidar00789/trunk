import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

import { SERVER_API_URL } from '../../app.constants';
import { Authority, Bank, Department , Currencies} from '..';

@Injectable()
export class LookupService {
    private resourceUrl = SERVER_API_URL;

    constructor(private http: HttpClient) { }

    authorities(type): Observable<Authority[]> {
        return this.http.get<Authority[]>(this.resourceUrl + 'lookup/authorities?type=' + type);
    }

    banks(): Observable<Bank[]> {
        return this.http.get<Bank[]>(this.resourceUrl + 'lookup/banks');
    }

    getBankByCode(bankCode: string): Observable<Bank> {
        return this.http.get<Bank>(this.resourceUrl + 'lookup/banks/' + bankCode);
    }

    getCurrencyList(){
        return this.http.get<Currencies[]>(this.resourceUrl + 'lookup/currencies');
    }
}
