function addRow(tableId){
		var names = document.getElementById(tableId+"_names").value;
		names = names.split(",");
		var rowCountObj = document.getElementById(tableId+"_rowCount");
		var rowCount = parseInt(rowCountObj.value);
		var rowIndex = parseInt(rowCount)+1;
		var tableRef = document.getElementById(tableId).getElementsByTagName('tbody')[0];
		var thead = document.getElementById(tableId).getElementsByTagName('thead')[0];
		// Insert a row in the table at the last row
		var newRow   = tableRef.insertRow(tableRef.rows.length);
		var cols = thead.rows[0].cells.length;
		
		// Insert a cells
		var fieldName;
		var domObj;
		var data;
		for(var i=0; i<cols;i++){
			var newCell  = newRow.insertCell(i);
			if(i==0){
				newCell.appendChild(document.createTextNode(rowIndex));
			}else if(i==cols-2){
				var a = document.createElement('a');
				var linkText = document.createTextNode("Update");
				a.appendChild(linkText);
				a.href = "javascript:updateRow(\'"+tableId+"',"+rowIndex+");";
				a.id="update_"+tableId+"_"+rowIndex;
				newCell.appendChild(a);
			}else if(i==cols-1){
				var a = document.createElement('a');
				var linkText = document.createTextNode("Delete");
				a.appendChild(linkText);
				a.href = "javascript:deleteRow(\'"+tableId+"',"+rowIndex+");";
				a.id="delete_"+tableId+"_"+rowIndex;
				newCell.appendChild(a);
			}else{
				fieldName = tableId+"["+rowCount+"]"+"."+names[i-1];
				domObj = document.getElementById(tableId+"_"+i);
				data = domObj.value;
				var element = document.createElement("input");
				element.setAttribute("type", "hidden");
			    element.setAttribute("value", data);
			    element.setAttribute("name", fieldName);
			    element.setAttribute("id", fieldName);
				newCell.appendChild(element);
				if(domObj.nodeName==="SELECT"){
					var display = domObj.options[domObj.selectedIndex].text;
					newCell.appendChild( document.createTextNode(display));
				}else{
					newCell.appendChild( document.createTextNode(data));					
				}
			}
		}
		rowCount = rowCount+1;
		rowCountObj.value= rowCount;
		clearFields(tableId);
	}
	
	function deleteRow(tableId,rowCount){
		document.getElementById(tableId).deleteRow(parseInt(rowCount));
		
		var rowCountObj = document.getElementById(tableId+"_rowCount");
		var rowCountVal = parseInt(rowCountObj.value);
		
		var names = document.getElementById(tableId+"_names").value;
		names = names.split(",");
		
		var tableRef = document.getElementById(tableId);
		var thead = tableRef.getElementsByTagName('thead')[0];
		var cols = thead.rows[0].cells.length;
		var rowCnt = tableRef.rows.length;
		var cellObj;
		var index;
		var fieldIndex;
		var field;
		var linkIndex;
		for(var i = parseInt(rowCount);i<rowCnt;i++){
			for(j=0;j<cols;j++){
				if(j==0){
					cellObj = tableRef.rows[i].cells[0];
					index = parseInt(cellObj.innerHTML)-1;
					cellObj.innerHTML = index;
				}else if(j==cols-1){
					linkIndex = parseInt(i)+1;
					var link = document.getElementById("delete_"+tableId+"_"+linkIndex);
					link.href = "javascript:deleteRow(\'"+tableId+"',"+i+");";
					link.id="delete_"+tableId+"_"+i;
				}else if(j==cols-2){
					linkIndex = parseInt(i)+1;
					var link = document.getElementById("update_"+tableId+"_"+linkIndex);
					link.href = "javascript:updateRow(\'"+tableId+"',"+i+");";
					link.id="update_"+tableId+"_"+i;
				}else{
					fieldIndex = parseInt(i)-1;
					fieldName = tableId+"["+fieldIndex+"]"+"."+names[j-1];
					field = document.getElementById(tableId+"["+i+"]"+"."+names[j-1]);
					field.name=fieldName;
					field.id=fieldName;
				}
			}
		}
		
		rowCountVal = rowCountVal-1;
		rowCountObj.value= rowCountVal;
		
	}
	
	function updateRow(tableId,rowCount){
		var fieldIndex = parseInt(rowCount-1);
		var tableRef = document.getElementById(tableId).getElementsByTagName('tbody')[0];
		var thead = document.getElementById(tableId).getElementsByTagName('thead')[0];
		var cols = thead.rows[0].cells.length;
		
		var names = document.getElementById(tableId+"_names").value;
		names = names.split(",");
		var hiddenName;
		var data;
		for(var i=1; i<cols-2;i++){
			hiddenName = tableId+"["+fieldIndex+"]"+"."+names[i-1];
			data = document.getElementById(hiddenName).value;
			document.getElementById(tableId+"_"+i).value = data;
		}
		document.getElementById(tableId+"_update_row_no").value = rowCount;
		document.getElementById("btn_update_"+tableId).disabled=false;
		document.getElementById("btn_save_"+tableId).disabled=true;
		//deleteRow(tableId,rowCount);
	}
	
	
	
	function updateRowContent(tableId){
		var rowCount = document.getElementById(tableId+"_update_row_no").value;
		var fieldIndex = parseInt(rowCount)-1;
		var tableRef = document.getElementById(tableId);
		var thead = tableRef.getElementsByTagName('thead')[0];
		var cols = thead.rows[0].cells.length;
		
		var names = document.getElementById(tableId+"_names").value;
		names = names.split(",");
		var hiddenName;
		var hiddenObj;
		var domObj;
		for(var i=1; i<cols-2;i++){
			hiddenName = tableId+"["+fieldIndex+"]"+"."+names[i-1];
			hiddenObj = document.getElementById(hiddenName);
			domObj = document.getElementById(tableId+"_"+i);
			cellObj = tableRef.rows[rowCount].cells[i];
			if(domObj.nodeName==="SELECT"){
				var display = domObj.options[domObj.selectedIndex].text;
				cellObj.innerHTML = display;
			}else{
				cellObj.innerHTML = domObj.value;					
			}
			
			hiddenObj.value = domObj.value;
			cellObj.appendChild(hiddenObj);
		}
		document.getElementById(tableId+"_update_row_no").value=0;
		clearFields(tableId);
	}
	
	function deleteAddressRow(tableId,rowCount){
		document.getElementById(tableId).deleteRow(parseInt(rowCount));
		
		var rowCountObj = document.getElementById(tableId+"_rowCount");
		var rowCountVal = parseInt(rowCountObj.value);
		
		var names = document.getElementById(tableId+"_names").value;
		names = names.split(",");
		
		var tableRef = document.getElementById(tableId);
		var thead = tableRef.getElementsByTagName('thead')[0];
		var cols = thead.rows[0].cells.length;
		var rowCnt = tableRef.rows.length;
		var cellObj;
		var index;
		var fieldIndex;
		var field;
		var linkIndex;
		for(var i = parseInt(rowCount);i<rowCnt;i++){
			for(j=0;j<cols;j++){
				if(j==0){
					cellObj = tableRef.rows[i].cells[0];
					index = parseInt(cellObj.innerHTML)-1;
					cellObj.innerHTML = index;
				}else if(j==cols-1){
					linkIndex = parseInt(i)+1;
					var link = document.getElementById("delete_"+tableId+"_"+linkIndex);
					link.href = "javascript:deleteAddressRow(\'"+tableId+"',"+i+");";
					link.id="delete_"+tableId+"_"+i;
				}else if(j==cols-2){
					linkIndex = parseInt(i)+1;
					var link = document.getElementById("update_"+tableId+"_"+linkIndex);
					link.href = "javascript:updateRowAddress(\'"+tableId+"',"+i+");";
					link.id="update_"+tableId+"_"+i;
				}else{
					fieldIndex = parseInt(i)-1;
				
					for(var k=1; k<=names.length;k++){
						fieldName = tableId+"["+fieldIndex+"]"+"."+names[k-1];
						field = document.getElementById(tableId+"["+i+"]"+"."+names[k-1]);
						field.name=fieldName;
						field.id=fieldName;
					}
				}
			}
		}
		rowCountVal = rowCountVal-1;
		rowCountObj.value= rowCountVal;
		
	}
	
	function addRowAddress(tableId){
		var names = document.getElementById(tableId+"_names").value;
		names = names.split(",");
		var rowCountObj = document.getElementById(tableId+"_rowCount");
		var rowCount = parseInt(rowCountObj.value);
		var rowIndex = parseInt(rowCount)+1;
		var tableRef = document.getElementById(tableId).getElementsByTagName('tbody')[0];
		var thead = document.getElementById(tableId).getElementsByTagName('thead')[0];
		// Insert a row in the table at the last row
		var newRow   = tableRef.insertRow(tableRef.rows.length);
		var cols = thead.rows[0].cells.length;
		
		// Insert a cells
		for(var i=0; i<cols;i++){
			
			var newCell  = newRow.insertCell(i);
			if(i==0){
				newCell.appendChild(document.createTextNode(rowIndex));
			}else if(i==cols-2){
				var a = document.createElement('a');
				var linkText = document.createTextNode("Update");
				a.appendChild(linkText);
				a.href = "javascript:updateRowAddress(\'"+tableId+"',"+rowIndex+");";
				a.id="update_"+tableId+"_"+rowIndex;
				newCell.appendChild(a);
			}else if(i==cols-1){
				var a = document.createElement('a');
				var linkText = document.createTextNode("Delete");
				a.appendChild(linkText);
				a.href = "javascript:deleteAddressRow(\'"+tableId+"',"+rowIndex+");";
				a.id="delete_"+tableId+"_"+rowIndex;
				newCell.appendChild(a);
			}else{
				var domObj;
				var data;
				var element;
				var addressStr;
				var fieldName;
				for(var j=1; j<=names.length;j++){
					fieldName = tableId+"["+rowCount+"]"+"."+names[j-1];
					domObj = document.getElementById(tableId+"_"+j);
					data = domObj.value;
					element = document.createElement("input");
					element.setAttribute("type", "hidden");
				    element.setAttribute("value", data);
				    element.setAttribute("name", fieldName);
				    element.setAttribute("id", fieldName);
				    newCell.appendChild(element);
				    if(domObj.nodeName==="SELECT"){
				    	data = domObj.options[domObj.selectedIndex].text;
				    	if(data!=""){
				    		if(j==1){
								addressStr = data.concat(",");
							}else if(j==names.length){
								addressStr = addressStr.concat(data.concat("."));
							}else{
								addressStr = addressStr.concat(data.concat(","));
							}	
				    	}
					}else{
						if(data!="" && data!="undefined" && data!=null && data!="null" && data!="NaN"){
							if(j==1){
								addressStr = data.concat(",");
							}else if(j==names.length){
								addressStr = addressStr.concat(data.concat("."));
							}else{
								addressStr = addressStr.concat(data.concat(","));
							}	
						}
					}
				}
				newCell.appendChild(document.createTextNode(addressStr));
			}
		}
		rowCount = rowCount+1;
		rowCountObj.value= rowCount;
		
		clearFields(tableId);
	}
	
	function updateAddressRowContent(tableId){
		var rowCount = document.getElementById(tableId+"_update_row_no").value;
		var fieldIndex = parseInt(rowCount)-1;
		var tableRef = document.getElementById(tableId);
		var thead = tableRef.getElementsByTagName('thead')[0];
		var cols = thead.rows[0].cells.length;
		
		var names = document.getElementById(tableId+"_names").value;
		names = names.split(",");
		var hiddenName;
		var hiddenObj;
		var domObj;
			
		var data;
		var addressStr;
		var cellObj = tableRef.rows[rowCount].cells[1];
		var domIndex;
		var namesLength =parseInt(names.length)-1;
		for(var j=0; j<names.length;j++){
			domIndex = parseInt(j)+1;
			hiddenName = tableId+"["+fieldIndex+"]"+"."+names[j];
			hiddenObj = document.getElementById(hiddenName);
			domObj = document.getElementById(tableId+"_"+domIndex);
			data = domObj.value;
			if(domObj.nodeName==="SELECT"){
		    	data = domObj.options[domObj.selectedIndex].text;
		    	if(data!=""){
		    		if(j==0){
						addressStr = data.concat(",");
					}else if(j==namesLength){
						addressStr = addressStr.concat(data.concat("."));
					}else{
						addressStr = addressStr.concat(data.concat(","));
					}	
		    	}
			}else{
				if(data!="" && data!="undefined" && data!=null && data!="null" && data!="NaN"){
					if(j==0){
						addressStr = data.concat(",");
					}else if(j==namesLength){
						addressStr = addressStr.concat(data.concat("."));
					}else{
						addressStr = addressStr.concat(data.concat(","));
					}
				}
			}
			hiddenObj.value = domObj.value;
			//cellObj.appendChild(hiddenObj);
		}
		//cellObj.innerText = addressStr;
		cellObj.childNodes.item(0).data = addressStr;
		document.getElementById(tableId+"_update_row_no").value=0;
		
		clearFields(tableId);
	}
	
	function updateRowAddress(tableId,rowCount){
		var fieldIndex = parseInt(rowCount-1);
		var tableRef = document.getElementById(tableId).getElementsByTagName('tbody')[0];
		var thead = document.getElementById(tableId).getElementsByTagName('thead')[0];
		var cols = thead.rows[0].cells.length;
		
		var names = document.getElementById(tableId+"_names").value;
		names = names.split(",");
		for(var i=1; i<=names.length;i++){
			var hiddenName = tableId+"["+fieldIndex+"]"+"."+names[i-1];
			var data = document.getElementById(hiddenName).value;
			document.getElementById(tableId+"_"+i).value = data;
		}
		document.getElementById(tableId+"_update_row_no").value = rowCount;
		document.getElementById("btn_update_"+tableId).disabled=false;
		document.getElementById("btn_save_"+tableId).disabled=true;
	}
	
	
	function isEmpty(tableId,index,name){
		var fieldVal = document.getElementById(tableId+"_"+index).value;
		if(fieldVal==""){
			alert("Please enter a valid "+name);
			return false;
		}
		return true;
	}
	
	
	function clearFields(tableId){
		var names = document.getElementById(tableId+"_names").value;
		names = names.split(",");
		var field;
		for(var i=1; i<=names.length;i++){
			field = document.getElementById(tableId+"_"+i);
			field.value = "";
		}
	}
	
	function addAttachmentRow(tableId){
		var rowCountObj = document.getElementById(tableId+"_rowCount");
		var rowCount = parseInt(rowCountObj.value);
		var tableRef = document.getElementById(tableId).getElementsByTagName('tbody')[0];
		// Insert a row in the table at the last row
		var newRow   = tableRef.insertRow(tableRef.rows.length);
		var cell1  = newRow.insertCell(0);cell1.width = "30%";
		var cell2  = newRow.insertCell(1);cell2.width = "60%";
		var cell3  = newRow.insertCell(2);cell3.width = "10%";
		var fieldElement = document.createElement("input");
		
		//vendorAttachments[0].fileAttachment , vendorAttachments_rowCount
		var fileFieldName = tableId+"["+rowCount+"]"+".fileAttachment";
		
		fieldElement.setAttribute("type", "file");
		fieldElement.setAttribute("name", fileFieldName);
		fieldElement.setAttribute("id", fileFieldName);
		cell1.appendChild(fieldElement);
		
		var descElement = document.createElement("input");
	    var descriptionFieldName = tableId+"["+rowCount+"]"+".description";
	    
	    descElement.setAttribute("type", "text");
	    descElement.setAttribute("name", descriptionFieldName);
	    descElement.setAttribute("id", descriptionFieldName);
	    descElement.setAttribute("class", "form-control");
	    descElement.setAttribute("placeholder", "Description");
	    cell2.appendChild(descElement);
	    
	    var linkElement = document.createElement("a");
	    var linkText = document.createTextNode("Delete");
	    linkElement.appendChild(linkText);
	    linkElement.setAttribute("href", "javascript:deleteAttachmentRow('vendorAttachments',"+rowCount+");");
	    linkElement.setAttribute("id","delete_vendorAttachments_"+rowCount);
	    cell3.appendChild(linkElement);
	    
	    rowCountObj.value = parseInt(rowCount+1);
	}
	
	function deleteAttachmentRow(tableId,rowCount){
		document.getElementById(tableId).deleteRow(parseInt(rowCount));
		var rowCountObj = document.getElementById(tableId+"_rowCount");
		var tableRef = document.getElementById(tableId);
		var rowCnt = tableRef.rows.length;
		var cellObj;
		var index;
		var descriptionFieldName;
		var fileFieldName;
		for(var i = parseInt(rowCount);i<rowCnt;i++){
			index = parseInt(i)+1;
			var link = document.getElementById("delete_"+tableId+"_"+index);
			link.href = "javascript:deleteAttachmentRow('vendorAttachments',"+i+");";
			link.id="delete_"+tableId+"_"+i;
			
			descriptionFieldName = tableId+"["+index+"]"+".description";
			var descObj = document.getElementById(descriptionFieldName);
			descObj.id = tableId+"["+i+"]"+".description";
			descObj.name = tableId+"["+i+"]"+".description";
			
			fileFieldName = tableId+"["+index+"]"+".fileAttachment";
			var fileObj = document.getElementById(fileFieldName);
			fileObj.id = tableId+"["+i+"]"+".fileAttachment";
			fileObj.name = tableId+"["+i+"]"+".fileAttachment";
			
		}
		
		rowCountObj.value = parseInt(rowCnt);
	}
	
	
	function validateAddressFields(){
	//vendorAddresses_3 vendorAddresses_4 vendorAddresses_5
		var field1,field2,field3,field4,field5,field6;
		field1 = document.getElementById("vendorAddresses_"+1).value;
		field2 = document.getElementById("vendorAddresses_"+2).value;
		field3 = document.getElementById("vendorAddresses_"+6).value;
		field4 = document.getElementById("vendorAddresses_"+7).value;
		field5 = document.getElementById("vendorAddresses_"+8).value;
		field6 = document.getElementById("vendorAddresses_"+9).value;
		if(''==field1){
			alert('Please enter SPOC Name');
			return false;
		}else if(''==field2){
			alert('Please enter Address Line 1');
			return false;
		}else if(''==field3){
			alert('Please enter State');
			return false;
		}else if(''==field4){
			alert('Please enter City');
			return false;
		}else if(''==field5){
			alert('Please enter Pincode');
			return false;
		}else if(''==field6){
			alert('Please enter SPOC Contact No');
			return false;
		}
		return true;
	}