//Display Session Timeout information in the Statusbar of the window
var sUserInfo;
var iSessionTimeout;
var iSessionTime="";
var sessionflag = true;
var sessionExpiredFlag = false;
var iSessionRefreshCount=1;
var iSessionRefreshCounter=iSessionRefreshCount;

function sessionTimeout(){
	/*if(document.getElementById("sUserInfo")) {
        sUserInfo = document.getElementById("sUserInfo").value;
    }*/
    /*if(document.getElementById("iSessionTimeout")){
        //iSessionTimeout = document.getElementById("iSessionTimeout").value;
    	_resetSessionTime();
    }
    if(sessionflag && iSessionTimeout != null){
        ShowSessionTimeout();
    }*/
}
/*function ShowSessionTimeout()
{
    var iMinutes=0;
    var iSeconds=0;
    if(iSessionTime == "")
        iSessionTime = parseInt(iSessionTimeout/60);
    if (iSessionTimeout > 0)
    {
        iMinutes =  parseInt(iSessionTimeout/60);
        iSeconds =  iSessionTimeout%60;
        if(sUserInfo != "")
            window.status = sUserInfo + ". Your session will expire within " + iMinutes + " minute(s) and " + iSeconds + " second(s).";
        else
            window.status = "Your session will expire within " + iMinutes + " minute(s) and " + iSeconds + " second(s).";

        if(iMinutes == 2 && iSeconds == 0)
        {
            var dtCurr = new Date();
            var iSec = parseInt(dtCurr.getTime()/1000);
            var iMin = iSessionTime - iMinutes;
            alert("Dear User, you have not clicked on any link or button for the last " + iMin + " minutes. Please click on any link or button within next " + iMinutes + " minutes.");
            var dtCurrNew = new Date();
            var iSecNew = parseInt(dtCurrNew.getTime()/1000);
            var iDiff = iSecNew - iSec;
            if(iDiff < iSessionTimeout)
                iSessionTimeout = iSessionTimeout - iDiff;
            else
                iSessionTimeout = 1;
        }
        iSessionTimeout = iSessionTimeout - 1;
        window.setTimeout("ShowSessionTimeout()", 1000);
    }
    else
    {
        window.status = sUserInfo + " Your session expired, Please log on afresh.";
        sessionExpiredFlag = true;
    }
}*/

function ShowSessionTimeout()
{	
	/*if (iSessionTimeout > 0)
	{
		_updateStatusBar();
		iSessionTimeout = iSessionTimeout - 1;
		window.setTimeout("ShowSessionTimeout()", 1000);
	}
	else
	{
		if(iSessionRefreshCounter > 1)
	    {
			iSessionRefreshCounter = iSessionRefreshCounter - 1;
			_refreshSessionTimeout();
	    }
	    else
	    {
	    	_alertUserForSession(1);
	    }
	}*/
}

function _alertUserForSession(waitMinutes)
{
	/*var dtCurr = new Date();
    var iSec = parseInt(dtCurr.getTime()/1000);
    //var iMin = iSessionTime - iMinutes;
    var iMin = ((iSessionTime / 60) * iSessionRefreshCount);
    
    if(confirm("Dear User, you have not clicked on any link or button for the last " + iMin + " minutes. Do you want to maintain your session ?"))
    {
    	var dtCurrNew = new Date();
        var iSecNew = parseInt(dtCurrNew.getTime()/1000);
        var iDiff = iSecNew - iSec;
        
        if(iDiff >= (waitMinutes * 60))
        {
        	alert("Sorry, your session has expired. Please login again.");
        	//window.status = sUserInfo + " Your session expired, Please log on a fresh.";
        	sessionExpiredFlag = true;
        }
        else
        {
        	_refreshSessionTimeout();
        }
    }
    else
    {
    	//window.status = sUserInfo + " Your session expired, Please log on afresh.";
    	sessionExpiredFlag = true;
    }*/
}

function _updateStatusBar()
{
	//var sessionTime = ((iSessionRefreshCounter - 1) * iSessionTime) + iSessionTimeout;
	//var iMinutes= parseInt((sessionTime/60));
	//var iSeconds= sessionTime%60;
    /*if(sUserInfo != "")
        window.status = sUserInfo + ". Your session will expire in " + iMinutes + " minute(s) and " + iSeconds + " second(s).";
    else
        window.status = "Your session will expire in " + iMinutes + " minute(s) and " + iSeconds + " second(s).";*/
}

function _refreshSessionTimeout()
{
	/*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on a fresh.");
        return null;
    }*/
    /*var xmlHttp = GetXmlHttpObject();
    
    xmlHttp.onreadystatechange = function()
    {
        if (xmlHttp.readyState == 4 || xmlHttp.readyState=="complete")
        {
        	if(xmlHttp.status == '200')
        	{
        		if(xmlHttp.responseText == 'T')
        		{
        			_resetSessionTime();
                	window.setTimeout("ShowSessionTimeout()", 1000);
        		}
        		else
        		{
        			alert('Your session has expired. Please login again.');
        			//window.status = sUserInfo + " Your session expired, Please log on a fresh.";
                	//sessionExpiredFlag = true;
        		}
        	}
        	else
        	{
        		window.status = 'Connection error with server. Will try connecting again.';
        		window.setTimeout("_refreshSessionTimeout()", 10000);
        	}
        }
    };
    
    var strURL = "/";
    if(xmlHttp)
    {
    	alert('closing session');
        document.emptyForm.action="${pageContext.request.contextPath}/frontController.do?actionCode=URALOGOFFUSER";
        submitform(document.emptyForm);
    	xmlHttp.open('POST', strURL, true);
        xmlHttp.send(null);
    }*/
}

function _resetSessionTime()
{
	//iSessionTimeout = parseInt(document.getElementById("iSessionTimeout").value); // Server session timeout minus 1 minute (now 1 minute = 60 secomds removed by Priyank)
	//iSessionTime = iSessionTimeout;
}

function _resetSessionRefreshCounter()
{
	//iSessionRefreshCounter = iSessionRefreshCount;
}

// End of Session Timeout 
//Ended By Hardik Shah on 16-Oct-2009

//  Methods implemented in this js:
//
//  "xmlhttpPost"
//  "GetXmlHttpObject"
//  "readXML"
//  "setXML"
//  "xmlPost"
//  "processAJAXRequest"
//  "XMLReqState"
//  "getParamString"
//  "xmlPostIntSave"
//  "xmlPostGetListBox"
//  "processAJAXComboRequest"
//  "populateCombo"
//  
//
//  "processXMLRequest" method should be implemented in the 
//  jsp importing this js and using "xmlhttpPost" method.
//  (Not reqd for jsp's using "xmlPost" method)
//  Sample implementation is shown below
//
//*******Please do not uncomment or delete********//
//function processXMLRequest()
//{
//  if(xmlHttp.getResponseHeader("Content")=="XML")
//  {  
//      var xmlObj = xmlHttp.responseXML;
//      readXML(xmlObj);
//  }
//  else if(xmlHttp.getResponseHeader("Content")=="Message")
//  {
//    alert((xmlHttp.responseText).substring(10))
//  }
//  else
//  {
//      alert("Unable to process the request. Please  contact System Administrator.")
//  }
//}

//************Call to xmlhttpPost('<Controller Path>','<ActionFlag>',<Input ParamArray>) should be made to pass the XML request to Controller*************//
//  Sample implementation is shown below
//
//function fetchDealerFirmName()
//{ if(document.scrRENTReturnsAckn.txt_regno.value!="")
//  {
//      if(validateForm('checkRENTTIN'))
//      {
//      var ParamArray = new Array();
//          ParamArray[0] = document.scrRENTReturnsAckn.txt_regno;
//          ParamArray[1] = document.scrRENTReturnsAckn.lstform; 
//          xmlhttpPost('<%=request.getContextPath()%>/FrontServlet?requestType=RENTAcknController','getDealerDetailsRENTReturns',ParamArray);
//      }
//  }
//  else
//  {
//      clearDetails('1');
//  }
//}
//
var xmlHttp;
var ajaxImageDisplayFlag = 1;   // This means common ajax image needs to display.. make it zero if you want to hide it
function xmlhttpPost(strActionCode,paramArray) 
{
    /*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on afresh.");
        return null;
    }*/
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp) 
    {
      
      strURL = strActionCode;
      var strParams = "";
      for(i=0;i<paramArray.length;i++)
      {
        //strURL = strURL + "&"+ encodeURIComponent(paramArray[i].name) + "=" + encodeURIComponent(paramArray[i].value);
    	  strParams = strParams + encodeURIComponent(paramArray[i].name) + "=" + encodeURIComponent(paramArray[i].value) + "&";
      }
  
      if (ajaxImageDisplayFlag == 1)
      {
    	  //_showDynamicDiv();
      }
      
      xmlHttp.onreadystatechange = function()
      {
          if (xmlHttp.readyState == 4 || xmlHttp.readyState=="complete")
          {
            //sessionflag = false;
            //sessionTimeout();
           // _hideDynamicDiv();
            if (xmlHttp.status == 200) //Numeric code returned by server, such as 404 for "Not Found" or 200 for "OK"
            {
                processXMLRequest('','');
            }
            else
            {
              alert("There was a problem retrieving the XML data:\n" + xmlHttp.statusText);
            }
          }
      };
      xmlHttp.open('POST', strURL, true);
      //xmlHttp.send(null);
      xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      xmlHttp.setRequestHeader("Content-length", strParams.length);
      if(!document.all){
    	  xmlHttp.setRequestHeader("Connection", "close");
      }
      xmlHttp.send(strParams);
      return null;
    }
    else
    {
        alert("Browser is not supporting XML");
    }
}

function GetXmlHttpObject()
{ 
  var objXMLHttp=null;
  if (window.XMLHttpRequest)
  {
    objXMLHttp=new XMLHttpRequest();
  } 
  else if (window.ActiveXObject)
  {
    objXMLHttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  return objXMLHttp;
}


function readXML(xmldoc){
    xmlObj=xmldoc.documentElement;
    var root = xmlObj.getElementsByTagName('param');  
    for (var iNode = 0; iNode < root.length; iNode++) {
        var node = root[iNode];
       
        paramName = readXMLNodeValue(node, 'name');
        paramVal = readXMLNodeValue(node, 'value');
        
        setXML(paramName,paramVal);      
    }
  }
 
function readHTML(xmldoc){
    xmlObj=xmldoc.documentElement;
    var root = xmlObj.getElementsByTagName('param');  
    for (var iNode = 0; iNode < root.length; iNode++) {
      var node = root[iNode];
      
      paramName = readXMLNodeValue(node, 'name');
      paramVal = readXMLNodeValue(node, 'value');
      
      setXML(paramName,paramVal);
    }
  }

function setXML(paramName,paramVal)
{
  var elementColl = null;
	var elementObj = null;
	elementColl = document.getElementsByName(paramName);
        
	for(var i = 0; i < elementColl.length; i++) 
  {
		elementObj = elementColl[i];
		if (elementObj) 
    {
        if (elementObj.type=="text" || elementObj.type=="textarea") {
                elementObj.value = paramVal;
                break;
        }
        
				if (elementObj.type=="select-one" ) 
        {
						if(elementObj) {
								for (var optionIndex=0; optionIndex < elementObj.length; optionIndex++) {
										if(elementObj[optionIndex].value == paramVal) {
												elementObj[optionIndex].selected = true;
												break;
										}
								}
						}
				}
        
				if (elementObj.type=="checkbox") {
						if (elementObj.value==paramVal) {
								elementObj.checked = true;
						}
				}
        
				if (elementObj.type=="radio" ) {
						if (elementObj.value==paramVal) {
								elementObj.checked = true;
						}
				}
        
				if (elementObj.type=="select-multiple" ) {
						if(elementObj) {
								for (var optionIndex=0; optionIndex < elementObj.length; optionIndex++) {
										if(elementObj[optionIndex].value == paramVal) {
												elementObj[optionIndex].selected = true;
												break;
										}
								}
						}
				}
        
				if (elementObj.type=="hidden" ) {
						elementObj.value=paramVal;
				}
   	}
	}
}

function xmlPostMapReturn(strActionCode,paramArray,preFunc,postFunc,alertFunc)
{
      /*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on afresh.");
        return null;
    }*/
    
    xmlPostWithReturn(strActionCode,paramArray,preFunc,beanListpostFunc,alertFunc);
    function beanListpostFunc()
    {
        var xmlString = xmlHttp.responseText ;
        try { //Internet Explorer  
              xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
              xmlDoc.async="false";
              xmlDoc.loadXML(xmlString);
          }
        catch(e)  {
          try { //Firefox, Mozilla, Opera, etc. 
              parser=new DOMParser();
              xmlDoc=parser.parseFromString(xmlString,"text/xml");
          }
          catch(e)  {
              alert(e.message);
              return;
          }
        }
        function beanValAdd (value,key){
            this.value = value;
            this.key = key;
        }
  
        var mapData = new Array();
        var beanList = new Array();
        var beanNode = xmlDoc.getElementsByTagName("map-data");
        if(beanNode(0))
        {
	        var  paramNode = beanNode(0).childNodes;
	        mapData = new Array();
	        for(var pNode = 0; pNode < paramNode.length; pNode++){
	            key = paramNode(pNode).childNodes(0).firstChild.text;
	            value = paramNode(pNode).childNodes(1).text;
	            mapData[pNode] = new beanValAdd(value,key);		 
	        }
        }
        if (postFunc!=null && postFunc!="")
                postFunc(mapData);
    }
    
}

function xmlPostBeanArrayReturn(strActionCode,paramArray,preFunc,postFunc,alertFunc) 
{
     /*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on afresh.");
        return null;
    }*/
    xmlPostWithReturn(strActionCode,paramArray,preFunc,beanListpostFunc,alertFunc, false);
    function beanListpostFunc()
    {
        var xmlString = xmlHttp.responseText ;
        try { //Internet Explorer  
              xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
              xmlDoc.async="false";
              xmlDoc.loadXML(xmlString);
          }
        catch(e)  {
          try { //Firefox, Mozilla, Opera, etc. 
              parser=new DOMParser();
              xmlDoc=parser.parseFromString(xmlString,"text/xml");
          }
          catch(e)  {
              alert(e.message);
              return;
          }
        }
        function beanValAdd (value,key){
            this.value = value;
            this.key = key;
        }
        
        var beanValues = new Array();
        var beanList = new Array();
        var beanNode = xmlDoc.getElementsByTagName("bean-data");
        for(var bNode = 0; bNode < beanNode.length; bNode++){
            //var  paramNode = beanNode[bNode].childNodes;
            var  paramNode = beanNode[bNode].getElementsByTagName('params');
            beanValues = new Array();
            for(var pNode = 0; pNode < paramNode.length; pNode++){
                     //key = paramNode[pNode].childNodes[0].firstChild.nodeValue;
                     //value = paramNode[pNode].childNodes[1].text;
            	
	            	key = readXMLNodeValue(paramNode[pNode], 'name');
	                value = readXMLNodeValue(paramNode[pNode], 'value');
	                //alert("Key:"+key+"\nValue:"+value);
                    beanValues[pNode] = new beanValAdd(value,key);	
            }
            beanList[bNode] = beanValues;
           }
        
        if (postFunc!=null && postFunc!="")
                postFunc(beanList);
    }
}


function xmlPostBeanMultipleArrayReturn(strActionCode,paramArray,preFunc,postFunc,alertFunc) 
{

     /*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on afresh.");
        return null;
    }*/
    
    xmlPostWithReturn(strActionCode,paramArray,preFunc,beanListpostFunc,alertFunc, false);
    function beanListpostFunc()
    {
        var xmlString = xmlHttp.responseText ;
        try { //Internet Explorer  
              xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
              xmlDoc.async="false";
              xmlDoc.loadXML(xmlString);
          }
        catch(e)  {
          try { //Firefox, Mozilla, Opera, etc. 
              parser=new DOMParser();
              xmlDoc=parser.parseFromString(xmlString,"text/xml");
          }
          catch(e)  {
              alert(e.message);
              return;
          }
        }
        function beanValAdd (value,key){
            this.value = value;
            this.key = key;
        }
        var arrayList = new Array();
        var beanValues = new Array();
        
        var arrayNode = xmlDoc.getElementsByTagName("Array-bean-data");
        
        
        for(var aCnt = 0; aCnt < arrayNode.length; aCnt ++)
        {
          var aNode = arrayNode[aCnt];
          var beanList = new Array();
          var beanNode = aNode.getElementsByTagName("bean-data");
            for(var bNode = 0; bNode < beanNode.length; bNode++){
                  //var  paramNode = beanNode[bNode].childNodes;
                  var  paramNode = beanNode[bNode].getElementsByTagName('params');
                  beanValues = new Array();
                  for(var pNode = 0; pNode < paramNode.length; pNode++){
                           //key = paramNode[pNode].childNodes[0].firstChild.nodeValue;
                           //value = paramNode[pNode].childNodes[1].text;
                	  	key = readXMLNodeValue(paramNode[pNode], 'name');
  	                	value = readXMLNodeValue(paramNode[pNode], 'value');
                        
  	                	beanValues[pNode] = new beanValAdd(value,key);		 
                  }
                  beanList[bNode] = beanValues;
           }
            arrayList[aCnt] = beanList;
        }
        
        if (postFunc!=null && postFunc!="")
                postFunc(arrayList);
    }
}

/**
 * The method is used to make ajax post to the server.
 * @param strActionCode
 * @param paramArray
 * @param preFunc
 * @param postFunc
 * @param alertFunc
 * @param asynchronousRequest
 * 		Defaulted to value as true. Pass this value to make the request as required.
 * @return
 */
function xmlPostWithReturn(strActionCode,paramArray,preFunc,postFunc,alertFunc, asynchronousRequest) 
{
	if(asynchronousRequest !== false)asynchronousRequest=true;
	
     /*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on afresh.");
        return null;
    }*/
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp) 
    {
      strURL = strActionCode;
      var queryString = "";
      for(i=0;i<paramArray.length;i++)
      {
        queryString = queryString + encodeURIComponent(paramArray[i].name) + "=" + encodeURIComponent(paramArray[i].value) + "&";
      }
        if (ajaxImageDisplayFlag == 1)
        {
        	//_showDynamicDiv();
        }
        
      if (preFunc!=null && preFunc!="")
        preFunc();
      if(asynchronousRequest)
      {
    	  xmlHttp.onreadystatechange = function()
          {
              if (xmlHttp.readyState == 4 || xmlHttp.readyState=="complete")
              {
                //sessionflag = false;
                //sessionTimeout();
                //_hideDynamicDiv();
                if (xmlHttp.status == 200) //Numeric code returned by server, such as 404 for "Not Found" or 200 for "OK"
                {
                  processAJAXRequest(postFunc,alertFunc);
                }
                else
                {
                  alert("There was a problem retrieving the XML data:\n" + xmlHttp.statusText);
                }
              }
          };  
      }
      
      xmlHttp.open('POST', strURL, asynchronousRequest);// Default is true
      xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xmlHttp.setRequestHeader("Content-length", queryString.length);
      if(!document.all){
    	  xmlHttp.setRequestHeader("Connection", "close");
      }
      xmlHttp.send(queryString);
      
      if(!asynchronousRequest) // Making post function call for synchronous
      {
    	  //sessionflag = false;
         // sessionTimeout();
          //_hideDynamicDiv();
          if (xmlHttp.status == 200) //Numeric code returned by server, such as 404 for "Not Found" or 200 for "OK"
          {
            processAJAXRequest(postFunc,alertFunc);
          }
          else
          {
            alert("There was a problem retrieving the XML data:\n" + xmlHttp.statusText);
          }
      }
      
      return null;
    }
    else
    {
        alert("Browser is not supporting XML");
    }
}

function xmlPost(strActionCode,paramArray) 
{
     /*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on afresh.");
        return null;
    }*/
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp) 
    {
      strURL = strActionCode;
      var strParams = "";
      for(i=0;i<paramArray.length;i++)
      {
        //strURL = strURL + "&"+ encodeURIComponent(paramArray[i].name) + "=" + encodeURIComponent(paramArray[i].value);
        strParams = strParams + encodeURIComponent(paramArray[i].name) + "=" + encodeURIComponent(paramArray[i].value) + "&";
      }
      if (ajaxImageDisplayFlag == 1)
      {
    	  //_showDynamicDiv();
      }
      xmlHttp.onreadystatechange = function()
      {
          if (xmlHttp.readyState == 4 || xmlHttp.readyState=="complete")
          {
           // sessionflag = false;
            //sessionTimeout();
            //_hideDynamicDiv();
            if (xmlHttp.status == 200) //Numeric code returned by server, such as 404 for "Not Found" or 200 for "OK"
            {
              processAJAXRequest('','');
            }
            else
            {
              alert("There was a problem retrieving the XML data:\n" + xmlHttp.statusText);
            }
          }
      };
      xmlHttp.open('POST', strURL, true);
      //	xmlHttp.send(null);
      xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      xmlHttp.setRequestHeader("Content-length", strParams.length);
      if(!document.all){
    	  xmlHttp.setRequestHeader("Connection", "close");
      }
      xmlHttp.send(strParams);
      return null;
    }
    else
    {
        alert("Browser is not supporting XML");
    }
}


function processAJAXRequest(postFunc,alertFunc)
{

  if(xmlHttp.getResponseHeader("Content")=="XML")
  {  
      var xmlObj = xmlHttp.responseXML;
      readXML(xmlObj);
      if (postFunc!=null && postFunc!="")
        postFunc();
  }
  else if(xmlHttp.getResponseHeader("Content")=="Message")
  {
     alert((xmlHttp.responseText).substring(7));
    if (alertFunc!=null && alertFunc!="")
        alertFunc();
  }else if(xmlHttp.getResponseHeader("Content")=="OpenPage")
  {
//location.href =xmlHttp.getResponseHeader("ContextPath")+'/'+ xmlHttp.responseText).substring(19);
  }else if(xmlHttp.getResponseHeader("Content")=="DoNothing")
  {
// alert("Do Nothing")  Pilot phase over-Mohan Commanded
  } 
  else if(xmlHttp.getResponseHeader("Content")=="GetHttpString")
  {
  getRspTextArrayFromXML(xmlHttp.responseText,postFunc);
  }
  else
  {
        alert("Unable to process the request. Please  contact System Administrator.");  
  }
  
  //_hideDynamicDiv();
}

function getRspTextArrayFromXML(responseTxt, postFunc){
        var arrayList = new Array();
        function rspTxtValAdd (key,value){
            this.value = value;
            this.key = trim(key);
        }
        var strKeyVal = responseTxt.split("<rprt-value-ends>");
        for (var cnt = 0; cnt < (strKeyVal.length-1); cnt++){
        var strVal = strKeyVal[cnt].split("<rprt-key-ends>");
        if (strVal.length == 2){
        arrayList[arrayList.length] = new rspTxtValAdd (strVal[0],strVal[1]); }
        }
      if (postFunc!=null && postFunc!="")
                postFunc(arrayList);
    }
    
function trim(str){    if(!str || typeof str != 'string')        return null;    return str.replace(/^[\s]+/,'').replace(/[\s]+$/,'').replace(/[\s]{2,}/,' ');}
//  Object status integer:
//  0 = uninitialized
//  1 = loading
//  2 = loaded
//  3 = interactive
//  4 = complete
function XMLReqState()
{
  if(xmlHttp!=null && (xmlHttp.readyState!="undefined"))
    return xmlHttp.readyState;
}

function getParamString(formObj)
{
    var paramString = "";
    for (i = 0; i < formObj.elements.length; i++ )
    {
        elementObj = formObj.elements[i];
        if(elementObj.name!="undefined" && elementObj.name!="")
        {            
          if ((elementObj.type == "text" || elementObj.type == "textarea" || elementObj.type == "hidden" )&& elementObj.value!="")
          {   
              paramString = paramString + "&" + encodeURIComponent(elementObj.name) + "=" + encodeURIComponent(elementObj.value);
          }
          else if ((elementObj.type == "select-one") && ((elementObj.length)>0))
          {
            if (elementObj.selectedIndex != -1)
            {
              paramString = paramString + "&" + encodeURIComponent(elementObj.name) + "=" + encodeURIComponent(elementObj[elementObj.selectedIndex].value);
            }
          }
          else if (elementObj.type == "select-multiple")
          {
              for (var optionIndex=0; optionIndex < elementObj.length; optionIndex++) 
              {
                if(elementObj[optionIndex].selected)
                {
                    paramString = paramString + "&" + encodeURIComponent(elementObj.name) + "=" + encodeURIComponent(elementObj[optionIndex].value);
                }
              }
          }
          else if ((elementObj.type == "radio" || elementObj.type == "checkbox") && elementObj.checked)
          { 
              paramString = paramString + "&" + encodeURIComponent(elementObj.name) + "=" + encodeURIComponent(elementObj.value);
          }
        }
    }
    return paramString;
}

var bkpTaskCategory="";
function xmlPostIntSave(strActionCode,formObj) 
{
     /*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on afresh.");
        return null;
    }*/
  // alert("before ajax 1");
     if(formObj.taskCategory){
         bkpTaskCategory=formObj.taskCategory.value;
         formObj.taskCategory.value="";
     }
    // alert("before ajax 2");
    xmlHttp = GetXmlHttpObject();
    
    if (xmlHttp) 
    {
      strURL = strActionCode;      
      
      // Changes to append execution id
      /*var execIdObj = (document.processInfoForm)?document.processInfoForm.procExeIdVar:null;
      if(execIdObj != null)
    	  strURL += "&processExecId=" + execIdObj.value;*/
      
      queryString = getParamString(formObj);
      if (ajaxImageDisplayFlag == 1)
      {
    	 // _showDynamicDiv();
      }
      xmlHttp.onreadystatechange = function()
      {
          if (xmlHttp.readyState == 4 || xmlHttp.readyState=="complete")
          {
            //sessionflag = false;
            //sessionTimeout();
            //_hideDynamicDiv();
            if (xmlHttp.status == 200) //Numeric code returned by server, such as 404 for "Not Found" or 200 for "OK"
            {
              processAJAXRequest();
            //alert("after ajax 1");
              if(formObj.taskCategory){
                  formObj.taskCategory.value=bkpTaskCategory;
                  bkpTaskCategory="";
              }
                //alert("after ajax 2");
            }
            else
            {
              alert("There was a problem retrieving the XML data:\n" + xmlHttp.statusText);
            }
          }
      };
      xmlHttp.open('POST', strURL, true);
      xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xmlHttp.setRequestHeader("Content-length", queryString.length);
      if(!document.all){
    	  xmlHttp.setRequestHeader("Connection", "close");
      }
      xmlHttp.send(queryString);
      return null;
    }
    else
    {
        alert("Browser is not supporting XML");
    }
}

//added by Siddharth Shah (242125) - 24 Jan 2011 for interim save of Selected Fields : Starts
function xmlPostIntSaveSelFields() 
{
    strActionCode = arguments[0];
     /*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on afresh.");
        return null;
    }*/
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp) 
    {
      strURL = strActionCode;  
      var paramString  = '';
      queryString = getParamString2(paramString,arguments);
      if (ajaxImageDisplayFlag == 1)
        {
        //crtDynamicDiv();
        //document.getElementById('blankImage').style.display = 'block';
        //document.getElementById('rotaterImage').style.display = 'block';
        }
      xmlHttp.onreadystatechange = function()
      {
          if (xmlHttp.readyState == 4 || xmlHttp.readyState=="complete")
          {
            //sessionflag = false;
           // sessionTimeout();
            if (xmlHttp.status == 200) //Numeric code returned by server, such as 404 for "Not Found" or 200 for "OK"
            {
              processAJAXRequest();
            }
            else
            {
              alert("There was a problem retrieving the XML data:\n" + xmlHttp.statusText);
            }
          }
      }
      xmlHttp.open('POST', strURL, true);
      xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xmlHttp.send(queryString);
      return null;
    }
    else
    {
        alert("Browser is not supporting XML");
    }
}
function getParamString2(paramString,arguments) {

 for( var i = 1; i < arguments.length; i++ ) 
    {
     paramString = paramString + "&" + encodeURIComponent(arguments[i]) + "=" + encodeURIComponent(document.getElementById(arguments[i]).value);
    } 

  //  alert("paramString = " + paramString);
   return paramString;
}

//added by Siddharth Shah (242125) - 24 Jan 2011 for interim save of Selected Fields : Ends

//added by Dipika M - 5th March 2010 for interim save of a single tab : starts
function xmlPostIntSaveSingleTab(strActionCode,formObj) 
{
     /*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on afresh.");
        return null;
    }*/
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp) 
    {
      strURL = strActionCode;  
      var paramString  = '';
      queryString = getParamString1(paramString,formObj);
      if (ajaxImageDisplayFlag == 1)
        {
        //crtDynamicDiv();
        //document.getElementById('blankImage').style.display = 'block';
        //document.getElementById('rotaterImage').style.display = 'block';
        }
      xmlHttp.onreadystatechange = function()
      {
          if (xmlHttp.readyState == 4 || xmlHttp.readyState=="complete")
          {
            //sessionflag = false;
            //sessionTimeout();
            if (xmlHttp.status == 200) //Numeric code returned by server, such as 404 for "Not Found" or 200 for "OK"
            {
              processAJAXRequest();
            }
            else
            {
              alert("There was a problem retrieving the XML data:\n" + xmlHttp.statusText);
            }
          }
      }
      xmlHttp.open('POST', strURL, true);
      xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xmlHttp.send(queryString);
      return null;
    }
    else
    {
        alert("Browser is not supporting XML");
    }
}


function getParamString1(paramString,formObj) {
 var eleTableRows = formObj.getElementsByTagName("INPUT"); 
 var eleTableTxtareaRows = formObj.getElementsByTagName("TEXTAREA");
 
 var eleTableSelect = formObj.getElementsByTagName("select");
 for(var i=0; i < eleTableRows.length; i++)  {
        //if(eleTableRows[i].value!="")
        elementObj = eleTableRows[i];
        if(elementObj){
            if ((elementObj.type == "text" || elementObj.type == "textarea" || elementObj.type == "hidden")&& elementObj.value!="") {   
                paramString = paramString + "&" + encodeURIComponent(elementObj.name) + "=" + encodeURIComponent(elementObj.value);
            }            
             else if ((elementObj.type == "radio" || elementObj.type == "checkbox") && elementObj.checked)
          { 
              paramString = paramString + "&" + encodeURIComponent(elementObj.name) + "=" + encodeURIComponent(elementObj.value);
          }
        }
    }
    for(var j=0; j < eleTableTxtareaRows.length; j++)  {
        elementObj = eleTableTxtareaRows[j];
        if(elementObj){
               paramString = paramString + "&" + encodeURIComponent(elementObj.name) + "=" + encodeURIComponent(elementObj.value);
        }
    }
    
     for(var k=0; k < eleTableSelect.length; k++)  {
        elementObj = eleTableSelect[k];
        if(elementObj){
               paramString = paramString + "&" + encodeURIComponent(elementObj.name) + "=" + encodeURIComponent(elementObj.value);
        }
    }
    
   return paramString;
}

//added by Dipika M - 5th March 2010 for interim save of a single tab : ends

// Added By Mohan (181988), For Posting the Multiselect Combo Data

function xmlPostMultiSelectComboData(strActionCode,elementObj) 
{
     /*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on afresh.");
        return null;
    }*/
    xmlHttp = GetXmlHttpObject();
    var queryString = "";
    if (xmlHttp) 
    {
    strURL = strActionCode;      
    for (var optionIndex=0; optionIndex < elementObj.length; optionIndex++) 
    {
      if(elementObj[optionIndex].selected)
      {
          queryString = queryString + "&" + encodeURIComponent(elementObj.name) + "=" + encodeURIComponent(elementObj[optionIndex].value);
      }
    }     
    
    if (ajaxImageDisplayFlag == 1)
    {
    	//_showDynamicDiv();
    }
    xmlHttp.onreadystatechange = function()
      {
          if (xmlHttp.readyState == 4 || xmlHttp.readyState=="complete")
          {
            //sessionflag = false;
            //sessionTimeout();
            //_hideDynamicDiv();
            if (xmlHttp.status == 200) //Numeric code returned by server, such as 404 for "Not Found" or 200 for "OK"
            {
              processAJAXRequest();
            }
            else
            {
              alert("There was a problem retrieving the XML data:\n" + xmlHttp.statusText);
            }
          }
      };
      xmlHttp.open('POST', strURL, true);
      xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xmlHttp.setRequestHeader("Content-length", queryString.length);
      if(!document.all){
    	  xmlHttp.setRequestHeader("Connection", "close");
      }
      xmlHttp.send(queryString);
      return null;
    }
    else
    {
        alert("Browser is not supporting XML");
    }
}


// Added By Mohan (181988), For Saving Data In Database- With Pre Post and Alert Function

function xmlPostSaveData(strActionCode,formObj,preFunc,postFunc,alertFunc) 
{
     /*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on afresh.");
        return null;
    }*/
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp) 
    {
    strURL = strActionCode;      
    queryString = getParamString(formObj);
    if (ajaxImageDisplayFlag == 1)
    {
    	//_showDynamicDiv();
    }
      if (preFunc!=null && preFunc!="")
        preFunc();
      xmlHttp.onreadystatechange = function()
      {
          if (xmlHttp.readyState == 4 || xmlHttp.readyState=="complete")
          {
            //sessionflag = false;
            sessionTimeout();
            _hideDynamicDiv();
            if (xmlHttp.status == 200) //Numeric code returned by server, such as 404 for "Not Found" or 200 for "OK"
            {
              processAJAXRequest(postFunc,alertFunc);
            }
            else
            {
              alert("There was a problem retrieving the XML data:\n" + xmlHttp.statusText);
            }
          }
      };
      xmlHttp.open('POST', strURL, true);
      xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xmlHttp.setRequestHeader("Content-length", queryString.length);
      if(!document.all){
    	  xmlHttp.setRequestHeader("Connection", "close");
      }
      xmlHttp.send(queryString);
      return null;
    }
    else
    {
        alert("Browser is not supporting XML");
    }
}



function xmlPostGetListBox(strActionCode,lb_Type,lbObj) 
{
     /*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on afresh.");
        return null;
    }*/
    var cmbLength = lbObj.length;
    for (i = cmbLength; i > 0;   i--)  
    {
       lbObj.remove(i);
    }
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp) 
    {
      strURL = strActionCode+"ListBoxType="+encodeURIComponent(lb_Type);
      if (ajaxImageDisplayFlag == 1)
      {
    	  //_showDynamicDiv();
      }
      xmlHttp.onreadystatechange = function()
      {
          if (xmlHttp.readyState == 4 || xmlHttp.readyState=="complete")
          {
            //sessionflag = false;
            sessionTimeout();
            _hideDynamicDiv();
            if (xmlHttp.status == 200) //Numeric code returned by server, such as 404 for "Not Found" or 200 for "OK"
            {
              processAJAXComboRequest(lbObj);
            }
            else
            {
              alert("There was a problem retrieving the XML data:\n" + xmlHttp.statusText);
            }
          }
      };
      xmlHttp.open('POST', strURL, true);
      xmlHttp.send(null);
      return null;
    }
    else
    {
        alert("Browser is not supporting XML");
    }
}

// for getting data from any table using Controllers to populate combo
function xmlPostGetCombo(strActionCode,paramArray,lbObj,isAsynchronousRequest) 
{
	if(isAsynchronousRequest !== false)isAsynchronousRequest=true;
	
     /*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on afresh.");
        return null;
    }*/
    
    //Remove the combo options
    var cmbLength = lbObj.length;
    for (i = cmbLength; i > 0;   i--)  
    {
       lbObj.remove(i);
    }
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp) 
    {
      strURL = strActionCode;
      var strParams = "";
      for(i=0;i<paramArray.length;i++)
      {
        //strURL = strURL + "&"+ encodeURIComponent(paramArray[i].name) + "=" + encodeURIComponent(paramArray[i].value);
        strParams = strParams + encodeURIComponent(paramArray[i].name) + "=" + encodeURIComponent(paramArray[i].value) + "&";
      }
      if (ajaxImageDisplayFlag == 1)
      {
    	  //_showDynamicDiv();
      }
      
      if(isAsynchronousRequest)
      {
		      xmlHttp.onreadystatechange = function()
		      {
		          if (xmlHttp.readyState == 4 || xmlHttp.readyState=="complete")
		          {
		            //sessionflag = false;
		            //sessionTimeout();
		            //_hideDynamicDiv();
		            if (xmlHttp.status == 200) //Numeric code returned by server, such as 404 for "Not Found" or 200 for "OK"
		            {
		              processAJAXComboRequest(lbObj);
		            }
		            else
		            {
		              alert("There was a problem retrieving the XML data:\n" + xmlHttp.statusText);
		            }
		          }
		    };
      }
      //xmlHttp.open('POST', strURL, true);
    	xmlHttp.open('POST', strURL, isAsynchronousRequest);
      //xmlHttp.send(null);
      xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      xmlHttp.setRequestHeader("Content-length", strParams.length);
      if(!document.all){
    	  xmlHttp.setRequestHeader("Connection", "close");
      }
      xmlHttp.send(strParams);
      if(!isAsynchronousRequest)
      {
    	  //sessionflag = false;
          //sessionTimeout();
          //_hideDynamicDiv();
          if (xmlHttp.status == 200) //Numeric code returned by server, such as 404 for "Not Found" or 200 for "OK"
          {
            processAJAXComboRequest(lbObj);
          }
          else
          {
            alert("There was a problem retrieving the XML data:\n" + xmlHttp.statusText);
          }
      }
      return null;
    }
    else
    {
        alert("Browser is not supporting XML");
    }
}

function xmlPostGetHttpResponseTxt(strActionCode,paramArray, postFunc) {
 /*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on afresh.");
        return null;
    }*/
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp) 
    {
      var strURL = new String(strActionCode);
      var strParams = "";
      if (strURL.indexOf("/")<0){
      strURL = strActionCode; 
      }
      
      for(i=0;i<paramArray.length;i++)
      {
//        strURL = strURL + "&"+ encodeURIComponent(paramArray[i].name) + "=" + encodeURIComponent(paramArray[i].value);
    	  strParams = strParams + encodeURIComponent(paramArray[i].name) + "=" + encodeURIComponent(paramArray[i].value) + "&";
      }
      if (ajaxImageDisplayFlag == 1)
      {
    	  //_showDynamicDiv();
      }
      xmlHttp.onreadystatechange = function()
      {
          if (xmlHttp.readyState == 4 || xmlHttp.readyState=="complete")
          {
            //sessionflag = false;
            //sessionTimeout();
            //_hideDynamicDiv();
            if (xmlHttp.status == 200) //Numeric code returned by server, such as 404 for "Not Found" or 200 for "OK"
            {
              processAJAXRequest(postFunc);
            }
            else
            {
              alert("There was a problem retrieving the XML data:\n" + xmlHttp.statusText);
            }
          }
    };
      xmlHttp.open('POST', strURL, true);
      //xmlHttp.send(null);
      xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      xmlHttp.setRequestHeader("Content-length", strParams.length);
      if(!document.all){
    	  xmlHttp.setRequestHeader("Connection", "close");
      }
      xmlHttp.send(strParams);
      return null;
    }
    else
    {
        alert("Browser is not supporting XML");
    }
}


function processAJAXComboRequest(comboObj)
{
//  alert(xmlHttp.getResponseHeader("Content"));
  if(xmlHttp.getResponseHeader("Content")=="XML")
  {
      var xmlObj = xmlHttp.responseXML;
      populateCombo(xmlObj,comboObj);
  }else if(xmlHttp.getResponseHeader("Content")=="Message")
  {
    alert((xmlHttp.responseText).substring(7));
  }
  else
  {
    if(xmlHttp.getResponseHeader("ContextPath")!=null)
      location.href = xmlHttp.getResponseHeader("ContextPath")+"/Error/send.jsp?VastisMsg=System Error.Please contact Database Administrator.";
    else
      {
          /*if(sessionflag == false)
          {
            alert("Your session expired, Please log on afresh.");
          }
          else
          {
            alert("Unable to process the request. Please  contact System Administrator.");  
          }*/
      }
  }
  //_hideDynamicDiv();
}



function populateCombo(xmldoc,comboObj)
  {
    xmlObj=xmldoc.documentElement;
    var root = xmlObj.getElementsByTagName('param');
    for (var iNode = 0; iNode < root.length; iNode++) 
    {
      var node = root[iNode];
      if(node.childNodes[1].firstChild!=null)
      {
        var oOption = document.createElement("option");    
        var key = readXMLNodeValue(node, 'value');
        oOption.text = key;
        oOption.title = key;
        oOption.value = readXMLNodeValue(node, 'name');
        
        //comboObj.add(oOption);
        addOptionInSelectObj(comboObj,oOption);
      }
    }
  }
  
  
function displayLoading()
  {
		/*var objLoad = document.getElementById("loading");    
		objLoad.style.display="block";
		objLoad.style.visibility="visible";
		var x = (document.body.offsetWidth)/2 + document.body.scrollLeft;
		var y = (document.body.offsetHeight)/2 + document.body.scrollTop;
                objLoad.style.left=x-300;
		objLoad.style.top=y;*/
    }
  

function hideLoading()
  {
  //document.getElementById("loading").style.display="none";
  }


function crtDynamicDiv(){
	/*dv = document.getElementById('blankImage');
	if(!dv)
	{
		dv = document.createElement('div'); 
		dv.setAttribute('id',"blankImage");    
		dv.className="forBlankImageToBlur";
		dv.innerHTML='&nbsp;';
		//document.forms[0].appendChild(dv);
		document.body.appendChild(dv);
	}

	dv = null;
	dv = document.getElementById('rotaterImage');
	if(!dv)
	{
		dv = document.createElement('div'); 
		dv.setAttribute('id',"rotaterImage");    
		dv.className="forAjaxImage";
		dv.innerHTML='&nbsp;';
		//document.forms[0].appendChild(dv);
		document.body.appendChild(dv);
	}*/
}

function _showDynamicDiv()
{
	/*crtDynamicDiv();
	var div = document.getElementById('blankImage');
	if(div)
		div.style.display = 'block';
	
	div = document.getElementById('rotaterImage');
	if(div)
		div.style.display = 'block';*/
}

function _hideDynamicDiv()
{
	/*var div = document.getElementById('blankImage');
	if(div)
		div.style.display = 'none';
	
	div = null;
	div = document.getElementById('rotaterImage');
	if(div)
		div.style.display = 'none';*/
}

function readXMLNodeValue(nodeObj, childNodeName)
{
	var value = '';
	if(nodeObj.getElementsByTagName(childNodeName)[0]&& nodeObj.getElementsByTagName(childNodeName)[0].childNodes[0])
	{	
		value = nodeObj.getElementsByTagName(childNodeName)[0].childNodes[0].nodeValue;
	}
	return value;
}

function processAJAXComboRequestwithReturn(comboObj,postFunc,alertFunc)
{
 //alert(xmlHttp.getResponseHeader("Content"));
  if(xmlHttp.getResponseHeader("Content")=="XML")
  {
      var xmlObj = xmlHttp.responseXML;
      populateCombo(xmlObj,comboObj);
      if (postFunc!=null && postFunc!="")
        postFunc();
  }else if(xmlHttp.getResponseHeader("Content")=="Message")
  {
    alert((xmlHttp.responseText).substring(7));
    if (alertFunc!=null && alertFunc!="")
        alertFunc();
  }  else
  {
    if(xmlHttp.getResponseHeader("ContextPath")!=null)
      location.href = xmlHttp.getResponseHeader("ContextPath")+"/Error/send.jsp?VastisMsg=System Error.Please contact Database Administrator.";
    else
      {
          /*if(sessionflag == false)
          {
            alert("Your session expired, Please log on afresh.")  
          }
          else
          {
            alert("Unable to process the request. Please  contact System Administrator.");  
          }*/
      }
  }
   if (ajaxImageDisplayFlag == 1) {
        //document.getElementById('blankImage').style.display = 'none';
       // document.getElementById('rotaterImage').style.display = 'none';
        }
}

function xmlPostGetComboWithReturn(strActionCode,paramArray,lbObj,preFunc,postFunc,alertFunc)
{
    /*if(sessionExpiredFlag == true)
    {
        alert("Your session expired, Please log on afresh.");
        return null;
    }*/
    
    //Remove the combo options
    var cmbLength = lbObj.length;
    for (i = cmbLength; i > 0;   i--)  
    {
       lbObj.remove(i);
    }
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp) 
    {
      strURL = strActionCode;
      for(i=0;i<paramArray.length;i++)
      {
        strURL = strURL + "&"+ encodeURIComponent(paramArray[i].name) + "=" + encodeURIComponent(paramArray[i].value);
      }
      if (ajaxImageDisplayFlag == 1)
        {
        //crtDynamicDiv();
        //document.getElementById('blankImage').style.display = 'block';
       // document.getElementById('rotaterImage').style.display = 'block';
        }
         if (preFunc!=null && preFunc!="")
        preFunc();
      xmlHttp.onreadystatechange = function()
      {
          if (xmlHttp.readyState == 4 || xmlHttp.readyState=="complete")
          {
            //sessionflag = false;
            //sessionTimeout();
            if (xmlHttp.status == 200) //Numeric code returned by server, such as 404 for "Not Found" or 200 for "OK"
            {
              processAJAXComboRequestwithReturn(lbObj,postFunc,alertFunc);
            }
            else
            {
              alert("There was a problem retrieving the XML data:\n" + xmlHttp.statusText);
            }
          }
    }
      xmlHttp.open('POST', strURL, true);
      xmlHttp.send(null);
      return null;
    }
    else
    {
        alert("Browser is not supporting XML");
    }
}  

