package com.klicksort.apps.vms.exception;

public class VendorException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6725679186466523444L;

	public VendorException(){
		super();
	}
	
	public VendorException(String message){
		super(message);
	}
	
	public VendorException(String message, Throwable cause){
		super(message, cause);
	}
	
	public VendorException(Throwable cause){
		super("Vendor is not active.", cause);
	}
}
