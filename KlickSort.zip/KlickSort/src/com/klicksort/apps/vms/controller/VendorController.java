package com.klicksort.apps.vms.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.klicksort.apps.common.manager.ServiceManager;
import com.klicksort.apps.common.service.CommonService;
import com.klicksort.apps.vms.dto.VendorActivityView;
import com.klicksort.apps.vms.dto.VendorAttachmentsView;
import com.klicksort.apps.vms.dto.VendorDetailView;
import com.klicksort.apps.vms.dto.VendorForm;
import com.klicksort.apps.vms.exception.VendorException;
import com.klicksort.apps.vms.service.VendorService;
@Controller
public class VendorController {
	
	@RequestMapping(value="/vendor_management_screen",method=RequestMethod.GET)
	public String viewVendorManagementScreen(HttpServletRequest request, Model model){
		VendorService vendorService = null;
		CommonService commonService = null;
		try {
			vendorService = (VendorService) ServiceManager.getBean("vendorService");
			commonService = (CommonService) ServiceManager.getBean("commonService");
			VendorForm vendorForm = new VendorForm();
			vendorForm.setBrands(vendorService.getBrands());
			vendorForm.setActivities(vendorService.getActivities());
			vendorForm.setCategories(vendorService.getCategories());
			vendorForm.setStates(commonService.getStates());
			vendorForm.setCities(commonService.getCities());
			model.addAttribute("vendorForm", vendorForm);
			//request.setAttribute("vendorForm", vendorForm);
		} catch (Exception e) {
			if(e instanceof VendorException){
				model.addAttribute("errMsg", e.getMessage());
			}
			e.printStackTrace();
		}
		
		return "vendorManagementForm";
	}
	
	@RequestMapping(value="/save_vendor",method=RequestMethod.POST)
	public String saveVendorDetail(@ModelAttribute("vendorForm") VendorForm vendorForm, HttpServletRequest request, Model model){
		VendorService vendorService = null;
		CommonService commonService = null;
		try {
			if(null!=vendorForm){
				vendorService = (VendorService) ServiceManager.getBean("vendorService");
				commonService = (CommonService) ServiceManager.getBean("commonService");
				if(null!=vendorForm.getVendorDetail()){
					VendorDetailView  vendorDetailView = vendorService.saveVendorDetails(vendorForm.getVendorDetail());
					if(null!=vendorDetailView){
						vendorForm.setVendorDetail(vendorDetailView);
					}else{
						throw new VendorException("There is no detail to save/update");
					}
				}else{
					throw new VendorException("There is no detail to save/update");
				}
				vendorForm.setSaveOrUpdate(false);
				vendorForm.setBrands(vendorService.getBrands());
				vendorForm.setActivities(vendorService.getActivities());
				vendorForm.setCategories(vendorService.getCategories());
				vendorForm.setStates(commonService.getStates());
				vendorForm.setCities(commonService.getCities());
				model.addAttribute("vendorForm", vendorForm);
			}else{
				// throw some message
			}
		} catch (Exception e) {
			if(e instanceof VendorException){
				model.addAttribute("errMsg", e.getMessage());
			}
			e.printStackTrace();
		}
		
		return "vendorManagementForm";
	}
	
	
	@RequestMapping(value="/vendor_form",method=RequestMethod.POST)
	public String getVendorFormByVendorId(@ModelAttribute("vendorForm") VendorForm vendorForm, HttpServletRequest request, Model model){
		try {
			if(null!=vendorForm){
				if(null!=vendorForm.getVendorDetail().getVendorId() && !"".equals(vendorForm.getVendorDetail().getVendorId())){
					this.populateVendorForm(vendorForm);
				}else{
					// throw some message
				}
				model.addAttribute("vendorForm", vendorForm);
			}else{
				// throw some message
			}
		} catch (Exception e) {
			if(e instanceof VendorException){
				model.addAttribute("errMsg", e.getMessage());
			}
			e.printStackTrace();
		}
		return "vendorManagementForm";
	}
	
	@RequestMapping(value="/save_vendor_brands",method=RequestMethod.POST)
	public String saveVendorBrands(@ModelAttribute("vendorForm") VendorForm vendorForm, HttpServletRequest request, Model model){
		VendorService vendorService = null;
		String msg = null;
		try {
			if(null!=vendorForm){
				vendorService = (VendorService) ServiceManager.getBean("vendorService");
				if(null!=vendorForm.getVendorDetail().getVendorId() && !"".equals(vendorForm.getVendorDetail().getVendorId())){
					msg = vendorService.saveVendorBrands(vendorForm.getVendorBrands(),Long.parseLong(vendorForm.getVendorDetail().getVendorId()),vendorForm.isSaveOrUpdate());
				}else{
					throw new VendorException("No vendor id found. Please enter vendor id.");
				}
				this.populateVendorForm(vendorForm);
				model.addAttribute("vendorForm", vendorForm);
				model.addAttribute("message", msg);
			}else{
				// throw some message
			}
		} catch (Exception e) {
			if(e instanceof VendorException){
				model.addAttribute("errMsg", e.getMessage());
			}
			e.printStackTrace();
		}
		
		return "vendorManagementForm";
	}
	
	@RequestMapping(value="/save_vendor_activities",method=RequestMethod.POST)
	public String saveVendorActivities(@ModelAttribute("vendorForm") VendorForm vendorForm, HttpServletRequest request, Model model){
		VendorService vendorService = null;
		String msg = null;
		try {
			if(null!=vendorForm){
				vendorService = (VendorService) ServiceManager.getBean("vendorService");
				if(null!=vendorForm.getVendorDetail().getVendorId() && !"".equals(vendorForm.getVendorDetail().getVendorId())){
					List<String> selectedActivities = vendorForm.getSelectedActivities();
					List<VendorActivityView> vendorActivities = null;
					if(null!=selectedActivities && selectedActivities.size()>0){
						vendorActivities = new ArrayList<VendorActivityView>();
						VendorActivityView activityView = null;
						for(String activity :selectedActivities){
							activityView = new VendorActivityView();
							activityView.setActivityCode(activity);
							vendorActivities.add(activityView);
						}
						vendorForm.setVendorActivities(vendorActivities);
						msg = vendorService.saveVendorActivities(vendorForm.getVendorActivities(),Long.parseLong(vendorForm.getVendorDetail().getVendorId()),vendorForm.isSaveOrUpdate());
					}
					
				}else{
					throw new VendorException("No vendor id found. Please enter vendor id.");
				}
				this.populateVendorForm(vendorForm);
				model.addAttribute("vendorForm", vendorForm);
				model.addAttribute("message", msg);
			}else{
				// throw some message
			}
		} catch (Exception e) {
			if(e instanceof VendorException){
				model.addAttribute("errMsg", e.getMessage());
			}
			e.printStackTrace();
		}
		
		return "vendorManagementForm";
	}
	
	@RequestMapping(value="/save_vendor_product_categories",method=RequestMethod.POST)
	public String saveVendorCategories(@ModelAttribute("vendorForm") VendorForm vendorForm, HttpServletRequest request, Model model){
		VendorService vendorService = null;
		String msg = null;
		try {
			if(null!=vendorForm){
				vendorService = (VendorService) ServiceManager.getBean("vendorService");
				if(null!=vendorForm.getVendorDetail().getVendorId() && !"".equals(vendorForm.getVendorDetail().getVendorId())){
					msg = vendorService.saveVendorProductCategories(vendorForm.getVendorProductCategories(),Long.parseLong(vendorForm.getVendorDetail().getVendorId()),vendorForm.isSaveOrUpdate());
				}else{
					throw new VendorException("No vendor id found. Please enter vendor id.");
				}
				this.populateVendorForm(vendorForm);
				model.addAttribute("vendorForm", vendorForm);
				model.addAttribute("message", msg);
			}else{
				// throw some message
			}
		} catch (Exception e) {
			if(e instanceof VendorException){
				model.addAttribute("errMsg", e.getMessage());
			}
			e.printStackTrace();
		}
		
		return "vendorManagementForm";
	}
	
	
	@RequestMapping(value="/save_vendor_terms",method=RequestMethod.POST)
	public String saveVendorTerms(@ModelAttribute("vendorForm") VendorForm vendorForm, HttpServletRequest request, Model model){
		VendorService vendorService = null;
		String msg = null;
		try {
			if(null!=vendorForm){
				vendorService = (VendorService) ServiceManager.getBean("vendorService");
				if(null!=vendorForm.getVendorDetail().getVendorId() && !"".equals(vendorForm.getVendorDetail().getVendorId())){
					msg = vendorService.saveVendorTerms(vendorForm.getVendorTerms(),Long.parseLong(vendorForm.getVendorDetail().getVendorId()),vendorForm.isSaveOrUpdate());
				}else{
					throw new VendorException("No vendor id found. Please enter vendor id.");
				}
				this.populateVendorForm(vendorForm);
				model.addAttribute("vendorForm", vendorForm);
				model.addAttribute("message", msg);
			}else{
				// throw some message
			}
		} catch (Exception e) {
			if(e instanceof VendorException){
				model.addAttribute("errMsg", e.getMessage());
			}
			e.printStackTrace();
		}
		
		return "vendorManagementForm";
	}
	
	
	@RequestMapping(value="/save_vendor_addresses",method=RequestMethod.POST)
	public String saveVendorAddresses(@ModelAttribute("vendorForm") VendorForm vendorForm, HttpServletRequest request, Model model){
		VendorService vendorService = null;
		String msg = null;
		try {
			if(null!=vendorForm){
				vendorService = (VendorService) ServiceManager.getBean("vendorService");
				if(null!=vendorForm.getVendorDetail().getVendorId() && !"".equals(vendorForm.getVendorDetail().getVendorId())){
					msg = vendorService.saveVendorAddress(vendorForm.getVendorAddresses(),Long.parseLong(vendorForm.getVendorDetail().getVendorId()),vendorForm.isSaveOrUpdate());
				}else{
					throw new VendorException("No vendor id found. Please enter vendor id.");
				}
				this.populateVendorForm(vendorForm);
				model.addAttribute("vendorForm", vendorForm);
				model.addAttribute("message", msg);
			}else{
				// throw some message
			}
		} catch (Exception e) {
			if(e instanceof VendorException){
				model.addAttribute("errMsg", e.getMessage());
			}
			e.printStackTrace();
		}
		
		return "vendorManagementForm";
	}
	
	@RequestMapping(value="/save_vendor_attachments",method=RequestMethod.POST)
	public String saveVendorAttachments(@ModelAttribute("vendorForm") VendorForm vendorForm, HttpServletRequest request, Model model){
		VendorService vendorService = null;
		String msg = null;
		try {
			if(null!=vendorForm){
				vendorService = (VendorService) ServiceManager.getBean("vendorService");
				if(null!=vendorForm.getVendorDetail().getVendorId() && !"".equals(vendorForm.getVendorDetail().getVendorId())){
					
					if(null!=vendorForm.getVendorAttachments() && vendorForm.getVendorAttachments().size()>0){
						for(VendorAttachmentsView attachmentsView:vendorForm.getVendorAttachments()){
							if(null!=attachmentsView && null!=attachmentsView.getFileAttachment()){
								attachmentsView.setAttachment(attachmentsView.getFileAttachment().getBytes());
							}else{
								vendorForm.getVendorAttachments().remove(attachmentsView);
							}
						}
					}
					msg = vendorService.saveVendorAttachments(vendorForm.getVendorAttachments(),Long.parseLong(vendorForm.getVendorDetail().getVendorId()));
				}else{
					throw new VendorException("No vendor id found. Please enter vendor id.");
				}
				this.populateVendorForm(vendorForm);
				model.addAttribute("vendorForm", vendorForm);
				model.addAttribute("message", msg);
			}else{
				// throw some message
			}
		} catch (Exception e) {
			if(e instanceof VendorException){
				model.addAttribute("errMsg", e.getMessage());
			}
			e.printStackTrace();
		}
		
		return "vendorManagementForm";
	}
	
	@RequestMapping(value="/delete_vendor_attachment",method=RequestMethod.POST)
	public String deleteVendorAttachment(@ModelAttribute("vendorForm") VendorForm vendorForm, HttpServletRequest request, Model model){
		VendorService vendorService = null;
		String msg = null;
		try {
			if(null!=vendorForm){
				vendorService = (VendorService) ServiceManager.getBean("vendorService");
				if(null!=vendorForm.getVendorDetail().getVendorId() && !"".equals(vendorForm.getVendorDetail().getVendorId())){
					if(null!=vendorForm.getAttachmentId() && !"".equals(vendorForm.getAttachmentId())){
						msg = vendorService.deleteVendorAttachment(Long.parseLong(vendorForm.getAttachmentId()));
					}else{
						throw new VendorException("No vendor id found. Please enter vendor id.");
					}
				}else{
					// throw some message
				}
				this.populateVendorForm(vendorForm);
				model.addAttribute("vendorForm", vendorForm);
				model.addAttribute("message", msg);
			}else{
				// throw some message
			}
		} catch (Exception e) {
			if(e instanceof VendorException){
				model.addAttribute("errMsg", e.getMessage());
			}
			e.printStackTrace();
		}
		
		return "vendorManagementForm";
	}
	
	private void populateVendorForm(VendorForm vendorForm)throws Exception{
		VendorService vendorService = null;
		CommonService commonService = null;
		long vendorId = Long.parseLong(vendorForm.getVendorDetail().getVendorId());
		try {
			vendorService = (VendorService) ServiceManager.getBean("vendorService");
			commonService = (CommonService) ServiceManager.getBean("commonService");
			
			vendorForm.setBrands(vendorService.getBrands());
			vendorForm.setActivities(vendorService.getActivities());
			vendorForm.setCategories(vendorService.getCategories());
			vendorForm.setStates(commonService.getStates());
			vendorForm.setCities(commonService.getCities());
			
			vendorForm.setVendorDetail(vendorService.getVendorDetail(vendorId));
			vendorForm.setVendorActivities(vendorService.getVendorActivities(vendorId));
			
			List<String> selectedActivities = null;
			if(null!=vendorForm.getVendorActivities() && vendorForm.getVendorActivities().size()>0){
				selectedActivities = new ArrayList<String>();
				for(VendorActivityView activityView:vendorForm.getVendorActivities()){
					selectedActivities.add(activityView.getActivityCode());
				}
			}else{
				selectedActivities = new ArrayList<String>();
			}
			vendorForm.setSelectedActivities(selectedActivities);
			
			vendorForm.setVendorBrands(vendorService.getVendorBrands(vendorId));
			vendorForm.setVendorProductCategories(vendorService.getVendorCategories(vendorId));
			vendorForm.setVendorTerms(vendorService.getVendorTerms(vendorId));
			vendorForm.setVendorAddresses(vendorService.getVendorAddresses(vendorId));
			vendorForm.setVendorAttachments(vendorService.getVendorAttachments(vendorId));
			
			if(null!=vendorForm.getVendorProductCategories() && vendorForm.getVendorProductCategories().size()>0){
				vendorForm.setVendorProductCategories_rowCount(String.valueOf(vendorForm.getVendorProductCategories().size()));
			}
			if(null!=vendorForm.getVendorBrands() && vendorForm.getVendorBrands().size()>0){
				vendorForm.setVendorBrands_rowCount(String.valueOf(vendorForm.getVendorBrands().size()));
			}
			if(null!=vendorForm.getVendorTerms() && vendorForm.getVendorTerms().size()>0){
				vendorForm.setVendorTerms_rowCount(String.valueOf(vendorForm.getVendorTerms().size()));
			}
			if(null!=vendorForm.getVendorAddresses() && vendorForm.getVendorAddresses().size()>0){
				vendorForm.setVendorAddresses_rowCount(String.valueOf(vendorForm.getVendorAddresses().size()));
			}
			
			vendorForm.setSaveOrUpdate(false);
			
		} catch (Exception e) {
			throw e;
		}
		
	}
}
