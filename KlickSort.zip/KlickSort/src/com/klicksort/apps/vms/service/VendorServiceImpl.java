package com.klicksort.apps.vms.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.klicksort.apps.common.dao.CommonDAO;
import com.klicksort.apps.common.dto.BrandView;
import com.klicksort.apps.common.dto.ProductCategoryView;
import com.klicksort.apps.vms.dao.VendorDAO;
import com.klicksort.apps.vms.dto.ContactView;
import com.klicksort.apps.vms.dto.VendorActivityView;
import com.klicksort.apps.vms.dto.VendorAttachmentsView;
import com.klicksort.apps.vms.dto.VendorDetailView;
import com.klicksort.apps.vms.dto.VendorTermsView;
import com.klicksort.apps.vms.exception.VendorException;
import com.klicksort.apps.vms.mapper.VendorMapper;
import com.klicksort.entity.Brand;
import com.klicksort.entity.Contact;
import com.klicksort.entity.ProductCategory;
import com.klicksort.entity.VendorActivity;
import com.klicksort.entity.VendorActivityMap;
import com.klicksort.entity.VendorAttachments;
import com.klicksort.entity.VendorBrandMap;
import com.klicksort.entity.VendorCategoryMap;
import com.klicksort.entity.VendorDetail;
import com.klicksort.entity.VendorTerms;

public class VendorServiceImpl implements VendorService{
	
	private VendorDAO vendorDAO = null;
	
	private CommonDAO commonDAO = null;
	
	public CommonDAO getCommonDAO() {
		return commonDAO;
	}
	public void setCommonDAO(CommonDAO commonDAO) {
		this.commonDAO = commonDAO;
	}
	public VendorDAO getVendorDAO() {
		return vendorDAO;
	}
	public void setVendorDAO(VendorDAO vendorDAO) {
		this.vendorDAO = vendorDAO;
	}

	@Override
	public VendorDetailView saveVendorDetails(VendorDetailView vendorDetailView) throws Exception {
		VendorDetail vendorDetail = null;
		if(null!=vendorDetailView.getVendorId() && !"".equals(vendorDetailView.getVendorId())){
			vendorDetail = this.vendorDAO.getVendorDetail(Long.parseLong(vendorDetailView.getVendorId()));
			if(null==vendorDetail){
				throw new VendorException("No vendor found for the given vendor id.");
			}
		}else{
			vendorDetail = new VendorDetail(); 
		}
		vendorDetail = VendorMapper.mapVendorDetailViewToVendorDetail(vendorDetail, vendorDetailView);
		this.vendorDAO.saveOrUpdate(vendorDetail);
		vendorDetailView.setVendorId(String.valueOf(vendorDetail.getVendorId()));
		return vendorDetailView;
	}

	@Override
	public String saveVendorAddress(List<ContactView> contactViewList,long vendorId,boolean isSaveOrUpdate) throws Exception {
		// delete existing addresses if any
		List<Contact> contacts = this.vendorDAO.getVendorAddresses(vendorId);
		if(null!=contacts && contacts.size()>0){
			for(Contact contact :contacts){
				this.vendorDAO.delete(contact);
			}
		}
		if(!isSaveOrUpdate && null!=contactViewList && contactViewList.size()>0){
			VendorDetail vendorDetail = this.vendorDAO.getVendorDetail(vendorId);
			
			if(null!=vendorDetail){
				if(!"Y".equals(vendorDetail.getActiveYn())){
					throw new VendorException("Vendor is deactivated. Addresses can not be saved for deactivated vendor");
				}
				for(ContactView contactView :contactViewList){
					Contact contact = new Contact();
					contact.setCity(this.commonDAO.getCityByPrimaryKey(Long.parseLong(contactView.getCityId())));
					contact.setState(this.commonDAO.getStateByPrimaryKey(Long.parseLong(contactView.getStateId())));
					contact.setVendorDetail(vendorDetail);
					contact = VendorMapper.mapContactViewToContact(contactView, contact);
					this.vendorDAO.saveOrUpdate(contact);
				}
			}else{
				throw new VendorException("No vendor found for the given vendor Id.");
			}
		}else{
			throw new VendorException("No vendor address are there to save/update. Please add addresses.");
		}
		
		return "Vendor addresses are saved/updated successfully.";
	}

	@Override
	public String saveVendorActivities(List<VendorActivityView> vendorActivityViewList,long vendorId,boolean isSaveOrUpdate)
			throws Exception {
		// delete existing activities
		List<VendorActivityMap> existingVendorActivities = this.vendorDAO.getVendorActivitieMaps(vendorId);
		if(null!=existingVendorActivities && existingVendorActivities.size()>0){
			for(VendorActivityMap activityMap :existingVendorActivities){
				this.vendorDAO.delete(activityMap);
			}
		}
		if(!isSaveOrUpdate && null!=vendorActivityViewList && vendorActivityViewList.size()>0){
			VendorDetail vendorDetail = this.vendorDAO.getVendorDetail(vendorId);
			if(null!=vendorDetail){
				if(!"Y".equals(vendorDetail.getActiveYn())){
					throw new VendorException("Vendor is deactivated. Activities can not be saved for deactivated vendor");
				}
				for(VendorActivityView vendorActivityView :vendorActivityViewList){
					VendorActivity vendorActivity = this.vendorDAO.getVendorActivityByActivityCode(vendorActivityView.getActivityCode());
					VendorActivityMap vendorActivityMap = new VendorActivityMap();
					vendorActivityMap.setVendorActivity(vendorActivity);
					vendorActivityMap.setVendorDetail(vendorDetail);
					this.vendorDAO.saveOrUpdate(vendorActivityMap);
				}
			}else{
				throw new VendorException("No vendor found for the given vendor Id.");
			}
		}else{
			throw new VendorException("No vendor activities are there to save/update. Please add activities.");
		}
		return "Vendor activities are saved/updated successfully.";
	}

	@Override
	public String saveVendorProductCategories(List<ProductCategoryView> productCategoryViewList,long vendorId,boolean isSaveOrUpdate)
			throws Exception {
		// delete existing data
		List<VendorCategoryMap> categoryMaps = this.vendorDAO.getVendorProductCategorieMaps(vendorId);
		if(null!=categoryMaps && categoryMaps.size()>0){
			for(VendorCategoryMap categoryMap:categoryMaps){
				this.vendorDAO.delete(categoryMap);
			}
		}
		
		if(!isSaveOrUpdate && null!=productCategoryViewList && productCategoryViewList.size()>0){
			VendorDetail vendorDetail = this.vendorDAO.getVendorDetail(vendorId);
			if(null!=vendorDetail){
				if(!"Y".equals(vendorDetail.getActiveYn())){
					throw new VendorException("Vendor is deactivated. Categories can not be saved for deactivated vendor");
				}
				
				for(ProductCategoryView productCategoryView :productCategoryViewList){
					ProductCategory productCategory = this.commonDAO.getProductCategoryByCategoryId(Long.parseLong(productCategoryView.getCategoryId()));
					VendorCategoryMap vendorCategoryMap = new VendorCategoryMap();
					vendorCategoryMap.setProductCategory(productCategory);
					vendorCategoryMap.setVendorDetail(vendorDetail);
					this.vendorDAO.saveOrUpdate(vendorCategoryMap);
				}
			}else{
				throw new VendorException("No vendor found for the given vendor Id.");
			}
		}else{
			throw new VendorException("No vendor categories are there to save/update. Please add categories.");
		}
		return "Vendor categories are saved/updated successfully.";
	}

	@Override
	public String saveVendorBrands(List<BrandView> brandViewList,long vendorId,boolean isSaveOrUpdate) throws Exception {
		// delete existing vendor brand mapping
		List<VendorBrandMap> vendorBrandMaps = this.vendorDAO.getVendorBrandMaps(vendorId);
		if(null!=vendorBrandMaps && vendorBrandMaps.size()>0){
			for(VendorBrandMap vendorBrandMap:vendorBrandMaps){
				if(null!=vendorBrandMap){
					this.vendorDAO.delete(vendorBrandMap);
				}
			}
		}
		if(!isSaveOrUpdate && null!=brandViewList && brandViewList.size()>0){
			VendorDetail vendorDetail = this.vendorDAO.getVendorDetail(vendorId);
			if(null!=vendorDetail){
				if(!"Y".equals(vendorDetail.getActiveYn())){
					throw new VendorException("Vendor is deactivated. Brands can not be saved for deactivated vendor");
				}
				
				for(BrandView brandView :brandViewList){
					Brand brand = this.commonDAO.getBrandByBrandCode(brandView.getBrandCode());
					VendorBrandMap vendorBrandMap = new VendorBrandMap();
					vendorBrandMap.setBrand(brand);
					vendorBrandMap.setVendorDetail(vendorDetail);
					this.vendorDAO.saveOrUpdate(vendorBrandMap);
				}
			}else{
				throw new VendorException("No vendor found for the given vendor Id.");
			}
		}else{
			
			throw new VendorException("No vendor brands are there to save/update. Please add brands.");
		}
		return "Vendor brands are saved/updated successfully.";
	}

	@Override
	public String saveVendorTerms(List<VendorTermsView> vendorTermsViewList,long vendorId,boolean isSaveOrUpdate) throws Exception {
		// delete existing records
		List<VendorTerms> vendorTermsList = this.vendorDAO.getVendorTerms(vendorId);
		if(null!=vendorTermsList && vendorTermsList.size()>0){
			for(VendorTerms vendorTerms:vendorTermsList){
				this.vendorDAO.delete(vendorTerms);
			}
		}
		if(!isSaveOrUpdate && null!=vendorTermsViewList && vendorTermsViewList.size()>0){
			VendorDetail vendorDetail = this.vendorDAO.getVendorDetail(vendorId);
			if(null!=vendorDetail){
				if(!"Y".equals(vendorDetail.getActiveYn())){
					throw new VendorException("Vendor is deactivated. Terms can not be saved for deactivated vendor");
				}
				
				for(VendorTermsView vendorTermsView :vendorTermsViewList){
					VendorTerms vendorTerms = new VendorTerms();
					vendorTerms.setVendorDetail(vendorDetail);
					vendorTerms = VendorMapper.mapVendorTermsViewToVendorTerms(vendorTermsView, vendorTerms);
					this.vendorDAO.saveOrUpdate(vendorTerms);
				}
			}else{
				throw new VendorException("No vendor found for the given vendor Id.");
			}
		}else{
			throw new VendorException("No vendor terms are there to save/update. Please add Terms.");
		}
		return "Vendor terms are saved/updated successfully.";
	}

	@Override
	public String saveVendorAttachments(List<VendorAttachmentsView> vendorAttachmentsViewList,long vendorId)
			throws Exception {
		if(null!=vendorAttachmentsViewList && vendorAttachmentsViewList.size()>0){
			VendorDetail vendorDetail = this.vendorDAO.getVendorDetail(vendorId);
			if(null!=vendorDetail){
				if(!"Y".equals(vendorDetail.getActiveYn())){
					throw new VendorException("Vendor is deactivated. Attachments can not be saved for deactivated vendor");
				}
				for(VendorAttachmentsView vendorAttachmentView :vendorAttachmentsViewList){
					if(null!=vendorAttachmentView){
						VendorAttachments vendorAttachment = new VendorAttachments();
						vendorAttachment.setVendorDetail(vendorDetail);
						vendorAttachment = VendorMapper.mapVendorAttachmentsViewToVendorAttachments(vendorAttachmentView, vendorAttachment);
						this.vendorDAO.saveOrUpdate(vendorAttachment);
					}
				}
			}else{
				throw new VendorException("No vendor found for the given vendor Id.");
			}
		}else{
			throw new VendorException("No vendor attachments are there to save. Please add attachments.");
		}
		return "Vendor attachments are saved successfully.";
	}
	@Override
	public List<BrandView> getBrands() throws Exception {
		List<BrandView> brandViewsCollection = null;
		Collection<Brand> brandCollection = this.vendorDAO.getBrands();
		if(null!=brandCollection && brandCollection.size()>0){
			brandViewsCollection = new ArrayList<BrandView>();
			BrandView brandView = null; 
			for(Brand brand :brandCollection){
				brandView  = new BrandView();
				brandView = VendorMapper.mapBrandToBrandView(brandView, brand);
				brandViewsCollection.add(brandView);
			}
		}else{
			// throw a message
		}
		return brandViewsCollection;
	}
	@Override
	public List<ProductCategoryView> getCategories() throws Exception {
		List<ProductCategoryView> productCategoryViews = null;
		Collection<ProductCategory> productCategoryCollection = this.vendorDAO.getCategories();
		if(null!=productCategoryCollection && productCategoryCollection.size()>0){
			productCategoryViews = new ArrayList<ProductCategoryView>();
			ProductCategoryView productCategoryView = null; 
			for(ProductCategory productCategory :productCategoryCollection){
				productCategoryView  = new ProductCategoryView();
				productCategoryView = VendorMapper.mapProductCategoryToProductCategoryView(productCategoryView, productCategory);
				productCategoryViews.add(productCategoryView);
			}
		}else{
			// throw a message
		}
		return productCategoryViews;
	}
	@Override
	public List<VendorActivityView> getActivities() throws Exception {
		List<VendorActivityView> vendorActivityViews = null;
		Collection<VendorActivity> vendorActivitieCollection = this.vendorDAO.getActivities();
		if(null!=vendorActivitieCollection && vendorActivitieCollection.size()>0){
			vendorActivityViews = new ArrayList<VendorActivityView>();
			VendorActivityView vendorActivityView = null; 
			for(VendorActivity vendorActivity :vendorActivitieCollection){
				vendorActivityView  = new VendorActivityView();
				vendorActivityView = VendorMapper.mapVendorActivityToVendorActivityView(vendorActivityView, vendorActivity);
				vendorActivityViews.add(vendorActivityView);
			}
		}else{
			// throw a message
		}
		return vendorActivityViews;
	}
	@Override
	public List<BrandView> getVendorBrands(long vendorId) throws Exception {
		List<BrandView> brandViewsCollection = null;
		Collection<Brand> brandCollection = this.vendorDAO.getVendorBrands(vendorId);
		if(null!=brandCollection && brandCollection.size()>0){
			brandViewsCollection = new ArrayList<BrandView>();
			BrandView brandView = null; 
			for(Brand brand :brandCollection){
				brandView  = new BrandView();
				brandView = VendorMapper.mapBrandToBrandView(brandView, brand);
				brandViewsCollection.add(brandView);
			}
		}else{
			// throw a message
		}
		return brandViewsCollection;
	}
	@Override
	public List<ProductCategoryView> getVendorCategories(long vendorId) throws Exception {
		List<ProductCategoryView> productCategoryViews = null;
		Collection<ProductCategory> productCategoryCollection = this.vendorDAO.getVendorProductCategories(vendorId);
		if(null!=productCategoryCollection && productCategoryCollection.size()>0){
			productCategoryViews = new ArrayList<ProductCategoryView>();
			ProductCategoryView productCategoryView = null; 
			for(ProductCategory productCategory :productCategoryCollection){
				productCategoryView  = new ProductCategoryView();
				productCategoryView = VendorMapper.mapProductCategoryToProductCategoryView(productCategoryView, productCategory);
				productCategoryViews.add(productCategoryView);
			}
		}else{
			// throw a message
		}
		return productCategoryViews;
	}
	@Override
	public List<VendorActivityView> getVendorActivities(long vendorId) throws Exception {
		List<VendorActivityView> vendorActivityViews = null;
		Collection<VendorActivity> vendorActivitieCollection = this.vendorDAO.getVendorActivities(vendorId);
		if(null!=vendorActivitieCollection && vendorActivitieCollection.size()>0){
			vendorActivityViews = new ArrayList<VendorActivityView>();
			VendorActivityView vendorActivityView = null; 
			for(VendorActivity vendorActivity :vendorActivitieCollection){
				vendorActivityView  = new VendorActivityView();
				vendorActivityView = VendorMapper.mapVendorActivityToVendorActivityView(vendorActivityView, vendorActivity);
				vendorActivityViews.add(vendorActivityView);
			}
		}else{
			// throw a message
		}
		return vendorActivityViews;
	}
	@Override
	public VendorDetailView getVendorDetail(long vendorId) throws Exception {
		VendorDetail vendorDetail = this.vendorDAO.getVendorDetail(vendorId);
		VendorDetailView vendorDetailView = null;
		if(null!=vendorDetail){
			vendorDetailView = new VendorDetailView();
			vendorDetailView = VendorMapper.mapVendorDetailToVendorDetailView(vendorDetail, vendorDetailView);
		}else{
			throw new VendorException("No vendor found for the given vendor id.");
		}
		return vendorDetailView;
	}
	@Override
	public List<VendorTermsView> getVendorTerms(long vendorId) throws Exception {
		List<VendorTerms> vendorTerms = this.vendorDAO.getVendorTerms(vendorId);
		List<VendorTermsView> vendorTermsViews = null;
		if(null!=vendorTerms && vendorTerms.size()>0){
			vendorTermsViews = new ArrayList<VendorTermsView>();
			VendorTermsView termsView = null;
			for(VendorTerms term :vendorTerms){
				termsView = new VendorTermsView();
				termsView = VendorMapper.mapVendorTermsToVendorTermsView(termsView, term);
				vendorTermsViews.add(termsView);
			}
		}
		return vendorTermsViews;
	}
	@Override
	public List<ContactView> getVendorAddresses(long vendorId) throws Exception {
		List<ContactView> contactViews = null;
		List<Contact> contacts = this.vendorDAO.getVendorAddresses(vendorId);
		if(null!=contacts && contacts.size()>0){
			contactViews = new ArrayList<ContactView>();
			ContactView contactView = null;
			for(Contact contact :contacts){
				contactView = new ContactView();
				contactView = VendorMapper.mapContactToContactView(contactView, contact);
				contactViews.add(contactView);
			}
		}
		return contactViews;
	}
	@Override
	public List<VendorAttachmentsView> getVendorAttachments(long vendorId) throws Exception {
		List<VendorAttachmentsView> attachmentsViews = null;
		List<VendorAttachments> attachments = this.vendorDAO.getVendorAttachments(vendorId);
		if(null!=attachments && attachments.size()>=0){
			attachmentsViews = new ArrayList<VendorAttachmentsView>();
			VendorAttachmentsView attachmentsView = null;
			for(VendorAttachments vendorAttachment :attachments){
				attachmentsView = new VendorAttachmentsView();
				attachmentsView = VendorMapper.mapVendorAttachmentsToVendorAttachmentsView(attachmentsView, vendorAttachment);
				attachmentsViews.add(attachmentsView);
			}
		}
		
		return attachmentsViews;
	}
	@Override
	public String deleteVendorAttachment(long attachmentId) throws Exception {
		VendorAttachments attachment = this.vendorDAO.getVendorAttachmentByAttachmentId(attachmentId);
		this.vendorDAO.delete(attachment);
		return "Attachment is successfully deleted.";
	}
	@Override
	public List<VendorDetailView> getVendors() throws Exception {
		List<VendorDetailView> vendorDetailViews = null;
		List<VendorDetail> vendorDetails = null;
		VendorDetailView vendorDetailView = null;
		vendorDetails = this.vendorDAO.getVendors();
		if(null!=vendorDetails){
			vendorDetailViews = new ArrayList<VendorDetailView>();
			for(VendorDetail vendorDetail :vendorDetails){
				vendorDetailView = new VendorDetailView();
				vendorDetailView = VendorMapper.mapVendorDetailToVendorDetailView(vendorDetail, vendorDetailView);
				vendorDetailViews.add(vendorDetailView);
			}
		}
		return vendorDetailViews;
	}
}
