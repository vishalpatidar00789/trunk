package com.klicksort.apps.vms.service;

import java.util.List;

import com.klicksort.apps.common.dto.BrandView;
import com.klicksort.apps.common.dto.ProductCategoryView;
import com.klicksort.apps.vms.dto.ContactView;
import com.klicksort.apps.vms.dto.VendorActivityView;
import com.klicksort.apps.vms.dto.VendorAttachmentsView;
import com.klicksort.apps.vms.dto.VendorDetailView;
import com.klicksort.apps.vms.dto.VendorTermsView;

public interface VendorService {
	public abstract VendorDetailView saveVendorDetails(VendorDetailView vendorDetailView)throws Exception;
	public abstract String saveVendorAddress(List<ContactView> contactViewList, long vendorId, boolean isSaveOrUpdate)throws Exception;
	public abstract String saveVendorActivities(List<VendorActivityView> vendorActivityViewList,long vendorId,boolean isSaveOrUpdate)throws Exception;
	public abstract String saveVendorProductCategories(List<ProductCategoryView> productCategoryViewList,long vendorId,boolean isSaveOrUpdate)throws Exception;
	public abstract String saveVendorBrands(List<BrandView> brandViewList,long vendorId,boolean isSaveOrUpdate)throws Exception;
	public abstract String saveVendorTerms(List<VendorTermsView> vendorTermsViewList,long vendorId,boolean isSaveOrUpdate)throws Exception;
	public abstract String saveVendorAttachments(List<VendorAttachmentsView> vendorAttachmentsViewList,long vendorId)throws Exception;
	
	public abstract String deleteVendorAttachment(long attachmentId)throws Exception;
	
	public abstract List<BrandView> getBrands()throws Exception;
	public abstract List<ProductCategoryView> getCategories()throws Exception;
	public abstract List<VendorActivityView> getActivities()throws Exception;
	
	public abstract List<BrandView> getVendorBrands(long vendorId)throws Exception;
	public abstract List<ProductCategoryView> getVendorCategories(long vendorId)throws Exception;
	public abstract List<VendorActivityView> getVendorActivities(long vendorId)throws Exception;
	public abstract List<VendorTermsView> getVendorTerms(long vendorId)throws Exception;
	public abstract List<ContactView> getVendorAddresses(long vendorId)throws Exception;
	public abstract List<VendorAttachmentsView> getVendorAttachments(long vendorId)throws Exception;
	
	public abstract VendorDetailView getVendorDetail(long vendorId)throws Exception;
	
	public abstract List<VendorDetailView> getVendors()throws Exception;
}
