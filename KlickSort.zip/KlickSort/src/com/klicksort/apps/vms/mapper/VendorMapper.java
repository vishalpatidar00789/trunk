package com.klicksort.apps.vms.mapper;

import com.klicksort.apps.common.dto.BrandView;
import com.klicksort.apps.common.dto.ProductCategoryView;
import com.klicksort.apps.vms.dto.ContactView;
import com.klicksort.apps.vms.dto.VendorActivityView;
import com.klicksort.apps.vms.dto.VendorAttachmentsView;
import com.klicksort.apps.vms.dto.VendorDetailView;
import com.klicksort.apps.vms.dto.VendorTermsView;
import com.klicksort.entity.Brand;
import com.klicksort.entity.Contact;
import com.klicksort.entity.ProductCategory;
import com.klicksort.entity.VendorActivity;
import com.klicksort.entity.VendorAttachments;
import com.klicksort.entity.VendorDetail;
import com.klicksort.entity.VendorTerms;

public class VendorMapper {
	
	public static VendorDetailView mapVendorDetailToVendorDetailView(VendorDetail vendorDetail,VendorDetailView vendorDetailView){
		vendorDetailView.setContactNo(String.valueOf(vendorDetail.getPersonalContactNo()));
		vendorDetailView.setFirmName(vendorDetail.getFirmName());
		vendorDetailView.setFirmType(vendorDetail.getFirmType());
		vendorDetailView.setFirstName(vendorDetail.getFirstName());
		vendorDetailView.setLastName(vendorDetail.getLastName());
		vendorDetailView.setVendorEmail(vendorDetail.getVendorEmail());
		vendorDetailView.setVendorId(String.valueOf(vendorDetail.getVendorId()));
		vendorDetailView.setActiveYn(("Y".equals(vendorDetail.getActiveYn()))?true:false);
		return vendorDetailView;
	}
	
	public static VendorDetail mapVendorDetailViewToVendorDetail(VendorDetail vendorDetail,VendorDetailView vendorDetailView){
		vendorDetail.setPersonalContactNo(Long.valueOf(vendorDetailView.getContactNo()));
		vendorDetail.setFirmName(vendorDetailView.getFirmName());
		vendorDetail.setFirmType(vendorDetailView.getFirmType());
		vendorDetail.setFirstName(vendorDetailView.getFirstName());
		vendorDetail.setLastName(vendorDetailView.getLastName());
		vendorDetail.setVendorEmail(vendorDetailView.getVendorEmail());
		//vendorDetail.setVendorId(Long.valueOf(vendorDetailView.getVendorId()));
		vendorDetail.setActiveYn((vendorDetailView.getActiveYn()==true)?"Y":"N");
		return vendorDetail;
	}
	
	public static ContactView mapContactToContactView(ContactView contactView, Contact contact){
		contactView.setAddressLine1(contact.getAddressLine1());
		contactView.setAddressLine2(contact.getAddressLine2());
		contactView.setCityId(String.valueOf(contact.getCity().getCityId()));
		contactView.setCityName(contact.getCity().getCityName());
		contactView.setContactId(String.valueOf(contact.getContactId()));
		contactView.setCountry(contact.getCountry());
		contactView.setLandmark(contact.getLandmark());
		contactView.setPincode(contact.getPincode());
		contactView.setSpocContactNo(contact.getSpocContactNo());
		contactView.setSpocName(contact.getSpocName());
		contactView.setStateId(String.valueOf(contact.getState().getStateId()));
		contactView.setStateName(contact.getState().getStateName());
		contactView.setStreet(contact.getStreet());
		contactView.setVendorId(String.valueOf(contact.getVendorDetail().getVendorId()));
		contactView.setFullAddress(prepareFullAddressStr(contactView));
		return contactView;
	}
	
	public static String prepareFullAddressStr(ContactView contactView){
		StringBuilder fullAddress = new StringBuilder("");
		fullAddress.append(contactView.getSpocName()+",");
		fullAddress.append(contactView.getAddressLine1()+",");
		if(null!=contactView.getAddressLine2() && !"".equals(contactView.getAddressLine2())){
			fullAddress.append(contactView.getAddressLine2()+",");
		}
		if(null!=contactView.getStreet() && !"".equals(contactView.getStreet())){
			fullAddress.append(contactView.getStreet()+",");
		}
		if(null!=contactView.getLandmark() && !"".equals(contactView.getLandmark())){
			fullAddress.append(contactView.getLandmark()+",");
		}
		fullAddress.append(contactView.getStateName()+",");
		fullAddress.append(contactView.getCityName()+"-");
		fullAddress.append(contactView.getPincode()+",");
		fullAddress.append(contactView.getSpocContactNo()+".");
		return fullAddress.toString();
	}
	
	public static Contact mapContactViewToContact(ContactView contactView, Contact contact){
		contact.setAddressLine1(contactView.getAddressLine1());
		contact.setAddressLine2(contactView.getAddressLine2());
		//contact.setCity(new City(Long.parseLong(contactView.getCityId()))); need to be set before calling mapper
		//contact.setContactId(Long.parseLong(contactView.getContactId()));
		contact.setCountry("India");
		contact.setLandmark(contactView.getLandmark());
		contact.setPincode(contactView.getPincode());
		contact.setSpocContactNo(contactView.getSpocContactNo());
		contact.setSpocName(contactView.getSpocName());
		//contact.setState(new State(Long.parseLong(contactView.getStateId()))); need to be set before calling mapper
		contact.setStreet(contactView.getStreet());
		// vendor object should be set by client before calling mapper.
		return contact;
	}
	
	public static VendorActivityView mapVendorActivityToVendorActivityView(VendorActivityView vendorActivityView, VendorActivity vendorActivity){
		vendorActivityView.setActivityCode(vendorActivity.getActivityCode());
		vendorActivityView.setActivityName(vendorActivity.getActivityName());
		return vendorActivityView;
	}
	
	public static VendorActivity mapVendorActivityViewToVendorActivity(VendorActivityView vendorActivityView, VendorActivity vendorActivity){
		vendorActivity.setActivityCode(vendorActivityView.getActivityCode());
		vendorActivity.setActivityName(vendorActivityView.getActivityName());
		return vendorActivity;
	}
	
	public static ProductCategoryView mapProductCategoryToProductCategoryView(ProductCategoryView productCategoryView,ProductCategory productCategory){
		productCategoryView.setCategoryId(String.valueOf(productCategory.getCategoryId()));
		productCategoryView.setCategoryName(productCategory.getCategoryName());
		productCategoryView.setParentCategory(String.valueOf(productCategory.getParentCategory()));
		return productCategoryView;
	}
	
	public static ProductCategory mapProductCategoryViewToProductCategory(ProductCategoryView productCategoryView,ProductCategory productCategory){
		productCategory.setCategoryId(Long.parseLong(productCategoryView.getCategoryId()));
		productCategory.setCategoryName(productCategoryView.getCategoryName());
		productCategory.setParentCategory(Long.parseLong(productCategoryView.getParentCategory()));
		return productCategory;
	}
	
	public static BrandView mapBrandToBrandView(BrandView brandView,Brand brand){
		brandView.setBrandCode(brand.getBrandCode());
		brandView.setBrandName(brand.getBrandName());
		brandView.setBrandType(brand.getBrandType());
		return brandView;
	}
	
	public static Brand mapBrandViewToBrand(BrandView brandView,Brand brand){
		brand.setBrandCode(brandView.getBrandCode());
		brand.setBrandName(brandView.getBrandName());
		brand.setBrandType(brandView.getBrandType());
		return brand;
	}
	
	public static VendorTermsView mapVendorTermsToVendorTermsView(VendorTermsView vendorTermsView, VendorTerms vendorTerms){
		vendorTermsView.setTermDescription(vendorTerms.getTermDescription());
		vendorTermsView.setTermType(vendorTerms.getTermType());
		vendorTermsView.setVendorId(String.valueOf(vendorTerms.getVendorDetail().getVendorId()));
		return vendorTermsView;
	}
	
	public static VendorTerms mapVendorTermsViewToVendorTerms(VendorTermsView vendorTermsView, VendorTerms vendorTerms){
		vendorTerms.setTermDescription(vendorTermsView.getTermDescription());
		vendorTerms.setTermType(vendorTermsView.getTermType());
		// vendor object should be set by client before calling mapper.
		return vendorTerms;
	}
	
	public static VendorAttachmentsView mapVendorAttachmentsToVendorAttachmentsView(VendorAttachmentsView vendorAttachmentsView, VendorAttachments vendorAttachments){
		vendorAttachmentsView.setAttachmentId(String.valueOf(vendorAttachments.getAttachmentsId()));
		vendorAttachmentsView.setAttachment(vendorAttachments.getAttachment());
		vendorAttachmentsView.setDescription(vendorAttachments.getAttachmentDescription());
		vendorAttachmentsView.setVendorId(String.valueOf(vendorAttachments.getVendorDetail().getVendorId()));
		return vendorAttachmentsView;
	}
	
	public static VendorAttachments mapVendorAttachmentsViewToVendorAttachments(VendorAttachmentsView vendorAttachmentsView, VendorAttachments vendorAttachments){
		vendorAttachments.setAttachment(vendorAttachmentsView.getAttachment());
		vendorAttachments.setAttachmentDescription(vendorAttachmentsView.getDescription());
		// vendor object should be set by client before calling mapper.
		return vendorAttachments;
	}
}


