package com.klicksort.apps.vms.dto;

public class VendorActivityView {
	private String activityCode;
	private String activityName;
	
	public VendorActivityView(){
		super();
	}
	
	public VendorActivityView(String activityCode,String activityName){
		super();
		this.activityCode = activityCode;
		this.activityName = activityName;
	}
	
	public String getActivityCode() {
		return activityCode;
	}

	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
}
