package com.klicksort.apps.vms.dto;

public class VendorTermsView {
	private String vendorId;
	private String termType;
	private String termDescription;
	
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getTermType() {
		return termType;
	}
	public void setTermType(String termType) {
		this.termType = termType;
	}
	public String getTermDescription() {
		return termDescription;
	}
	public void setTermDescription(String termDescription) {
		this.termDescription = termDescription;
	}
}
