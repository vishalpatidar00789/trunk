package com.klicksort.apps.vms.dto;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

public class VendorAttachmentsView {
	private String attachmentId;
	private String vendorId;
	private byte[] attachment;
	private CommonsMultipartFile fileAttachment;
	private String description;
	
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public byte[] getAttachment() {
		return attachment;
	}
	public void setAttachment(byte[] attachment) {
		this.attachment = attachment;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public CommonsMultipartFile getFileAttachment() {
		return fileAttachment;
	}
	public void setFileAttachment(CommonsMultipartFile fileAttachment) {
		this.fileAttachment = fileAttachment;
	}
	public String getAttachmentId() {
		return attachmentId;
	}
	public void setAttachmentId(String attachmentId) {
		this.attachmentId = attachmentId;
	}
	
}
