package com.klicksort.apps.vms.dto;

import java.util.ArrayList;
import java.util.List;

import com.klicksort.apps.common.dto.BrandView;
import com.klicksort.apps.common.dto.CityView;
import com.klicksort.apps.common.dto.ProductCategoryView;
import com.klicksort.apps.common.dto.StateView;

public class VendorForm {
	private VendorDetailView vendorDetail;
	private List<ContactView> vendorAddresses;
	private List<VendorActivityView> vendorActivities;
	private List<ProductCategoryView> vendorProductCategories;
	private List<BrandView> vendorBrands;
	private List<VendorTermsView> vendorTerms;
	private List<VendorAttachmentsView> vendorAttachments;
	private List<StateView> states;
	private List<CityView> cities;
	private List<VendorActivityView> activities;
	private List<ProductCategoryView> categories;
	private List<BrandView> brands;
	private List<String> selectedActivities;
	
	private String vendorBrands_rowCount="0";
	private String vendorProductCategories_rowCount = "0";
	private String vendorAddresses_rowCount = "0";
	private String vendorTerms_rowCount = "0";
	private String command;
	private String attachmentId;
	
	private boolean saveOrUpdate = true;
	
	public VendorForm(){
		super();
		
		categories = new ArrayList<ProductCategoryView>();
		
		brands = new ArrayList<BrandView>();
		
		states = new ArrayList<StateView>();
		
		cities = new ArrayList<CityView>();
	}
	
	
	public String getAttachmentId() {
		return attachmentId;
	}

	public void setAttachmentId(String attachmentId) {
		this.attachmentId = attachmentId;
	}

	public boolean isSaveOrUpdate() {
		return saveOrUpdate;
	}

	public void setSaveOrUpdate(boolean saveOrUpdate) {
		this.saveOrUpdate = saveOrUpdate;
	}

	public String getCommand() {
		return command;
	}

	public void setCommand(String command) {
		this.command = command;
	}

	public List<String> getSelectedActivities() {
		return selectedActivities;
	}

	public void setSelectedActivities(List<String> selectedActivities) {
		this.selectedActivities = selectedActivities;
	}

	public List<VendorActivityView> getActivities() {
		return activities;
	}

	public void setActivities(List<VendorActivityView> activities) {
		if(null!=activities)
			this.activities = activities;
	}

	public List<ProductCategoryView> getCategories() {
		return categories;
	}

	public void setCategories(List<ProductCategoryView> categories) {
		if(null!=categories)
			this.categories = categories;
	}

	public List<BrandView> getBrands() {
		return brands;
	}

	public void setBrands(List<BrandView> brands) {
		if(null!=brands)
			this.brands = brands;
	}

	public List<StateView> getStates() {
		return states;
	}

	public void setStates(List<StateView> states) {
		if(null!=states)
			this.states = states;
	}

	public List<CityView> getCities() {
		return cities;
	}

	public void setCities(List<CityView> cities) {
		if(null!=cities)
			this.cities = cities;
	}

	public String getVendorBrands_rowCount() {
		return vendorBrands_rowCount;
	}

	public void setVendorBrands_rowCount(String vendorBrands_rowCount) {
		this.vendorBrands_rowCount = vendorBrands_rowCount;
	}

	public String getVendorProductCategories_rowCount() {
		return vendorProductCategories_rowCount;
	}

	public void setVendorProductCategories_rowCount(String vendorProductCategories_rowCount) {
		this.vendorProductCategories_rowCount = vendorProductCategories_rowCount;
	}

	public String getVendorAddresses_rowCount() {
		return vendorAddresses_rowCount;
	}

	public void setVendorAddresses_rowCount(String vendorAddresses_rowCount) {
		this.vendorAddresses_rowCount = vendorAddresses_rowCount;
	}

	public String getVendorTerms_rowCount() {
		return vendorTerms_rowCount;
	}

	public void setVendorTerms_rowCount(String vendorTerms_rowCount) {
		this.vendorTerms_rowCount = vendorTerms_rowCount;
	}

	public VendorDetailView getVendorDetail() {
		return vendorDetail;
	}
	public void setVendorDetail(VendorDetailView vendorDetail) {
		this.vendorDetail = vendorDetail;
	}
	public List<ContactView> getVendorAddresses() {
		return vendorAddresses;
	}
	public void setVendorAddresses(List<ContactView> vendorAddresses) {
		this.vendorAddresses = vendorAddresses;
	}
	public List<VendorActivityView> getVendorActivities() {
		return vendorActivities;
	}
	public void setVendorActivities(List<VendorActivityView> vendorActivities) {
		this.vendorActivities = vendorActivities;
	}
	public List<ProductCategoryView> getVendorProductCategories() {
		return vendorProductCategories;
	}
	public void setVendorProductCategories(List<ProductCategoryView> vendorProductCategories) {
		this.vendorProductCategories = vendorProductCategories;
	}
	public List<BrandView> getVendorBrands() {
		return vendorBrands;
	}
	public void setVendorBrands(List<BrandView> vendorBrands) {
		this.vendorBrands = vendorBrands;
	}
	public List<VendorTermsView> getVendorTerms() {
		return vendorTerms;
	}
	public void setVendorTerms(List<VendorTermsView> vendorTerms) {
		this.vendorTerms = vendorTerms;
	}
	public List<VendorAttachmentsView> getVendorAttachments() {
		return vendorAttachments;
	}
	public void setVendorAttachments(List<VendorAttachmentsView> vendorAttachments) {
		this.vendorAttachments = vendorAttachments;
	}
	
}
