package com.klicksort.apps.vms.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.criterion.Restrictions;

import com.klicksort.apps.common.dao.GenericDaoImpl;
import com.klicksort.apps.common.expection.ObjectNotFound;
import com.klicksort.entity.Brand;
import com.klicksort.entity.Contact;
import com.klicksort.entity.ProductCategory;
import com.klicksort.entity.VendorActivity;
import com.klicksort.entity.VendorActivityMap;
import com.klicksort.entity.VendorAttachments;
import com.klicksort.entity.VendorBrandMap;
import com.klicksort.entity.VendorCategoryMap;
import com.klicksort.entity.VendorDetail;
import com.klicksort.entity.VendorTerms;

public class VendorDAOImpl extends GenericDaoImpl implements VendorDAO{

	@Override
	public VendorDetail getVendorDetail(long vendorId) throws Exception {
		VendorDetail vendorDetail = null;
		vendorDetail = (VendorDetail) this.getSession().get(VendorDetail.class, vendorId);
		return vendorDetail;
	}

	@Override
	public List<Contact> getVendorAddresses(long vendorId) throws Exception {
		List<Contact> contactList = this.getSession().createCriteria(Contact.class).add(Restrictions.eq("vendorDetail.vendorId", vendorId)).list();
		return contactList;
	}

	@Override
	public List<VendorActivity> getVendorActivities(long vendorId) throws Exception{
		List<VendorActivity> vendorActivityList = null;
		List<VendorActivityMap> vendorActivityMapList = this.getSession().createCriteria(VendorActivityMap.class).add(Restrictions.eq("vendorDetail.vendorId", vendorId)).list();
		if(null!=vendorActivityMapList){
			vendorActivityList = new ArrayList<VendorActivity>();
			for(VendorActivityMap activityMap :vendorActivityMapList){
				if(null!=activityMap){
					vendorActivityList.add(activityMap.getVendorActivity());
				}
			}
		}
		return vendorActivityList;
	}

	@Override
	public List<ProductCategory> getVendorProductCategories(long vendorId) throws Exception{
		List<ProductCategory> productCategoryList = null;
		List<VendorCategoryMap> vendorCategoryMapList= this.getSession().createCriteria(VendorCategoryMap.class).add(Restrictions.eq("vendorDetail.vendorId", vendorId)).list();
		if(null!=vendorCategoryMapList){
			productCategoryList = new ArrayList<ProductCategory>();
			for(VendorCategoryMap vendorCategoryMap :vendorCategoryMapList){
				if(null!=vendorCategoryMap){
					productCategoryList.add(vendorCategoryMap.getProductCategory());
				}
			}
		}
		return productCategoryList;
	}

	@Override
	public List<Brand> getVendorBrands(long vendorId) throws Exception{
		List<Brand> brandList = null;
		List<VendorBrandMap> vendorBrandMapList = this.getSession().createCriteria(VendorBrandMap.class).add(Restrictions.eq("vendorDetail.vendorId", vendorId)).list();
		if(null!=vendorBrandMapList){
			brandList = new ArrayList<Brand>();
			for(VendorBrandMap brandMap :vendorBrandMapList){
				if(null!=brandMap){
					brandList.add(brandMap.getBrand());
				}
			}
		}
		return brandList;
	}

	@Override
	public List<VendorTerms> getVendorTerms(long vendorId) throws Exception{
		List<VendorTerms> vendorTermsList = this.getSession().createCriteria(VendorTerms.class).add(Restrictions.eq("vendorDetail.vendorId", vendorId)).list();
		return vendorTermsList;
	}

	@Override
	public List<VendorAttachments> getVendorAttachments(long vendorId) throws Exception{
		List<VendorAttachments> vendorAttachmentsList = this.getSession().createCriteria(VendorAttachments.class).add(Restrictions.eq("vendorDetail.vendorId", vendorId)).list();
		return vendorAttachmentsList;
	}

	@Override
	public List<Brand> getBrands() throws Exception {
		List<Brand> brandList = this.getSession().createCriteria(Brand.class).list(); 
		return brandList;
	}

	@Override
	public List<ProductCategory> getCategories() throws Exception {
		List<ProductCategory> productCategoryList = this.getSession().createCriteria(ProductCategory.class).list(); 
		return productCategoryList;
	}

	@Override
	public List<VendorActivity> getActivities() throws Exception {
		List<VendorActivity> vendorActivityList = this.getSession().createCriteria(VendorActivity.class).list(); 
		return vendorActivityList;
	}

	@Override
	public List<VendorActivityMap> getVendorActivitieMaps(long vendorId) throws Exception {
		List<VendorActivityMap> vendorActivityMapList = this.getSession().createCriteria(VendorActivityMap.class).add(Restrictions.eq("vendorDetail.vendorId", vendorId)).list();
		return vendorActivityMapList;
	}

	@Override
	public List<VendorCategoryMap> getVendorProductCategorieMaps(long vendorId) throws Exception {
		List<VendorCategoryMap> vendorCategoryMapList = this.getSession().createCriteria(VendorCategoryMap.class).add(Restrictions.eq("vendorDetail.vendorId", vendorId)).list();
		return vendorCategoryMapList;
	}

	@Override
	public List<VendorBrandMap> getVendorBrandMaps(long vendorId) throws Exception {
		List<VendorBrandMap> vendorBrandMapList = this.getSession().createCriteria(VendorBrandMap.class).add(Restrictions.eq("vendorDetail.vendorId", vendorId)).list();
		return vendorBrandMapList;
	}

	@Override
	public VendorActivity getVendorActivityByActivityCode(String activityCode) throws Exception {
		VendorActivity vendorActivity= (VendorActivity) this.getSession().createCriteria(VendorActivity.class).add(Restrictions.eq("activityCode", activityCode)).uniqueResult();
		if(null==vendorActivity){
			throw new ObjectNotFound("No activity found for the given activity code");
		}
		return vendorActivity;
	}

	@Override
	public VendorAttachments getVendorAttachmentByAttachmentId(long attachmentId) throws Exception {
		VendorAttachments attachment = (VendorAttachments) this.get(VendorAttachments.class, attachmentId);
		if(null==attachment){
			throw new ObjectNotFound("No attachment found for the given attachment id.");
		}
		return attachment;
	}

	@Override
	public List<VendorDetail> getVendors() throws Exception {
		List<VendorDetail> vendorDetails = this.getSession().createCriteria(VendorDetail.class).list();
		return vendorDetails;
	}

}
