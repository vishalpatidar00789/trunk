package com.klicksort.apps.vms.dao;

import java.util.List;

import com.klicksort.apps.common.dao.GenericDAO;
import com.klicksort.entity.Brand;
import com.klicksort.entity.Contact;
import com.klicksort.entity.ProductCategory;
import com.klicksort.entity.VendorActivity;
import com.klicksort.entity.VendorActivityMap;
import com.klicksort.entity.VendorAttachments;
import com.klicksort.entity.VendorBrandMap;
import com.klicksort.entity.VendorCategoryMap;
import com.klicksort.entity.VendorDetail;
import com.klicksort.entity.VendorTerms;

public interface VendorDAO extends GenericDAO{
	
	public abstract VendorDetail getVendorDetail(long vendorId)throws Exception;
	public abstract List<Contact> getVendorAddresses(long vendorId) throws Exception;
	public abstract List<VendorActivity> getVendorActivities(long vendorId) throws Exception;
	public abstract List<ProductCategory> getVendorProductCategories(long vendorId) throws Exception;
	public abstract List<Brand> getVendorBrands(long vendorId) throws Exception;
	public abstract List<VendorTerms> getVendorTerms(long vendorId) throws Exception;
	public abstract List<VendorAttachments> getVendorAttachments(long vendorId) throws Exception;
	
	public abstract List<Brand> getBrands()throws Exception;
	public abstract List<ProductCategory> getCategories()throws Exception;
	public abstract List<VendorActivity> getActivities()throws Exception;
	
	public abstract List<VendorActivityMap> getVendorActivitieMaps(long vendorId) throws Exception;
	public abstract List<VendorCategoryMap> getVendorProductCategorieMaps(long vendorId) throws Exception;
	public abstract List<VendorBrandMap> getVendorBrandMaps(long vendorId) throws Exception;
	
	public abstract VendorActivity getVendorActivityByActivityCode(String activityCode)throws Exception;
	
	public abstract VendorAttachments getVendorAttachmentByAttachmentId(long attachmentId)throws Exception;
	
	public abstract List<VendorDetail> getVendors()throws Exception;
}
