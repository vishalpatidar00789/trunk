package com.klicksort.apps.common.constants;

/**
     * This is an constants class having final class and method used in framework package.
     * It is used in various services for getting value based on key-value mapping defined below.
     */
public final class ServiceConstants {
    
    /**
     * This is a default constructor
     */
    public ServiceConstants() {
    }
    
    /**
     * This constant contains name of the message page. Value of this variable is
     * configured in the core-framework-views.properties file.
     */
    public static final String MESSAGE_PAGE= "messagePage";
    
    /**
     * This constant is used to set any message in the ServiceResult Object.
     */
    public static final String MESSAGE$MESSAGE= "MESSAGE";
    
    /**
     * This constant is used to set any error message in the ServiceResult Object.
     */
    public static final String MESSAGE$ERROR= "ERROR";
    
    /**
     * This constant contains name of the ajax page where request and response objects are used. Value of this variable is
     * configured in the core-framework-views.properties file.
     */
    public static final String AJAX_PAGE= "writeAjaxData";
    
    /**
     * This constant is used to pass any data to the AJAX_PAGE
     */
    public static final String AJAX$DATA= "AJAX_DATA";
    
    
    /**
     * This contstant is used to show any error message for the ajax request
     */
    public static final String AJAX$ERROR_MESSAGE= "ALERT";    
    
    /**
     * This contstant is used to show any alert message for the ajax request
     */
    public static final String AJAX$ALERT_MESSAGE= "ERROR";
    
    /**
     * This constant is used to pass failure flag from application module to the handler class.
     */
    public static final String FAILURE_CODE="FAIL";
    
    /**
     * This constant is used to pass success flag from application module to the handler class.
     */
    public static final String SUCCESS_CODE="SUCCESS";
    
     
     /**
     * This variable is used to get UserSessionInfo object from session. 
     * This is also used to add UserSessionInfo object into session object.
     */
    public static final String USER_SESSION_INFO = "UserSessionInfo";
    
    /**
     * Following constants are added to show message on MessagePage for success and warning messages
     */
     
    public static final String AJAX$GET_HTTP_REPSONSE_STRING="AJAX_GET_HTTP_RESPONSE_STRING";
    public static final String ERROR$MSG$STRING = "Some Error occured. Please contact System Administrator.";
    public static final String YES = "Y";
    public static final String NO = "N";
    
    public static final String ONLOAD_JS_MESSAGE = "onloadJSMessage";
}
