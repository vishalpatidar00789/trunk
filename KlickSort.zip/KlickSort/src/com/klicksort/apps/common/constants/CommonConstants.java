package com.klicksort.apps.common.constants;

public class CommonConstants {
}
