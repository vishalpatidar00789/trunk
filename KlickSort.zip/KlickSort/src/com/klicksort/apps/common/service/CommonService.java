package com.klicksort.apps.common.service;

import java.util.List;

import com.klicksort.apps.common.dto.CityView;
import com.klicksort.apps.common.dto.CountryView;
import com.klicksort.apps.common.dto.StateView;

public interface CommonService {
	public abstract List<StateView> getStates()throws Exception;
	public abstract List<CityView> getCities()throws Exception;
	
	public abstract CityView getCityByCityId(long cityId)throws Exception;
	public abstract StateView getStateByStateId(long stateId)throws Exception;
	public abstract CountryView getCountryByCountryId(long countryId)throws Exception;
}
