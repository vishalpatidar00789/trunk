package com.klicksort.apps.common.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.klicksort.apps.common.dao.CommonDAO;
import com.klicksort.apps.common.dto.CityView;
import com.klicksort.apps.common.dto.CountryView;
import com.klicksort.apps.common.dto.StateView;
import com.klicksort.apps.common.mapper.CommonMapper;
import com.klicksort.entity.City;
import com.klicksort.entity.State;

public class CommonServiceImpl implements CommonService{
	
	private CommonDAO commonDAO = null;
	
	public CommonDAO getCommonDAO() {
		return commonDAO;
	}

	public void setCommonDAO(CommonDAO commonDAO) {
		this.commonDAO = commonDAO;
	}

	@Override
	public List<StateView> getStates() throws Exception {
		List<StateView> states = null;
		Collection<State> entityStates = this.commonDAO.getStates();
		if(null!=entityStates && entityStates.size()>0){
			states = new ArrayList<StateView>();
			StateView stateView = null;
			for(State state :entityStates){
				stateView = new StateView();
				stateView = CommonMapper.mapStateToStateView(stateView, state);
				states.add(stateView);
			}
		}else{
			// throw new message
		}
		return states;
	}

	@Override
	public List<CityView> getCities() throws Exception {
		List<CityView> cities = null;
		Collection<City> entityCities = this.commonDAO.getCities();
		if(null!=entityCities && entityCities.size()>0){
			cities = new ArrayList<CityView>();
			CityView cityView = null;
			for(City city :entityCities){
				cityView = new CityView();
				cityView = CommonMapper.mapCityToCityView(cityView, city);
				cities.add(cityView);
			}
		}else{
			// throw new message
		}
		return cities;
	}

	@Override
	public CityView getCityByCityId(long cityId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public StateView getStateByStateId(long stateId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CountryView getCountryByCountryId(long countryId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
