package com.klicksort.apps.common.dto;

public class CountryView {
	private String countryId;
	private String countryName;
	
	public CountryView(){
		super();
	}
	
	public CountryView(String countryId, String countryName) {
		super();
		this.countryId = countryId;
		this.countryName = countryName;
	}
	public String getCountryId() {
		return countryId;
	}
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	
	
}
