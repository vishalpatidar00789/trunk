package com.klicksort.apps.common.dto;

public class ProductCategoryView {
	private String categoryId;
	private String categoryName;
	private String parentCategory;
	
	public ProductCategoryView(){
		super();
	}
	
	public ProductCategoryView(String categoryId,String categoryName){
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getParentCategory() {
		return parentCategory;
	}
	public void setParentCategory(String parentCategory) {
		this.parentCategory = parentCategory;
	}
}
