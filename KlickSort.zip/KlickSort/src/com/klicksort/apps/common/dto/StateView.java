package com.klicksort.apps.common.dto;

public class StateView {
	private String stateId;
	private String countryId;
	private String stateName;
	
	public StateView(){
		super();
	}
	public StateView(String stateId,String stateName){
		super();
		this.stateId = stateId;
		this.stateName = stateName;
	}
	public String getStateId() {
		return stateId;
	}
	public void setStateId(String stateId) {
		this.stateId = stateId;
	}
	public String getCountryId() {
		return countryId;
	}
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	
}
