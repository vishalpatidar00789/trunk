package com.klicksort.apps.common.dto;

public class BrandView {
	private String brandCode;
	private String brandType;
	private String brandName;
	
	public BrandView(){
		super();
	}
	public BrandView(String brandCode,String brandName){
		super();
		this.brandCode = brandCode;
		this.brandName = brandName;
	}
	public String getBrandCode() {
		return brandCode;
	}
	public void setBrandCode(String brandCode) {
		this.brandCode = brandCode;
	}
	public String getBrandType() {
		return brandType;
	}
	public void setBrandType(String brandType) {
		this.brandType = brandType;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
}
