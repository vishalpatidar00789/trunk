package com.klicksort.apps.common.mapper;

import com.klicksort.apps.common.dto.CityView;
import com.klicksort.apps.common.dto.CountryView;
import com.klicksort.apps.common.dto.StateView;
import com.klicksort.entity.City;
import com.klicksort.entity.Country;
import com.klicksort.entity.State;

public class CommonMapper {
	
	public static State mapStateViewToState(StateView stateView, State state){
		state.setStateId(Long.parseLong(stateView.getStateId()));
		state.setStateName(stateView.getStateName());
		return state;
	}
	
	public static StateView mapStateToStateView(StateView stateView, State state){
		stateView.setStateId(String.valueOf(state.getStateId()));
		stateView.setStateName(state.getStateName());
		return stateView;
	}
	
	public static City mapCityViewToCity(CityView cityView, City city){
		city.setCityId(Long.parseLong(cityView.getCityId()));
		city.setCityName(cityView.getCityName());
		return city;
	}
	
	public static CityView mapCityToCityView(CityView cityView, City city){
		cityView.setCityId(String.valueOf(city.getCityId()));
		cityView.setCityName(city.getCityName());
		return cityView;
	}
	
	public static Country mapCountryViewToCountry(CountryView countryView, Country country){
		country.setCountryId(Long.parseLong(countryView.getCountryId()));
		country.setCountryName(countryView.getCountryName());
		return country;
	}
	
	public static CountryView mapCountryToCountryView(CountryView countryView, Country country){
		countryView.setCountryId(String.valueOf(country.getCountryId()));
		countryView.setCountryName(country.getCountryName());
		return countryView;
	}
}
