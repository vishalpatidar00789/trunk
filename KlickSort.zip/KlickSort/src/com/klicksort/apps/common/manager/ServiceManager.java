package com.klicksort.apps.common.manager;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class ServiceManager implements ApplicationContextAware{
	private static ApplicationContext applicationContext;
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {

		ServiceManager.applicationContext = applicationContext;
	}

	public static Object getBean(String beanId){
		return applicationContext.getBean(beanId);
	}
}
