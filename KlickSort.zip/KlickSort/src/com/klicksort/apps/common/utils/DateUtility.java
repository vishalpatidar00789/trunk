package com.klicksort.apps.common.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;


/**
 * This class is an utility for various date related functions. It contains
 * methods to get sysdate and for conversion from one format to other.
 * 
 * @author Vishal  (Modified as per need of new framework)
 * @version: 1.1 date: 5th Sept 2014
 */
public class DateUtility {

	private static Locale localUS = new Locale("en_US");
	private static long dayInMilli = 1000 * 60 * 60 * 24;

	public static final String format1 = "yyyy-MM-dd HH:mm:ss";
	public static final String format2 = "dd-MM-yyyy HH:mm:ss";
	public static final String format3 = "dd/MM/yyyy HH:mm:ss";
	public static final String format4 = "yyyy-MM-dd";
	public static final String format5 = "dd-MM-yyyy";
	public static final String format6 = "yyyy/MM/dd";
	public static final String format7 = "dd/MM/yyyy";
	public static final String format8 = "hh:mm:ss";
	public static final String format9 = "h:mm:ss a";
	/**
	 * The format for date as dd-Mon-YYYY
	 */
	public static final String formatOra = "dd-MMM-yyyy";

	/**
	 * The format for date as dd-MMM-YYYY HH:mm:ss a
	 */
	public static final String formatOraWithTime = "dd-MMM-yyyy HH:mm:ss a";

	public DateUtility() {
	}

	public static Date getTodayDt() {
		return new Date();
	}

	/**
	 * This method is used to convert Date Object into String Object as per
	 * given pattern.
	 * 
	 * @author: Vishal  Date : 5thSept,2009
	 */
	public static String getDateString(Date date, String pattern)
			throws Exception {
		String lStrDate = "";

		if (date != null && pattern != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(pattern, localUS);
			lStrDate = sdf.format(date);
		}

		return lStrDate;
	}

	/**
	 * This method is used to convert string into date object . Note : Input
	 * String must have given pattern. Otherwise Parse Exception would occur.
	 * Author : Vishal  Date : 5th Sept , 2009
	 */
	public static Date getDateObject(String strDate, String pattern)
			throws Exception {
		Date parsedt = null;

		if (strDate != null && !strDate.equals("") && pattern != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(pattern, localUS);
			parsedt = sdf.parse(strDate);
		}
		return parsedt;
	}

	/**
	 * This method is used to get today date in String as per given pattern.
	 * Author: Vishal  Date : 5thSpet,2009
	 */
	public static String getTodayDateString(String pattern) throws Exception {
		String todayDtStr = "";
		if (pattern != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(pattern, localUS);
			todayDtStr = sdf.format(getTodayDt());
		}
		return todayDtStr;
	}

	/**
	 * This method is used to change String Date into one pattern to another
	 * pattern. Author: Vishal  Note : Input String must have
	 * pattern1. Otherwise parse Exception would be created. Date : 5th Sept,
	 * 2009
	 */
	public static String getDateStringIntoDiffPattern(String dateStr,
			String pattern1, String pattern2) throws Exception {
		String formattedDate = "";

		if(dateStr != null && !"".equals(dateStr))
		{
			SimpleDateFormat sdf = new SimpleDateFormat(pattern1, localUS);
			Date parsedt = sdf.parse(dateStr);
			sdf.applyPattern(pattern2);
			formattedDate = sdf.format(parsedt);
		}
		
		return formattedDate;
	}

	/**
	 * It was already written DateDiff -- compute the difference between two
	 * dates. This method is used to get difference in two dates.
	 * 
	 * @param java
	 *            .util.Date date1
	 * @param java
	 *            .util.Date date2
	 * @return java.lang.String
	 */
	public static String dateDiff(Date date1, Date date2) {
		if (date1 != null && date2 != null) {
			return Long.toString(dateDiffInLong(date1, date2), 10);
		}
		return "";
	}

	/**
	 * This method the difference of days between 2 dates.
	 * 
	 * @param date1
	 * @param date2
	 * @return days in long.
	 */
	public static long dateDiffInLong(Date date1, Date date2) {
		long diff = 0L;
		if (date1 != null && date2 != null) {
			if (date1.getTime() >= date2.getTime()) {
				diff = date1.getTime() - date2.getTime();
			} else if (date2.getTime() >= date1.getTime()) {
				diff = date2.getTime() - date1.getTime();
			}
			diff = diff / dayInMilli;
		}
		return diff;
	}

	/**
	 * This method is used to calculate financial year using provided
	 * java.util.Date
	 * 
	 * @param java
	 *            .util.Date
	 * @return java.util.Date
	 */
	public static Date calFinancialYr(Date toDate) {

		Date utDt = null;
		Calendar cldt = Calendar.getInstance();
		cldt.setTime(toDate);
		int month = cldt.get(Calendar.MONTH); // get the current month
		int year = cldt.get(Calendar.YEAR); // get the current year

		if (month > 2) {
			year++;
		}
		cldt.set(year, 2, 31);
		utDt = cldt.getTime();
		return utDt;
	}

	/**
	 * This method is to get the financial year of the date passes in
	 * parameters. will return in format as ex. 2007-08
	 * 
	 * @param java
	 *            .util.date toDate
	 * @return java.lang.String
	 */
	public static String getFinancialYearAsYYYYyy(Date toDate) {
		// Date toDate = parseDate(strDate);
		String fYear = "";
		String start_yr_str = "";
		String end_yr_str = "";
		Calendar cldt = Calendar.getInstance();
		cldt.setTime(toDate);
		int month = cldt.get(Calendar.MONTH); // get the current month
		int start_yr = cldt.get(Calendar.YEAR); // get the current year
		int end_yr = start_yr;
		if (month > 2) {
			end_yr = start_yr + 1;
		} else {
			end_yr = start_yr;
			start_yr = start_yr - 1;
		}
		start_yr_str = Integer.toString(start_yr);
		start_yr_str = start_yr_str.substring(0, 4);
		end_yr_str = Integer.toString(end_yr);
		end_yr_str = end_yr_str.substring(2, 4);
		fYear = start_yr_str + "-" + end_yr_str;
		return fYear;
	}

	/**
	 * This method is to get the financial year of the date passes in
	 * parameters. will return in format as ex. 2007-2008
	 * 
	 * @param java
	 *            .util.date toDate
	 * @return java.lang.String
	 */
	public static String getFinancialYearAsYYYYyyyy(Date toDate) {
		// Date toDate = parseDate(strDate);
		String fYear = "";
		String start_yr_str = "";
		String end_yr_str = "";
		Calendar cldt = Calendar.getInstance();
		cldt.setTime(toDate);
		int month = cldt.get(Calendar.MONTH); // get the current month
		int start_yr = cldt.get(Calendar.YEAR); // get the current year
		int end_yr = start_yr;
		if (month > 2) {
			end_yr = start_yr + 1;
		} else {
			end_yr = start_yr;
			start_yr = start_yr - 1;
		}
		start_yr_str = Integer.toString(start_yr);
		end_yr_str = Integer.toString(end_yr);
		fYear = start_yr_str + "-" + end_yr_str;
		return fYear;
	}

	/**
	 * This method is to get the financial year of the date passes in
	 * parameters. will return in format as ex. 0809
	 * 
	 * @param java
	 *            .util.date toDate
	 * @return java.lang.String
	 */
	public static String getFinancialYrAsYYyy(Date toDate) {
		// Date toDate = parseDate(strDate);
		String fYear = "";
		String start_yr_str = "";
		String end_yr_str = "";
		Calendar cldt = Calendar.getInstance();
		cldt.setTime(toDate);
		int month = cldt.get(Calendar.MONTH); // get the current month
		int start_yr = cldt.get(Calendar.YEAR); // get the current year
		int end_yr = start_yr;
		if (month > 2) {
			end_yr = start_yr + 1;
		} else {
			end_yr = start_yr;
			start_yr = start_yr - 1;
		}
		start_yr_str = Integer.toString(start_yr);
		start_yr_str = start_yr_str.substring(2, 4);
		end_yr_str = Integer.toString(end_yr);
		end_yr_str = end_yr_str.substring(2, 4);
		fYear = start_yr_str + end_yr_str;
		return fYear;
	}

	/**
	 * This method is to get the date for the parameter passes as day, month and
	 * year.
	 * 
	 * @param day
	 * @param month
	 * @param year
	 * @return java.util.date
	 */
	public static Date getDate(int day, int month, int year) {
		Calendar cldt = Calendar.getInstance();
		Date utDt = null;
		cldt.set(year, month, day);
		utDt = cldt.getTime();
		return utDt;
	}

	/**
	 * This method is to get the year of the date passed in parameters
	 * 
	 * @param toDate
	 * @return int year.
	 */
	public static int getYear(Date toDate) {
		Calendar cldt = Calendar.getInstance();
		cldt.setTime(toDate);

		return cldt.get(Calendar.YEAR); // get the current Year
	}

	/**
	 * This method is to get the month of the date passed in parameters
	 * 
	 * @param toDate
	 * @return int month
	 */
	public static int getMonth(Date toDate) {
		Calendar cldt = Calendar.getInstance();
		cldt.setTime(toDate);
		return cldt.get(Calendar.MONTH);
	}

	/**
	 * This method is to get the day of the date passed in parameters
	 * 
	 * @param toDate
	 * @return int Day
	 */
	public static int getDay(Date toDate) {
		Calendar cldt = Calendar.getInstance();
		cldt.setTime(toDate);
		return cldt.get(Calendar.DATE); // get the current Day
	}

	/**
	 * This method is used to get date in dd-mm-yy format using the input
	 * parameter.
	 * 
	 * @param java
	 *            .lang.String
	 * @return java.lang.String
	 */
	public static String getddmonyyyydate(String strDate) {
		String strDateFormated = "";
		int liTokenIndex1, liTokenIndex2;
		int iMonth = 0;
		String strMonth = "";
		String finalDate = "";
		strDateFormated = replaceString(strDate, "/", "-");
		liTokenIndex1 = strDateFormated.indexOf("-", 0);
		String day = strDateFormated.substring(0, liTokenIndex1);
		liTokenIndex1 = liTokenIndex1 + 1;
		liTokenIndex2 = strDateFormated.indexOf("-", liTokenIndex1);
		String month = strDateFormated.substring(liTokenIndex1, liTokenIndex2);
		liTokenIndex2 = liTokenIndex2 + 1;
		String year = strDateFormated.substring(liTokenIndex2);
		iMonth = Integer.parseInt(month);
		switch (iMonth) {
		case 1: {
			strMonth = "JAN";
			break;
		}
		case 2: {
			strMonth = "FEB";
			break;
		}
		case 3: {
			strMonth = "MAR";
			break;
		}
		case 4: {
			strMonth = "APR";
			break;
		}
		case 5: {
			strMonth = "MAY";
			break;
		}
		case 6: {
			strMonth = "JUN";
			break;
		}
		case 7: {
			strMonth = "JUL";
			break;
		}
		case 8: {
			strMonth = "AUG";
			break;
		}
		case 9: {
			strMonth = "SEP";
			break;
		}
		case 10: {
			strMonth = "OCT";
			break;
		}
		case 11: {
			strMonth = "NOV";
			break;
		}
		case 12: {
			strMonth = "DEC";
			break;
		}
		default: {
			strMonth = "Month Is Incorrect";
			break;
		}

		}
		finalDate = day + "-" + strMonth + "-" + year;

		return finalDate;

	}

	/**
	 * This method gets the starting date of the financial year Pass date as
	 * null to get the start date of current financial year
	 * 
	 * @param dt
	 * @return
	 */
	public static String getFinancialStartDate(Date dt) {
		String startDate = "01/04/";
		Calendar cldt = Calendar.getInstance();
		if (dt != null)
			cldt.setTime(dt);
		int month = cldt.get(Calendar.MONTH); // get the current month
		int year = cldt.get(Calendar.YEAR); // get the current year

		if (month <= 2) {
			year--;
		}

		startDate += year;
		return startDate;
	}

	/**
	 * This function gets the end date of the financial year Pass null to get
	 * the end date of current financial year
	 * 
	 * @param dt
	 * @return
	 */
	public static String getFinancialEndDate(Date dt) {
		String startDate = "31/03/";
		Calendar cldt = Calendar.getInstance();
		if (dt != null)
			cldt.setTime(dt);
		int month = cldt.get(Calendar.MONTH); // get the current month
		int year = cldt.get(Calendar.YEAR); // get the current year

		if (month > 2) {
			year++;
		}

		startDate += year;
		return startDate;
	}

	/**
	 * This function gets the end date of the next financial year required in ET
	 * Form VI in MPVAT. Pass null to get the end date of current financial year
	 * 
	 * @param dt
	 * @return
	 */
	public static String getNextFinancialEndDate(Date dt) {
		String endDate = "31/03/";
		Calendar cldt = Calendar.getInstance();
		if (dt != null)
			cldt.setTime(dt);

		int year = cldt.get(Calendar.YEAR); // get the current year
		year++; // for getting next year.

		endDate += year;
		return endDate;
	}

	/**
	 * This function gets the start date of next quarter. Pass dt to get the
	 * start date of next quarte
	 * 
	 * @param dt
	 * @return
	 */
	public static String getStartDateOfNextQuarter(Date dt) {
		String startDateOfNextQuarter = "01/";
		Calendar cldt = Calendar.getInstance();
		if (dt != null)
			cldt.setTime(dt);
		int month = cldt.get(Calendar.MONTH); // get the current month
		int year = cldt.get(Calendar.YEAR); // get the current year

		if (month <= 2) {
			month = 4;
		} else if (month > 2 && month <= 5) {
			month = 7;
		} else if (month > 5 && month <= 8) {
			month = 10;
		} else if (month > 8) {
			month = 1;
			year++;
		}

		if (month < 10) {
			startDateOfNextQuarter = startDateOfNextQuarter + "0" + month + "/"
					+ year;
		} else {
			startDateOfNextQuarter = startDateOfNextQuarter + month + "/"
					+ year;
		}
		return startDateOfNextQuarter;
	}

	/**
	 * This function gets the End date of next quarter. Pass dt to get the End
	 * date of next quarte
	 * 
	 * @param dt
	 * @return
	 */
	public static String getEndDateOfNextQuarter(Date dt) {
		String endDateOfNextQuarter = "";
		Calendar cldt = Calendar.getInstance();
		if (dt != null)
			cldt.setTime(dt);
		int month = cldt.get(Calendar.MONTH); // get the current month
		int year = cldt.get(Calendar.YEAR); // get the current year

		if (month <= 2) {
			endDateOfNextQuarter = "30/";
			month = 6;
		} else if (month > 2 && month <= 5) {
			endDateOfNextQuarter = "30/";
			month = 9;
		} else if (month > 5 && month <= 8) {
			endDateOfNextQuarter = "31/";
			month = 13;
		} else if (month > 8) {
			endDateOfNextQuarter = "31/";
			month = 3;
			year++;
		}

		if (month < 10) {
			endDateOfNextQuarter = endDateOfNextQuarter + "0" + month + "/"
					+ year;
		} else {
			endDateOfNextQuarter = endDateOfNextQuarter + month + "/" + year;
		}

		return endDateOfNextQuarter;
	}

	/**
	 * function for adding specific number of days to a given date
	 * 
	 * @param fromDt
	 * @param days
	 * @return
	 * @paramType <parameter name> <parameter Type>
	 */
	public static String addDays(String fromDt, int days) {
		String formattedDate = "";
		try {
			Date d1 = getDateObject(fromDt, "dd/MM/yyyy");
			long newDate = d1.getTime() + days * dayInMilli;
			// System.out.println(newDate);
			Date d2 = new Date(newDate);
			System.out.println(d2);
			String newDateStr = d2.toString();
			SimpleDateFormat sdf = new SimpleDateFormat(
					"EEE MMM dd HH:mm:ss zzz yyyy");
			Date parsedt = sdf.parse(newDateStr);
			sdf.applyPattern("dd/MM/yyyy");
			formattedDate = sdf.format(parsedt);
			System.out.println(formattedDate);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return formattedDate;
	}

	public static Date addDays(Date d1, int days) {
		String formattedDate = "";
		Date d2 = null;
		try {
			long newDate = d1.getTime() + days * dayInMilli;
			// System.out.println(newDate);
			 d2 = new Date(newDate);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return d2;
	}
	
	public static Date getTruncatdate() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", localUS);
		String tempdt = sdf.format(getTodayDt());
		Date truncDate = null;
		try {
			truncDate = sdf.parse(tempdt);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return truncDate;
	}

	// Ended By Vishal 
	/**
	 * This method is used to get Today's date and time in string format.
	 * 
	 * @return java.lang.String
	 */
	// Please do not use it
	public static String getTodayDateTime() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
				localUS);
		return sdf.format(getTodayDt());
	}

	/**
	 * This method is used to get today's date in string format.
	 * 
	 * @return java.lang.String
	 */
	// Please do not use it
	public static String getTodayDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", localUS);
		return sdf.format(getTodayDt());
	}

	/**
	 * This method is used to get java.sql.Date from String. Input parameter
	 * date must be in 'dd/MM/yyyy' format.
	 * 
	 * @param dateStr
	 * @return
	 */
	// Not useful in Hibernate
	public static java.sql.Date getSQLDate(String dateStr) throws Exception {
		java.sql.Date sqlDate = null;

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", localUS);
		if (dateStr != null && !dateStr.equals("")) {
			java.util.Date parsedt = sdf.parse(dateStr);
			sqlDate = new java.sql.Date(parsedt.getTime());
		}

		return sqlDate;
	}

	// Not useful in Hibernate
	public static String getStringFromSQLDate(java.sql.Date sqlDate) {
		String sqlDateStr = null;

		sqlDateStr = String.format("%td/%<tm/%<ty", sqlDate);

		return sqlDateStr;
	}

	/**
	 * This method is used to get JBO date & time from input parameter. Input
	 * parameter should be in dd/mm/yyyy hh:mm:ss format.
	 * 
	 * @param java
	 *            .lang.String dateStr
	 * @return java.lang.String
	 */
	// No need now
	public static String getJBODateTime(String dateStr) throws Exception {
		String formattedDate = "";

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss",
				localUS);
		java.util.Date parsedt = sdf.parse(dateStr);

		sdf.applyPattern("yyyy-MM-dd HH:mm:ss");
		formattedDate = sdf.format(parsedt);

		// oracle.jbo.domain.Date l_o_today = new
		// oracle.jbo.domain.Date(formattedDate);
		// l_dt_date = l_o_today.toString();

		return formattedDate;
	}

	/**
	 * This method is used to get due date of return filing.
	 * 
	 * @param java
	 *            .util.Date rtnPrdToDate
	 * @return java.lang.String
	 */
	/*
	 * public static String getDueDateOfReturnFiling(String rtnPrdToDate) {
	 * String dueDate = ""; if (!"".equals(rtnPrdToDate)) { Date rtnPrdTo =
	 * getDateObject(rtnPrdToDate); Calendar cldt = Calendar.getInstance();
	 * cldt.setTime(rtnPrdTo); int month = cldt.get(Calendar.MONTH) + 1; //As
	 * Month In caleder Starts with 0 i.e January int year =
	 * cldt.get(Calendar.YEAR); int nxtMonth; int nxtYear; if ((month == 12) ||
	 * (month == 11) || (month == 10)) { nxtMonth = 1; nxtYear = year + 1; }
	 * else { nxtMonth = month + 1; nxtYear = year; } dueDate = "30/" +
	 * Integer.toString(nxtMonth) + "/" + Integer.toString(nxtYear); } return
	 * dueDate; }
	 */
	/**
	 * This method is used to get due date of yearly return filing.
	 * 
	 * @param java
	 *            .lang.String rtnPrdToDate
	 * @return java.lang.String
	 */
	/*
	 * public static String getDueDateOfReturnFilingYearly(String rtnPrdToDate)
	 * { String dueDate = ""; if (!"".equals(rtnPrdToDate)) { Date rtnPrdTo =
	 * getDateObject(rtnPrdToDate); Calendar cldt = Calendar.getInstance();
	 * cldt.setTime(rtnPrdTo); int month = cldt.get(Calendar.MONTH) + 1; //As
	 * Month In caleder Starts with 0 i.e January int year =
	 * cldt.get(Calendar.YEAR); int nxtMonth; int nxtYear;
	 * 
	 * nxtMonth = month + 3; nxtYear = year; dueDate = "30/" +
	 * Integer.toString(nxtMonth) + "/" + Integer.toString(nxtYear); } return
	 * dueDate; }
	 */

	/**
	 * This method is used to get java date & time. Input should be in
	 * dd/mm/yyyy hh:mm:ss format.
	 * 
	 * @param java
	 *            .lang.String
	 * @return java.lang.String
	 */
	// No need now
	public static String getJavaDateTime(String dateStr) throws Exception {

		String l_dt_date = "";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss",
				localUS);
		java.util.Date parsedt = sdf.parse(dateStr);

		sdf.applyPattern("dd/MM/yyyy hh:mm:ss");
		l_dt_date = sdf.format(parsedt);

		return l_dt_date;
	}

	/**
	 * Following function takes input as string which is date in the format of
	 * dd/mm/yyyy and output the string in the yyyy-mm-dd format(jbo date
	 * format)
	 */
	// No need
	public static String getDate(String strDate) throws Exception {

		String formattedDate = "";
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", localUS);
		java.util.Date parsedt = sdf.parse(strDate);
		sdf.applyPattern("yyyy-MM-dd");
		formattedDate = sdf.format(parsedt);

		return formattedDate;
	}

	/**
	 * This method is used to get date in java.lang.String format from
	 * oracle.jbo.domain.Date
	 * 
	 * @param oracle
	 *            .jbo.domain.Date
	 * @return java.lang.String
	 */
	// No need
	/*
	 * public static String getDateString(Date date) { String lStrDate = ""; if
	 * (date != null) { lStrDate = formatDate(date); } return lStrDate; }
	 */

	/**
	 * This method is used to get Time in 24 hours format from
	 * oracle.jbo.domain.Date to java.lang.String format.
	 * 
	 * @param oracle
	 *            .jbo.domain.Date
	 * @return java.lang.String
	 */
	// no need
	public static String getTime24String(Date date) {
		String lStrDate = "";
		if (date != null) {
			lStrDate = formatDate24(date);
		}
		return lStrDate;
	}

	/**
	 * This method is used to get Time in 24 hours format from
	 * oracle.jbo.domain.Date to java.lang.String format.
	 * 
	 * @param oracle
	 *            .jbo.domain.Date
	 * @return java.lang.String
	 */
	// no need
	public static String getTime12String(Date date) {
		String lStrDate = "";
		if (date != null) {
			lStrDate = formatDate12(date);
		}
		return lStrDate;
	}

	/**
	 * This method is used to convert java.lang.String date into java.util.Date.
	 * 
	 * @param java
	 *            .lang.String
	 * @return java.util.Date
	 */
	// No need now
	/*
	 * public static Date getDateObject(String strDate) { java.util.Date parsedt
	 * = null; try { if (strDate != null && !strDate.equals("")) {
	 * SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", localUS);
	 * parsedt = sdf.parse(strDate); return parsedt; } else return null;
	 * 
	 * } catch (Exception e) { throw new GenericFrameworkException(e); } }
	 */

	/**
	 * Following function takes input as string which is date in the format of
	 * yyyy-mm-dd format(jbo date format) and output the string in the
	 * dd/mm/yyyy format(standard format)
	 */
	// no need
	/*
	 * public static String dispDate(String strDate) {
	 * 
	 * String convrtdDate = ""; try { SimpleDateFormat sdf = new
	 * SimpleDateFormat("yyyy-MM-dd", localUS); java.util.Date parsedt =
	 * sdf.parse(strDate); sdf.applyPattern("dd/MM/yyyy"); convrtdDate =
	 * sdf.format(parsedt); } catch (Exception e) { throw new
	 * GenericFrameworkException(e); } return convrtdDate; }
	 */
	/**
	 * This method is used to get today's date in java.lang.String
	 * 
	 * @return java.lang.String
	 */
	// no need
	/*
	 * public static String dispTodayDate() {
	 * 
	 * String convrtdDate = ""; try { SimpleDateFormat sdf = new
	 * SimpleDateFormat("dd/MM/yyyy", localUS); convrtdDate =
	 * sdf.format(todayDt); } catch (Exception e) { throw new
	 * GenericFrameworkException(e); } return convrtdDate; }
	 */

	// no need
	/*
	 * public static String formatDate(java.util.Date dateValue) { String
	 * formattedDate = ""; if (dateValue != null) { SimpleDateFormat sdf = new
	 * SimpleDateFormat("dd/MM/yyyy", localUS); formattedDate =
	 * sdf.format(dateValue); } return formattedDate; }
	 */

	/**
	 * This method is used to format Date in 24 hours
	 * 
	 * @param java
	 *            .util.Date
	 * @return java.lang.String
	 */
	// no need
	public static String formatDate24(java.util.Date dateValue) {
		String formattedDate = "";
		if (dateValue != null) {
			SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss", localUS);
			formattedDate = sdf.format(dateValue);
		}
		return formattedDate;
	}

	/**
	 * This method is used to format Date in 12 hours
	 * 
	 * @param java
	 *            .util.Date
	 * @return java.lang.String
	 */
	// no need
	public static String formatDate12(java.util.Date dateValue) {
		String formattedDate = "";
		if (dateValue != null) {
			SimpleDateFormat sdf = new SimpleDateFormat("h:mm:ss a", localUS);
			formattedDate = sdf.format(dateValue);
		}
		return formattedDate;
	}

	/**
	 * This method is used to convert java.lang.String to java.util.Date with
	 * dd/MM/yyyy format
	 * 
	 * @param java
	 *            .lang.String
	 * @return java.util.Date
	 */
	// no need
	public static java.util.Date parseDate(String formattedDate)
			throws Exception {
		java.util.Date dateValue = null;
		if (formattedDate != null) {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", localUS);
			dateValue = sdf.parse(formattedDate);
		}

		return dateValue;
	}

	/**
	 * This method is used to calculate financial year.
	 * 
	 * @return java.util.Date
	 */
	// No need
	public static Date calFinancialYr() {

		Date utDt = null;
		Calendar cldt = Calendar.getInstance();
		cldt.setTime(getTodayDt());
		int month = cldt.get(Calendar.MONTH); // get the current month
		int year = cldt.get(Calendar.YEAR); // get the current year

		if (month > 2) {
			year++;

		}

		cldt.set(year, 2, 31);
		utDt = cldt.getTime();
		return utDt;
	}

	/**
	 * This method is used to replace String.
	 * 
	 * @param inString
	 * @param searchStr
	 * @param replaceStr
	 * @return
	 */
	private static String replaceString(String inString, String searchStr,
			String replaceStr) {
		String retStr = inString; // Holds the return String
		StringBuffer tempStr = new StringBuffer();

		int indexPos = 0; // Current position of the search String
		int prevPos = 0; // Previous position of the search String

		// If the input string or search string is null then don't proceed.
		if (inString == null || searchStr == null) {
			return retStr;
		}

		// Replace the search string with the replace string for all the
		// occurrences in inString
		indexPos = inString.indexOf(searchStr, indexPos);
		while (indexPos >= 0) {
			tempStr.append(inString.substring(prevPos, indexPos)).append(
					replaceStr);
			indexPos = indexPos + searchStr.length();
			prevPos = indexPos;
		}

		// Append the remaining characters in the String to the temporary
		// buffer.
		tempStr.append(inString.substring(prevPos));

		// If everything went fine then assigne the temporary buffer to the
		// return String.

		retStr = tempStr.toString();

		return retStr;
	}

	/**
	 * This function will return the array of String which contain two dates one
	 * is start date of Quarter and 2nd date is end date of Quarter
	 * 
	 * @param dt
	 * @return
	 */
	public static String[] getPreviousQuarterDates(Date dt) {
		if (dt == null) {
			return null;
		}
		String dateArry[] = new String[2];
		String startDate = "01/";
		String quaterEndDate = "";
		String endMonth = "0";
		Calendar cldt = Calendar.getInstance();
		cldt.setTime(dt);
		int month = cldt.get(Calendar.MONTH) + 1; // get the current month add 1
													// as month start from 0
		int year = cldt.get(Calendar.YEAR); // get the current year
		int endDate = 0;
		;
		if (month >= 4 && month <= 6) {
			month = 1;
			endMonth = "03";
			endDate = 31;
		} else if (month >= 7 && month <= 9) {
			month = 4;
			endMonth = "06";
			endDate = 30;
		} else if (month >= 10 && month <= 12) {
			month = 7;
			endMonth = "09";
			endDate = 30;
		} else if (month >= 1 && month <= 3) {
			month = 10;
			endMonth = "12";
			endDate = 31;
			year--;
		}
		if (month < 10) {
			startDate = startDate + "0" + month + "/" + year;
			quaterEndDate = endDate + "/" + endMonth + "/" + year;
		} else {
			startDate = startDate + month + "/" + year;
			quaterEndDate = endDate + "/" + endMonth + "/" + year;
		}
		dateArry[0] = startDate;
		dateArry[1] = quaterEndDate;
		return dateArry;
	}

	/**
	 * Function will return the Start and End Date of financial year
	 * 
	 * @param dt
	 * @return
	 */
	public static String[] getPreviousYearFinacailDates(Date dt) {
		if (dt == null) {
			return null;
		}
		String dateArry[] = new String[2];
		String startDate = "01/04/";
		String quaterEndDate = "31/03/";
		Calendar cldt = Calendar.getInstance();
		cldt.setTime(dt);
		int month = cldt.get(Calendar.MONTH) + 1; // get the current month add 1
													// as month start from 0
		int year = cldt.get(Calendar.YEAR); // get the current year
		if (month >= 1 && month <= 3) {
			year--;
		}
		dateArry[0] = startDate + (year - 1);
		dateArry[1] = quaterEndDate + (year);
		return dateArry;
	}

	/**
	 * This method will return the Start and End Date of privious month
	 * 
	 * @param str1
	 * @return
	 */
	public static String[] getPreviousMonthDate(Date str1) {
		Calendar cldt = Calendar.getInstance();
		cldt.setTime(str1);
		String[] strDates = new String[2];
		int month = cldt.get(Calendar.MONTH) + 1;
		int year = cldt.get(Calendar.YEAR);
		int endDate = 0;
		if (month == 4 || month == 6 || month == 9 || month == 11) {
			endDate = 30;
		} else if (month == 2) {
			endDate = 28;
			if ((year % 4 == 0 && year % 100 != 0)
					|| (year % 100 == 0 && year % 400 == 0)) {
				endDate = 29;
			}
		} else {
			if (month == 1) {
				month = 12;
			}
			endDate = 31;
		}

		if (month != 1) {
			month = month - 1;
		}
		if (month < 10) {
			strDates[0] = "01/0" + month + "/" + year;
			strDates[1] = endDate + "/0" + month + "/" + year;
		} else {
			strDates[0] = "01/" + month + "/" + year;
			strDates[1] = endDate + "/" + month + "/" + year;
		}
		return strDates;
	}

	/**
	 * The function returns the number of days between 2 dates. The number of
	 * days is irrespective of the time of the day. If one date is of 08-12-2010
	 * 23:59:00 and other date of 09-12-2010 00:00:01 even then the difference
	 * of 2 minutes will return 1 day as the day has crossed.
	 * 
	 * @param d1
	 * @param d2
	 * @return
	 */
	public static long daysBetweenDates(Date d1, Date d2) {
		long daysDiff = 0;
		Calendar c1 = Calendar.getInstance();
		Calendar c2 = Calendar.getInstance();
		c1.setTime(d1);
		c2.setTime(d2);

		DateUtility.setMidnight(c1);
		DateUtility.setMidnight(c2);

		daysDiff = (c1.getTimeInMillis() - c2.getTimeInMillis()) / dayInMilli;

		return Math.abs(daysDiff);
	}

	/**
	 * The function sets the caledar object to the midnight time. It is
	 * specially required while comparison or setting today date without time
	 * stamp.
	 * 
	 * @param cal
	 */
	public static void setMidnight(Calendar cal) {
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
	}

	public static void main(String args[]) throws Exception {
		String defaultTimeZone = TimeZone.getDefault().getID();
		TimeZone.setDefault(TimeZone.getTimeZone("IST"));// Indian Time Zone
		System.out.println("Default Time Zone : " + defaultTimeZone
				+ ", Time Zone Set : " + TimeZone.getDefault().getID());

		System.out.println(getTodayDateString(DateUtility.formatOra));
		System.out.println(getTodayDateString(DateUtility.formatOraWithTime));

		Date todayDt = new Date();
		Date d1;
		Calendar c1 = Calendar.getInstance();
		c1.add(Calendar.DAY_OF_YEAR, -1);
		d1 = c1.getTime();
		System.out.println("Days Diff : " + DateUtility.dateDiff(d1, todayDt));

		c1.add(Calendar.HOUR_OF_DAY, 1);
		d1 = c1.getTime();
		System.out.println("Days Diff : " + DateUtility.dateDiff(d1, todayDt));
		System.out.println("Days Diff : "
				+ DateUtility.daysBetweenDates(d1, todayDt));

		c1.add(Calendar.HOUR_OF_DAY, 22);
		d1 = c1.getTime();
		System.out.println("Days Diff : " + DateUtility.dateDiff(d1, todayDt));
		System.out.println("Days Diff : "
				+ DateUtility.daysBetweenDates(d1, todayDt));

		System.out.println("Financial Year : "
				+ getFinancialYearAsYYYYyyyy(todayDt));

		c1.set(Calendar.MONTH, Calendar.APRIL);
		System.out.println("Financial Year : "
				+ getFinancialYearAsYYYYyyyy(c1.getTime()));

		System.out.println("Financial Quarter :  " + getFinancialQuarter());

	}

	public static int getFinancialQuarter() {
		int tmp = Calendar.getInstance().get(Calendar.MONTH) / 3;
		return (tmp == 0) ? 4 : tmp;
	}
	
	public static Calendar getPreviousMonthStartDt()
	{
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -1);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		setMidnight(cal);
		return cal;
	}
	
	public static Calendar getCurrentMonthStartDt()
	{
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, 1);
		setMidnight(cal);
		return cal;
	}
	
	public static Calendar getPreviousMonthEndDt()
	{
		Calendar cal = getCurrentMonthStartDt();
		cal.add(Calendar.SECOND, -1);
		return cal;
	}
	
	public static Calendar getCurrentMonthEndDt()
	{
		Calendar cal = getCurrentMonthStartDt();
		cal.add(Calendar.MONTH, 1);
		cal.add(Calendar.SECOND, -1);
		return cal;
	}
	
	public static Calendar getDateValue(String dateType,Calendar cal) throws Exception
	{
		
		if(dateType.length() == 5) 
		{
			if(dateType.charAt(0) == 'C') // For cases of CWSDT,CWEDT, CMSDT, CMEDT, CQSDT, CQEDT, CYSDT, CYEDT
			{
				switch(dateType.charAt(1)) // For W,M,Q,Y
				{
				case 'W' : // For Week
					if(dateType.charAt(2) == 'S') // for starting
					{
						cal.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
					}
					else // for ending
					{
						cal.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
					}
					break;
				case 'M' : // For Month
					if(dateType.charAt(2) == 'S') // for starting
					{
						cal.set(Calendar.DAY_OF_MONTH, 1);
					}
					else // for ending 
					{
						cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
					}
					break;
				case 'Q' : // For Quarter
					cal.add(Calendar.MONTH, getNumOfMonthToPrviousQuarterStart(cal));
					cal.add(Calendar.MONTH, 3);
					if(dateType.charAt(2) == 'S') // for starting
					{
						cal.set(Calendar.DAY_OF_MONTH, 1);
					}
					else // for ending
					{
						cal.add(Calendar.MONTH, 2);
						cal.set(Calendar.DAY_OF_MONTH, cal.getMaximum(Calendar.DAY_OF_MONTH));
					}
					break;
				case 'Y' : // For Year
					cal.add(Calendar.YEAR, getNumOfYearToPreviousFinancialYear(cal));
					cal.add(Calendar.YEAR, 1);
					if(dateType.charAt(2) == 'S') // for starting
					{
						cal.set(Calendar.MONTH, Calendar.APRIL);
						cal.set(Calendar.DAY_OF_MONTH, 1);
					}
					else // for ending
					{
						cal.add(Calendar.YEAR, 1);
						cal.set(Calendar.MONTH, Calendar.MARCH);
						cal.set(Calendar.DAY_OF_MONTH, cal.getMaximum(Calendar.DAY_OF_MONTH));
					}
					break;
				}
			}
			else // For cases of LWSDT, LWEDT, LMSDT, LMEDT, LQSDT, LQEDT, LYSDT, LYEDT
			{
				switch(dateType.charAt(1)) // For W,M,Q,Y
				{
				case 'W' : // For Week
					cal.add(Calendar.WEEK_OF_YEAR, -1);
					if(dateType.charAt(2) == 'S') // for starting
					{
						cal.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
					}
					else // for ending
					{
						cal.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
					}
					break;
				case 'M' : // For Month
					cal.add(Calendar.MONTH, -1);
					if(dateType.charAt(2) == 'S') // for starting
					{
						cal.set(Calendar.DAY_OF_MONTH, 1);
					}
					else // for ending 
					{
						cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
					}
					break;
				case 'Q' : // For Quarter
					cal.add(Calendar.MONTH, getNumOfMonthToPrviousQuarterStart(cal));
					if(dateType.charAt(2) == 'S') // for starting
					{
						cal.set(Calendar.DAY_OF_MONTH, 1);
					}
					else // for ending
					{
						cal.add(Calendar.MONTH, 2);
						cal.set(Calendar.DAY_OF_MONTH, cal.getMaximum(Calendar.DAY_OF_MONTH));
					}
					break;
				case 'Y' : // For Year
					
					cal.add(Calendar.YEAR, getNumOfYearToPreviousFinancialYear(cal));
					if(dateType.charAt(2) == 'S') // for starting
					{
						cal.set(Calendar.MONTH, Calendar.APRIL);
						cal.set(Calendar.DAY_OF_MONTH, 1);
					}
					else // for ending
					{
						cal.add(Calendar.YEAR, 1);
						cal.set(Calendar.MONTH, Calendar.MARCH);
						cal.set(Calendar.DAY_OF_MONTH, cal.getMaximum(Calendar.DAY_OF_MONTH));
					}
					break;
				}
			}
		}
		return cal;
	}
	
	private static int getNumOfMonthToPrviousQuarterStart(Calendar cal)
	{
		int currMonth = cal.get(Calendar.MONTH);
		return ((2 + ((currMonth)%3) + 1)* -1);
	}
	
	private static int getNumOfYearToPreviousFinancialYear(Calendar cal)
	{
		int currMonth = cal.get(Calendar.MONTH);
		if(currMonth < 3)
			return -2;
		else return -1;
	}
}
