package com.klicksort.apps.common.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;


public class CommonUtility 
{ 
	private static String pathSeparator = "\\";
	
	// To initialize the properties
	static
	{
		ResourceBundle resourceBundle = null;
		String tmpPathSeparator = null;
		try
    	{
    		resourceBundle = ResourceBundle.getBundle("conf.CommonConfig");
    		tmpPathSeparator = resourceBundle.getString("path.separator");
    		if(tmpPathSeparator != null && !"".equals(tmpPathSeparator))
    			pathSeparator = tmpPathSeparator;
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
	}
	
	/**
	 * The method returns the system file path separator which is configured
	 * in CommonConfig by property name of path.separator
	 * @return
	 */
	public static String getPathSeparator()
	{
		return pathSeparator;
	}
	
    public CommonUtility() 
    { 
    }
    /*
    public static Long getJBONumber(String asNumStr)
    {
        Long liIntStr = 0L;

        if ((asNumStr != null) && !asNumStr.trim().equals(""))
        {
            liIntStr = Long.parseLong(asNumStr);
            return liIntStr;
        }
		return null;   
    }
    */
    //This Method takes LookUp Type as argument and returns Map of code - description
    
    /*
     * This method returns Reg Status from status code given by centre
     * i.e:A,E,H,R
     */
    public static Double getDoubleFromString(String asNumStr)
    {
        Double liIntStr = null;
        if ((asNumStr != null) && !asNumStr.trim().equals(""))
        {
            liIntStr = Double.parseDouble(asNumStr);
        }
        return liIntStr;
    }
    
    public static Double getDoubleFromStringWithDefault(String asNumStr)
    {
        Double liIntStr = 0.0;
        if ((asNumStr != null) && !asNumStr.trim().equals(""))
        {
            liIntStr = Double.parseDouble(asNumStr);
        }
        return liIntStr;
    }
    
    /**
     *  Function to convert the integer in the string format to
     *  oracle.jbo.domain.number format
     * @param String asNumStr
     * @return oracle.jbo.domain.number
     */
       public static Float getFloatFromString(String asNumStr)
       {
           Float liIntStr = null;
           if ((asNumStr != null) && !asNumStr.trim().equals(""))
           {
               liIntStr = Float.parseFloat(asNumStr);
           }
           return liIntStr;
       }
       
       public static Long getLongFromString(String asNumStr)
       {
           Long liIntStr = null;
           if ((asNumStr != null) && !asNumStr.trim().equals(""))
           {
               liIntStr = Long.parseLong(asNumStr);
           }
           return liIntStr;
       }
       public static Integer getIntegerFromString(String asNumStr)
       {
           Integer liIntStr = null;
           if ((asNumStr != null) && !asNumStr.trim().equals(""))
           {
               liIntStr = Integer.parseInt(asNumStr);
           }
           return liIntStr;
       }
       
       public static Integer getIntegerFromLong(Long asNum)
       {
           if (asNum != null)
           {
        	   Integer i = asNum.intValue();
               return i;
           }
		return null;               
      }
       public static long getlongPrimitiveFromString(String asNumStr)
       {
           long liIntStr = 0L;
           if ((asNumStr != null) && !asNumStr.trim().equals(""))
           {
               liIntStr = Long.parseLong(asNumStr);
           }
		return liIntStr;
       }
  
       
           
    public static String formatFloatAsPercentage(float value)
       {
         DecimalFormat decimalFormat = new DecimalFormat();
         decimalFormat.applyPattern("##0.0#");         
         return decimalFormat.format((new Double(value)).doubleValue());
       }
    
    /**
     * Function to check if the String being passed is null or not.
     * if it is null then it is converted to a blank value.
     * @param java.lang.String
     * @return java.lang.String
     */
       public static String checkNull(String asCheckString)
       {
           if (asCheckString == null)
           {
               return "";
           }

           return asCheckString;
       }
    
    /**
     * Function to check if the object being passed is null or not.
     * if it is null then it is converted to a blank value else return its string .
     * @param java.lang.String
     * @return java.lang.String
     */ 
    public static String checkNullObj(Object aoCheckObject)
    {
            if (aoCheckObject == null)
            {
                return "";
            }
            return aoCheckObject.toString();
     }
  
    public static String checkNullNumeric(String aoCheckObject)
    {
            if (aoCheckObject == null)
            {
                return "0";
            }
            return aoCheckObject.toString();
     }

    
        /**
      * Replaces comma from any numeric data. If input is in Indian Rupee format, this function returns
      * a String after removing all the comma from the input.
      * @return 
      * @param number
      */
    public static String removeCommaFrmNumber(String number) 
    {
    	boolean flag= false;
        if ((number == null) || number.equals("")) {
            return "";
        }

        number = number.replaceAll(",", "");

        double wholeDigit            = new Double(number).doubleValue();
       
        long   Intpart            = (long) (wholeDigit * 100) / 100;
        if(wholeDigit<0 && Intpart==0)
        {
        	flag=true;	
        }
        String deciPart     = "" + (wholeDigit - Intpart);
        int    decimalIndex = deciPart.indexOf(".");
        String decimalPart  = "";

        if (decimalIndex != -1) {
            decimalPart = deciPart.substring(decimalIndex);

            if (decimalPart.length() > 3) {
                int k = Integer.parseInt("" + decimalPart.charAt(3));

                if (k >= 5) {
                    int temp = Integer.parseInt(decimalPart.substring(1, 3)) + 1;

                    if (temp < 100) {
                        decimalPart = "." + keepTwoDigits("" + temp);
                    } else {
                    	Intpart           = Intpart + 1;
                        decimalPart = ".0";
                    }
                } else {
                    decimalPart = decimalPart.substring(0, 3);
                }
            }

            if (Integer.parseInt(decimalPart.substring(1)) == 0) {
                decimalPart = "";
            }
        }
       if(!flag)
        number = Intpart + decimalPart;
       else
    	   number = "-"+Intpart + decimalPart;

        return number;
    }

    private static String keepTwoDigits(String input) {
        if ((input == null) || input.equals("")) {
            return "";
        }

        if (input.length() > 2) {
            input = input.substring(0, 2);
        }

        while (input.length() < 2) {
            input = "0" + input;
        }

        return input;
    }
    
    /**
      * Converts an input numeric String to Indian Rupee format
      * @return A String containing the Indian Rupee format of the input String
      * @param objNumber
      */
     public static String convertToIndianRupeeFormat(Object objNumber)
     {
       if(objNumber == null)
         return "";
       String number = objNumber.toString();
       if(number == null || number.equals(""))
       {
         return "";
       }
       String formatNumber = "";
       
       //getting the sign of the input
       String sign = "";
       double d = new Double(number).doubleValue();
       long l = (long)(d*100)/100;
       if(d < 0)
         sign = "-";
       
       //if you directly take index of "." then if the number is in double format containing E
       //then it will give incorrect result. hence the following way is used
       String deciPart = "" + (d - l);
       //separating decimal part :
       int decimalIndex = deciPart.indexOf(".");
       String decimalPart = "";
       if(decimalIndex != -1)
       {
         decimalPart = deciPart.substring(decimalIndex);
         if(decimalPart.length() > 3)
         {
           int k = Integer.parseInt(""+decimalPart.charAt(3));
           if(k >= 5)
           {
             int temp = Integer.parseInt(decimalPart.substring(1,3)) + 1;
             if(temp < 100)
               decimalPart = "." + keepTwoDigits(""+temp);
             else
             {
               l = l + 1;
               decimalPart = ".0";
             }
           }
           else
             decimalPart = decimalPart.substring(0, 3);
         }
         else  if(decimalPart.length()== 0)
         {
        	 decimalPart=".00";
         }
         else  if(decimalPart.length()== 2)
         {
        	 decimalPart=decimalPart+"0";
         }
         /*if(Integer.parseInt(decimalPart.substring(1)) == 0) 
           decimalPart = "";*/
       }
       
       l = Math.abs(l);
       
       //converting into indian number format
       if(l > 999)
       {
         int i = 1;
         while(l != 0)
         {
           if(i == 1)
           {
             String temp = new Long(l % 1000).toString();
             while(temp.length() < 3)
             {
               temp = "0" + temp;
             }
             formatNumber = "," + temp + formatNumber;
             l = l/1000;
           }
           else
           {
             String temp = new Long(l % 100).toString();
             while(temp.length() < 2)
             {
               temp = "0" + temp;
             }
             formatNumber = "," + temp + formatNumber;
             l = l/100;
           }
           i++;
         }
       }
       else
       {
         formatNumber = "" + l;
       }
       //formatting the final result
       formatNumber = formatNumber + decimalPart;
       if(formatNumber.startsWith(","))
         formatNumber = formatNumber.substring(1);
       if(formatNumber.startsWith("0") && !formatNumber.substring(1,2).equals("."))
         formatNumber = formatNumber.substring(1);
       formatNumber = sign + formatNumber;
       return formatNumber;
     }
    // getJBONumberRemoveComma->
	public static Long getNumberAfterRemovingCommaFrmString(String lStrNum) throws Exception
	{
		Long lnJboNum = null;
		String lstrNumTmp = removeCommaFrmNumber(lStrNum);
		if (lstrNumTmp != null && !"".equals(lstrNumTmp))
		{
			lnJboNum = Long.parseLong(lstrNumTmp);
		}

		return lnJboNum;
	}

	/**
	 * Function returns the Double variable after removing comma from the input string
	 * @param lStrNum
	 * @return
	 *   Double object or null
	 * @throws GenericFrameworkException
	 */
	public static Double getDoubleAfterRemovingCommaFrmString(String lStrNum) throws Exception
	{
		Double lnJboNum = null;
		String lstrNumTmp = removeCommaFrmNumber(lStrNum);
		if (lstrNumTmp != null && !"".equals(lstrNumTmp))
		{
			lnJboNum = Double.parseDouble(lstrNumTmp);
		}

		return lnJboNum;
	}
	
   public static String removeEfrmNumber(Object numberObj) 
    {
      String returnNumber = "";
      if(numberObj == null)
      {
        return "";
      }
      String number = numberObj.toString();
      if(number == null || number.equals(""))
      {
        return "";
      }
	/*double d = new Double(number).doubleValue();
	long l = new Double(number).longValue();
	String decimalPart = String.valueOf(((d*100)-(l*100))/100);
	if(decimalPart.indexOf(".") != -1)
	{
	  int index = decimalPart.indexOf(".");
	  decimalPart = decimalPart.substring(index);
	  if(decimalPart.length() > 3)
	  {
	    decimalPart = decimalPart.substring(0,3);
	  }
	  else if(decimalPart.length() == 2)
	  {
		  decimalPart += "0";
	  }
	}
	returnNumber = String.valueOf(l) + decimalPart;*/
      
      	BigDecimal num = new BigDecimal(number);
		String numStr = num.toPlainString();
		
		String[] numArr = numStr.split("\\.");
		
		returnNumber = numArr[0];
		if(numArr.length == 2)
		{
			if(numArr[1].length() > 2)
				returnNumber += "." + numArr[1].substring(0,2);
			else if(numArr[1].length() == 1)
				returnNumber += "." + numArr[1] + "0";
			else
				returnNumber += "." + numArr[1];
		}
		
      return returnNumber;
    }
    
    /**
    *  this function will return the N/A if Object/String is null
    * @return 
    * @param string
    */
    public static String ObjNullBlankToNA(Object string)
    { 
        if(string==null || string.toString()==null || string.toString().equals(""))
        {
            return "N/A";
        }
        return string.toString();
    }

	public static byte[] blobToByteArray(Blob fromImageBlob) throws SQLException, IOException
	{
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		byte buf[] = new byte[4000];
		int dataSize;
		InputStream is = fromImageBlob.getBinaryStream();

		try
		{
			while ((dataSize = is.read(buf)) != -1)
			{
				baos.write(buf, 0, dataSize);
			}
		}
		finally
		{
			if (is != null)
			{
				is.close();
			}
		}
		return baos.toByteArray();
	}

	public static boolean validateFileExtn(String name)
	{
		return validateFileExtn(name, new String[]{"pdf","xls","csv","doc","docx","xlsx","jpg","jpeg"});
	}
	
	public static boolean validateFileExtn(String name, String[] extnList)
	{
		boolean valid = false;
		try{
		int index = name.lastIndexOf('.')+1;
		if(index > 0)
		{
			String fileExtn = name.substring(name.lastIndexOf('.')+1);
			for(String extn : extnList)
			{
				if(fileExtn.equalsIgnoreCase(extn))
				{
					valid = true;
					break;
				}
			}
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return valid;
	}
	
	public static void main(String[] args) throws Exception
	{
		System.out.println(removeEfrmNumber("123456789012.5667"));
		System.out.println(removeEfrmNumber("-0.222E2"));
		System.out.println(removeEfrmNumber("9876543200123.45"));
		System.out.println(checkNullAndCaret("This is\n new line\r test and ^ carrot test"));
	}
	
	public static BigDecimal getBigDecimalFromString(String str) throws Exception
	{
		BigDecimal rtnVal = null;
		if("".equalsIgnoreCase(str) || str==null)
			return rtnVal;
		else
			rtnVal = new BigDecimal(str);
		return rtnVal;
	}
	public static String getStringFromLong(Long lng)
    {
    	return lng == null?"":removeEfrmNumber(lng);
    }
	public static String getStringFromDouble(Double dble)
    {
    	return dble == null?"":removeEfrmNumber(dble);
    }
	
	public static String checkNullAndCaret(String asCheckString)
    {
        if (asCheckString == null)
        {
            return "";
        }
        else
        {
        	asCheckString = asCheckString.replaceAll("\\^", "");
        	asCheckString = asCheckString.replaceAll("\\n", "");
        	asCheckString = asCheckString.replaceAll("\\r", "");
        	asCheckString = asCheckString.replaceAll("\\f", "");
        }

        return asCheckString;
    }
	
	public static boolean isNullOrEmptyString(String checkString)
	{
		return CommonUtility.checkNull(checkString).equals("");
	}
	
	public static boolean isNullOrEmptyObject(Object checkString)
	{
		if(checkString != null)
		return checkString.toString().equals("");
		else return true;
	}
	
	public static byte[] readZipEntryFromZip(ZipInputStream zis, ZipEntry zipEntry) throws IOException
	{
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		int BUFFER = 2048;
		byte[] data = new byte[BUFFER];
		int count;
		while ((count = zis.read(data, 0, BUFFER)) != -1)
		{
			baos.write(data, 0, count);
		}
		baos.close();
		
		return baos.toByteArray();
	}
	
	public static void writeZipEntryFromData(ZipOutputStream zos, String entryName, byte[] data) throws IOException
	{
		ZipEntry zipEntry = new ZipEntry(entryName);
		zos.putNextEntry(zipEntry);
		zos.write(data);
	}
	
	public static double getPrimitiveDoubleFromString(String asNumStr)
    {
        double liIntStr = 0.0;
        if (!isNullOrEmptyString(asNumStr))
        {
            liIntStr = Double.parseDouble(asNumStr);
        }
        return liIntStr;
    }
	
  } 
  
