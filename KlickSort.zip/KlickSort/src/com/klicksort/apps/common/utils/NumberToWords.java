package com.klicksort.apps.common.utils;

import java.math.BigDecimal;


public class NumberToWords {

	public static String RUPEESTXT = "Rupees";
	public static String PAISATXT = "Paisa";
	private static final String[] ONES = {
		"Zero ", "One ", "Two ", "Three ", "Four ", "Five ",
		"Six ", "Seven ", "Eight ", "Nine " };
	private static final String[] TEENS = {
		"Ten ", "Eleven ", "Twelve ", "Thirteen ", null, "Fifteen ",
		null, null, "Eighteen ", null };
	private static final String[] TENS = {
		null, null, "Twenty ", "Thirty ", "Forty ", "Fifty ",
		"Sixty ", "Seventy ", "Eighty ", "Ninety " };

	private static String scaleName[] = {"Thousand ", "Lakh ", "Crore ", "Arab ", "Kharab ", "Neel ", "Padma ", "Shankh ", "Udpadha ", "Ank ", "Jald ", "Madh "};
	/**
	 * Convert number between 0 - 99
	 * @param number
	 * @return
	 */
	private static String convertUpto99(int number) {
		if (number<10) {
			return ONES[number];
		} else if (number<20) {
			int n = number - 10;
			String words = TEENS[n];
			return words==null ? ONES[n]+"teen " : TEENS[n];
		} else {
			int n = number % 10;
			return TENS[number/10] +
				(n==0 ? "" : (convertUpto99(n)));
		}
	}

	public static void main(String[] args) throws Exception {
		/*for (int i=0; i<100; i++) {
			System.out.println(i+" "+convertUpto99(i));
		}*/

		printTest(100);
		printTest(101);
		printTest(110);
		printTest(126);
		printTest(500);
		printTest(789);
		printTest(999);
		printTest(1000);
		printTest(1001);
		printTest(1023);
		printTest(1234);
		printTest(5678);
		printTest(11000);
		printTest(12345);
		printTest(99000);
		printTest(100001);
		printTest(100012);
		printTest(100123);
		printTest(101234);
		printTest(9900012);
		printTest(9912345);
		printTest(19900012);
		printTest(569900012);
		printTest(1569900012);
		printTest(76569900012L);
		printTest(476569900012L);
		printTest(5676569900012L);
		printTest(1000000000012L);
		printTest(0.0);
		printTest(0.01);
		printTest(12345.345);
		printTest(0.10);
		printTest(0.23);
		printTest(0.345);
		printTest(123234556.122340);	
		printTest(Double.parseDouble("11.42"));
		printTest(Double.parseDouble("9876543200123.45"));
		printTest(9876543200123.45);
		printTest(CommonUtility.getDoubleAfterRemovingCommaFrmString("98,76,54,32,00,123.45"));
		
	}
	
	public static void printTest(double number)
	{
		try
		{
			System.out.println(number + " : " + convertNumberToWords(number, NumberToWords.RUPEESTXT, NumberToWords.PAISATXT ));
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Convert number between 100 - 999
	 * @param number
	 * @return
	 */
	private static String convertHundred(int number)
	{
		String convertedString = "";
		int lessThanHundred = number % 100;
		int hundreth = (int)(number / 100);
		
		if(hundreth > 0)
		{
			convertedString += convertUpto99(hundreth);
			convertedString += "Hundred ";
		}
		
		if(lessThanHundred > 0)
		{
			convertedString += convertUpto99(lessThanHundred);
		}
		
		return convertedString;
	}
	
	/**
	 * Convert number Upto 10 raise to power 25. I.e. thousand, lakh, crore, arab, kharab, neel, padma, shankh, Udpadha , Ank, Jald, Madh. 
	 * @param number
	 * @return
	 */
	public static String convertIntegralNumber(long number)
	{
		String convertedString = "";
		if(number == 0)
		{
			convertedString = ONES[0];
		}
		else
		{
			int lessThanThousand = (int)(number % 1000);
			long thousandAndAbove = (long)(number / 1000);
			//int currentScale = (int) (Math.floor(Math.log10(lakhAndAbove))/2);	
			
			if(thousandAndAbove > 0)
			{
				convertedString += convertMoreThanThousandRecursive(thousandAndAbove, 0);
			}
			
			if(lessThanThousand > 0)
			{
				convertedString += convertHundred(lessThanThousand);
			}
		}
		
		return convertedString;
	}
	
	private static String convertMoreThanThousandRecursive(long number, int currentScale)
	{
		String convertedString = "";
		int scaleValue = (int)(number % 100);
		number = number / 100;
		
		if(number > 0)
		{
			convertedString = convertMoreThanThousandRecursive(number, currentScale + 1);
		}
		
		if(scaleValue > 0)
		{
			convertedString += convertUpto99(scaleValue);
			convertedString += scaleName[currentScale];
		}
		
		return convertedString;
	}
	
	/**
	 * Convert a number to Indian currency words. E.g. 12345.345 : Twelve Thousand Three Hundred Forty Five Rupees AND Thirty Four Paisa
	 * @param number
	 * 			The number to convert.
	 * @return
	 * @throws Exception
	 */
	public static String convertNumberToWords(double number) throws Exception
	{
		return convertNumberToWords(number, NumberToWords.RUPEESTXT, NumberToWords.PAISATXT);
	}
	
	/**
	 * Convert a number to Indian currency words. E.g. 12345.345 : Twelve Thousand Three Hundred Forty Five Rupees AND Thirty Four Paisa
	 * @param number
	 * 			The number to convert.
	 * @param rupeesTxt
	 * 			The rupees text that will be appended in the converted text.
	 * @param paisaTxt
	 * 			The paisa text that will be appended in the converted text.
	 * @return
	 * @throws Exception
	 */
	public static String convertNumberToWords(double number, String rupeesTxt, String paisaTxt) throws Exception
	{
		if(number < 0)
			throw new Exception("Not a positive number : " + number);
		
		BigDecimal num = new BigDecimal(String.valueOf(number));
		String numStr = num.toPlainString();
		String convertedString = "";
		long integralPart = num.longValue();
		int floatPart = 0;
		
		int decimalStartIndex = numStr.indexOf('.') + 1;
		int decimalEndIndex = 0;
		
		if(decimalStartIndex > 0)
		{
			decimalEndIndex = decimalStartIndex + 2;
			if(decimalEndIndex > numStr.length())
				decimalEndIndex = numStr.length();
			
			floatPart = Integer.parseInt(numStr.substring(decimalStartIndex,decimalEndIndex));
			
		}
			
		
		convertedString = convertIntegralNumber((long)integralPart) + rupeesTxt + " ";
		
		if(floatPart > 0 && floatPart < 100)
			convertedString += "AND " + convertUpto99(floatPart) + paisaTxt; 
		
		return convertedString;
	}
}
