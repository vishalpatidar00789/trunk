package com.klicksort.apps.common.utils;

import javax.servlet.http.HttpServletRequest;


/**
 * StringUtility.java file is used to apply different type of string operations.
 * It converts the Requested Parameter or Parameter Array from the ISO-8859-1
 * to the UTF8 format. It also provides function to convert normal
 * text into HTML format. 
 */
public class StringUtility {
    public StringUtility() {
    }

    /**
     * This method is used to get parameter value from the request object.
     * If the fieldName is not found in the request object then this funcion will
     * return empty value
     * @param fieldName It is used to get value of this parameter
     * @param request This variable is used to get value of passed parameter in HttpServletRequest object
     * @return String contains value of filedName from request object.
     * @throws Exception
     */
    public static String getParameter(String fieldName, 
                                      HttpServletRequest request) throws Exception {
        String param = "";
        String tempParam = "";
        try {
            if (request.getParameter(fieldName) != null && 
                request.getParameter(fieldName).length() > 0) {
                //tempParam = new String(request.getParameter(fieldName).getBytes("ISO-8859-1"), "UTF8");
                tempParam = request.getParameter(fieldName);
                   param =  stringToHTMLString(tempParam);
                }
            else
                param = "";
        } catch (Exception e) {
            throw e;
        }
        return param;
    }

     /**
      * This method is used to get parameter values from the request object. This
      * function return array of String object. If the fieldName is not found in
      * request object then it will return String Array with size of 0.
      * @param fieldName It is used to get value of this parameter
      * @param request This variable is used to get value of passed parameter in HttpServletRequest object
      * @return array of String based on the fieldName parameter
      * @throws Exception
      */
    public static String[] getParameterValues(String fieldName, 
                                              HttpServletRequest request) throws Exception {
        String paramList[] = new String[0];
        String tempParamList[] = new String[0];
        if (request.getParameterValues(fieldName) != null)
            tempParamList = request.getParameterValues(fieldName);
        try {
            paramList = new String[tempParamList.length];
            if (tempParamList != null && tempParamList.length > 0) {
                for (int i = 0; i < tempParamList.length; i++){
//                    paramList[i] = new String(tempParamList[i].getBytes("ISO-8859-1"), "UTF8");
                    paramList[i] = tempParamList[i];
                }
            }
            tempParamList = null;
        } catch (Exception e) {
            throw e;
        }
        return paramList;
    }
    
    /**
     * This function is used to convert normal text into HTML format
     * @param string String which is used to convert into HTML format
     * @return contains HTML formated string
     */
    public static String stringToHTMLString(String string)
        {
            StringBuffer strBuffer = new StringBuffer(string.length());
            boolean lastWasBlankChar = false;
            int len = string.length();
            for(int i = 0; i < len; i++)
            {
                char chr = string.charAt(i);
                if(chr == ' ')
                {
                    if(lastWasBlankChar)
                    {
                        lastWasBlankChar = false;
                        strBuffer.append("&nbsp;");
                    } else
                    {
                        lastWasBlankChar = true;
                        strBuffer.append(' ');
                    }
                    continue;
                }
                lastWasBlankChar = false;
                if(chr == '"')
                {
                    strBuffer.append("&quot;");
                    continue;
                }
                if(chr == '&')
                {
                    strBuffer.append("&amp;");
                    continue;
                }
                if(chr == '<')
                {
                    strBuffer.append("&lt;");
                    continue;
                }
                if(chr == '>')
                {
                    strBuffer.append("&gt;");
                    continue;
                }
                if(chr == '\n')
                {
                    strBuffer.append("&lt;br/&gt;");
                    continue;
                }
                int cInt = 0xffff & chr;
                if(cInt < 160)
                {
                    strBuffer.append(chr);
                } else
                {
                    strBuffer.append("&#");
                    strBuffer.append(((Integer.valueOf(cInt))).toString());
                    strBuffer.append(';');
                }
            }
            return strBuffer.toString();
        }
    
    /**
     * Encode string replacing the special meta characters with the escaped charactes 
     * for Jasper report Styled Text Element
     * @param input
     * @return
     */
    public static String encodeStringForJasper(String input)
	{
		String result = input;
		if(input != null && !"".equals(input))
		{
			result = result.replaceAll("&", "&amp;");
			result = result.replaceAll("\\<", "&lt;");
			result = result.replaceAll("\\>", "&gt;");
			result = result.replaceAll("\"", "&quot;");
		}
		return result;
	}

    /**
     * This function solves the problem of hindi characters for pdf writing.
     * @param input
     * @return
     */
    public static String encodeHindiStringForJasper(String input)
	{
		StringBuilder sb = new StringBuilder();
		
		if(input != null && input.length() > 1)
		{
			sb.append(input.charAt(0));
			for(int i=1; i<input.length(); i++)
			{
				if(input.charAt(i) == '\u093F')
				{
					sb.insert(i-1, '\u093F');
				}
				else
				{
					sb.append(input.charAt(i));
				}
			}
		}
		return encodeStringForJasper(sb.toString());
	}
    
    public static String truncateStr(String val, int size)
	{
		String result = "";
		
		if(val != null && !"".equals(val))
		{
			if(val.length() > size)
			{
				result = val.substring(0, size);
			}
			else
			{
				result = val;
			}
		}
		return result;
	}
}

