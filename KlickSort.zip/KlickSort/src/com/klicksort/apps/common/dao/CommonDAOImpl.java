package com.klicksort.apps.common.dao;

import java.util.List;

import com.klicksort.apps.common.expection.ObjectNotFound;
import com.klicksort.entity.Brand;
import com.klicksort.entity.City;
import com.klicksort.entity.Country;
import com.klicksort.entity.ProductCategory;
import com.klicksort.entity.State;

public class CommonDAOImpl extends GenericDaoImpl implements CommonDAO {

	@Override
	public List<State> getStates() throws Exception {
		List<State> states = this.getSession().createCriteria(State.class).list();
		return states;
	}

	@Override
	public List<City> getCities() throws Exception {
		List<City> cities = this.getSession().createCriteria(City.class).list();
		return cities;
	}
	
	@Override
	public City getCityByPrimaryKey(long cityId) throws Exception {
		City city = (City) this.get(City.class, cityId);
		if(null==city){
			throw new ObjectNotFound("No city found.");
		}
		return city;
	}

	@Override
	public State getStateByPrimaryKey(long stateId) throws Exception {
		State state = (State) this.get(State.class, stateId);
		if(null==state){
			throw new ObjectNotFound("No state found.");
		}
		return state;
	}

	@Override
	public Country getCountryByPrimaryKey(long countryId) throws Exception {
		Country country = (Country) this.get(Country.class, countryId);
		if(null==country){
			throw new ObjectNotFound("No state found.");
		}
		return country;
	}
	
	@Override
	public Brand getBrandByBrandCode(String brandCode) throws Exception {
		Brand brand= (Brand) this.get(Brand.class, brandCode);
		//Brand brand= (Brand) this.getSession().createCriteria(Brand.class).add(Restrictions.eq("brandCode", brandCode)).uniqueResult();
		if(null==brand){
			throw new ObjectNotFound("No brand found for the given code");
		}
		return brand;
	}

	@Override
	public ProductCategory getProductCategoryByCategoryId(long categoryId) throws Exception {
		ProductCategory productCategory= (ProductCategory) this.get(ProductCategory.class, categoryId);
		//ProductCategory productCategory= (ProductCategory) this.getSession().createCriteria(ProductCategory.class).add(Restrictions.eq("categoryId", categoryId)).uniqueResult();
		if(null==productCategory){
			throw new ObjectNotFound("No category found for the given category id");
		}
		return productCategory;
	}
	
}
