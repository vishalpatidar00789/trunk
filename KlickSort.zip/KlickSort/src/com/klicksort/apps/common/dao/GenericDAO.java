package com.klicksort.apps.common.dao; 

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;


public interface GenericDAO
{
// Comment Part is left
    public abstract Serializable create(Object obj)throws Exception;
    public abstract Session getSession()throws Exception;
    public abstract Session getReadOnlySession()throws Exception;
    public abstract List select(Class type,String propList[])throws Exception;
    public abstract Object get(Class type,Serializable id)throws Exception;
    public abstract void update(Object obj)throws Exception;
    public abstract Object saveOrUpdate(Object o) throws Exception;
    public abstract void updateWithHistory(Object obj)throws Exception;
    public abstract void delete(Object obj)throws Exception;
    public abstract List selectByColumnAndValue(Class type,String aStrColumnName, Object aValueObj, String Orderby,String propList[])throws Exception;
    public abstract List selectByColumnAndValueWithIgnoreCase(Class type,String aStrColumnName, Object aValueObj, String Orderby,String propList[])throws Exception;
    public abstract List selectByColumnAndValue(Class type,String aStrColumnName[], Object aValueObj[], String orderBy[], String sortingOrder,String propList[])throws Exception;
    public abstract List selectForColumnByValues(Class type,String aStrColumnName, List Values,String propList[])throws Exception;
    public abstract Integer countRow(Class type)throws Exception;
    public abstract Integer countRow(Class type,String aStrColumnName[], Object aValueObj[])throws Exception;
    public abstract List selectRowsByIndexing(Class type,String aStrColumnName, Object aValueObj, String Orderby, int startIndex, int endIndex)throws Exception;
    public abstract Long genNextValOfSequence(String seq)throws Exception;
   
}