package com.klicksort.apps.common.dao;

import java.util.List;

import com.klicksort.entity.Brand;
import com.klicksort.entity.City;
import com.klicksort.entity.Country;
import com.klicksort.entity.ProductCategory;
import com.klicksort.entity.State;

public interface CommonDAO extends GenericDAO{
	public abstract List<State> getStates()throws Exception;
	public abstract List<City> getCities()throws Exception;
	
	public abstract City getCityByPrimaryKey(long cityId)throws Exception;
	public abstract State getStateByPrimaryKey(long stateId)throws Exception;
	public abstract Country getCountryByPrimaryKey(long countryId)throws Exception;
	
	public abstract Brand getBrandByBrandCode(String brandCode) throws Exception;
	public abstract ProductCategory getProductCategoryByCategoryId(long categoryId)throws Exception;
}
