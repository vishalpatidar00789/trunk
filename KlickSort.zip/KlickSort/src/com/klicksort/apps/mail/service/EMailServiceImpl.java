package com.klicksort.apps.mail.service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;

import com.klicksort.apps.mail.dto.MailInfo;

public class EMailServiceImpl implements EMailService{
	
    private JavaMailSender mailSender;
	
    
	public JavaMailSender getMailSender() {
		return mailSender;
	}


	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}


	@Override
	public String sendMail(MailInfo mailInfo) throws Exception {
		mailSender.send(new MimeMessagePreparator() {
			  public void prepare(MimeMessage mimeMessage) throws MessagingException {
				    MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true, "UTF-8");
				    message.setFrom(mailInfo.getFrom());
				    message.setTo(mailInfo.getTo());
				    message.setSubject(mailInfo.getSubject());
				    message.setText(mailInfo.getBody(), true);
				    //message.addAttachment("filename.doc", new File("filename.doc"));
			  }
		}	);
		return "Mail sent";
	}

}
