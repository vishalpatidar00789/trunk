package com.klicksort.apps.mail.service;

import com.klicksort.apps.mail.dto.MailInfo;

public interface EMailService {
	
	public abstract String sendMail(MailInfo mailInfo)throws Exception;
}
