package com.klicksort.apps.crm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.klicksort.apps.common.manager.ServiceManager;
import com.klicksort.apps.mail.dto.MailInfo;
import com.klicksort.apps.mail.service.EMailService;
import com.klicksort.apps.oms.dto.EOrderView;
import com.klicksort.apps.oms.dto.OrderStates;
import com.klicksort.apps.oms.service.OrderService;

@Controller
public class CRMController {
	
	@RequestMapping(value="/eOrders",method=RequestMethod.GET)
	public String eOrdersScreen(@ModelAttribute("eOrdersForm") EOrderView eOrderView,HttpServletRequest request, Model model){
		return "e_orders_screen";
	}
	
	@RequestMapping(value="/searchEOrders",method=RequestMethod.POST)
	public String getEOrders(@ModelAttribute("eOrdersForm") EOrderView eOrderView,HttpServletRequest request, Model model){
		OrderService orderService = null;
		List<EOrderView> orderViews = null;
		try {
			orderService = (OrderService) ServiceManager.getBean("omsService");
			eOrderView.setOrderState(OrderStates.ORDERCREATED.name());
			orderViews = orderService.getOrders(eOrderView);
			model.addAttribute("orderViews", orderViews);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "e_orders_screen";
	}
	
	@RequestMapping(value="/confirmForm**",method=RequestMethod.GET)
	public String confirmForm(@ModelAttribute("eOrderForm") EOrderView eOrderView, HttpServletRequest request, Model model){
		OrderService orderService = null;
		EOrderView orderView = null;
		try {
			if(null!=eOrderView.getOrderId() && !"".equals(eOrderView.getOrderId())){
				orderService = (OrderService) ServiceManager.getBean("omsService");
				orderView = orderService.getOrder(eOrderView.getOrderId());
				model.addAttribute("orderView", orderView);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "confirmation_screen";
	}
	
	@RequestMapping(value="/confirmOrder",method=RequestMethod.POST)
	public String confirmOrder(@ModelAttribute("eOrderForm") EOrderView eOrderView, HttpServletRequest request, Model model){
		OrderService orderService = null;
		try {
			if(null!=eOrderView.getOrderId() && !"".equals(eOrderView.getOrderId())){
				orderService = (OrderService) ServiceManager.getBean("omsService");
				String msg = orderService.updateOrderState(OrderStates.ORDERCONFIRMED.name(), eOrderView.getOrderId());
				// send mail and sms
				
				// refresh e orders 
				model.addAttribute("msg", msg);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "confirmation_screen";
	}
	
	@RequestMapping(value="/testMail",method=RequestMethod.GET)
	public String testMail(HttpServletRequest request, Model model){
		EMailService eMailService = null;
		MailInfo mailInfo = null;
		try {
				eMailService = (EMailService) ServiceManager.getBean("eMailService");
				mailInfo = new MailInfo("vishalpatidar00789@gmail.com",
						"neelesh@klicksort.com", "Dear Mohit, <br><br> Your klicksort server is hacked by bhulbhulbhiya. <br><br>Do not try to complain again this action otherwise I will hack your whole account.<br><br>Thanks.<br><br>Yours bhulbhulbhiya", "Your KlickSort Mail Server is Hacked");
				String msg = eMailService.sendMail(mailInfo);
				model.addAttribute("msg", msg);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "home";
	}
}
