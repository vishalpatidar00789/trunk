package com.klicksort.apps.oms.service;

import java.util.List;

import com.klicksort.apps.oms.dto.EOrderView;
import com.klicksort.apps.oms.dto.ProductView;
import com.klicksort.entity.KlicksortProductDetail;

public interface OrderService {
	public abstract List<EOrderView> getOrders(EOrderView eOrderView)throws Exception;
	public abstract EOrderView getOrder(String orderId)throws Exception;
	public abstract String updateOrderState(String state, String orderId)throws Exception;
	public abstract ProductView getProductByProductId(String productId)throws Exception;
}
