package com.klicksort.apps.oms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.klicksort.apps.common.dao.CommonDAO;
import com.klicksort.apps.oms.dao.OrderDAO;
import com.klicksort.apps.oms.dto.EOrderView;
import com.klicksort.apps.oms.dto.ProductView;
import com.klicksort.apps.oms.mapper.OMSMapper;
import com.klicksort.entity.Order;
import com.klicksort.entity.OrderDetail;

public class OrderServiceImpl implements OrderService{
	private OrderDAO orderDAO = null;
	private CommonDAO commonDAO = null;
	public CommonDAO getCommonDAO() {
		return commonDAO;
	}
	public void setCommonDAO(CommonDAO commonDAO) {
		this.commonDAO = commonDAO;
	}
	public OrderDAO getOrderDAO() {
		return orderDAO;
	}

	public void setOrderDAO(OrderDAO orderDAO) {
		this.orderDAO = orderDAO;
	}
	
	@Override
	public List<EOrderView> getOrders(EOrderView eOrderView) throws Exception {
		List<Order> orders = this.orderDAO.getOrders(eOrderView);
		List<EOrderView> orderViews = null;
		if(null!=orders && orders.size()>0){
			orderViews = new ArrayList<EOrderView>();
			for(Order order :orders){
				orderViews.add(OMSMapper.mapOrderToOrderView(order, new EOrderView()));
			}
		}
		return orderViews;
	}
	@Override
	public EOrderView getOrder(String orderId) throws Exception {
		Order order = this.orderDAO.getOrderByOrderId(orderId);
		EOrderView orderView = null;
		if(null!=order){
			orderView = new EOrderView();
			orderView = OMSMapper.mapOrderToOrderView(order, orderView);
		}else{
			//throw some message
		}
		return orderView;
	}
	@Override
	public String updateOrderState(String state, String orderId) throws Exception {
		Order order = this.orderDAO.getOrderByOrderId(orderId);
		if(null!=order){
			order.setStatus(state);
			Set<OrderDetail> orderDetails = order.getOrderDetails();
			if(null!=orderDetails && orderDetails.size()>0){
				for(OrderDetail orderDetail:orderDetails){
					orderDetail.setProductLineStatus(state);
					this.orderDAO.update(orderDetail);
				}
				this.orderDAO.update(order);
			}else{
				// throw some message.
			}
		}else{
			// throw some message.
		}
		
		return "Order state updated successfully";
	}
	@Override
	public ProductView getProductByProductId(String productId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
