package com.klicksort.apps.oms.exception;

public class OMSException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5970033803983038401L;

	public OMSException(){
		super();
	}
	
	public OMSException(String message){
		super(message);
	}
	
	public OMSException(String message, Throwable cause){
		super(message, cause);
	}
	
	public OMSException(Throwable cause){
		super("OMS Error.", cause);
	}
}
