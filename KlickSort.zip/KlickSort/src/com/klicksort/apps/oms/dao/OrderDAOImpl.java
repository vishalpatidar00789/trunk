package com.klicksort.apps.oms.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import com.klicksort.apps.common.dao.GenericDaoImpl;
import com.klicksort.apps.common.utils.DateUtility;
import com.klicksort.apps.oms.dto.EOrderView;
import com.klicksort.apps.oms.exception.OMSException;
import com.klicksort.entity.KlicksortProductDetail;
import com.klicksort.entity.Order;

public class OrderDAOImpl extends GenericDaoImpl implements OrderDAO{
	@Override
	public List<Order> getOrders(EOrderView eOrderView) throws Exception {
		int pageNumber = 2;
		int pageSize = 10;
		if(null!=eOrderView.getPageNumber() && !"".equals(eOrderView.getPageNumber())){
			pageNumber = Integer.valueOf(eOrderView.getPageNumber());
		}
		if(null!=eOrderView.getPageSize() && !"".equals(eOrderView.getPageSize())){
			pageNumber = Integer.valueOf(eOrderView.getPageSize());
		}
		List<Order> orders = null;
		Criteria crt = (Criteria) this.getSession().createCriteria(Order.class);
		
		if(null!=eOrderView.getOrderState() && !"".equals(eOrderView.getOrderState())){
			crt.add(Restrictions.eq("status", eOrderView.getOrderState()));
		}
		if(null!=eOrderView.getOrderId() && !"".equals(eOrderView.getOrderId())){
			crt.add(Restrictions.eq("orderId", eOrderView.getOrderId()));
		}else{
			int fday = Integer.valueOf(eOrderView.getFromDate().split("/")[1]);
			int fmonth = Integer.valueOf(eOrderView.getFromDate().split("/")[0])-1;
			int fyear = Integer.valueOf(eOrderView.getFromDate().split("/")[2]);
			int tday = Integer.valueOf(eOrderView.getToDate().split("/")[1]);
			int tmonth = Integer.valueOf(eOrderView.getToDate().split("/")[0])-1;
			int tyear = Integer.valueOf(eOrderView.getToDate().split("/")[2]);
			crt.add(Restrictions.ge("orderCreateDate", DateUtility.getDate(fday,fmonth,fyear))); 
			crt.add(Restrictions.lt("orderCreateDate", DateUtility.getDate(tday,tmonth,tyear)));
			//DateUtility.getDateObject(eOrderView.getFromDate(), DateUtility.format5)
			//crt.setFirstResult((pageNumber - 1) * pageSize);
			//crt.setMaxResults(pageSize);
		}
		orders = crt.list();
		return orders;
	}

	@Override
	public Order getOrderByOrderId(String orderId) throws Exception {
		Order order = (Order) this.getSession().createCriteria(Order.class)
				.add(Restrictions.eq("orderId", orderId)).uniqueResult();
		return order;
	}

	@Override
	public KlicksortProductDetail getProductById(String productId) throws Exception {
		KlicksortProductDetail product = (KlicksortProductDetail) this.getSession().get(KlicksortProductDetail.class, productId);
		if(null!=product){
			if("Y".equals(product.getIsLive())){
				return product;
			}else{
				throw new OMSException("Product is no more active now.");
			}
		}else{
			throw new OMSException("No product is found for the given product id.");
		}
	}

}
