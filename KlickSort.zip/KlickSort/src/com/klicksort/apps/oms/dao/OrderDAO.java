package com.klicksort.apps.oms.dao;

import java.util.List;

import com.klicksort.apps.common.dao.GenericDAO;
import com.klicksort.apps.oms.dto.EOrderView;
import com.klicksort.entity.KlicksortProductDetail;
import com.klicksort.entity.Order;

public interface OrderDAO extends GenericDAO{
	public abstract List<Order> getOrders(EOrderView eOrderView)throws Exception;
	public abstract Order getOrderByOrderId(String orderId)throws Exception;
	public abstract KlicksortProductDetail getProductById(String productId)throws Exception;
	
}
