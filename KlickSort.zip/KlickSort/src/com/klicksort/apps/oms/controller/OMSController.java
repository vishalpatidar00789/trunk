package com.klicksort.apps.oms.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.betwixt.XMLUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.klicksort.apps.common.constants.ServiceConstants;
import com.klicksort.apps.common.manager.ServiceManager;
import com.klicksort.apps.oms.dto.ClubBoxMap;
import com.klicksort.apps.oms.dto.EOrderView;
import com.klicksort.apps.oms.dto.OrderStates;
import com.klicksort.apps.oms.service.OrderService;

@Controller
public class OMSController {
	
	@RequestMapping(value="/activityBoard**",method=RequestMethod.GET)
	public String eOrdersScreen(@ModelAttribute("eOrdersForm") EOrderView eOrderView,HttpServletRequest request, Model model){
		String function = request.getParameter("function");
		if(null!=function && !"".equals(function) && "po".equals(function)){
			model.addAttribute("action", "confirmedOrders");
		}else{
			// throw some message
		}
		return "activity_screen";
	}
	
	@RequestMapping(value="/confirmedOrders",method=RequestMethod.POST)
	public String getConfirmedOrders(@ModelAttribute("eOrdersForm") EOrderView eOrderView,HttpServletRequest request, Model model){
		OrderService orderService = null;
		List<EOrderView> orderViews = null;
		try {
			orderService = (OrderService) ServiceManager.getBean("omsService");
			eOrderView.setOrderState(OrderStates.ORDERCONFIRMED.name());
			orderViews = orderService.getOrders(eOrderView);
			model.addAttribute("orderViews", orderViews);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "activity_screen";
	}
	
	@RequestMapping(value="/addToBox**",method=RequestMethod.POST)
	public ModelAndView addToCart(HttpServletRequest request, HttpServletResponse response){
		XMLUtils xml =  new XMLUtils();
		ModelAndView model = null;
		ClubBoxMap clubBoxMap = null;
		String state="", productId = "";
		try {
			clubBoxMap = (ClubBoxMap) ServiceManager.getBean("clubBoxMap");
			state = request.getParameter("state");
			productId = request.getParameter("productId");
			//clubBoxMap.addToBox(state, clubBoxInfo)
			//xml.addTag("cartSize", String.valueOf(userCartBean.getBookItemsList().size()));
		}catch (Exception e){
			
		}
		finally{
			response.setContentType("text/xml");
	        //request.setAttribute(ServiceConstants.AJAX$DATA , xml.getXMLString()); 
	        model = new ModelAndView(ServiceConstants.AJAX_PAGE); 
		}
		return model;
	}
}
