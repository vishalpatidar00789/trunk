package com.klicksort.apps.oms.mapper;

import com.klicksort.apps.common.dto.CityView;
import com.klicksort.apps.common.dto.CountryView;
import com.klicksort.apps.common.dto.StateView;
import com.klicksort.apps.common.mapper.CommonMapper;
import com.klicksort.apps.common.utils.DateUtility;
import com.klicksort.apps.oms.dto.CouponView;
import com.klicksort.apps.oms.dto.EOrderView;
import com.klicksort.apps.oms.dto.InvoiceView;
import com.klicksort.apps.oms.dto.OfferView;
import com.klicksort.apps.oms.dto.OrderDetailView;
import com.klicksort.apps.oms.dto.RoleView;
import com.klicksort.apps.oms.dto.UserContactView;
import com.klicksort.apps.oms.dto.UserView;
import com.klicksort.entity.Coupon;
import com.klicksort.entity.Invoice;
import com.klicksort.entity.Offer;
import com.klicksort.entity.Order;
import com.klicksort.entity.OrderDetail;
import com.klicksort.entity.Role;
import com.klicksort.entity.User;
import com.klicksort.entity.UserContact;

public class OMSMapper {
	
	public static EOrderView mapOrderToOrderView(Order order, EOrderView orderView) throws Exception{
		
		orderView.setExpectedDeliveryDate(DateUtility.getDateString(order.getExpectedDeliveryDate(), DateUtility.format2));
		orderView.setGiftWrappingCharges(String.valueOf(order.getGiftWrappingCharges()));
		orderView.setDiscount(String.valueOf(order.getDiscount()));
		orderView.setIsCashOnDelivery(order.getIsCashOnDelivery());
		orderView.setOrderCreateDate(DateUtility.getDateString(order.getOrderCreateDate(), DateUtility.format2));
		orderView.setOrderId(order.getOrderId());
		orderView.setOrderUpdateDate(DateUtility.getDateString(order.getOrderUpdateDate(), DateUtility.format2));
		orderView.setPaymentMethod(order.getPaymentMethod());
		orderView.setShippingCharges(String.valueOf(order.getShippingCharges()));
		orderView.setStatus(order.getStatus());
		orderView.setTotal(String.valueOf(order.getTotal()));
		orderView.setTransactionNumber(String.valueOf(order.getTransactionNumber()));
		orderView.setTransactionStatus(String.valueOf(order.getTransactionStatus()));
		
		for(OrderDetail orderDetail :order.getOrderDetails()){
			orderView.getOrderDetails().add(mapOrderDetailToOrderDetailView(orderDetail, new OrderDetailView()));
		}
		if(null!=order.getOffer()){
			orderView.setOffer(mapOfferToOfferView(order.getOffer(), new OfferView()));
		}
		if(null!=order.getCoupon()){
			orderView.setCoupon(mapCouponToCouponView(order.getCoupon(), new CouponView()));
		}
		
		orderView.setContact(mapUserContactToUserContactView(order.getContact(), new UserContactView()));
		//orderView.setInvoice(mapInvoiceToInvoiceView(order.getInvoice(), new InvoiceView()));
		orderView.setUser(mapUserToUserView(order.getUser(), new UserView()));
		
		return orderView;
	}
	
	public static UserView mapUserToUserView(User user, UserView userView) throws Exception{
		userView.setEmail(user.getEmail());
		userView.setFirstName(user.getFirstName());
		userView.setIsActive(user.getIsActive());
		userView.setIsRegistered(user.getIsRegistered());
		userView.setIsVarified(user.getIsVarified());
		userView.setLastName(user.getLastName());
		userView.setLoyaltyPoint(String.valueOf(user.getLoyaltyPoint()));
		userView.setRegDate(DateUtility.getDateString(user.getRegDate(), DateUtility.format2));
		userView.setUpdDate(DateUtility.getDateString(user.getUpdDate(), DateUtility.format2));
		userView.setRole(mapRoleToRoleView(user.getRole(), new RoleView()));
		userView.setUserId(String.valueOf(user.getUserId()));
		userView.setVarificationCode(user.getVarificationCode());
		
		for(UserContact userContact :user.getContacts()){
			userView.getContacts().add(mapUserContactToUserContactView(userContact, new UserContactView()));
		}
		return userView;
	}
	
	public static RoleView mapRoleToRoleView(Role role, RoleView roleView){
		roleView.setIsActive(role.getIsActive());
		roleView.setRoleId(String.valueOf(role.getRoleId()));
		roleView.setRoleName(role.getRoleName());
		return roleView;
	}
	
	public static CouponView mapCouponToCouponView(Coupon coupon, CouponView couponView)throws Exception{
		couponView.setCouponCode(coupon.getCouponCode());
		couponView.setCouponId(String.valueOf(coupon.getCouponId()));
		couponView.setCouponSource(coupon.getCouponSource());
		couponView.setCouponValue(String.valueOf(coupon.getCouponValue()));
		couponView.setExpiryDate(DateUtility.getDateString(coupon.getExpiryDate(), DateUtility.format2));
		couponView.setUseCount(String.valueOf(coupon.getUseCount()));
		return couponView;
	}
	
	public static OfferView mapOfferToOfferView(Offer offer, OfferView offerView)throws Exception{
		offerView.setExpiryDate(DateUtility.getDateString(offer.getExpiryDate(), DateUtility.format2));
		offerView.setOfferCode(offer.getOfferCode());
		offerView.setOfferId(String.valueOf(offer.getOfferId()));
		offerView.setOfferValue(String.valueOf(offer.getOfferValue()));
		offerView.setUseCount(String.valueOf(offer.getUseCount()));
		return offerView;
		
	}
	
	public static InvoiceView mapInvoiceToInvoiceView(Invoice invoice, InvoiceView invoiceView ){
		invoiceView.setInvoiceId(String.valueOf(invoice.getInvoiceId()));
		invoiceView.setStatus(invoice.getStatus());
		invoiceView.setTotalAmount(String.valueOf(invoice.getTotalAmount()));
		return invoiceView;
	}
	
	public static OrderDetailView mapOrderDetailToOrderDetailView(OrderDetail orderDetail, OrderDetailView orderDetailView){
		orderDetailView.setDesiredColor(orderDetail.getDesiredColor());
		orderDetailView.setDesiredSize(orderDetail.getDesiredSize());
		orderDetailView.setOrderDetailId(String.valueOf(orderDetail.getOrderDetailId()));
		orderDetailView.setProductId(orderDetail.getProductId());
		orderDetailView.setProductLineStatus(orderDetail.getProductLineStatus());
		orderDetailView.setQty(String.valueOf(orderDetail.getQty()));
		return orderDetailView;
	}
	
	public static UserContactView mapUserContactToUserContactView(UserContact userContact, UserContactView userContactView){
		userContactView.setAddressLine1(userContact.getAddressLine1());
		userContactView.setAddressLine2(userContact.getAddressLine2());
		userContactView.setContactId(String.valueOf(userContact.getContactId()));
		userContactView.setContactNo(userContact.getContactNo());
		userContactView.setIsActive(userContact.getIsActive());
		userContactView.setIsregisteredAddress(userContact.getIsregisteredAddress());
		userContactView.setLandmark(userContact.getLandmark());
		userContactView.setPincode(userContact.getPincode());
		userContactView.setStreet(userContact.getStreet());
		userContactView.setCity(CommonMapper.mapCityToCityView(new CityView(), userContact.getCity()));
		userContactView.setState(CommonMapper.mapStateToStateView(new StateView(), userContact.getState()));
		userContactView.setCountry(CommonMapper.mapCountryToCountryView(new CountryView(), userContact.getCountry()));
		userContactView.setFullAddress(prepareFullAddressStr(userContactView));
		return userContactView;
	}
	
	public static String prepareFullAddressStr(UserContactView userContactView){
		StringBuilder fullAddress = new StringBuilder("");
		fullAddress.append(userContactView.getAddressLine1()+",");
		if(null!=userContactView.getAddressLine2() && !"".equals(userContactView.getAddressLine2())){
			fullAddress.append(userContactView.getAddressLine2()+",");
		}
		if(null!=userContactView.getStreet() && !"".equals(userContactView.getStreet())){
			fullAddress.append(userContactView.getStreet()+",");
		}
		if(null!=userContactView.getLandmark() && !"".equals(userContactView.getLandmark())){
			fullAddress.append(userContactView.getLandmark()+",");
		}
		fullAddress.append(userContactView.getState().getStateName()+",");
		fullAddress.append(userContactView.getCity().getCityName()+"-");
		fullAddress.append(userContactView.getPincode()+",");
		fullAddress.append(userContactView.getContactNo()+".");
		return fullAddress.toString();
	}
}
