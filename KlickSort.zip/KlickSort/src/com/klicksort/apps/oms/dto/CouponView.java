package com.klicksort.apps.oms.dto;

import java.io.Serializable;
import java.util.List;

public class CouponView implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2140679058002015044L;
	private String couponId;
	private String couponCode;
	private String couponValue;
	private String expiryDate;
	private String useCount;
	private String couponSource;
	private List<EOrderView> orders = null;
	public String getCouponId() {
		return couponId;
	}
	public void setCouponId(String couponId) {
		this.couponId = couponId;
	}
	public String getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	public String getCouponValue() {
		return couponValue;
	}
	public void setCouponValue(String couponValue) {
		this.couponValue = couponValue;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getUseCount() {
		return useCount;
	}
	public void setUseCount(String useCount) {
		this.useCount = useCount;
	}
	public String getCouponSource() {
		return couponSource;
	}
	public void setCouponSource(String couponSource) {
		this.couponSource = couponSource;
	}
	public List<EOrderView> getOrders() {
		return orders;
	}
	public void setOrders(List<EOrderView> orders) {
		this.orders = orders;
	}
}
