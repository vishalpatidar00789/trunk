package com.klicksort.apps.oms.dto;

import java.io.Serializable;

public class ClubBoxInfo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5450371184379472598L;
	private String productId;
	private String orderId;
	private String activity;
	private String blockedBy;
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public String getBlockedBy() {
		return blockedBy;
	}
	public void setBlockedBy(String blockedBy) {
		this.blockedBy = blockedBy;
	}
	
}
