package com.klicksort.apps.oms.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.klicksort.entity.UserContact;

public class UserView implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4902093813759076644L;
	private String userId;
	private RoleView role;
	private String firstName;
	private String lastName;
	private String email;
	private String password;
	private String regDate;
	private String updDate;
	private String varificationCode;
	private String isVarified;
	private String isRegistered;
	private String isActive;
	private String loyaltyPoint;
	private List<UserContactView> contacts = null;
	private List<EOrderView> orders = null;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public RoleView getRole() {
		return role;
	}
	public void setRole(RoleView role) {
		this.role = role;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getUpdDate() {
		return updDate;
	}
	public void setUpdDate(String updDate) {
		this.updDate = updDate;
	}
	public String getVarificationCode() {
		return varificationCode;
	}
	public void setVarificationCode(String varificationCode) {
		this.varificationCode = varificationCode;
	}
	public String getIsVarified() {
		return isVarified;
	}
	public void setIsVarified(String isVarified) {
		this.isVarified = isVarified;
	}
	public String getIsRegistered() {
		return isRegistered;
	}
	public void setIsRegistered(String isRegistered) {
		this.isRegistered = isRegistered;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getLoyaltyPoint() {
		return loyaltyPoint;
	}
	public void setLoyaltyPoint(String loyaltyPoint) {
		this.loyaltyPoint = loyaltyPoint;
	}
	public List<UserContactView> getContacts() {
		if(null==contacts){
			contacts = new ArrayList<UserContactView>(0);
		}
		return contacts;
	}
	public void setContacts(List<UserContactView> contacts) {
		this.contacts = contacts;
	}
	public List<EOrderView> getOrders() {
		return orders;
	}
	public void setOrders(List<EOrderView> orders) {
		this.orders = orders;
	}
	
}
