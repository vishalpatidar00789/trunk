package com.klicksort.apps.oms.dto;

import com.klicksort.apps.common.dto.BrandView;
import com.klicksort.apps.common.dto.ProductCategoryView;
import com.klicksort.apps.vms.dto.VendorDetailView;

public class ProductView {
	private String productId;
	private BrandView brand;
	private ProductCategoryView productCategory;
	private VendorDetailView vendorDetail;
	//private TaxTypeView taxType;
	//private UomView uom;
	private String productName;
	private String productDescription;
	private String qty;
	private String salePrice;
	private String discount;
	private String afterDiscountSalePrice;
	private String createDt;
	private String updateDt;
	private String createBy;
	private String updateBy;
	private String size;
	private String weight;
	private String color;
	private String warrantyDescription;
	private String isFeatured;
	private String isLive;
}
