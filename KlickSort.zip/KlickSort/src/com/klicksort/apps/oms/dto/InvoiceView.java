package com.klicksort.apps.oms.dto;

import java.io.Serializable;

public class InvoiceView implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 6353073045743839189L;
	private String invoiceId;
	private EOrderView order;
	private String totalAmount;
	private String status;
	public String getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}
	public EOrderView getOrder() {
		return order;
	}
	public void setOrder(EOrderView order) {
		this.order = order;
	}
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
