package com.klicksort.apps.oms.dto;

import java.io.Serializable;
import java.util.List;

import com.klicksort.apps.common.dto.CityView;
import com.klicksort.apps.common.dto.CountryView;
import com.klicksort.apps.common.dto.StateView;

public class UserContactView implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2358609663721337455L;
	private String contactId;
	private CountryView country;
	private StateView state;
	private UserView user;
	private CityView city;
	private String addressLine1;
	private String addressLine2;
	private String street;
	private String landmark;
	private String pincode;
	private String contactNo;
	private String isregisteredAddress;
	private String isActive;
	private List<EOrderView> orders = null;
	private String fullAddress;
	
	public String getFullAddress() {
		return fullAddress;
	}
	public void setFullAddress(String fullAddress) {
		this.fullAddress = fullAddress;
	}
	public String getContactId() {
		return contactId;
	}
	public void setContactId(String contactId) {
		this.contactId = contactId;
	}
	public CountryView getCountry() {
		return country;
	}
	public void setCountry(CountryView country) {
		this.country = country;
	}
	public StateView getState() {
		return state;
	}
	public void setState(StateView state) {
		this.state = state;
	}
	public UserView getUser() {
		return user;
	}
	public void setUser(UserView user) {
		this.user = user;
	}
	public CityView getCity() {
		return city;
	}
	public void setCity(CityView city) {
		this.city = city;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getIsregisteredAddress() {
		return isregisteredAddress;
	}
	public void setIsregisteredAddress(String isregisteredAddress) {
		this.isregisteredAddress = isregisteredAddress;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public List<EOrderView> getOrders() {
		return orders;
	}
	public void setOrders(List<EOrderView> orders) {
		this.orders = orders;
	}
	
}
