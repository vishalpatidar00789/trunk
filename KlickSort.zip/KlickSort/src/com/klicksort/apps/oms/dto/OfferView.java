package com.klicksort.apps.oms.dto;

import java.io.Serializable;
import java.util.List;

public class OfferView implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4906561709484659942L;
	private String offerId;
	private String offerCode;
	private String offerValue;
	private String expiryDate;
	private String useCount;
	private String offercol;
	private List<EOrderView> orders = null;
	public String getOfferId() {
		return offerId;
	}
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}
	public String getOfferCode() {
		return offerCode;
	}
	public void setOfferCode(String offerCode) {
		this.offerCode = offerCode;
	}
	public String getOfferValue() {
		return offerValue;
	}
	public void setOfferValue(String offerValue) {
		this.offerValue = offerValue;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getUseCount() {
		return useCount;
	}
	public void setUseCount(String useCount) {
		this.useCount = useCount;
	}
	public String getOffercol() {
		return offercol;
	}
	public void setOffercol(String offercol) {
		this.offercol = offercol;
	}
	public List<EOrderView> getOrders() {
		return orders;
	}
	public void setOrders(List<EOrderView> orders) {
		this.orders = orders;
	}
	
}
