package com.klicksort.apps.oms.dto;

import java.io.Serializable;
import java.util.List;

public class OrderDetailView implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8365966741120154516L;
	private String orderDetailId;
	private EOrderView order;
	private String productId;
	private String qty;
	private String productLineStatus;
	private String desiredColor;
	private String desiredSize;
	private List<RefundsView> refundses = null;
	private List<ReturnsView> returnses = null;
	private List<CancellationView> cancellations = null;
	public String getOrderDetailId() {
		return orderDetailId;
	}
	public void setOrderDetailId(String orderDetailId) {
		this.orderDetailId = orderDetailId;
	}
	public EOrderView getOrder() {
		return order;
	}
	public void setOrder(EOrderView order) {
		this.order = order;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getQty() {
		return qty;
	}
	public void setQty(String qty) {
		this.qty = qty;
	}
	public String getProductLineStatus() {
		return productLineStatus;
	}
	public void setProductLineStatus(String productLineStatus) {
		this.productLineStatus = productLineStatus;
	}
	public String getDesiredColor() {
		return desiredColor;
	}
	public void setDesiredColor(String desiredColor) {
		this.desiredColor = desiredColor;
	}
	public String getDesiredSize() {
		return desiredSize;
	}
	public void setDesiredSize(String desiredSize) {
		this.desiredSize = desiredSize;
	}
	public List<RefundsView> getRefundses() {
		return refundses;
	}
	public void setRefundses(List<RefundsView> refundses) {
		this.refundses = refundses;
	}
	public List<ReturnsView> getReturnses() {
		return returnses;
	}
	public void setReturnses(List<ReturnsView> returnses) {
		this.returnses = returnses;
	}
	public List<CancellationView> getCancellations() {
		return cancellations;
	}
	public void setCancellations(List<CancellationView> cancellations) {
		this.cancellations = cancellations;
	}
	
}
