package com.klicksort.apps.oms.dto;

import java.util.HashMap;
import java.util.Map;

import com.klicksort.apps.oms.exception.OMSException;

public class ClubBoxMap {

	private Map<String, Map<String,ClubBoxInfo>> clubBox = null;

	private static ClubBoxMap INSTANCE = null;
	
	private ClubBoxMap(){
		clubBox = new HashMap<String, Map<String,ClubBoxInfo>>();
	}

	public static ClubBoxMap getInstance(){
		if(INSTANCE == null){
			synchronized(ClubBoxMap.class){
				if(INSTANCE == null){
					INSTANCE = new ClubBoxMap();
				}
			}
		}
		return INSTANCE;
	}


	public Map<String, Map<String, ClubBoxInfo>> getClubBoxMap() {
		return clubBox;
	}
	
	public synchronized boolean addToBox(String state, ClubBoxInfo clubBoxInfo) throws OMSException{
		if((null!=state && !"".equals(state)) && (null!=clubBoxInfo)){
			if(null!=this.clubBox){
				Map<String, ClubBoxInfo> stateClubBox = this.clubBox.get(state);
				if(null==stateClubBox){
					stateClubBox = new HashMap<String, ClubBoxInfo>();
				}
				stateClubBox.put(clubBoxInfo.getProductId(), clubBoxInfo);
				this.clubBox.put(state, stateClubBox);
				return true;
			}else{
				throw new OMSException("Invalid access of club box: Club box is not yet initialized.");
			}
		}else{
			throw new OMSException("Invalid operation: State and Product is required");
		}
	}
	
	public synchronized boolean removeFromBox(String state, String productKey) throws OMSException{
		if((null!=state && !"".equals(state)) && (null!=productKey && !"".equals(productKey))){
			if(null!=this.clubBox){
				Map<String, ClubBoxInfo> stateClubBox = this.clubBox.get(state);
				if(null==stateClubBox){
					throw new OMSException("Invalid operation: There is nothing to remove.");
				}
				stateClubBox.remove(productKey);
				this.clubBox.put(state, stateClubBox);
				return true;
			}else{
				throw new OMSException("Invalid access of club box.");
			}
		}else{
			throw new OMSException("Invalid operation: State and Product is required");
		}
	}
	
	public synchronized boolean isProductExist(String state, String productKey)throws OMSException{
		if((null!=state && !"".equals(state)) && (null!=productKey && !"".equals(productKey))){
			if(null!=this.clubBox){
				Map<String, ClubBoxInfo> stateClubBox = this.clubBox.get(state);
				if(null==stateClubBox){
					return false;
				}
				if(null==stateClubBox.get(productKey)){
					return false;
				}
				return true;
			}else{
				throw new OMSException("Invalid access of club box.");
			}
		}else{
			throw new OMSException("Invalid operation: State and Product is required");
		}
	}
}
