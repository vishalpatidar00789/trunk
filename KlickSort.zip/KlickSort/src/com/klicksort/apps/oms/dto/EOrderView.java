package com.klicksort.apps.oms.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class EOrderView implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 156373405607238205L;
	private String orderId;
	private CouponView coupon;
	private UserView user;
	private OfferView offer;
	private UserContactView contact;
	private String orderCreateDate;
	private String orderUpdateDate;
	private String discount;
	private String shippingCharges;
	private String giftWrappingCharges;
	private String total;
	private String transactionNumber;
	private String transactionStatus;
	private String paymentMethod;
	private String isCashOnDelivery;
	private String status;
	private String expectedDeliveryDate;
	private List<OrderDetailView> orderDetails = null;
	private InvoiceView invoice;
	
	private String fromDate;
	private String toDate;
	private String pageNumber;
	private String pageSize;
	private String orderState;
	
	
	public String getOrderState() {
		return orderState;
	}
	public void setOrderState(String orderState) {
		this.orderState = orderState;
	}
	public String getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(String pageNumber) {
		this.pageNumber = pageNumber;
	}
	public String getPageSize() {
		return pageSize;
	}
	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public CouponView getCoupon() {
		return coupon;
	}
	public void setCoupon(CouponView coupon) {
		this.coupon = coupon;
	}
	public UserView getUser() {
		return user;
	}
	public void setUser(UserView user) {
		this.user = user;
	}
	public OfferView getOffer() {
		return offer;
	}
	public void setOffer(OfferView offer) {
		this.offer = offer;
	}
	public UserContactView getContact() {
		return contact;
	}
	public void setContact(UserContactView contact) {
		this.contact = contact;
	}
	public String getOrderCreateDate() {
		return orderCreateDate;
	}
	public void setOrderCreateDate(String orderCreateDate) {
		this.orderCreateDate = orderCreateDate;
	}
	public String getOrderUpdateDate() {
		return orderUpdateDate;
	}
	public void setOrderUpdateDate(String orderUpdateDate) {
		this.orderUpdateDate = orderUpdateDate;
	}
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}
	public String getShippingCharges() {
		return shippingCharges;
	}
	public void setShippingCharges(String shippingCharges) {
		this.shippingCharges = shippingCharges;
	}
	public String getGiftWrappingCharges() {
		return giftWrappingCharges;
	}
	public void setGiftWrappingCharges(String giftWrappingCharges) {
		this.giftWrappingCharges = giftWrappingCharges;
	}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getTransactionNumber() {
		return transactionNumber;
	}
	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public String getIsCashOnDelivery() {
		return isCashOnDelivery;
	}
	public void setIsCashOnDelivery(String isCashOnDelivery) {
		this.isCashOnDelivery = isCashOnDelivery;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getExpectedDeliveryDate() {
		return expectedDeliveryDate;
	}
	public void setExpectedDeliveryDate(String expectedDeliveryDate) {
		this.expectedDeliveryDate = expectedDeliveryDate;
	}
	public List<OrderDetailView> getOrderDetails() {
		if(null==orderDetails){
			orderDetails = new ArrayList<OrderDetailView>();
		}
		return orderDetails;
	}
	public void setOrderDetails(List<OrderDetailView> orderDetails) {
		this.orderDetails = orderDetails;
	}
	public InvoiceView getInvoice() {
		return invoice;
	}
	public void setInvoice(InvoiceView invoice) {
		this.invoice = invoice;
	}
	
}
