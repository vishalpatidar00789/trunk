package com.klicksort.apps.api;

import javax.jws.WebService;

import com.klicksort.apps.common.manager.ServiceManager;
import com.klicksort.apps.vms.dto.VendorDetailView;
import com.klicksort.apps.vms.service.VendorService;

@WebService(endpointInterface="com.klicksort.apps.api.VendorAPIService",targetNamespace="http://api.klicksort.com",
portName="VendorAPIServiceImplPort",serviceName="VendorWebService",name="VendorAPIServiceInterface")
public class VendorAPIServiceImpl implements VendorAPIService{

	@Override
	public VendorDetailView getVendor(long vendorId){
		VendorDetailView detailView = null;
		try {
			com.klicksort.apps.vms.service.VendorService vendorService = (VendorService) ServiceManager.getBean("vendorService");
			detailView = vendorService.getVendorDetail(vendorId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return detailView;
	}

}
