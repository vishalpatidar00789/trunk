package com.klicksort.apps.api;

import javax.jws.WebMethod;
import javax.jws.WebService;

import com.klicksort.apps.vms.dto.VendorDetailView;

@WebService(name="VendorAPIServiceInterface",targetNamespace="http://api.klicksort.com")
public interface VendorAPIService {
	
	@WebMethod(operationName="fetchVendorDetail",action="fetchVendorAction")
	public VendorDetailView getVendor(long vendorId);
}
