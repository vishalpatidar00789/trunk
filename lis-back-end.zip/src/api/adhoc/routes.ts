import * as Hapi from 'hapi';
import * as Joi from 'joi';
import AdhocController from './adhoc-controller';
import { AdhocModel } from './adhoc';
import * as AdhocValidator from './adhoc-validator';
import { IDatabase } from '../../database';
import { IServerConfigurations } from '../../configurations';
import LoanService from '../../services/loan-service';
import ConfigurationService from '../../services/configuration-service';
import EmailService from '../../services/email-service';

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase,
  emailService: EmailService
) {
  const configService = new ConfigurationService(serverConfigs, database);
  const loanService = new LoanService(serverConfigs, database, server, configService);
  const adhocController = new AdhocController(serverConfigs, database, loanService, emailService);
  server.bind(adhocController);

  server.route({
    method: 'GET',
    path: '/adhoc/info/{id}',
    options: {
      handler: adhocController.getAdhoc,
      auth: "jwt",
      // auth: false,
      tags: ['api', 'adhoc'],
      description: 'Get Adhoc info.',
      validate: {
        headers: AdhocValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Adhoc found.'
            },
            '401': {
              description: 'Please login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'DELETE',
    path: '/adhoc',
    options: {
      handler: adhocController.deleteAdhoc,
      //auth: "jwt",
      tags: ['api', 'adhoc'],
      description: 'Delete current Adhoc.',
      validate: {
        headers: AdhocValidator.jwtValidator
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Adhoc deleted.'
            },
            '401': {
              description: 'User does not have authorization.'
            }
          }
        }
      }
    }
  });

  // server.route({
  //   method: "PUT",
  //   path: "/adhoc/submit/{id}",
  //   options: {
  //     handler: adhocController.updateLoan,
  //     auth: false,
  //     tags: ["api", "adhoc"],
  //     description: "Update current adhoc info.",
  //     validate: {
  //       payload: AdhocValidator.createLoanModel,
  //       //headers: AdhocValidator.jwtValidator,
  //       params: {
  //         id: Joi.string().required()
  //       }
  //     },
  //     plugins: {
  //       "hapi-swagger": {
  //         responses: {
  //           "200": {
  //             description: "Updated Adhoc info."
  //           },
  //           "401": {
  //             description: "User does not have authorization."
  //           }
  //         }
  //       }
  //     }
  //   }
  // });

  server.route({
    method: 'POST',
    path: '/adhoc',
    options: {
      handler: adhocController.createAdhoc,
      auth: "jwt",
      tags: ['api', 'adhoc'],
      description: 'Create a new other Adhoc request.',
      validate: {
        payload: AdhocValidator.adhocPayload,
        headers: AdhocValidator.jwtValidator,
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '201': {
              description: 'Adhoc created.'
            }
          }
        }
      }
    }
  });

  // server.route({
  //   method: 'POST',
  //   path: '/adhoc/search',
  //   options: {
  //     handler: adhocController.searchAdhoc,
  //     auth: "jwt",
  //     auth: false,
  //     tags: ['api', 'adhoc'],
  //     description: 'Search for adhoc applications.',
  //     validate: {
  //       payload: AdhocValidator.searchAdhocPayload
  //     },
  //     plugins: {
  //       'hapi-swagger': {
  //         responses: {
  //           '200': {
  //             description: 'List of all matching Adhoc applications.'
  //           },
  //           '401': {
  //             description: 'Please Login.'
  //           }
  //         }
  //       }
  //     }
  //   }
  // });

  // server.route({
  //   method: "PUT",
  //   path: "/adhoc/adverseInfo/{id}",
  //   options: {
  //     handler: adhocController.updateLoanAdverseInfo,
  //     auth: false,
  //     tags: ["api", "adhoc"],
  //     description: "Update adhoc adverse info.",
  //     validate: {
  //       payload: AdhocValidator.createAdverseInfo,
  //       //headers: AdhocValidator.jwtValidator,
  //       params: {
  //         id: Joi.string().required()
  //       }
  //     },
  //     plugins: {
  //       "hapi-swagger": {
  //         responses: {
  //           "200": {
  //             description: "Updated Adhoc adverse info."
  //           },
  //           "401": {
  //             description: "User does not have authorization."
  //           }
  //         }
  //       }
  //     }
  //   }
  // });

  server.route({
    method: 'PUT',
    path: '/adhoc/updateAdhoc/{id}',
    options: {
      handler: adhocController.updateAdhoc,
      auth: "jwt",
      tags: ['api', 'adhoc'],
      description: 'Update current adhoc info.',
      validate: {
        payload: AdhocValidator.adhocPayload,
        headers: AdhocValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Updated Adhoc request.'
            },
            '401': {
              description: 'User does not have authorization.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/adhoc/adhocAdverseInfo/{id}",
    options: {
      handler: adhocController.updateAdhocAdverseInfo,
      auth: "jwt",
      tags: ["api", "adhoc"],
      description: "Update adhoc adverse info.",
      validate: {
        payload: AdhocValidator.adhocPayload,
        headers: AdhocValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated Loan adverse info."
            },
            "401": {
              description: "User does not have authorization."
            }
          }
        }
      }
    }
  });
}
