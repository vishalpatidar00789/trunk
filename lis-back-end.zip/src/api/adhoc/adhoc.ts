import * as Mongoose from "mongoose";
import * as Bcrypt from "bcryptjs";
//import * as diffHistory from 'mongoose-diff-history/diffHistory';
// import { IPFI, PFISchema } from "./pfi/pfi";
// import { IUOB, UOBSchema } from "./uob/uob";

export interface IAdhoc extends Mongoose.Document {
  status: string;
  marshRefNo: string;
  loanMarshRefNo: string;
  baseLoanId: string;
  consortium: string;
  app: number;
  createdBy: string;
  createdDate: Date;
  lastModifiedBy: string;
  lastModifiedDate: Date;

  nameOfStaff: string;
  // submissionDate: Date;
  // pfiCode: string;
  // pfiName: string;
  // regName: string;
  // uenNumber: string;
  // primary: number;
  // autoTopUp: number;
  // bg: number;
  // lisPlus: number;
  // foreignCurrencyType: string;
  // foreignCurrency: number;
  // exRate: number;

  // Section 1
  cancellationSectionChkBx: boolean;
  cancellationRadio: string;
  outstandingAmountRadio: string;
  cancellationSectionRadio: string;
  cancellationReason: string;
  loAcceptedDateRadio: boolean;
  // loAcceptedDate: Date; // loAcceptanceDate
  otherRemarks: string;
  cancellationOfAccepted: string;
  cancellationOutstandingAmountSGD: number;
  cancellationOutstandingAmountUSD: number;
  otherRemarksAccepted: string;

  // Section 2
  expiryExtensionChkBx: boolean;
  facilityExpiryExtentsionChkBx: boolean;
  facilityExpiryDate: Date;
  eFacilityExpiryDate: Date;

  // Section 3
  dueDateExtensionChkBx: boolean;
  billDueDate: Date;
  eBillDueDate: Date;
  billInfoChkBx: boolean;

  // Section 4
  overseasBuyerChkBx: boolean;
  domesticBuyerChkBx: boolean;

  // Section 5
  preShipmentChkBx: boolean;
  insurersApprovalChkBx: boolean;

  // Section 6
  moreTimeLoChkBx: boolean;
  decisionDate: Date;
  calendarDays: Date;
  decisionDateLis: Date;
  calendarDaysLis: Date;
  extendedLoDate: Date;
  extensionReason: string;

  // Section 7 commented out

  // Section 8
  newDisbursementsChkBx: boolean;
  internalCreditMemoChkBx: boolean;

  // Section 9
  reValidateInsuranceChkBx: boolean;
  reasonForBreachRadio: string;
  reasonForBreachRadio2Txt: string;
  reasonForBreachRadio3Txt: string;
  noAdverseInfoChkBx: boolean;
  outstandingAmountChkBx: boolean;
  borrwLoAcceptedDate: Date;

  // Section 10
  processRequestChkBx: boolean;
  otherReason: string;
  reviewDocChkBx: boolean;

  creditInfo: {
    pfiCode: string,
    pfiName: string,
    totalRequstedLimitSGD: number,
    submissionDate: Date,
    primary: number,
    autoTopUp: number,
    bg: number,
    lisPlus: number,
    requesterName: string,
    foreignCurrency: string,
    foreignCurrencyAmount: number,
    exRate: number,
    loAcceptanceDate: Date,
    loanExpiryDate: Date,
  };

  adverseInfo: {
    adverseStatus: string,
    additionalInfo: string,
    overdue: string,
    overdueDate: Date,
    listOfOverdue: boolean,
    repaymentPlanAttached: boolean,
  };
  typeOfRequest: string;
}

export const AdhocSchema = new Mongoose.Schema(
  {
    status: { type: String },
    marshRefNo: { type: String },
    // adhocMarshRefNo: { type: String }, // Change it to marshRefNo
    loanMarshRefNo: { type: String }, //marshRefNo
    baseLoanId: { type: String },
    consortium: { type: String },
    app: { type: Number },
    createdBy: { type: String },
    createdDate: { type: Date },
    lastModifiedBy: { type: String },
    lastModifiedDate: { type: Date },

    nameOfStaff: { type: String },
    regName: { type: String },
    uenNumber: { type: String },


    submissionDate: { type: Date },
    pfiCode: { type: String },
    pfiName: { type: String },
    primary: { type: Number },
    autoTopUp: { type: Number },
    bg: { type: Number },
    lisPlus: { type: Number },
    foreignCurrencyType: { type: String }, //foreignCurrency
    foreignCurrency: { type: Number }, //foreignCurrencyAmount
    exRate: { type: Number },

    // Section 1
    cancellationSectionChkBx: { type: Boolean },
    cancellationRadio: { type: String },
    outstandingAmountRadio: { type: String },
    cancellationSectionRadio: { type: String },
    cancellationReason: { type: String },
    loAcceptedDateRadio: { type: Boolean },
    loAcceptedDate: { type: Date },
    otherRemarks: { type: String },
    cancellationOfAccepted: { type: String },
    cancellationOutstandingAmountSGD: { type: Number },
    cancellationOutstandingAmountUSD: { type: Number },
    otherRemarksAccepted: { type: String },

    // Section 2
    expiryExtensionChkBx: { type: Boolean },
    facilityExpiryExtentsionChkBx: { type: Boolean },
    facilityExpiryDate: { type: Date }, //loanExpiryDate
    eFacilityExpiryDate: { type: Date },

    // Section 3
    dueDateExtensionChkBx: { type: Boolean },
    billDueDate: { type: Date },
    eBillDueDate: { type: Date },
    billInfoChkBx: { type: Boolean },

    // Section 4
    overseasBuyerChkBx: { type: Boolean },
    domesticBuyerChkBx: { type: Boolean },

    // Section 5
    preShipmentChkBx: { type: Boolean },
    insurersApprovalChkBx: { type: Boolean },

    // Section 6
    moreTimeLoChkBx: { type: Boolean },
    decisionDate: { type: Date },
    calendarDays: { type: Date },
    decisionDateLis: { type: Date },
    calendarDaysLis: { type: Date },
    extendedLoDate: { type: Date },
    extensionReason: { type: String },

    // Section 7 commented out

    // Section 8
    newDisbursementsChkBx: { type: Boolean },
    internalCreditMemoChkBx: { type: Boolean },

    // Section 9
    reValidateInsuranceChkBx: { type: Boolean },
    reasonForBreachRadio: { type: String },
    reasonForBreachRadio2Txt: { type: String },
    reasonForBreachRadio3Txt: { type: String },
    noAdverseInfoChkBx: { type: Boolean },
    outstandingAmountChkBx: { type: Boolean },
    borrwLoAcceptedDate: { type: Date },

    // Section 10
    processRequestChkBx: { type: Boolean },
    otherReason: { type: String },
    reviewDocChkBx: { type: Boolean },


    sponsorForm: {
      regComName: { type: String }, //regName
      ACRANo: { type: String }, //uenNumber
    },
    creditInfo: {
      pfiCode: { type: String },
      pfiName: { type: String },
      totalRequstedLimitSGD: { type: Number },
      submissionDate: { type: Number },
      primary: { type: Number },
      autoTopUp: { type: Number },
      bg: { type: Number },
      lisPlus: { type: Number },
      requesterName: { type: String },
      foreignCurrency: { type: String },
      foreignCurrencyAmount: { type: Number },
      exRate: { type: Number },
    },
    adverseInfo: {
      adverseStatus: { type: String },
      additionalInfo: { type: String },
      overdue: { type: String },
      overdueDate: { type: Date },
      listOfOverdue: { type: Boolean },
      repaymentPlanAttached: { type: Boolean }
    },
    supportingDocs: [
      {
        _id: { type: String },
        name: { type: String },
        id: { type: String },
        status: { type: Boolean },
        files: { type: String }
      },
      {
        _id: { type: String },
        name: { type: String },
        id: { type: String },
        status: { type: Boolean },
        files: { type: String }
      },
      {
        _id: { type: String },
        name: { type: String },
        id: { type: String },
        status: { type: Boolean },
        files: { type: String }
      },
      {
        _id: { type: String },
        name: { type: String },
        id: { type: String },
        status: { type: Boolean },
        files: { type: String }
      },
      {
        _id: { type: String },
        name: { type: String },
        id: { type: String },
        status: { type: Boolean },
        files: { type: String }
      },
      {
        _id: { type: String },
        name: { type: String },
        id: { type: String },
        status: { type: Boolean },
        files: { type: String }
      },
      {
        _id: { type: String },
        name: { type: String },
        id: { type: String },
        status: { type: Boolean },
        files: { type: String }
      },
      {
        _id: { type: String },
        name: { type: String },
        id: { type: String },
        status: { type: Boolean },
        files: { type: String }
      },
      {
        _id: { type: String },
        name: { type: String },
        id: { type: String },
        status: { type: Boolean },
        files: { type: String }
      },
      {
        _id: { type: String },
        name: { type: String },
        id: { type: String },
        status: { type: Boolean },
        files: { type: String }
      }
    ],
    typeOfRequest: { type: String }
  });

var diffHistory = require("mongoose-diff-history/diffHistory");
AdhocSchema.plugin(diffHistory.plugin);

export const AdhocModel = Mongoose.model<IAdhoc>("Adhoc", AdhocSchema);
