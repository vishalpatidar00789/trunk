import * as Hapi from 'hapi';
import * as Boom from 'boom';
import * as Jwt from 'jsonwebtoken';
import { IAdhoc, AdhocModel } from './adhoc';
import { IDatabase } from '../../database';
import { IServerConfigurations } from '../../configurations';
import { IRequest, ILoginRequest, IMailOptions } from '../../interfaces/request';
import { getHeapSpaceStatistics } from 'v8';
import { IApp } from '../master-data/app-management/app-management';
import { ObjectId } from 'mongodb';
import { ILoan } from '../loan/loan';
import LoanService from '../../services/loan-service';
import EmailService from '../../services/email-service';

export default class AdhocController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase, private loanService: LoanService, private emailService: EmailService) {
    this.database = database;
    this.configs = configs;
  }

  public async createAdhoc(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let requestPayload: any = request['payload'];
      const userId = request.auth.credentials.id;
      requestPayload['createdBy'] = userId;
      requestPayload['createdDate'] = new Date();
      // indicator column typeOfRequest added by vishal p
      requestPayload['typeOfRequest'] = "adhoc";

      let adhoc: any = await this.database.adhocModel.create(requestPayload);
      if (adhoc) {
        return h.response({ _id: adhoc._id, status: adhoc.status }).code(201);
      } else {
        return Boom.badData("Internal Server Error While Creating Adhoc Application.");
      }

    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateAdhoc(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params['id'];

    console.log("adhocid: " + id);
    try {
      let requestPayload: any = request['payload'];
      const userId = request.auth.credentials.id;
      requestPayload['lastmodifiedBy'] = userId;
      requestPayload['lastModifiedDate'] = new Date();
      console.log(requestPayload);

      let app = await this.getCurrentApp();
      requestPayload['app'] = app;

      if (requestPayload["status"] && requestPayload["status"] === 'Processing') {
        // generate marsh ref number for adhoc transaction
        const loanMarshRefNumber = requestPayload["loanMarshRefNo"];
        if (loanMarshRefNumber) {
          const resultObj = await this.loanService.generateOtherMarshRefNumber(loanMarshRefNumber);
          if (resultObj && resultObj["marshRefNumber"] && resultObj["seqNumber"]) {
            requestPayload["marshRefNo"] = resultObj["marshRefNumber"];
            const seqNumber = resultObj["seqNumber"];
            let adhoc: IAdhoc = await this.database.adhocModel.findByIdAndUpdate(
              { _id: id },
              { $set: requestPayload },
              { new: true }
            ).lean(true);
            if (adhoc) {
              if (await this.loanService.updateLoanRequestSeqNo(loanMarshRefNumber, seqNumber)) {
                delete adhoc['typeOfRequest'];
                this.sendAcknowledmentMail(adhoc, userId);
                return adhoc;
              } else {
                return Boom.badImplementation("Internal Server Error While Updating Loan Request Sequence Number.");
              }
            } else {
              return Boom.badData("Internal Server Error While Saving Adhoc.");
            }
          } else {
            return Boom.badImplementation("Internal Server Error While Generating Adhoc Reference Number.");
          }
        } else {
          return Boom.badData("No Loan Marsh Reference Number Found.");
        }
      } else if (requestPayload["status"] && requestPayload["status"] === 'Draft') {
        let adhoc: IAdhoc = await this.database.adhocModel.findByIdAndUpdate(
          { _id: id },
          { $set: requestPayload },
          { new: true }
        ).lean(true);
        delete adhoc['typeOfRequest'];
        return adhoc;
      }
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  private sendAcknowledmentMail(adhoc: IAdhoc, userId: string) {

    let date1 = adhoc['createdDate'].toString().substr(4, 11);
    let m = date1.substr(0, 3);
    let d = date1.substr(4, 2);
    let y = date1.substr(7, 4);

    let pfiName = adhoc['creditInfo']['pfiName'];
    let regComName = adhoc['sponsorForm']['regComName'];
    let ACRANo = adhoc['sponsorForm']['ACRANo'];
    let loanMarshRefNo = adhoc['loanMarshRefNo'];
    let adhocMarshRefNo = adhoc['marshRefNo'];

    //TO PFI USER
    let emailOptions = new IMailOptions();
    emailOptions.from = this.configs.systemEmail; // this should be configurable
    emailOptions.to = userId;
    emailOptions.subject = `QA - Acknowledgement for Ad-hoc Request Submission - ${regComName} - ${adhocMarshRefNo}`;
    emailOptions.html = `Dear ${userId}<br><br>
                        This is an acknowledgement email for your Ad-hoc request submission over Loan application ${loanMarshRefNo} in Marsh's Loan Insurance Scheme Portal. Please find the details below: <br>
                        Marsh Reference number:  ${adhocMarshRefNo}<br>
                        Marsh Submission Date:   ${d} ${m} ${y}<br>
                        PFI Name:                ${pfiName}<br>
                        Registered Company Name: ${regComName}<br>
                        UEN No:                  ${ACRANo}<br>
                        <br><br>
                        Disclaimer: Users can submit applications and track the status of requests at any time, but processing of applications would only be during regular business hours from 8.30 AM to 5.30 PM, Monday – Friday.
                        Note: This is an automated email sent from Marsh's Loan Insurance Scheme Portal. Please do not reply to this email.`;
    this.emailService.sendEmail(emailOptions);

    //TO MARSH USER
    let emailOptions2 = new IMailOptions();
    emailOptions2.from = this.configs.systemEmail; // this should be configurable
    emailOptions2.to = 'Upendra.Krishtam01@marsh.com;Amit.Kumar02@marsh.com';
    emailOptions2.subject = `QA - Adhoc Request Submission by -${pfiName} - ${regComName} - ${adhocMarshRefNo}`;
    emailOptions2.html = `Dear Marsh Users<br><br>
                      Ad-hoc request submission over Loan application ${loanMarshRefNo} has been submitted in Marsh's Loan Insurance Scheme Portal. Please find the details below:<br>
                      Marsh Reference number:  ${adhocMarshRefNo}<br>
                      Marsh Submission Date:   ${d} ${m} ${y} <br>
                      PFI Name:                ${pfiName}<br>
                      Registered Company Name: ${regComName}<br>
                      UEN No:                  ${ACRANo}<br>
                      <br><br>
                      Note: This is an automated email sent from Marsh's Loan Insurance Scheme Portal. Please do not reply to this email.`;
    this.emailService.sendEmail(emailOptions2);
  }

  public async updateAdhocAdverseInfo(request: IRequest, h: Hapi.ResponseToolkit) {
    let id = request.params['id'];
    try {
      let requestPayload: any = request['payload'];
      console.log(requestPayload);
      const userId = request.auth.credentials.id;
      requestPayload['lastmodifiedBy'] = userId;
      requestPayload['lastModifiedDate'] = new Date();
      console.log('id', id);
      let adhoc: IAdhoc = await this.database.adhocModel.findByIdAndUpdate(
        { _id: id },
        { $set: requestPayload },
        { new: true }
      );
      return { message: 'success' };
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteAdhoc(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.auth.credentials.id;
    let adhoc: IAdhoc = await this.database.adhocModel.findByIdAndRemove(id);
    delete adhoc['typeOfRequest'];
    return adhoc;
  }

  public async getAdhoc(request: IRequest, h: Hapi.ResponseToolkit) {
    const adhocId = request.params.id;
    console.log("Adhoc id:" + adhocId);
    try {
      let adhoc: IAdhoc = await this.database.adhocModel.findById(adhocId).lean(true);
      if (adhoc) {
        delete adhoc['typeOfRequest'];
        return adhoc;
      } else {
        return Boom.notFound();
      }
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async saveAsDraft(request: IRequest, h: Hapi.ResponseToolkit) {
    console.log(JSON.stringify(request.params.id));
    const id = request.params.id;

    let requestPayload: any = request['payload'];
    let app = await this.getCurrentApp();
    requestPayload['app'] = app;

    try {
      let adhoc: IAdhoc = await this.database.adhocModel.findByIdAndUpdate(
        id,
        { $set: requestPayload },
        { new: true }
      ).lean(true);
      delete adhoc['typeOfRequest'];
      return adhoc;
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  private async getCurrentApp() {
    let appManagement: IApp = await this.database.appModel.findOne({
      activated: true
    });
    return appManagement.app;
  }
}
