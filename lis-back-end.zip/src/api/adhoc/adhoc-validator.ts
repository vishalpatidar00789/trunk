import * as Joi from "joi";
export const adhocPayload = Joi.object().keys({
  status: Joi.string().allow("").allow(null).optional(),
  marshRefNo: Joi.string().allow("").allow(null).optional(),
  loanMarshRefNo: Joi.string().allow("").allow(null).optional(),
  baseLoanId: Joi.string().allow("").allow(null).optional(),
  consortium: Joi.string().allow("").allow(null).optional(),
  app: Joi.number().allow(null),
  createdBy: Joi.string().allow("").optional(),
  createdDate: Joi.date().allow("").allow(null).optional(),
  lastModifiedBy: Joi.string().allow("").optional(),
  lastModifiedDate: Joi.date().allow("").allow(null).optional(),

  // nameOfStaff: Joi.string().allow("").allow(null).optional(),
  // submissionDate: Joi.date().allow(null).optional(),

  // pfiCode: Joi.string().allow("").allow(null).optional(),
  // pfiName: Joi.string().allow("").allow(null).optional(),
  // regName: Joi.string().allow("").allow(null).optional(),
  // uenNumber: Joi.string().allow("").allow(null).optional(),
  // primary: Joi.number().allow(null),
  // autoTopUp: Joi.number().allow(null),
  // bg: Joi.number().allow(null),
  // lisPlus: Joi.number().allow(null),
  // foreignCurrencyType: Joi.string().allow("").allow(null).optional(),
  // foreignCurrency: Joi.number().allow(null),
  // exRate: Joi.number().allow(null),

  // Section 1
  cancellationSectionChkBx: Joi.boolean().allow("").allow(null).optional(),
  cancellationRadio: Joi.string().allow("").allow(null).optional(),
  outstandingAmountRadio: Joi.string().allow("").allow(null).optional(),
  cancellationSectionRadio: Joi.string().allow("").allow(null).optional(),
  cancellationReason: Joi.string().allow("").allow(null).optional(),
  loAcceptedDateRadio: Joi.boolean().allow("").allow(null).optional(),
  loAcceptedDate: Joi.date().allow(null).optional(),
  otherRemarks: Joi.string().allow("").allow(null).optional(),
  cancellationOfAccepted: Joi.string().allow("").allow(null).optional(),
  cancellationOutstandingAmountSGD: Joi.number().allow(null),
  cancellationOutstandingAmountUSD: Joi.number().allow(null),
  otherRemarksAccepted: Joi.string().allow("").allow(null).optional(),

  // Section 2
  expiryExtensionChkBx: Joi.boolean().allow("").allow(null).optional(),
  facilityExpiryExtentsionChkBx: Joi.boolean().allow("").allow(null).optional(),
  facilityExpiryDate: Joi.date().allow(null).optional(),
  eFacilityExpiryDate: Joi.date().allow(null).optional(),

  // Section 3
  dueDateExtensionChkBx: Joi.boolean().allow("").allow(null).optional(),
  billDueDate: Joi.date().allow(null).optional(),
  eBillDueDate: Joi.date().allow(null).optional(),
  billInfoChkBx: Joi.boolean().allow("").allow(null).optional(),

  // Section 4
  overseasBuyerChkBx: Joi.boolean().allow("").allow(null).optional(),
  domesticBuyerChkBx: Joi.boolean().allow("").allow(null).optional(),

  // Section 5
  preShipmentChkBx: Joi.boolean().allow("").allow(null).optional(),
  insurersApprovalChkBx: Joi.boolean().allow("").allow(null).optional(),

  // Section 6
  moreTimeLoChkBx: Joi.boolean().allow("").allow(null).optional(),
  decisionDate: Joi.date().allow(null).optional(),
  calendarDays: Joi.date().allow(null).optional(),
  decisionDateLis: Joi.date().allow(null).optional(),
  calendarDaysLis: Joi.date().allow(null).optional(),
  extendedLoDate: Joi.date().allow(null).optional(),
  extensionReason: Joi.string().allow("").allow(null).optional(),

  // Section 7 commented out

  // Section 8
  newDisbursementsChkBx: Joi.boolean().allow("").allow(null).optional(),
  internalCreditMemoChkBx: Joi.boolean().allow("").allow(null).optional(),

  // Section 9
  reValidateInsuranceChkBx: Joi.boolean().allow("").allow(null).optional(),
  reasonForBreachRadio: Joi.string().allow("").allow(null).optional(),
  reasonForBreachRadio2Txt: Joi.string().allow("").allow(null).optional(),
  reasonForBreachRadio3Txt: Joi.string().allow("").allow(null).optional(),
  noAdverseInfoChkBx: Joi.boolean().allow("").allow(null).optional(),
  outstandingAmountChkBx: Joi.boolean().allow("").allow(null).optional(),
  borrwLoAcceptedDate: Joi.date().allow(null).optional(),

  // Section 10
  processRequestChkBx: Joi.boolean().allow("").allow(null).optional(),
  otherReason: Joi.string().allow("").allow(null).optional(),
  reviewDocChkBx: Joi.boolean().allow("").allow(null).optional(),
  supportingDocs: Joi.array().items(
    { name: Joi.string(), id: Joi.string().allow("").optional(), status: Joi.boolean(), files: Joi.string().allow("").optional() },
    { name: Joi.string(), id: Joi.string().allow("").optional(), status: Joi.boolean(), files: Joi.string().allow("").optional() },
    { name: Joi.string(), id: Joi.string().allow("").optional(), status: Joi.boolean(), files: Joi.string().allow("").optional() },
    { name: Joi.string(), id: Joi.string().allow("").optional(), status: Joi.boolean(), files: Joi.string().allow("").optional() },
    { name: Joi.string(), id: Joi.string().allow("").optional(), status: Joi.boolean(), files: Joi.string().allow("").optional() },
    { name: Joi.string(), id: Joi.string().allow("").optional(), status: Joi.boolean(), files: Joi.string().allow("").optional() },
    { name: Joi.string(), id: Joi.string().allow("").optional(), status: Joi.boolean(), files: Joi.string().allow("").optional() },
    { name: Joi.string(), id: Joi.string().allow("").optional(), status: Joi.boolean(), files: Joi.string().allow("").optional() },
    { name: Joi.string(), id: Joi.string().allow("").optional(), status: Joi.boolean(), files: Joi.string().allow("").optional() }
  ),

  sponsorForm: Joi.object().keys({
    regComName: Joi.string().allow("").optional(), //regName
    ACRANo: Joi.string().allow("").optional(), //uenNumber
  }),
  creditInfo: Joi.object().keys({
    pfiCode: Joi.string().allow("").optional(),
    pfiName: Joi.string().allow("").optional(),
    totalRequstedLimitSGD: Joi.number().allow(null).optional(),
    submissionDate: Joi.date().allow(null).optional(),
    primary: Joi.number().allow(null).optional(),
    autoTopUp: Joi.number().allow(null).optional(),
    bg: Joi.number().allow(null).optional(),
    lisPlus: Joi.number().allow(null).optional(),
    requesterName: Joi.string().allow("").allow(null).optional(),
    foreignCurrency: Joi.string().allow("").allow(null).optional(),
    foreignCurrencyAmount: Joi.number().allow(null).optional(),
    exRate: Joi.number().allow(null).optional(),
  }),

  adverseInfo: Joi.object().keys({
    adverseStatus: Joi.string().allow("").optional(),
    additionalInfo: Joi.string().allow("").optional(),
    overdue: Joi.string().allow("").optional(),
    overdueDate: Joi.date().allow(null).optional(),
    listOfOverdue: Joi.boolean().allow(null).optional(),
    repaymentPlanAttached: Joi.boolean().allow(null).optional(),
  }),
});

export const searchAdhocPayload = Joi.object().keys({

  marshRefNo: Joi.string().allow("").allow(null).optional(),
  borrowerName: Joi.string().allow("").allow(null).optional(),
  uenNumber: Joi.string().allow("").allow(null).optional(),
  pfiName: Joi.array().allow(null).optional(),
  consortium: Joi.string().allow("").allow(null).optional(),
  adverseStatus: Joi.string().allow("").allow(null).optional(),
  typeOfDate: Joi.string().allow("").allow(null).optional(),
  fromDate: Joi.any().allow("").allow(null).optional(),
  toDate: Joi.any().allow("").allow(null).optional(),
  natureOfApplication: Joi.array().allow(null).allow("").optional(),
  marshLoanApplicationStatus: Joi.array().allow(null).allow("").optional(),
  excludeExpiredApplications: Joi.boolean().allow("").allow(null).optional(),
  app: Joi.array().allow(null).optional(),
});

export const jwtValidator = Joi.object({ 'authorization': Joi.string().required() }).unknown();
