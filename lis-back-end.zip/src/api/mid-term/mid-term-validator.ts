import * as Joi from 'joi';
export const createMidTermModel = Joi.object().keys({
  status: Joi.string(),
  marshRefNo: Joi.string()
    .allow('')
    .optional(),
  loanBaseId: Joi.string()
    .allow('')
    .optional(),
  consortium: Joi.string()
    .allow('')
    .optional(),
  app: Joi.number()
    .allow('')
    .optional(),
  loanRequestSeqNo: Joi.number()
    .allow('')
    .optional(),
  isClaimSubmitted: Joi.boolean(),
  isMidTermIncrease: Joi.boolean(),
  grossSGDPremiumPL: Joi.number()
    .allow(null)
    .optional(),
  grossSGDPremiumTUL: Joi.number()
    .allow(null)
    .optional(),
  grossSGDPremiumBG: Joi.number()
    .allow(null)
    .optional(),
  grossSGDPremiumLISPlus: Joi.number()
    .allow(null)
    .optional(),
  createdBy: Joi.string()
    .allow('')
    .optional(),
  createdDate: Joi.date()
    .allow('')
    .allow(null)
    .optional(),
  lastmodifiedBy: Joi.string()
    .allow('')
    .optional(),
  lastModifiedDate: Joi.date()
    .allow('')
    .allow(null)
    .optional(),
  creditInfo: Joi.object().keys({
    _id: Joi.string(),
    lisCoinsurer: Joi.string(),
    pfiName: Joi.string(),
    pfiCode: Joi.string()
      .allow('')
      .optional(),
    requesterName: Joi.string()
      .allow('')
      .optional(),
    aCRArefNo: Joi.string()
      .allow('')
      .optional(),
    borrowerRegName: Joi.string()
      .allow('')
      .optional(),
    submissionDate: Joi.date()
      .allow('')
      .allow(null)
      .optional(),
    totalRequstedLimitSGD: Joi.number()
      .allow(null)
      .optional(),
    preshipmentApprovalChkBx: Joi.boolean(),
    exRate: Joi.number()
      .allow(null)
      .optional(),
    foreignCurrencyAmount: Joi.number()
      .allow(null)
      .optional(),
    primary: Joi.number()
      .allow(null)
      .optional(),
    autoTopUp: Joi.number()
      .allow(null)
      .optional(),
    bg: Joi.number()
      .allow(null)
      .optional(),
    lisPlus: Joi.number()
      .allow(null)
      .optional(),
    inventoryChkBx: Joi.boolean(),
    workingCapChkBx: Joi.boolean(),
    overseaseWorkingChkBx: Joi.boolean(),
    bankersGuaranteeChkBx: Joi.boolean(),
    tempIncreaseLimitChkBx: Joi.boolean(),
    midTermIncreaseLimitChkBx: Joi.boolean(),
    decreaseLimitChkBx: Joi.boolean(),
    beforeMidTermIncreaseLimitChkBx: Joi.boolean(),
    beforeDecreaseLimitChkBx: Joi.boolean(),
    resourceFactoringChkBx: Joi.boolean(),
    loanQuantumChkBx: Joi.boolean(),
    operatongTrackChkBx: Joi.boolean(),
    latestAuditedChkBx: Joi.boolean(),
    auditedFinanceChkBx: Joi.boolean(),
    applicationChkBx: Joi.boolean(),
    bankersGuaranteeBChkBx: Joi.boolean(),
    guaranteeAmountChkBx: Joi.boolean(),
    guaranteeAmount2ChkBx: Joi.boolean(),
    bankersGuaranteeB2ChkBx: Joi.boolean(),
    principalChkBx: Joi.boolean(),
    lisSponsersApplChkBx: Joi.boolean(),
    companySearchesChkBx: Joi.boolean(),
    pfiInternalCreditChkBx: Joi.boolean(),
    inventoryTradeChkBx: Joi.boolean(),
    latestSignedChkBx: Joi.boolean(),
    additionalItemChkBx: Joi.boolean(),
    forOverseasChkBx: Joi.boolean(),
    inventoryTxt: Joi.number()
      .allow(null)
      .optional(),
    overseaseWorkingTxt: Joi.number()
      .allow(null)
      .optional(),
    tempIncreaseLimitTxt: Joi.number()
      .allow(null)
      .optional(),
    structuredWorkingCapTxt: Joi.number()
      .allow(null)
      .optional(),
    inventoryTradeTxt: Joi.number()
      .allow(null)
      .optional(),
    resourceFactoringTxt: Joi.number()
      .allow(null)
      .optional(),
    additionalItemTxt: Joi.string()
      .allow('')
      .optional(),
    beforeMidTermIncreaseLimitTxt: Joi.number()
      .allow(null)
      .optional(),
    decreaseLimitTxt: Joi.number()
      .allow(null)
      .optional(),
    beforeDecreaseLimitTxt: Joi.number()
      .allow(null)
      .optional(),
    tempIncreaseLimitChkBxTxt: Joi.number()
      .allow(null)
      .optional(),
    midTermIncreaseLimitTxt: Joi.number()
      .allow(null)
      .optional(),
    bankersGuaranteeTxt: Joi.number()
      .allow(null)
      .optional(),
    latestSignedDt: Joi.date()
      .allow('')
      .allow(null)
      .optional(),
    latestAuditedDt: Joi.date()
      .allow('')
      .allow(null)
      .optional(),
    foreignCurrency: Joi.string()
      .allow('')
      .optional(),
    appliedAmountDL: Joi.number()
      .allow(null)
      .optional(),
    exceptionalCrrRate: Joi.number()
      .allow(null)
      .optional(),
    // borrowersGroup: Joi.array().items({
    //         name: Joi.string().allow("").optional()
    // }),
    latestAuditFinanceChkBx: Joi.boolean(),
    supportingDocs: Joi.array().items(
      {
        _id: Joi.string()
          .allow('')
          .optional(),
        name: Joi.string(),
        id: Joi.string()
          .allow('')
          .optional(),
        status: Joi.boolean(),
        files: Joi.string()
          .allow('')
          .optional()
      },
      {
        _id: Joi.string()
          .allow('')
          .optional(),
        name: Joi.string(),
        id: Joi.string()
          .allow('')
          .optional(),
        status: Joi.boolean(),
        files: Joi.string()
          .allow('')
          .optional()
      },
      {
        _id: Joi.string()
          .allow('')
          .optional(),
        name: Joi.string(),
        id: Joi.string()
          .allow('')
          .optional(),
        status: Joi.boolean(),
        files: Joi.string()
          .allow('')
          .optional()
      },
      {
        _id: Joi.string()
          .allow('')
          .optional(),
        name: Joi.string(),
        id: Joi.string()
          .allow('')
          .optional(),
        status: Joi.boolean(),
        files: Joi.string()
          .allow('')
          .optional()
      },
      {
        _id: Joi.string()
          .allow('')
          .optional(),
        name: Joi.string(),
        id: Joi.string()
          .allow('')
          .optional(),
        status: Joi.boolean(),
        files: Joi.string()
          .allow('')
          .optional()
      },
      {
        _id: Joi.string()
          .allow('')
          .optional(),
        name: Joi.string(),
        id: Joi.string()
          .allow('')
          .optional(),
        status: Joi.boolean(),
        files: Joi.string()
          .allow('')
          .optional()
      },
      {
        _id: Joi.string()
          .allow('')
          .optional(),
        name: Joi.string(),
        id: Joi.string()
          .allow('')
          .optional(),
        status: Joi.boolean(),
        files: Joi.string()
          .allow('')
          .optional()
      },
      {
        _id: Joi.string()
          .allow('')
          .optional(),
        name: Joi.string(),
        id: Joi.string()
          .allow('')
          .optional(),
        status: Joi.boolean(),
        files: Joi.string()
          .allow('')
          .optional()
      },
      {
        _id: Joi.string()
          .allow('')
          .optional(),
        name: Joi.string(),
        id: Joi.string()
          .allow('')
          .optional(),
        status: Joi.boolean(),
        files: Joi.string()
          .allow('')
          .optional()
      }
    ),

    //}),
    //uob: Joi.object().keys({
    // _id: Joi.string(),
    //pfiName: Joi.string().allow("").optional(),
    discretiolaryLimitDL: Joi.boolean(),
    creditLimitCL: Joi.boolean(),
    borrowersCrr: Joi.number()
      .allow(null)
      .optional(),
    crrRate: Joi.string()
      .allow('')
      .optional(),
    lisType: Joi.string()
      .allow('')
      .optional(),
    inventoryStockChkBx: Joi.boolean(),
    structuredWorkingCapitalChkBx: Joi.boolean(),
    recourseFactoringBillChkBx: Joi.boolean(),
    overseasWorkingCapitalChkBx: Joi.boolean(),
    bankersGuarantee: Joi.boolean(),
    //submissionDate: Joi.string().allow("").optional(),
    renewalToUSDTxt: Joi.number()
      .allow(null)
      .optional(),
    renewalToSGDTxt: Joi.number()
      .allow(null)
      .optional(),
    increaseLimitToSGD: Joi.number()
      .allow(null)
      .optional(),
    increaseLimitToUSD: Joi.number()
      .allow(null)
      .optional(),
    decreaseLimitToSGD: Joi.number()
      .allow(null)
      .optional(),
    decreaseLimitToUSD: Joi.number()
      .allow(null)
      .optional(),
    renewalFromSGDTxt: Joi.number()
      .allow(null)
      .optional(),
    renewalFromUSDTxt: Joi.number()
      .allow(null)
      .optional(),
    //latestAuditedDt: Joi.string().allow("").optional(),
    //latestSignedDt: Joi.string().allow("").optional(),
    sgdCurrencyCurrentLIS: Joi.number()
      .allow(null)
      .optional(),
    usdCurrencyCurrentLIS: Joi.number()
      .allow(null)
      .optional(),
    usdCurrency: Joi.number()
      .allow(null)
      .optional(),
    sgdCurrency: Joi.number()
      .allow(null)
      .optional(),
    currencyExchangeRate: Joi.number()
      .allow(null)
      .optional(),
    usdCurrencyCurrent: Joi.number()
      .allow(null)
      .optional(),
    sgdCurrencyCurrent: Joi.number()
      .allow(null)
      .optional(),
    usdCurrencyCurrentLISP: Joi.number()
      .allow(null)
      .optional(),
    sgdCurrencyCurrentLISP: Joi.number()
      .allow(null)
      .optional(),
    // borrowerRegName: Joi.string().allow("").optional(),
    bankersGuaranteeAmountChkBx: Joi.boolean(),
    // pfiInternalCreditChkBx: Joi.boolean(),
    // lisSponsersApplChkBx: Joi.boolean(),
    //companySearchesChkBx: Joi.boolean(),
    //latestAuditedChkBx: Joi.boolean(),
    //latestSignedChkBx: Joi.boolean(),
    // additionalItemChkBx: Joi.boolean(),
    //forOverseasChkBx: Joi.boolean(),
    // additionalItemTxt: Joi.string().allow("").optional(),
    inventoryUSDTxt: Joi.number()
      .allow(null)
      .optional(),
    inventorySGDTxt: Joi.number()
      .allow(null)
      .optional(),
    withRecourseUSDTxt: Joi.number()
      .allow(null)
      .optional(),
    withRecourseSGDTxt: Joi.number()
      .allow(null)
      .optional(),
    structuredWorkingCapitalUSDTxt: Joi.number()
      .allow(null)
      .optional(),
    structuredWorkingCapitalSGDTxt: Joi.number()
      .allow(null)
      .optional(),
    overseaseCapitalSGDTxt: Joi.number()
      .allow(null)
      .optional(),
    overseaseCapitalUSDTxt: Joi.number()
      .allow(null)
      .optional(),
    bankersGuaranteeAmountSGDTxt: Joi.number()
      .allow(null)
      .optional(),
    rocRefNo: Joi.string()
      .allow('')
      .optional(),
    tenureMonths: Joi.number()
      .allow(null)
      .optional(),
    bankersGuaranteeAmountUSDTxt: Joi.number(),
    //foreignCurrency: Joi.string().allow("").optional(),
    borrowersGroup: Joi.array().items({
      name: Joi.string()
        .allow('')
        .optional(),
      limit: Joi.number()
        .allow(null)
        .optional()
    }),
    requestLimit: Joi.string()
      .allow('')
      .optional(),
    afterTempIncreaseTxt: Joi.number()
      .allow(null)
      .optional(),
    afterMidTempIncreaseTxt: Joi.number()
      .allow(null)
      .optional(),
    beforeMidTempIncreaseTxt: Joi.number()
      .allow(null)
      .optional(),
    afterMidTempDecreaseTxt: Joi.number()
      .allow(null)
      .optional(),
    beforeMidTempDecreaseTxt: Joi.number()
      .allow(null)
      .optional(),
    requestLimitValue: Joi.number()
      .allow(null)
      .optional(),
    requestLimitForeignValue: Joi.number()
      .allow(null)
      .optional(),
    appliedIncAmountDL: Joi.number()
      .allow(null)
      .optional(),
    appliedIncAmountBG: Joi.number()
      .allow(null)
      .optional(),
    approvedPrimaryLayer: Joi.number()
      .allow(null)
      .optional(),
    approvedBgLayer: Joi.number()
      .allow(null)
      .optional(),
    appliedDecAmountDL: Joi.number()
      .allow(null)
      .optional(),
    appliedDecAmountBG: Joi.number()
      .allow(null)
      .optional(),

    typeOfLimit: Joi.string()
      .allow('')
      .optional(),
    TypeOfLISPlusLimit: Joi.string()
      .allow('')
      .optional(),
    natureOfApplication: Joi.string()
      .allow('')
      .optional(),
    loanDomesticTrade1: Joi.number()
      .allow(null)
      .optional(),
    loanDomesticTrade2: Joi.number()
      .allow(null)
      .optional(),
    purposeOfLoan: Joi.string()
      .allow('')
      .optional(),
    insurersApprovalDate: Joi.date()
      .allow(null)
      .optional(),
    loAcceptanceDate: Joi.date()
      .allow(null)
      .optional(),
    loanExpiryDate: Joi.date()
      .allow(null)
      .optional(),
    dateSentForLISPlus: Joi.date()
      .allow(null)
      .optional(),
    lISPlusApprovedDate: Joi.date()
      .allow(null)
      .optional(),
    //approvedPrimaryLayer: Joi.number().allow(null).optional(),
    approvedAutoTopUpLayer: Joi.number()
      .allow(null)
      .optional(),
    //approvedBgLayer: Joi.number().allow(null).optional(),
    approvedSGDLimitLISPlus: Joi.number()
      .allow(null)
      .optional(),
    lis5TotalApprovedLimit: Joi.number()
      .allow(null)
      .optional(),
    totalApprovedLimitincludingLISPLUS: Joi.number()
      .allow(null)
      .optional(),
    totalApprovedPrimaryLimitInForce: Joi.number()
      .allow(null)
      .optional(),
    totalApprovedAutoTopUpLimitInForce: Joi.number()
      .allow(null)
      .optional(),
    totalApprovedBGlimitInForce: Joi.number()
      .allow(null)
      .optional(),
    totalApprovedLISPlusLimitInForce: Joi.number()
      .allow(null)
      .optional(),
    totalApprovedLimitInForce: Joi.number()
      .allow(null)
      .optional(),
    totalRequstedLimitSGDForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
    approvedPrimaryLayerForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
    approvedAutoTopUpLayerForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
    approvedBgLayerForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
    approvedSGDLimitLISPlusForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
    lis5TotalApprovedLimitForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
    totalApprovedLimitincludingLISPLUSForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
    totalApprovedPrimaryLimitInForceForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
    totalApprovedAutoTopUpLimitInForceForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
    totalApprovedBGlimitInForceForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
    totalApprovedLISPlusLimitInForceForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
    totalApprovedLimitInForceForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
    LIS5ApprovalRatio: Joi.number()
      .allow(null)
      .optional(),
    approvalRatioWithLISPLUS: Joi.number()
      .allow(null)
      .optional(),
    LIS5TurnaroundDays: Joi.number()
      .allow(null)
      .optional(),
    turnaroundWithLISPLUSDays: Joi.number()
      .allow(null)
      .optional(),
    utilization: Joi.string()
      .allow('')
      .optional(),
    reportedMonth: Joi.number()
      .allow(null)
      .optional(),
    loanApplicationNumber: Joi.string()
      .allow('')
      .optional(),
    internalRemark: Joi.string()
      .allow('')
      .optional(),

    totalAppliedLimitForLIS5: Joi.number()
      .allow(null)
      .optional(),
    totalAppliedLimitForLIS5ForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
    approvedlimitPrimaryLayerForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
    approvedLimitAutoTopUpLayerForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
    approvedLimitBGLayerForeignCurrency: Joi.number()
      .allow(null)
      .optional(),
      effectiveStartDate: Joi.date().allow(null).optional(),
    effectiveEndDate: Joi.date().allow(null).optional(),
    proRateRatio: Joi.number()
      .allow(null)
      .optional()
  }),
  sponsorForm: Joi.object().keys({
    _id: Joi.string(),
    regComName: Joi.string().allow(null),
    registeredCompanyName: Joi.string().allow(null),
    uniqueEntityNumber: Joi.string().allow(null),
    correspondenceAddress: Joi.string().allow(null),
    contactPersonDesignation: Joi.string().allow(null),
    phoneNumber: Joi.string().allow(null),
    contactEmail: Joi.string().allow(null),
    numberofStaff: Joi.number().allow(null),
    dateofIncorporation: Joi.date()
      .allow(null)
      .optional(),
    dateOfSingature: Joi.string().allow(null),
    contactPersonNo: Joi.string().allow(null),
    ACRANo: Joi.string().allow(null),
    corrAddress1: Joi.string().allow(null),
    corrAddress2: Joi.string().allow(null),
    corrAddress3: Joi.string().allow(null),
    contactPerson: Joi.string().allow(null),
    contactPersonEmail: Joi.string().allow(null),
    businessActivity: Joi.string().allow(null),
    numStaff: Joi.string().allow(null),
    appLFY: Joi.number().allow(null),
    appSubLFY: Joi.number().allow(null),
    appSales: Joi.number().allow(null),
    appSubSales: Joi.number().allow(null),
    appNetProfit: Joi.number().allow(null),
    appNetProfitsubsidiaries: Joi.number().allow(null),
    appSubNetProfit: Joi.number().allow(null),
    shareholdingSub: Joi.array().items(
      Joi.object({
        level: Joi.string()
          .allow('')
          .allow(null)
          .optional(),
        name: Joi.string()
          .allow('')
          .allow(null)
          .optional(),
        aCRA: Joi.string()
          .allow('')
          .allow(null)
          .optional(),
        type: Joi.string()
          .allow('')
          .allow(null)
          .optional(),
        country: Joi.string()
          .allow(null)
          .allow('')
          .optional(),
        share: Joi.string()
          .allow(null)
          .allow('')
          .optional(),
        parentUEN: Joi.string()
          .allow(null)
          .allow('')
          .optional(),
        turnover: Joi.string()
          .allow(null)
          .allow('')
          .optional(),
        noOfStaff: Joi.string()
          .allow(null)
          .allow('')
          .optional()
      })
    ),
    subsidiaries: Joi.array().items(
      Joi.object({
        subsidLevel: Joi.string()
          .allow(null)
          .allow('')
          .optional(),
        name: Joi.string()
          .allow(null)
          .allow('')
          .optional(),
        sharePercent: Joi.string()
          .allow(null)
          .allow('')
          .optional(),
        noStaff: Joi.string()
          .allow(null)
          .allow('')
          .optional(),
        UEN: Joi.string()
          .allow(null)
          .allow('')
          .optional()
      })
    ),
    invStockFinancing: Joi.number()
      .allow(null)
      .optional(),
    workingCapital: Joi.number()
      .allow(null)
      .optional(),
    aRDiscount: Joi.number()
      .allow(null)
      .optional(),
    capitalLoan: Joi.number()
      .allow(null)
      .optional(),
    bankerGuarantee: Joi.number()
      .allow(null)
      .optional(),
    total: Joi.number().allow(null),
    loanDomesticTrade1: Joi.number().allow(null),
    loanDomesticTrade2: Joi.number().allow(null),
    invStockFinancingChecked: Joi.boolean().allow(null),
    workingCapitalChecked: Joi.boolean().allow(null),
    aRDiscountChecked: Joi.boolean().allow(null),
    capitalLoanChecked: Joi.boolean().allow(null),
    bankerGuaranteeChecked: Joi.boolean().allow(null),
    purposeOfLoan: Joi.string()
      .allow(null)
      .allow('')
      .optional()
  })
});

export const createAdverseInfo = Joi.object().keys({
  adverseInfo: Joi.object().keys({
    adverseStatus: Joi.string()
      .allow('')
      .optional(),
    additionalInfo: Joi.string()
      .allow('')
      .optional(),
    overdue: Joi.string()
      .allow('')
      .optional(),
    overdueDate: Joi.date()
      .allow(null)
      .optional(),
    listOfOverdue: Joi.boolean(),
    repaymentPlanAttached: Joi.boolean()
  })
});

// export const searchLoanPayload = Joi.object().keys({

//   marshRefNo: Joi.string().allow("").allow(null).optional(),
//   borrowerName: Joi.string().allow("").allow(null).optional(),
//   uenNumber: Joi.string().allow("").allow(null).optional(),
//   pfiCode: Joi.array().allow(null).optional(),
//   consortium: Joi.string().allow("").allow(null).optional(),
//   adverseStatus: Joi.string().allow("").allow(null).optional(),
//   typeOfDate: Joi.string().allow("").allow(null).optional(),
//   fromDate: Joi.any().allow("").allow(null).optional(),
//   toDate: Joi.any().allow("").allow(null).optional(),
//   natureOfApplication: Joi.array().allow(null).allow("").optional(),
//   marshLoanApplicationStatus: Joi.array().allow(null).allow("").optional(),
//   excludeExpiredApplications: Joi.boolean().allow("").allow(null).optional(),
//   app: Joi.array().allow(null).optional(),
// });

export const jwtValidator = Joi.object({
  authorization: Joi.string().required()
}).unknown();
