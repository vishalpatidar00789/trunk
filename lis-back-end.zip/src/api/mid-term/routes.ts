import * as Hapi from 'hapi';
import * as Joi from 'joi';
import MidTermController from './mid-term-controller';
import { MidTermModel } from './mid-term';
import * as MidTermValidator from './mid-term-validator';
import { IDatabase } from '../../database';
import { IServerConfigurations } from '../../configurations';
import LoanService from '../../services/loan-service';
import ConfigurationService from '../../services/configuration-service';
import EmailService from '../../services/email-service';

export default function(
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase,
  emailService: EmailService
) {
  const configService = new ConfigurationService(serverConfigs, database);
  const loanService = new LoanService(
    serverConfigs,
    database,
    server,
    configService
  );
  const midTermController = new MidTermController(
    serverConfigs,
    database,
    loanService,
    emailService
  );
  server.bind(midTermController);

  server.route({
    method: 'GET',
    path: '/mid-term/info',
    options: {
      handler: midTermController.infoMidTerm,
      //auth: "jwt",
      tags: ['api', 'mid-term'],
      description: 'Get Mid Term info.',
      validate: {
        headers: MidTermValidator.jwtValidator
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Mid Term founded.'
            },
            '401': {
              description: 'Please login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'GET',
    path: '/mid-term/{id}',
    options: {
      handler: midTermController.getMidTerm,
      auth: false,
      tags: ['api', 'mid-term'],
      description: 'Get mid term by id.',
      validate: {
        // headers: MidTermValidator.jwtValidator
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Mid Term founded.'
            },
            '401': {
              description: 'Please login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'DELETE',
    path: '/mid-term',
    options: {
      handler: midTermController.deleteMidTerm,
      //auth: "jwt",
      tags: ['api', 'mid-term'],
      description: 'Delete current Mid Term.',
      validate: {
        headers: MidTermValidator.jwtValidator
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Mid Term deleted.'
            },
            '401': {
              description: 'User does not have authorization.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'PUT',
    path: '/mid-term/submit/{id}',
    options: {
      handler: midTermController.updateMidTerm,
      auth: 'jwt',
      tags: ['api', 'mid-term'],
      description: 'Update current mid-term info.',
      validate: {
        payload: MidTermValidator.createMidTermModel,
        headers: MidTermValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Updated Mid-Term info.'
            },
            '401': {
              description: 'User does not have authorization.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/mid-term',
    options: {
      handler: midTermController.createMidTerm,
      auth: 'jwt',
      tags: ['api', 'mid-term'],
      description: 'Create a Mid Term.',
      validate: {
        payload: MidTermValidator.createMidTermModel
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '201': {
              description: 'Mid Term created.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'PUT',
    path: '/mid-term/adverseInfo/{id}',
    options: {
      handler: midTermController.updateMidTermAdverseInfo,
      auth: 'jwt',
      tags: ['api', 'loan'],
      description: 'Update loan adverse info.',
      validate: {
        payload: MidTermValidator.createAdverseInfo,
        headers: MidTermValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Updated Loan adverse info.'
            },
            '401': {
              description: 'User does not have authorization.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'PUT',
    path: '/mid-term/saveAsDraft/{id}',
    options: {
      handler: midTermController.saveAsDraft,
      auth: false,
      tags: ['api', 'mid-term'],
      description: 'Update current mid term info.',
      validate: {
        //payload: MidTermValidator.createMidTermModel,
        //headers: MidTermValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Updated Mid Term info.'
            },
            '401': {
              description: 'User does not have authorization.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/mid-term/dlValidation',
    options: {
      handler: midTermController.dlValidation,
      //auth: "jwt",
      auth: false,
      tags: ['api', 'mid-term'],
      description: 'DL validation for Mid-Term applications.',
      validate: {
        payload: MidTermValidator.createMidTermModel
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'DL validation for Loan applications.'
            },
            '401': {
              description: 'Please Login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/mid-term/bgValidation',
    options: {
      handler: midTermController.bgValidation,
      //auth: "jwt",
      auth: false,
      tags: ['api', 'mid-term'],
      description: 'BG validation for Mid-term applications.',
      validate: {
        payload: MidTermValidator.createMidTermModel
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'BG validation for Mid-term applications.'
            },
            '401': {
              description: 'Please Login.'
            }
          }
        }
      }
    }
  });
}
