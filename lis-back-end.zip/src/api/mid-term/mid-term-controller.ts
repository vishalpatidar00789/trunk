import * as Hapi from 'hapi';
import * as Boom from 'boom';
import * as Jwt from 'jsonwebtoken';
import { IMidTerm } from './mid-term';
import { IDatabase } from '../../database';
import { IServerConfigurations } from '../../configurations';
import { IRequest, ILoginRequest, IMailOptions } from '../../interfaces/request';
import { getHeapSpaceStatistics } from 'v8';
import { IApp } from '../master-data/app-management/app-management';
import { ILimit } from '../master-data/consortium/limit-management/limit';
import LoanService from '../../services/loan-service';
import EmailService from '../../services/email-service';

export default class MidTermController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  private service: Hapi.Server;


  constructor(configs: IServerConfigurations, database: IDatabase, private loanService: LoanService, private emailService: EmailService) {
    this.database = database;
    this.configs = configs;

  }

  public async createMidTerm(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      const userId = request.auth.credentials.id;
      let requestPayload: any = request['payload'];
      let app = await this.getCurrentApp();
      requestPayload['app'] = app;
      requestPayload['createdBy'] = userId;
      requestPayload['createdDate'] = new Date();
      requestPayload["typeOfRequest"] = "midterm";
      let midTerm: any = await this.database.midTermModel.create(requestPayload);
      return h.response({ _id: midTerm._id, status: midTerm.status }).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async dlValidation(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let requestPayload: any = request['payload'];
      let loanType = "MIDTERM";
      let isDLValid = await this.loanService.validation_DL(requestPayload, loanType);
      console.log('isDLValid::' + isDLValid);
      if (isDLValid) {
        return true;
      } else {
        return false;
      }
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async bgValidation(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let requestPayload: any = request['payload'];
      let loanType = "MIDTERM";
      let isBGValid = await this.loanService.validation_BG(requestPayload, loanType);
      console.log('isBGValid::' + isBGValid);
      return { message: isBGValid };
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateMidTerm(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params['id'];

    try {
      const userId = request.auth.credentials.id;
      let requestPayload: any = request['payload'];
      // let app = await this.getCurrentApp();
      // requestPayload['app'] = app;
      // let bankCd = requestPayload['creditInfo']['pfiCode'];
      // console.log("bankCd::" + bankCd);
      // let marshRefNo = await this.generateMarshReferenceNumber(bankCd);
      // requestPayload['marshRefNo'] = marshRefNo;
      // console.log('######' + marshRefNo + '######');

      //requestPayload["marshRefNo"] = "abc123";

      let midTerm: IMidTerm = await this.database.midTermModel.findByIdAndUpdate(
        { _id: id },
        { $set: requestPayload },
        { new: true }
      );
      if (midTerm) {
        this.sendAcknowledmentMail(midTerm, userId);
        return midTerm;
      } else {
        return Boom.badData("Internal Server Error While Saving Loan.");
      }
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  private sendAcknowledmentMail(loan: IMidTerm, userId: string) {
    let createdDate = null;
    let m = null;
    let d = null;
    let y = null;

    if (loan['createdDate']) {
      let date1 = loan['createdDate'].toString().substr(4, 11);
      m = date1.substr(0, 3);
      d = date1.substr(4, 2);
      y = date1.substr(7, 4);
    }

    let pfiName = loan['creditInfo']['pfiName'];
    let regComName = loan['sponsorForm']['regComName'];
    let ACRANo = loan['sponsorForm']['ACRANo'];
    let midTermMarshRefNo = loan['marshRefNo'];
    let loanMarshNo = loan[''];

    let typeOfRequest: string;
    if (loan['isMidTermIncrease'] === true) {
      typeOfRequest = 'Mid Term/Temp Increase';
    } else {
      typeOfRequest = 'Mid Term/Temp Decrease';
    }

    //TO PFI USER
    let emailOptions = new IMailOptions();
    emailOptions.from = this.configs.systemEmail;
    emailOptions.to = userId;
    emailOptions.subject = `QA- Acknowledgement for Mid-term/Temp Request Submission- ${regComName} - ${midTermMarshRefNo}`;
    emailOptions.html = `Dear ${userId} <br><br>
                      This is an acknowledgement email for your Mid-term/Temp request submission over  Loan application ${loanMarshNo} in Marsh's Loan Insurance Scheme Portal. Please find the details below: <br>
                      Marsh Reference number:   ${midTermMarshRefNo}<br>
                      Marsh Submission Date:    ${d} ${m} ${y}<br>
                      PFI Name:                 ${pfiName}<br>
                      Registered Company Name:  ${regComName}<br>
                      UEN no:                   ${ACRANo}<br>
                      Type of Request:          ${typeOfRequest}<br>
                      <br><br>
                      Disclaimer: Users can submit applications and track the status of requests at any time, but processing of applications would only be during regular business hours from 8.30 AM to 5.30 PM, Monday – Friday.
                      Note: This is an automated email sent from Marsh's Loan Insurance Scheme Portal. Please do not reply to this email.`;

    this.emailService.sendEmail(emailOptions);

    //TO MARSH USER
    let emailOptions2 = new IMailOptions();
    emailOptions2.from = this.configs.systemEmail;
    emailOptions2.to = 'Upendra.Krishtam01@marsh.com';
    emailOptions2.subject = `QA- Acknowledgement for Mid-term/Temp Request Submission- ${regComName} - ${midTermMarshRefNo}`;
    emailOptions2.html = `Dear Marsh Users <br><br>
                      A Mid-term/Temp request over loan application ${loanMarshNo} has been submitted in Marsh's Loan Insurance Scheme Portal. Please find the details below: <br>
                      Marsh Reference number:    ${midTermMarshRefNo}<br>
                      Marsh Submission Date:     ${d} ${m} ${y}<br>
                      PFI Name:                  ${pfiName}<br>
                      Registered Company Name:   ${regComName}<br>
                      UEN no:                    ${ACRANo}<br>
                      Type of Request:           ${typeOfRequest}<br>
                      <br><br>
                      Note: This is an automated email sent from Marsh's Loan Insurance Scheme Portal. Please do not reply to this email.`;

    this.emailService.sendEmail(emailOptions2);
  }

  public async deleteMidTerm(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.auth.credentials.id;
    let midTerm: IMidTerm = await this.database.midTermModel.findByIdAndRemove(id).lean(true);
    delete midTerm["typeOfRequest"];
    return midTerm;
  }

  public async infoMidTerm(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.auth.credentials.id;
    let midTerm: IMidTerm = await this.database.midTermModel.findById(id).lean(true);
    delete midTerm["typeOfRequest"];
    return midTerm;
  }

  public async getMidTerm(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params['id'];
    try {
      let midTerm: IMidTerm = await this.database.midTermModel.findById(id).lean(true);
      if (midTerm) {
        delete midTerm["typeOfRequest"];
        return midTerm;
      } else {
        return Boom.notFound();
      }
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async saveAsDraft(request: IRequest, h: Hapi.ResponseToolkit) {
    console.log(JSON.stringify(request.params.id));
    const id = request.params.id;

    let requestPayload: any = request['payload'];
    // let app = await this.getCurrentApp();
    // requestPayload['app'] = app;

    try {
      let loan: IMidTerm = await this.database.midTermModel.findByIdAndUpdate(
        id,
        { $set: requestPayload },
        { new: true }
      );
      return loan;
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  // public async searchLoan(request: IRequest, h: Hapi.ResponseToolkit) {
  //   let requestPayload: any = request['payload'];
  //   let query: any = {};

  //   console.log(requestPayload);

  //   const pfiCode: string[] = requestPayload.pfiCode;

  //   // if (typeof pfiCode !== 'undefined') {
  //   //   if (pfiCode.length === 1) {
  //   //     if (pfiCode.some(pfi => pfi !== 'UOB')) {
  //   //       console.log("PFI USER");
  //   //       query = this.buildPfiQuery(requestPayload);
  //   //     } else {
  //   //       console.log("UOB USER");
  //   //       query = this.buildUobQuery(requestPayload);
  //   //     }
  //   //   } else {
  //   //     console.log("MARSH USER");
  //   //     query = this.buildMarshQuery(requestPayload);
  //   //   }
  //   // } else {
  //   //   console.log("Please select the pfi");
  //   // }

  //   query = this.buildQuery(requestPayload);
  //   let loan: ILoan[] = await this.database.loanModel.find(query).sort({"creditInfo.submissionDate": -1});

  //   return loan;
  // }

  buildQuery(requestPayload: any) {
    console.log('Building Query');
    const marshReferenceNumber: string = requestPayload.marshRefNo;
    const borrowerName = requestPayload.borrowerName;
    const uenNumber = requestPayload.uenNumber;
    const pfiCode: string[] = requestPayload.pfiCode;
    const consortium = requestPayload.consortium;
    const adverseStatus = requestPayload.adverseStatus;
    const typeOfDate = requestPayload.typeOfDate;
    const selectedFromDate: any = requestPayload.fromDate;
    const selectedToDate: any = requestPayload.toDate;
    let splittedCurrentDate = new Date().toISOString().split('T');
    let currentDateISO = new Date(splittedCurrentDate[0]);
    let fromDate;
    let toDate;
    if (typeof selectedFromDate !== 'undefined') {
      let splittedFromDate = selectedFromDate.split('T');
      fromDate = new Date(splittedFromDate[0]);
      console.log('fromDate ' + fromDate);
    }
    if (typeof selectedToDate !== 'undefined') {
      let splittedToDate = selectedToDate.split('T');
      console.log('splittedToDate ' + (splittedToDate[0] + 'T23:59:59.000Z'));
      toDate = new Date(splittedToDate[0] + 'T23:59:59.000Z');
      // toDate = new Date(splittedToDate[0]);
      console.log('toDate ' + toDate);
    }
    const natureOfApplication: string[] = requestPayload.natureOfApplication;
    const marshLoanApplicationStatus: string[] =
      requestPayload.marshLoanApplicationStatus;
    const excludeExpiredApplications =
      requestPayload.excludeExpiredApplications;
    const app: any[] = requestPayload.app;
    let query: any = {};
    let selectedDate: string;

    switch (typeOfDate) {
      case 'Marsh Submission Date':
        selectedDate = 'createdAt';
        break;

      case 'COFANET Submission Date':
        selectedDate = 'creditInfo.submissionDate';
        break;

      case 'LO Acceptance Date':
        selectedDate = 'additionalInfo.loAcceptanceDate';
        break;

      case 'Loan Expiry Date':
        selectedDate = 'additionalInfo.loanExpiryDateFromLoAcceptanceDate';
        break;

      default:
        selectedDate = 'creditInfo.submissionDate';
    }
    console.log('Selected date type :' + selectedDate);
    if (
      typeof marshReferenceNumber !== 'undefined' &&
      marshReferenceNumber !== '' &&
      marshReferenceNumber !== '*' &&
      marshReferenceNumber !== '**'
    ) {
      let marshReferenceRegex = marshReferenceNumber;
      if (
        marshReferenceNumber.includes('*') ||
        marshReferenceNumber.includes('?') ||
        marshReferenceNumber.includes('%')
      ) {
        if (marshReferenceNumber.includes('.')) {
          marshReferenceRegex = marshReferenceNumber.split('.').join('\\.');
        }
        // let marshReferenceRegex = marshReferenceNumber.replace('//*/g', '.*');
        marshReferenceRegex = marshReferenceRegex.split('%').join('*');
        marshReferenceRegex = marshReferenceRegex.split('*').join('.*');
        marshReferenceRegex = marshReferenceRegex.split('?').join('.?');
        query['marshRefNo'] = {
          $regex: '^' + marshReferenceRegex + '$',
          $options: 's'
        };
      } else {
        query['marshRefNo'] = marshReferenceNumber;
      }
    }
    if (
      typeof borrowerName !== 'undefined' &&
      borrowerName !== '' &&
      borrowerName !== '*' &&
      borrowerName !== '**'
    ) {
      let borrowerNameRegex = borrowerName;
      if (
        borrowerName.includes('*') ||
        borrowerName.includes('?') ||
        borrowerName.includes('%')
      ) {
        if (borrowerName.includes('.')) {
          borrowerNameRegex = borrowerName.split('.').join('\\.');
        }
        borrowerNameRegex = borrowerNameRegex.split('%').join('*');
        borrowerNameRegex = borrowerNameRegex.split('*').join('.*');
        borrowerNameRegex = borrowerNameRegex.split('?').join('.?');
        query['sponsorForm.regComName'] = {
          $regex: '^' + borrowerNameRegex + '$',
          $options: 's'
        };
      } else {
        query['sponsorForm.regComName'] = borrowerName;
      }
    }
    if (
      typeof uenNumber !== 'undefined' &&
      uenNumber !== '' &&
      uenNumber !== '*' &&
      uenNumber !== '**'
    ) {
      let uenNumberRegex = uenNumber;
      if (
        uenNumber.includes('*') ||
        uenNumber.includes('?') ||
        uenNumber.includes('%')
      ) {
        if (uenNumber.includes('.')) {
          uenNumberRegex = uenNumber.split('.').join('\\.');
        }
        uenNumberRegex = uenNumberRegex.split('%').join('*');
        uenNumberRegex = uenNumberRegex.split('*').join('.*');
        uenNumberRegex = uenNumberRegex.split('?').join('.?');
        query['sponsorForm.ACRANo'] = {
          $regex: '^' + uenNumberRegex + '$',
          $options: 's'
        };
      } else {
        query['sponsorForm.ACRANo'] = uenNumber;
      }
    }
    if (typeof pfiCode !== 'undefined') {
      query['creditInfo.pfiCode'] = { $in: pfiCode };
    }
    if (typeof consortium !== 'undefined' && consortium !== '') {
      query['consortium'] = consortium;
    }
    if (
      typeof adverseStatus !== 'undefined' &&
      adverseStatus !== '' &&
      adverseStatus !== 'All'
    ) {
      query['adverseInfo.adverseStatus'] = adverseStatus;
    }
    // if (typeof adverseStatus !== 'undefined' && adverseStatus !== '' && adverseStatus === "All") {
    //   query["adverseInfo.adverseStatus"] = { $in: ["Yes", "No"] };
    // }
    if (
      typeof fromDate !== 'undefined' &&
      (typeof toDate === 'undefined' || toDate === null)
    ) {
      query[selectedDate] = { $gte: fromDate };
    }
    if (
      typeof toDate !== 'undefined' &&
      (typeof fromDate === 'undefined' || fromDate === null)
    ) {
      query[selectedDate] = { $lte: toDate };
    }
    if (typeof fromDate !== 'undefined' && typeof toDate !== 'undefined') {
      query[selectedDate] = { $gte: fromDate, $lte: toDate };
    }
    if (
      typeof natureOfApplication !== 'undefined' &&
      natureOfApplication.length > 0
    ) {
      query['additionalInfo.natureofApplication'] = {
        $in: natureOfApplication
      };
    }
    if (
      typeof marshLoanApplicationStatus !== 'undefined' &&
      marshLoanApplicationStatus.length > 0
    ) {
      query['status'] = { $in: marshLoanApplicationStatus };
    }
    if (
      excludeExpiredApplications === true &&
      selectedDate !== 'additionalInfo.loanExpiryDateFromLoAcceptanceDate'
    ) {
      query['additionalInfo.loanExpiryDateFromLoAcceptanceDate'] = {
        $gte: currentDateISO
      };
    }
    if (
      excludeExpiredApplications === true &&
      selectedDate === 'additionalInfo.loanExpiryDateFromLoAcceptanceDate'
    ) {
      let fromLoanExpiryDate = fromDate;
      let toLoanExpiryDate = toDate;

      if (
        typeof fromDate !== 'undefined' &&
        fromLoanExpiryDate <= currentDateISO
      ) {
        fromLoanExpiryDate = currentDateISO;
        console.log('fromLoanExpiryDate ' + fromLoanExpiryDate);
      }
      if (typeof toDate !== 'undefined' && currentDateISO >= toLoanExpiryDate) {
        fromLoanExpiryDate = currentDateISO;
        toLoanExpiryDate = currentDateISO;
        console.log('toLoanExpiryDate ' + toLoanExpiryDate);
      }
      if (
        typeof fromLoanExpiryDate !== 'undefined' &&
        (typeof toLoanExpiryDate === 'undefined' || toLoanExpiryDate === null)
      ) {
        query[selectedDate] = { $gte: fromLoanExpiryDate };
      }
      if (
        typeof toLoanExpiryDate !== 'undefined' &&
        (typeof fromLoanExpiryDate === 'undefined' ||
          fromLoanExpiryDate === null)
      ) {
        query[selectedDate] = { $lte: toLoanExpiryDate };
      }
      if (
        typeof fromLoanExpiryDate !== 'undefined' &&
        typeof toLoanExpiryDate !== 'undefined'
      ) {
        console.log('Both dates seleted');
        query[selectedDate] = {
          $gte: new Date(fromLoanExpiryDate),
          $lte: new Date(toLoanExpiryDate)
        };
      }
      // if((fromDate <= currentDate) && (toDate <= currentDate)) {
      //   query["additionalInfo.loanExpiryDateFromLoAcceptanceDate"] = { "$gte": new Date(fromDate), "$lte": new Date(toDate), "$lte": new Date() } ;
      // }
    }
    if (typeof app !== 'undefined' && app.length > 0) {
      query['app'] = { $in: app };
    }

    console.log(JSON.stringify(query));
    return query;
  }

  public async updateMidTermAdverseInfo(request: IRequest, h: Hapi.ResponseToolkit) {
    let id = request.params['id'];
    try {
      let requestPayload: any = request['payload'];
      console.log('id', id);
      let loan: IMidTerm = await this.database.midTermModel.findByIdAndUpdate(
        { _id: id },
        { $set: requestPayload },
        { new: true }
      );
      if (loan) {
        //this.sendAdverseInformationAcknowledgmentMail(loan);
        return { message: 'success' };
      } else {
        return Boom.badData("Internal Server Error While Saving Adverse Information.");
      }
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  private sendAdverseInformationAcknowledgmentMail(loan: IMidTerm) {
    let date1 = loan['createdDate'].toString().substr(4, 11);
    let m = date1.substr(0, 3);
    let d = date1.substr(4, 2);
    let y = date1.substr(7, 4);

    let pfiName = loan['creditInfo']['pfiName'];
    let regComName = loan['sponsorForm']['regComName'];
    let uenNo = loan['sponsorForm']['ACRANo'];
    let marshRefNo = loan['marshRefNo'];

    let emailOptions = new IMailOptions();
    emailOptions.from = this.configs.systemEmail;
    emailOptions.to = 'Upendra.Krishtam01@marsh.com';
    emailOptions.subject = `QA- Adverse Information entered by ${pfiName} for - ${regComName} ${marshRefNo}`;
    emailOptions.html = `Dear Marsh Users<br><br>
                      Adverse information has been entered for application ${marshRefNo} in Marsh's Loan Insurance Scheme Portal. Please find the details below:<br>
                      Marsh Submission Date:     ${d} ${m} ${y}<br>
                      PFI Name:                  ${pfiName}<br>
                      Registered Company Name:   ${regComName}<br>
                      UEN no:                    ${uenNo}<br>
                      <br><br>
                      Note: This is an automated email sent from Marsh's Loan Insurance Scheme Portal.  Please do not reply to this email.`;
    this.emailService.sendEmail(emailOptions);
  }

  private async getCurrentApp() {
    let appManagement: IApp = await this.database.appModel.findOne({
      activated: true
    });
    return appManagement.app;
  }

  private async validation_DL(requestPayload) {
    let isDLFail: boolean = true;
    let currentAmount = requestPayload.creditInfo.appliedAmountDL;
    let limitDL: ILimit = await this.database.limitModel.findOne(
      { activated: true, applicationType: 'Discretionary limit' },
      { maximumLimit: 1, _id: 0 }
    );

    console.log('limitDL:' + limitDL.maximumLimit);
    let loan_applied: any = await this.database.loanModel.aggregate([
      {
        $match: {
          'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
          'creditInfo.consortium': requestPayload.creditInfo.consortium,
          status: 'Processing'
        }
      },
      {
        $group: {
          _id: null,
          total: {
            $sum: '$creditInfo.appliedAmountDL'
          }
        }
      }
    ]);

    // to do - add loan expiry date in query
    // console.log('loan_applied_DL:' + loan_applied[0].total);
    console.log(loan_applied);
    let loan_approved: any = await this.database.loanModel.aggregate([
      {
        $match: {
          'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
          'creditInfo.consortium': requestPayload.creditInfo.consortium,
          status: 'Answered'
        }
      },
      {
        $group: {
          _id: null,
          total: {
            $sum: '$creditInfo.primary'
          }
        }
      }
    ]);
    console.log(loan_approved);
    if (loan_approved.length > 0 && loan_applied.length > 0) {
      let totalAmount =
        loan_applied[0].total + loan_approved[0].total + currentAmount;

      if (totalAmount > limitDL.maximumLimit) {
        isDLFail = false;
      } else {
        isDLFail = true;
      }
    } else if (loan_applied.length > 0) {
      let totalAmount = loan_applied[0].total + currentAmount;
      if (totalAmount > limitDL.maximumLimit) {
        isDLFail = false;
      } else {
        isDLFail = true;
      }
    } else if (loan_approved.length > 0) {
      console.log('case3');

      let totalAmount = loan_approved[0].total + currentAmount;

      if (totalAmount > limitDL.maximumLimit) {
        isDLFail = false;
      } else {
        isDLFail = true;
      }
    } else {
      console.log('case4');
      let totalAmount = currentAmount;

      if (totalAmount > limitDL.maximumLimit) {
        isDLFail = false;
      } else {
        isDLFail = true;
      }
    }
    return isDLFail;
  }

  private async validation_BG(requestPayload) {
    let limitBG: ILimit = await this.database.limitModel.findOne(
      { activated: true, applicationType: 'Bankers Guarantee' },
      { maximumLimit: 1, _id: 0 }
    );
    console.log('limitBG::' + limitBG.maximumLimit);
    let appliedAmount = requestPayload.creditInfo.appliedAmountDL;
    let currentBG = requestPayload.creditInfo.bankersGuaranteeTxt;

    console.log('currentBG::' + currentBG);
    console.log('appliedAmount ::' + appliedAmount);
    console.log('appliedAmount2 ::' + appliedAmount / 2);

    if (currentBG <= appliedAmount / 2) {
      let bg_applied: any = await this.database.loanModel.aggregate([
        {
          $match: {
            'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
            'creditInfo.consortium': requestPayload.creditInfo.consortium,
            status: 'Processing'
          }
        },
        {
          $group: {
            _id: null,
            total: {
              $sum: '$creditInfo.bankersGuaranteeTxt'
            }
          }
        }
      ]);
      // to do - add loan expiry date in query
      //console.log('bg_applied::' + bg_applied[0].total);
      let bg_approved: any = await this.database.loanModel.aggregate([
        {
          $match: {
            'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
            'creditInfo.consortium': requestPayload.creditInfo.consortium,
            status: 'Answered'
          }
        },
        {
          $group: {
            _id: null,
            total: {
              $sum: '$creditInfo.bg'
            }
          }
        }
      ]);
      if (bg_approved.length > 0 && bg_applied.length > 0) {
        console.log('bg_approved::' + bg_approved[0].total);
        console.log('bg_applied::' + bg_applied[0].total);
        console.log('currentBG::' + currentBG);
        console.log(
          'total BG::' + bg_approved[0].total + bg_applied[0].total + currentBG
        );

        if ((bg_approved[0].total + bg_applied[0].total + currentBG) > limitBG.maximumLimit
        ) {
          return 'BG2V_Fail';
        } else {
          return 'BG2V_PASS';
        }
      } else if (bg_approved.length > 0) {
        console.log('bg_approved::' + bg_approved[0].total);
        console.log('currentBG::' + currentBG);
        console.log('total BG::' + (bg_approved[0].total + currentBG));
        if ((bg_approved[0].total + currentBG) > limitBG.maximumLimit) {
          return 'BG2V_Fail';
        } else {
          return 'BG2V_PASS';
        }
      } else if (bg_applied.length > 0) {
        console.log('bg_applied::' + bg_applied[0].total);
        console.log('currentBG::' + currentBG);
        console.log('total BG::' + (bg_applied[0].total + currentBG));

        if ((bg_applied[0].total + currentBG) > limitBG.maximumLimit) {
          return 'BG2V_Fail';
        } else {
          return 'BG2V_PASS';
        }
      } else {
        console.log('currentBG::' + currentBG);
        if (currentBG > limitBG.maximumLimit) {
          return 'BG2V_Fail';
        } else {
          return 'BG2V_PASS';
        }
      }
    } else {
      return 'BG1V_Fail';
    }
  }
}

// public getCurrentApp() {
//  let appManagement: IApp = await this.database.appModel.find({"activated": true});
//  return app.app;
//  }
