import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IDatabase } from "../../database";
import { IServerConfigurations } from "../../configurations";
import { IRequest, FileMetaData, IGridFsFile, IFilesByDocTypeAndRefId, IMailOptions } from "../../interfaces/request";
import * as Path from "path";
import DocumentService from "../../services/document-service";
import EmailService from "../../services/email-service";
import { ILoan } from "../loan/loan";
import { IMidTerm } from "../mid-term/mid-term";
import { IAdhoc } from "../adhoc/adhoc";
import { Collection } from "mongoose";
import { file } from "nconf";
//let sleep = require('thread-sleep');
let async = require("async");


export default class FileUploadController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  private docService: DocumentService;
  constructor(configs: IServerConfigurations, database: IDatabase, docService: DocumentService, private emailService: EmailService) {
    this.docService = docService;
    this.database = database;
    this.configs = configs;
  }

  public async uploadDocument(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      var file = [request.payload["uploads"]];
      //var today = new Date().getTime();
      //var fileName = file[0].hapi.filename + '_' + today;
      var fileName = request.payload["fileName"];
      var contentType = file[0].hapi.headers.content_type;
      var fileData = file[0]._data;
      let fileMetaData: FileMetaData = new FileMetaData();
      fileMetaData.contentType = contentType;
      fileMetaData.file = fileData;
      fileMetaData.fileName = fileName;
      fileMetaData.refAppId = request.params["refAppId"];
      fileMetaData.collectionName = request.payload["collection"];
      fileMetaData.documentType = request.payload["documentType"];
      fileMetaData.uploadedBy = request.payload["uploadedBy"];
      let uploadedFile = await this.docService.uploadFile(fileMetaData);
      if (uploadedFile) {
        this.sendEmail(uploadedFile);
        return uploadedFile;
      } else {
        return Boom.badData("Internal Server Error While uploading Document.");
      }
    } catch (err) {
      console.log(err);
      return Boom.badImplementation("Internal server error. Please contact admin.");
    }
  }

  private async sendEmail(uploadedFile) {
    let id = uploadedFile.metadata.refAppId;
    let collectionName = uploadedFile.metadata.collection;
    let dateOfUpload = uploadedFile.uploadDate.toString().substr(4, 11);

    let pfiName;
    let regComName;
    let uenNo;
    let marshRefNo;
    let applicationTxt;
    let status;

    if (collectionName === 'LOAN') {
      let loan: ILoan = await this.database.loanModel.findById(id).lean(true);
      pfiName = loan['creditInfo']['pfiName'];
      regComName = loan['sponsorForm']['regComName'];
      uenNo = loan['sponsorForm']['ACRANo'];
      marshRefNo = loan['marshRefNo'];
      applicationTxt = 'Loan';
      status = loan['status'];
    } else if (collectionName === 'ADHOC') {
      let adhoc: IAdhoc = await this.database.adhocModel.findById(id).lean(true);
      pfiName = adhoc['creditInfo']['pfiName'];
      regComName = adhoc['sponsorForm']['regComName'];
      uenNo = adhoc['sponsorForm']['ACRANo'];
      marshRefNo = adhoc['loanMarshRefNo'];
      applicationTxt = 'Adhoc';
      status = adhoc['status'];
    } else if (collectionName === 'MIDTERM') {
      let midTerm: IMidTerm = await this.database.midTermModel.findById(id).lean(true);
      pfiName = midTerm['creditInfo']['pfiName'];
      regComName = midTerm['sponsorForm']['regComName'];
      uenNo = midTerm['sponsorForm']['ACRANo'];
      marshRefNo = midTerm['marshRefNo'];
      applicationTxt = 'Mid-term/Temp';
      status = midTerm['status'];
    } else if (collectionName === 'CLAIM') {
      let claim = await this.database.claimModel.findById(id).lean(true);
      pfiName = claim['pfiName'];
      regComName = claim['regCompanyName'];
      uenNo = claim['uen'];
      marshRefNo = claim['marshRefNo'];
      applicationTxt = 'Claim';
      status = claim['status'];
    }

    if (status === 'Draft') {
      return;
    }
    console.log('STATUS##', status);
    console.log('FILE UPLOAD', pfiName, regComName, uenNo, marshRefNo);
    console.log('SYSTEM::', this.configs.systemEmail);
    if (uploadedFile.documentType === 'LO Acceptance') {
      this.sendLOAcceptanceAcknowledgmentMail(pfiName, regComName, marshRefNo, dateOfUpload, uenNo, applicationTxt);
    } else {
      this.sendAdditionalInfoAcknowledgmentMail(pfiName, regComName, marshRefNo, dateOfUpload, uenNo, applicationTxt);
    }
  }

  private sendLOAcceptanceAcknowledgmentMail(pfiName, regComName, marshRefNo, dateOfUpload, uenNo, applicationTxt) {
    let m = dateOfUpload.substr(0, 3);
    let d = dateOfUpload.substr(4, 2);
    let y = dateOfUpload.substr(7, 4);
    console.log('D M Y', d, m, y);

    let emailOptions = new IMailOptions();
    emailOptions.from = this.configs.systemEmail;
    emailOptions.to = 'Upendra.Krishtam01@marsh.com;Amit.Kumar02@marsh.com';
    emailOptions.subject = `QA - LO Acceptance form uploaded by ${pfiName} for - ${regComName} ${marshRefNo}`;
    emailOptions.html = `Dear Marsh Users<br><br>
                        LO Acceptance document has been uploaded for ${applicationTxt} Application  ${marshRefNo} in Marsh's Loan Insurance Scheme Portal. Please find the details below:<br>
                        PFI Name:                 ${pfiName}<br>
                        Date of Upload :          ${d} ${m} ${y}<br>
                        Registered Company Name:  ${regComName}<br>
                        UEN no:                   ${uenNo}<br>
                        <br><br>
                        Note: This is an automated email sent from Marsh's Loan Insurance Scheme Portal.  Please do not reply to this email.`;
    this.emailService.sendEmail(emailOptions);
  }

  private sendAdditionalInfoAcknowledgmentMail(pfiName, regComName, marshRefNo, dateOfUpload, uenNo, applicationTxt) {
    let m = dateOfUpload.substr(0, 3);
    let d = dateOfUpload.substr(4, 2);
    let y = dateOfUpload.substr(7, 4);
    console.log('D M Y', d, m, y);
    let emailOptions = new IMailOptions();
    emailOptions.from = this.configs.systemEmail;
    emailOptions.to = 'Upendra.Krishtam01@marsh.com;Amit.Kumar02@marsh.com';
    emailOptions.subject = `QA - Document Upload -${pfiName} for - ${regComName} ${marshRefNo}`;
    emailOptions.html = `Dear Marsh Users<br><br>
                        Additional Documents have been uploaded for ${applicationTxt} Application  ${marshRefNo} in Marsh's Loan Insurance Scheme Portal. Please find the details below:<br>
                        PFI Name:                 ${pfiName}<br>
                        Date of Upload :          ${d} ${m} ${y}<br>
                        Registered Company Name:  ${regComName}<br>
                        UEN no:                   ${uenNo}<br>
                        <br><br>
                        Note: This is an automated email sent from Marsh's Loan Insurance Scheme Portal. Please do not reply to this email.`;
    this.emailService.sendEmail(emailOptions);
  }

  public async getSupportingDocsByRefAppId(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      const refAppId = request.params.refAppId;
      let files: IGridFsFile[] = await this.docService.getSupportingDocsByRefAppId(refAppId);
      return files;
    } catch (err) {
      console.log(err); // log this into audit
      return Boom.badImplementation("Internal server error. Please contact admin.");
    }
  }

  public async getSupportingDocsByDocumentType(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      const docType = request.params.docType;
      let files: IGridFsFile[] = await this.docService.getSupportingDocsByDocType(docType);
      return files;
    } catch (err) {
      console.log(err); // log this into audit
      return Boom.badImplementation("Internal server error. Please contact admin.");
    }
  }

  public async getDocsByRefAppIdAndDocType(request: IFilesByDocTypeAndRefId, h: Hapi.ResponseToolkit) {
    try {
      let payload: any = request['payload'];
      console.log(payload);
      const docType = payload['docType'];
      const refAppId = payload['refAppId'];
      let files: IGridFsFile[] = await this.docService.getDocsByRefAppIdAndDocType(refAppId, docType);
      return files;
    } catch (err) {
      console.log(err);
      return Boom.badImplementation("Internal server error. Please contact admin.");
    }
  }

  public async removeSupportingDoc(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      const fileId = request.params.fileId;
      let msg: string = await this.docService.removeDocById(fileId);
      return msg;
    } catch (err) {
      console.log(err);
      return Boom.badImplementation("Internal server error. Please contact admin.");
    }
  }

  public async getSupportingDocByFileId(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      const fileId = request.params.fileId;
      let file: any = await this.docService.getDocById(fileId);
      if (file) {
        const response = h.response(file["fileStream"]);
        response.header("Content-Type", file["contentType"]);
        response.header("Content-Disposition", "attachment; filename=" + file["fileName"]);
        return response;
      } else {
        return Boom.notFound("No file found.");
      }
    } catch (err) {
      console.log(err); // log this into audit
      return Boom.badImplementation("Internal server error. Please contact admin.");
    }
  }

  public async validateSupportingDocumentForSubmission(request: IRequest, h: Hapi.ResponseToolkit) {
    try {

      let payload: any = request['payload'];
      console.log('PAYLOAD::--', payload);
      const documents = payload['documents'];
      const refAppId = payload['refAppId'];
      const collection = payload['collection'];
      let missingDocTypes = [];

      // documents.forEach(async element => {
      //   let files: IGridFsFile[] = await this.docService.getDocsByRefAppIdAndDocType(refAppId, element.name);
      //   if (files.length <= 0) {
      //     missingDocTypes.push(element.name);
      //   }
      // });

      for (const doc of documents) {
        let files: IGridFsFile[] = await this.docService.getDocsByRefAppIdAndDocType(refAppId, doc.name);
        if (files.length <= 0) {
          missingDocTypes.push(doc.name);
          console.log('MISSING DOC', doc.name);
        }
      }

      console.log('MISSING FILES:: ', missingDocTypes);
      return h.response({ 'missingfiles' : missingDocTypes }).code(201);

    } catch (err) {
      console.log(err);
      return Boom.badImplementation("Internal server error. Please contact admin.");
    }
  }

  private async validateDocuments(payload): Promise<any> {
    const documents = payload['documents'];
    const refAppId = payload['refAppId'];
    const collection = payload['collection'];
    let missingDocTypes = [];
    return new Promise<any>((resolve, reject) => {

      documents.forEach(async element => {
        let files: IGridFsFile[] = await this.docService.getDocsByRefAppIdAndDocType(refAppId, element.name);
        if (files.length > 0) {
        } else {
          missingDocTypes.push(element.name);
          console.log('Miss doc :: ', element.name);
        }
      });

      resolve(missingDocTypes);
    });
    // return missingDocTypes;

  }

}