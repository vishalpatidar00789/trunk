import * as Hapi from "hapi";
import * as Joi from "joi";
import FileUploadController from "./file-upload-controller";

import { jwtValidator } from "../users/user-validator";
import { IDatabase } from "../../database";
import { IServerConfigurations } from "../../configurations";
import DocumentService from "../../services/document-service";
import EmailService from "../../services/email-service";

export default function (
  server: Hapi.Server,
  configs: IServerConfigurations,
  database: IDatabase,
  emailService: EmailService
) {
  const docService = new DocumentService();
  const fileUploadController = new FileUploadController(configs, database, docService, emailService);
  server.bind(fileUploadController);

  server.route({
    method: "POST",
    path: "/supporting-documents/upload-document/{refAppId}",
    options: {
      handler: fileUploadController.uploadDocument,
      auth: false,
      tags: ["api", "supporting-documents"],
      description: "Uploaded file document.",
      payload: {
        output: "stream",
        parse: true,
        allow: "multipart/form-data",
        maxBytes: 20 * 1000 * 1000
      },
      validate: {
        params: {
          refAppId: Joi.string().required()
        }
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "Uploaded file document."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/supporting-documents/document-list/{refAppId}",
    options: {
      handler: fileUploadController.getSupportingDocsByRefAppId,
      auth: false,
      tags: ["api", "supporting-documents"],
      description: "Get all supporting documents by loan id.",
      validate: {
        params: {
          refAppId: Joi.string().required()
        }
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "list of documents fetched."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/supporting-documents/document-list-by-docType/{docType}",
    options: {
      handler: fileUploadController.getSupportingDocsByDocumentType,
      auth: false,
      tags: ["api", "supporting-documents"],
      description: "Get all supporting documents by documentType.",
      validate: {
        params: {
          docType: Joi.string().required()
        }
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "list of documents fetched."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/supporting-documents/delete-document/{fileId}",
    options: {
      handler: fileUploadController.removeSupportingDoc,
      auth: false,
      tags: ["api", "supporting-documents"],
      description: "Delete document from gridfs.",
      validate: {
        params: {
          fileId: Joi.string().required()
        }
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Document deleted."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/supporting-documents/document-by-id/{fileId}",
    options: {
      handler: fileUploadController.getSupportingDocByFileId,
      auth: false,
      tags: ["api", "supporting-documents"],
      description: "Get supporting document by file id.",
      validate: {
        params: {
          fileId: Joi.string().required()
        }
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "Supporting document fetched."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/supporting-documents/document-by-id-and-docType",
    options: {
      handler: fileUploadController.getDocsByRefAppIdAndDocType,
      auth: false,
      tags: ["api", "supporting-documents"],
      description: "Get List of Documents.",
      // validate: {
      //   payload: {
      //     refAppId: Joi.string().required(),
      //     docType: Joi.string().required()
      //   }
      // },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "Get list of Documents."
            }
          }
        }
      }
    }
  });

}