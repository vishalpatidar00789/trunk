import * as Mongoose from "mongoose";

export interface IAuthority extends Mongoose.Document {
  authority: string;
  description: string;
  createdBy: string;
  createdDate: Date;
  lastModifiedBy: string;
  lastModifiedDate: Date;
  activated: boolean;
}

export const AuthoritySchema = new Mongoose.Schema(
{
    authority: {type: String, unique: true, required: true },
    type: {type: String, required: true},
    description: { type: String, required: false },
    createdBy: { type: String, required: true },
    createdDate: { type: Date, required: true },
    lastModifiedBy: { type: String, required: false },
    lastModifiedDate: { type: Date, required: false },
    activated: { type: Boolean, required: false }
  }
);

export const AuthorityModel = Mongoose.model<IAuthority>("Authority", AuthoritySchema);
