import * as Joi from "joi";

export const createAuthorityModel = Joi.object().keys({
    authority: Joi.string().trim().required(),
    type: Joi.string().trim().required(),
    description: Joi.string().optional(),
    createdBy: Joi.string().required(),
    activated: Joi.boolean().optional(),
    createdDate: Joi.any().allow(null).optional(),
    lastModifiedBy: Joi.any().allow(null).optional(),
    lastModifiedDate: Joi.any().allow(null).optional()
});

export const jwtValidator = Joi.object({'authorization': Joi.string().required()}).unknown();