import * as Hapi from "hapi";
import * as Joi from "joi";
import BankController from "./bank-controller";
import { BankModel } from "./bank";
import * as BankValidator from "./bank-validator";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";

export default function (
    server: Hapi.Server,
    serverConfigs: IServerConfigurations,
    database: IDatabase
) {
    const bankController = new BankController(serverConfigs, database);
    server.bind(bankController);
    // routes starts from here
    server.route({
        method: "GET",
        path: "/lookup/banks",
        options: {
            handler: bankController.getAllBanks,
            auth: false,
            tags: ["api", "banks"],
            description: "Get list of all active banks",
            plugins: {
                "hapi-swagger": {
                    responses: {
                        "201": {
                            description: "active bank list is fetched"
                        }
                    }
                }
            }
        }
    });

    server.route({
        method: "GET",
        path: "/lookup/banks/{bankId}",
        options: {
            handler: bankController.getBackByCode,
            auth: false,
            tags: ["api", "banks"],
            description: "Get bank by bank code",
            validate: {
                params: {
                    bankId: Joi.string().required()
                }
            },
            plugins: {
                "hapi-swagger": {
                    responses: {
                        "201": {
                            description: "Get bank by bank code"
                        }
                    }
                }
            }
        }
    });

    server.route({
        method: "DELETE",
        path: "/lookup/banks/{bankCode}",
        options: {
            handler: bankController.deleteBank,
            auth: false,
            tags: ["api", "users"],
            description: "Delete current bank.",
            validate: {
                params: {
                    id: Joi.string().required()
                }
                // headers: BankValidator.jwtValidator
            },
            plugins: {
                "hapi-swagger": {
                    responses: {
                        "200": {
                            description: "Bank deleted."
                        },
                        "401": {
                            description: "User does not have authorization."
                        }
                    }
                }
            }
        }
    });

    server.route({
        method: "PUT",
        path: "/lookup/banks/{bankCode}",
        options: {
            handler: bankController.updateBank,
            auth: false,
            tags: ["api", "banks"],
            description: "Update current bank info.",
            validate: {
                params: {
                    bankCode: Joi.string().required()
                },
                payload: BankValidator.createBankModel
                // headers: BankValidator.jwtValidator
            },
            plugins: {
                "hapi-swagger": {
                    responses: {
                        "200": {
                            description: "Updated info."
                        },
                        "401": {
                            description: "User does not have authorization."
                        }
                    }
                }
            }
        }
    });

    server.route({
        method: "POST",
        path: "/lookup/banks",
        options: {
            handler: bankController.createBank,
            auth: false,
            tags: ["api", "banks"],
            description: "Create a bank.",
            validate: {
                // headers: BankValidator.jwtValidator,
                payload: BankValidator.createBankModel
            },
            plugins: {
                "hapi-swagger": {
                    responses: {
                        "201": {
                            description: "Bank created."
                        }
                    }
                }
            }
        }
    });
}