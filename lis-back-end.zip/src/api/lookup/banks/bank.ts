import * as Mongoose from "mongoose";

export interface IBank extends Mongoose.Document {
  bankCode: string;
  bankName: string;
  createdBy: string;
  createdDate: Date;
  lastModifiedBy: string;
  lastModifiedDate: Date;
  activated: boolean;
  // CHANGE ADDED
  registrationNumber: string;
  consortiumid: string;
}

export const BankSchema = new Mongoose.Schema(
{
    bankCode: {type: String, unique: true, required: true },
    bankName: { type: String, required: true },
    createdBy: { type: String, required: true },
    createdDate: { type: Date, required: true },
    lastModifiedBy: { type: String, required: false },
    lastModifiedDate: { type: Date, required: false },
    activated: { type: Boolean, required: false },
    registrationNumber: {type: String, required: true},
    consortiumid: {type: String, required: false}
  }
);

export const BankModel = Mongoose.model<IBank>("Bank", BankSchema);
