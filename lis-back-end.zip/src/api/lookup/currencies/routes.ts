import * as Hapi from "hapi";
import * as Joi from "joi";
import CurrenciesController from "./currencies-controller";
import { CurrenciesModel } from "./currencies";
import * as CurrenciesValidator from "./currencies-validator";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";

export default function (
    server: Hapi.Server,
    serverConfigs: IServerConfigurations,
    database: IDatabase
) {
    const currenciesController = new CurrenciesController(serverConfigs, database);
    server.bind(currenciesController);
    // routes starts from here
    server.route({
        method: "GET",
        path: "/lookup/currencies",
        options: {
            handler: currenciesController.getAllCurrencies,
            auth: false,
            description: "Get list of all currencies",
            plugins: {
                "hapi-swagger": {
                    responses: {
                        "201": {
                            description: "currencies list is fetched"
                        }
                    }
                }
            }
        }
    });
}