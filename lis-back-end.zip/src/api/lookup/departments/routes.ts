import * as Hapi from "hapi";
import * as Joi from "joi";
import DepartmentController from "./department-controller";
import { DepartmentModel } from "./department";
import * as DepartmentValidator from "./department-validator";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";

export default function(
    server: Hapi.Server,
    serverConfigs: IServerConfigurations,
    database: IDatabase
  ) {
    const departmentController = new DepartmentController(serverConfigs, database);
    server.bind(departmentController);
    // routes starts from here
    server.route({
    method: "GET",
    path: "/lookup/departments",
    options: {
        handler: departmentController.getAllDepartments,
        auth: false,
        tags: ["api", "departments"],
        description: "Get list of all active departments",
        plugins: {
            "hapi-swagger": {
                responses: {
                    "201": {
                        description: "active department list is fetched"
                    }
                }
            }
        }
    }
    });
}