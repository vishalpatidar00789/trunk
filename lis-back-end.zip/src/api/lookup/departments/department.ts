import * as Mongoose from "mongoose";

export interface IDepartment extends Mongoose.Document {
  departmentName: string;
  departmentCode: string;
  createdBy: string;
  createdDate: Date;
  lastModifiedBy: string;
  lastModifiedDate: Date;
  activated: boolean;
}

export const DepartmentSchema = new Mongoose.Schema(
{
    departmentName: {type: String, required: true },
    departmentCode: {type: String, required: true},
    createdBy: { type: String, required: true },
    createdDate: { type: Date, required: true },
    lastModifiedBy: { type: String, required: false },
    lastModifiedDate: { type: Date, required: false },
    activated: { type: Boolean, required: false }
  }
);

var diffHistory = require("mongoose-diff-history/diffHistory");
DepartmentSchema.plugin(diffHistory.plugin);

export const DepartmentModel = Mongoose.model<IDepartment>("Department", DepartmentSchema);
