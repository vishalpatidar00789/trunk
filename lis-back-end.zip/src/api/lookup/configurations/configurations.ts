import * as Mongoose from "mongoose";

export interface IConfigurations extends Mongoose.Document {
  code: string;
  value: string;
}

export const ConfigurationsSchema = new Mongoose.Schema(
  {
    code: { type: String, unique: true, required: true },
    value: { type: String, unique: false, required: false }
  }
);

var diffHistory = require("mongoose-diff-history/diffHistory");
ConfigurationsSchema.plugin(diffHistory.plugin);

export const ConfigurationsModel = Mongoose.model<IConfigurations>("configurations", ConfigurationsSchema);
