import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IConfigurations } from "./configurations";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest } from "../../../interfaces/request";
import ConfigurationService from "../../../services/configuration-service";

export default class ConfigurationsController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  constructor(configs: IServerConfigurations, database: IDatabase, private confgService: ConfigurationService) {
    this.database = database;
    this.configs = configs;
  }

  public async getValue() {

  }

  public async getValueByCode(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      const code = request.params['code'];
      let seqNo = await this.confgService.getValueByCode(code);
      return seqNo;
    } catch (error) {
      console.log(error);
      return Boom.badImplementation(error);
    }
  }

  public async updateValue(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      const code = request.params['code'];
      let seqNo = this.confgService.updateByCode(code, '5');
      return seqNo;
    } catch (error) {
      console.log(error);
      return Boom.badImplementation(error);
    }
  }

  public deleteConfigurations() {

  }

  public createConfigurations() {
    try {

    } catch (error) {
      console.log(error);
      return Boom.badImplementation(error);
    }
  }
}