import * as Hapi from "hapi";
import * as Joi from "joi";
import ConfigurationsController from "./configurations-controller";
import { ConfigurationsModel } from "./configurations";
import * as ConfigurationsValidator from "./configurations-validator";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import ConfigurationService from "../../../services/configuration-service";

export default function (
    server: Hapi.Server,
    serverConfigs: IServerConfigurations,
    database: IDatabase
) {
    const configService = new ConfigurationService(serverConfigs, database);
    const configurationsController = new ConfigurationsController(serverConfigs, database, configService);
    server.bind(configurationsController);
    // routes starts from here

    server.route({
        method: "GET",
        path: "/lookup/value",
        options: {
            handler: configurationsController.getValue,
            auth: false,
            tags: ["api", "configurations"],
            description: "Get value",
            plugins: {
                "hapi-swagger": {
                    responses: {
                        "201": {
                            description: "configurations fetched"
                        }
                    }
                }
            }
        }
    });

    server.route({
        method: "GET",
        path: "/lookup/configurations/{code}",
        options: {
            handler: configurationsController.getValueByCode,
            auth: false,
            tags: ["api", "configurations"],
            description: "Get configurations by configurations code",
            validate: {
                params: {
                    code: Joi.string().required()
                }
            },
            plugins: {
                "hapi-swagger": {
                    responses: {
                        "201": {
                            description: "Get configurations by configurations code"
                        }
                    }
                }
            }
        }
    });

    server.route({
        method: "DELETE",
        path: "/lookup/configurations/{code}",
        options: {
            handler: configurationsController.deleteConfigurations,
            auth: false,
            tags: ["api", "configurations"],
            description: "Delete current configurations.",
            validate: {
                params: {
                    code: Joi.string().required()
                }
            },
            plugins: {
                "hapi-swagger": {
                    responses: {
                        "200": {
                            description: "configurations deleted."
                        },
                        "401": {
                            description: "User does not have authorization."
                        }
                    }
                }
            }
        }
    });

    server.route({
        method: "PUT",
        path: "/lookup/configurations/{code}",
        options: {
            handler: configurationsController.updateValue,
            auth: false,
            tags: ["api", "configurations"],
            description: "Update current configurations.",
            validate: {
                params: {
                    code: Joi.string().required()
                },
                payload: ConfigurationsValidator.createConfigurationsModel
            },
            plugins: {
                "hapi-swagger": {
                    responses: {
                        "200": {
                            description: "Updated info."
                        },
                        "401": {
                            description: "User does not have authorization."
                        }
                    }
                }
            }
        }
    });

    server.route({
        method: "POST",
        path: "/lookup/configurations",
        options: {
            handler: configurationsController.createConfigurations,
            auth: false,
            tags: ["api", "configurations"],
            description: "Create a configurations.",
            validate: {
                payload: ConfigurationsValidator.createConfigurationsModel
            },
            plugins: {
                "hapi-swagger": {
                    responses: {
                        "201": {
                            description: "configurations created."
                        }
                    }
                }
            }
        }
    });
}