import * as Joi from "joi";

export const createConfigurationsModel = Joi.object().keys({
    code: Joi.string().required(),
    value: Joi.string().allow(null).optional()
});

export const jwtValidator = Joi.object({ 'authorization': Joi.string().required() }).unknown();