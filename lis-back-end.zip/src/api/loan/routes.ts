import * as Hapi from 'hapi';
import * as Joi from 'joi';
import LoanController from './loan-controller';
import { LoanModel } from './loan';
import * as LoanValidator from './loan-validator';
import { IDatabase } from '../../database';
import { IServerConfigurations } from '../../configurations';
import LoanService from '../../services/loan-service';
import ConfigurationService from '../../services/configuration-service';
import EmailService from '../../services/email-service';

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase,
  emailService: EmailService
) {
  // const loanService = new LoanService(serverConfigs, database, server);
  //const loanController = new LoanController(serverConfigs, database, server, loanService);
  const configService = new ConfigurationService(serverConfigs, database);
  const loanService = new LoanService(serverConfigs, database, server, configService);
  const loanController = new LoanController(serverConfigs, database, server, loanService, emailService);
  server.bind(loanController);

  server.route({
    method: 'GET',
    path: '/loanform/info',
    options: {
      handler: loanController.infoLoan,
      auth: "jwt",
      tags: ['api', 'loan'],
      description: 'Get Loan info.',
      validate: {
        headers: LoanValidator.jwtValidator

      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Loan founded.'
            },
            '401': {
              description: 'Please login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'GET',
    path: '/loanform/loan/{id}',
    options: {
      handler: loanController.getLoan,
      auth: "jwt",
      tags: ['api', 'loan'],
      description: 'Get loan by id.',
      validate: {
        headers: LoanValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Loan founded.'
            },
            '401': {
              description: 'Please login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'PUT',
    path: '/loanform/update-loan-by-id',
    options: {
      handler: loanController.updateLoanById,
      auth: "jwt",
      tags: ['api', 'loan'],
      description: 'Update loan by id.',
      validate: {
        payload: LoanValidator.createLoanModel,
        headers: LoanValidator.jwtValidator
        // params: {
        //   id: Joi.string().required()
        // }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Updated Loan info'
            },
            '401': {
              description: 'Please login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'PUT',
    path: '/loanform/update-adhoc-by-id',
    options: {
      handler: loanController.updateAdhocById,
      auth: "jwt",
      tags: ['api', 'adhoc'],
      description: 'Update Adhoc By Id.',
      validate: {
        payload: LoanValidator.createLoanModel,
        headers: LoanValidator.jwtValidator
        // params: {
        //   id: Joi.string().required()
        // }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Updated Adhoc Info'
            },
            '401': {
              description: 'Please login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'GET',
    path: '/loanform/loanByMarshId/{marshId}',
    options: {
      handler: loanController.getLoanByMarshId,
      auth: "jwt",
      tags: ['api', 'loan'],
      description: 'Get loan by id.',
      validate: {
        headers: LoanValidator.jwtValidator,
        params: {
          marshId: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Loan founded.'
            },
            '401': {
              description: 'Please login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'DELETE',
    path: '/loanform',
    options: {
      handler: loanController.deleteLoan,
      auth: "jwt",
      tags: ['api', 'loan'],
      description: 'Delete current Loan.',
      validate: {
        headers: LoanValidator.jwtValidator
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Loan deleted.'
            },
            '401': {
              description: 'User does not have authorization.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/loanform/submit/{id}",
    options: {
      handler: loanController.updateLoan,
      auth: "jwt",
      tags: ["api", "loan"],
      description: "Update current loan info.",
      validate: {
        payload: LoanValidator.createLoanModel,
        headers: LoanValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated Loan info."
            },
            "401": {
              description: "User does not have authorization."
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/loanform',
    options: {
      handler: loanController.createLoan,
      auth: "jwt",
      //auth: false,
      tags: ['api', 'loan'],
      description: 'Create a Loan.',
      validate: {
        payload: LoanValidator.createLoanModel,
        headers: LoanValidator.jwtValidator
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '201': {
              description: 'Loan created.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/loanform/search',
    options: {
      handler: loanController.searchLoan,
      auth: "jwt",
      //auth: false,
      tags: ['api', 'loan'],
      description: 'Search for loan applications.',
      validate: {
        payload: LoanValidator.searchLoanPayload,
        headers: LoanValidator.jwtValidator
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'List of all matching Loan applications.'
            },
            '401': {
              description: 'Please Login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/loanform/adverseInfo/{id}",
    options: {
      handler: loanController.updateLoanAdverseInfo,
      auth: "jwt",
      tags: ["api", "loan"],
      description: "Update loan adverse info.",
      validate: {
        payload: LoanValidator.createAdverseInfo,
        headers: LoanValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated Loan adverse info."
            },
            "401": {
              description: "User does not have authorization."
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'PUT',
    path: '/loanform/saveAsDraft/{id}',
    options: {
      handler: loanController.saveAsDraft,
      auth: "jwt",
      tags: ['api', 'loan'],
      description: 'Update current loan info.',
      validate: {
        payload: LoanValidator.createLoanModel,
        headers: LoanValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Updated Loan info.'
            },
            '401': {
              description: 'User does not have authorization.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/loanform/dlValidation',
    options: {
      handler: loanController.dlValidation,
      auth: "jwt",
      //auth: false,
      tags: ['api', 'loan'],
      description: 'DL validation for Loan applications.',
      validate: {
        payload: LoanValidator.createLoanModel,
        headers: LoanValidator.jwtValidator,
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'DL validation for Loan applications.'
            },
            '401': {
              description: 'Please Login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/loanform/bgValidation',
    options: {
      handler: loanController.bgValidation,
      auth: "jwt",
      //auth: false,
      tags: ['api', 'loan'],
      description: 'BG validation for Loan applications.',
      validate: {
        payload: LoanValidator.createLoanModel,
        headers: LoanValidator.jwtValidator
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'BG validation for Loan applications.'
            },
            '401': {
              description: 'Please Login.'
            }
          }
        }
      }
    }
  });
}
