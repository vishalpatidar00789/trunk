import * as Mongoose from 'mongoose';
import * as Bcrypt from 'bcryptjs';
//import * as diffHistory from 'mongoose-diff-history/diffHistory';
//diffHistory = require('mongoose-diff-history/diffHistory'),
//import { IPFI, PFISchema } from './pfi/pfi';
//import { IUOB, UOBSchema } from './uob/uob';

export interface ILoan extends Mongoose.Document {
  _id: string;
  marshRefNo: string;
  status: string;
  consortium: string;
  app: number;
  typeOfRequest: string;
  loanRequestSeqNo: number;

  createdBy: string;
  createdDate: Date;
  lastmodifiedBy: string;
  lastModifiedDate: Date;
  grossSGDPremiumPL: number;
  grossSGDPremiumTUL: number;
  grossSGDPremiumBG: number;
  grossSGDPremiumLISPlus: number;
  isClaimSubmitted: boolean;
  //pfi: {
  creditInfo: {
    _id: string;
    lisCoinsurer: string;
    pfiName: string;
    pfiCode: string;
    requesterName: string;
    aCRArefNo: string;
    borrowerRegName: string;
    totalReqLimit: number;
    preshipmentApprovalChkBx: boolean;
    exRate: number;
    foreignCurrencyAmount: number;
    primary: number;
    autoTopUp: number;
    bg: number;
    lisPlus: number;
    inventoryChkBx: boolean;
    workingCapChkBx: boolean;
    overseaseWorkingChkBx: boolean;
    bankersGuaranteeChkBx: boolean;
    tempIncreaseLimitChkBx: boolean;
    midTermIncreaseLimitChkBx: boolean;
    decreaseLimitChkBx: boolean;
    beforeMidTermIncreaseLimitChkBx: boolean;
    beforeDecreaseLimitChkBx: boolean;
    resourceFactoringChkBx: boolean;
    loanQuantumChkBx: boolean;
    operatongTrackChkBx: boolean;
    latestAuditedChkBx: boolean;
    auditedFinanceChkBx: boolean;
    applicationChkBx: boolean;
    bankersGuaranteeBChkBx: boolean;
    guaranteeAmountChkBx: boolean;
    guaranteeAmount2ChkBx: boolean;
    bankersGuaranteeB2ChkBx: boolean;
    principalChkBx: boolean;
    lisSponsersApplChkBx: boolean;
    companySearchesChkBx: boolean;
    pfiInternalCreditChkBx: boolean;
    latestSignedChkBx: boolean;
    additionalItemChkBx: boolean;
    forOverseasChkBx: boolean;
    inventoryTxt: number;
    structuredWorkingCapTxt: number;
    inventoryTradeTxt: number;
    resourceFactoringTxt: number;
    additionalItemTxt: string;
    beforeMidTermIncreaseLimitTxt: number;
    decreaseLimitTxt: number;
    beforeDecreaseLimitTxt: number;
    tempIncreaseLimitTxt: number;
    midTermIncreaseLimitTxt: number;
    bankersGuaranteeTxt: number;
    latestSignedDt: Date;
    latestAuditedDt: Date;
    latestAuditFinanceChkBx: boolean;
    foreignCurrency: string;
    exceptionalCrrRate: number;
    appliedAmountDL: number;
    supportingDocs: [
      { _id: string; name: string; id: string; status: boolean; files: string },
      { _id: string; name: string; id: string; status: boolean; files: string },
      { _id: string; name: string; id: string; status: boolean; files: string },
      { _id: string; name: string; id: string; status: boolean; files: string },
      { _id: string; name: string; id: string; status: boolean; files: string },
      { _id: string; name: string; id: string; status: boolean; files: string },
      { _id: string; name: string; id: string; status: boolean; files: string },
      { _id: string; name: string; id: string; status: boolean; files: string },
      { _id: string; name: string; id: string; status: boolean; files: string }
    ];
    //uob:
    submissionDate: Date;
    discretiolaryLimitDL: boolean;
    creditLimitCL: boolean;
    borrowersCrr: number;
    crrRate: string;
    lisType: string;
    inventoryStockChkBx: boolean;
    structuredWorkingCapitalChkBx: boolean;
    recourseFactoringBillChkBx: boolean;
    overseasWorkingCapitalChkBx: boolean;
    bankersGuarantee: boolean;
    renewalToUSDTxt: number;
    renewalToSGDTxt: number;
    increaseLimitToSGD: number;
    increaseLimitToUSD: number;
    decreaseLimitToSGD: number;
    decreaseLimitToUSD: number;
    renewalFromSGDTxt: number;
    renewalFromUSDTxt: number;
    sgdCurrencyCurrentLIS: number;
    usdCurrencyCurrentLIS: number;
    uobInternalCreditChkBx: boolean;
    usdCurrency: number;
    sgdCurrency: number;
    currencyExchangeRate: number;
    usdCurrencyCurrent: number;
    sgdCurrencyCurrent: number;
    usdCurrencyCurrentLISP: number;
    sgdCurrencyCurrentLISP: number;
    bankersGuaranteeAmountChkBx: boolean;
    inventoryUSDTxt: number;
    inventorySGDTxt: number;
    withRecourseUSDTxt: number;
    withRecourseSGDTxt: number;
    structuredWorkingCapitalSGDTxt: number;
    overseaseCapitalSGDTxt: number;
    overseaseCapitalUSDTxt: number;
    bankersGuaranteeAmountSGDTxt: number;
    bankersGuaranteeAmountUSDTxt: number;
    rocRefNo: string;
    tenureMonths: number;

    uniqueEntityNumber: string;
    uenNumber: string;
    overseaseWorkingTxt: number;
    typeOfLimit: string;
    TypeOfLISPlusLimit: string;
    natureOfApplication: string;
    loanDomesticTrade1: number;
    loanDomesticTrade2: number;
    purposeOfLoan: string;
    insurersApprovalDate: Date;
    loAcceptanceDate: Date;
    loanExpiryDate: Date;
    dateSentForLISPlus: Date;
    lISPlusApprovedDate: Date;
    totalRequstedLimitSGD: number;
    approvedPrimaryLayer: number;
    approvedAutoTopUpLayer: number;
    approvedBgLayer: number;
    approvedSGDLimitLISPlus: number;
    lis5TotalApprovedLimit: number;
    totalApprovedLimitincludingLISPLUS: number;
    totalApprovedPrimaryLimitInForce: number;
    totalApprovedAutoTopUpLimitInForce: number;
    totalApprovedBGlimitInForce: number;
    totalApprovedLISPlusLimitInForce: number;
    totalApprovedLimitInForce: number;

    totalRequstedLimitSGDForeignCurrency: number;
    approvedPrimaryLayerForeignCurrency: number;
    approvedAutoTopUpLayerForeignCurrency: number;
    approvedBgLayerForeignCurrency: number;
    approvedSGDLimitLISPlusForeignCurrency: number;
    lis5TotalApprovedLimitForeignCurrency: number;
    totalApprovedLimitincludingLISPLUSForeignCurrency: number;
    totalApprovedPrimaryLimitInForceForeignCurrency: number;
    totalApprovedAutoTopUpLimitInForceForeignCurrency: number;
    totalApprovedBGlimitInForceForeignCurrency: number;
    totalApprovedLISPlusLimitInForceForeignCurrency: number;
    totalApprovedLimitInForceForeignCurrency: number;

    LIS5ApprovalRatio: number;
    approvalRatioWithLISPLUS: number;
    LIS5TurnaroundDays: number;
    turnaroundWithLISPLUSDays: number;
    utilization: string;
    reportedMonth: number;
    loanApplicationNumber: string;
    internalRemark: string;


    totalAppliedLimitForLIS5: number,
    totalAppliedLimitForLIS5ForeignCurrency: number,
    approvedlimitPrimaryLayerForeignCurrency: number,
    approvedLimitAutoTopUpLayerForeignCurrency: number,
    approvedLimitBGLayerForeignCurrency: number,
    appliedIncAmountDL: number,
    appliedIncAmountBG: number,
    appliedDecAmountDL: number,
    appliedDecAmountBG: number,



    //foreignCurrency: string;
    // supportingDocs: [
    //   { name: string, id: string, status: boolean, files: string },
    //   { name: string, id: string, status: boolean, files: string },
    //   { name: string, id: string, status: boolean, files: string },
    //   { name: string, id: string, status: boolean, files: string },
    //   { name: string, id: string, status: boolean, files: string },
    //   { name: string, id: string, status: boolean, files: string },
    //   { name: string, id: string, status: boolean, files: string }
    // ]
  };
  sponsorForm: {
    _id: string;
    registeredCompanyName: string;
    uniqueEntityNumber: string;
    correspondenceAddress: string;
    contactPersonDesignation: string;
    phoneNumber: string;
    contactEmail: string;
    numberofStaff: number;
    dateofIncorporation: Date;
    dateOfSingature: any;
    contactPersonNo: string;
    ACRANo: string;
    regComName: string;
    corrAddress1: string;
    corrAddress2: string;
    corrAddress3: string;
    contactPerson: string;
    contactPersonEmail: string;
    businessActivity: string;
    numStaff: string;
    appLFY: string;
    appSubLFY: string;
    appSales: number;
    appSubSales: number;
    appNetProfit: number;
    appNetProfitsubsidiaries: number;
    appSubNetProfit: number;
    level: number;
    name: string;
    aCRA: string;
    type: string;
    country: string;
    share: number;
    parentUEN: string;
    turnover: number;
    noOfStaff: number;
    //subsidiaries: subsideries[];
    invStockFinancing: number;
    workingCapital: number;
    aRDiscount: number;
    capitalLoan: number;
    bankerGuarantee: number;
    total: number;
    loanDomesticTrade1: number;
    loanDomesticTrade2: number;
    invStockFinancingChecked: boolean;
    workingCapitalChecked: boolean;
    aRDiscountChecked: boolean;
    capitalLoanChecked: boolean;
    bankerGuaranteeChecked: boolean;
    purposeOfLoan: string;
  };

  adverseInfo: {
    adverseStatus: string;
    additionalInfo: string;
    overdue: string;
    overdueDate: Date;
    listOfOverdue: boolean;
    repaymentPlanAttached: boolean;
  };
}

export const LoanSchema = new Mongoose.Schema(
  {
    status: { type: String },
    marshRefNo: { type: String },
    consortium: { type: String },
    app: { type: Number },
    typeOfRequest: { type: String },
    loanRequestSeqNo: { type: Number },
    grossSGDPremiumPL: { type: Number },
    grossSGDPremiumTUL: { type: Number },
    grossSGDPremiumBG: { type: Number },
    grossSGDPremiumLISPlus: { type: Number },
    createdBy: { type: String },
    createdDate: { type: Date },
    lastmodifiedBy: { type: String },
    lastModifiedDate: { type: Date },
    isClaimSubmitted: { type: Boolean },

    sponsorForm: {
      _id: { type: String },
      registeredCompanyName: { type: String },
      uniqueEntityNumber: { type: String },
      correspondenceAddress: { type: String },
      contactPersonDesignation: { type: String },
      phoneNumber: { type: String },
      contactEmail: { type: String },
      numberofStaff: { type: Number },
      dateofIncorporation: { type: Date },
      dateOfSingature: { type: String },
      contactPersonNo: { type: String },
      ACRANo: { type: String },
      regComName: { type: String },
      corrAddress1: { type: String },
      corrAddress2: { type: String },
      corrAddress3: { type: String },
      contactPerson: { type: String },
      contactPersonEmail: { type: String },
      businessActivity: { type: String },
      numStaff: { type: String },
      // dateOfIncorporation: { type: String },
      appLFY: { type: String },
      appSubLFY: { type: String },
      appSales: { type: Number },
      appSubSales: { type: Number },
      appNetProfit: { type: Number },
      appNetProfitsubsidiaries: { type: Number },
      appSubNetProfit: { type: Number },
      shareholdingSub: { type: Array },
      // shareholdingSub: [{
      //   level: { type: String },
      //   name: { type: String },
      //   aCRA: { type: String },
      //   type: { type: String },
      //   country: { type: String },
      //   share: { type: String },
      //   parentUEN: { type: String },
      //   turnover: { type: String },
      //   noOfStaff: { type: String }
      // }],
      level: { type: Number },
      name: { type: String },
      aCRA: { type: String },
      type: { type: String },
      country: { type: String },
      share: { type: Number },
      parentUEN: { type: String },
      turnover: { type: Number },
      noOfStaff: { type: Number },
      subsidiaries: { type: Array },
      invStockFinancing: { type: Number },
      workingCapital: { type: Number },
      aRDiscount: { type: Number },
      capitalLoan: { type: Number },
      bankerGuarantee: { type: Number },
      total: { type: Number },
      loanDomesticTrade1: { type: Number },
      loanDomesticTrade2: { type: Number },
      invStockFinancingChecked: { type: Boolean },
      workingCapitalChecked: { type: Boolean },
      aRDiscountChecked: { type: Boolean },
      capitalLoanChecked: { type: Boolean },
      bankerGuaranteeChecked: { type: Boolean },
      purposeOfLoan: { type: String }
    },
    // pfi: {
    creditInfo: {
      _id: { type: String },
      lisCoinsurer: { type: String },
      pfiName: { type: String },
      pfiCode: { type: String },
      requesterName: { type: String },
      aCRArefNo: { type: String },
      borrowerRegName: { type: String },
      submissionDate: { type: Date },
      totalRequstedLimitSGD: { type: Number },
      preshipmentApprovalChkBx: { type: Boolean },
      exRate: { type: Number },
      foreignCurrencyAmount: { type: Number },
      primary: { type: Number },
      autoTopUp: { type: Number },
      bg: { type: Number },
      lisPlus: { type: Number },
      inventoryChkBx: { type: Boolean },
      workingCapChkBx: { type: Boolean },
      overseaseWorkingChkBx: { type: Boolean },
      bankersGuaranteeChkBx: { type: Boolean },
      tempIncreaseLimitChkBx: { type: Boolean },
      midTermIncreaseLimitChkBx: { type: Boolean },
      decreaseLimitChkBx: { type: Boolean },
      beforeMidTermIncreaseLimitChkBx: { type: Boolean },
      beforeDecreaseLimitChkBx: { type: Boolean },
      resourceFactoringChkBx: { type: Boolean },
      loanQuantumChkBx: { type: Boolean },
      operatongTrackChkBx: { type: Boolean },
      latestAuditedChkBx: { type: Boolean },
      auditedFinanceChkBx: { type: Boolean },
      applicationChkBx: { type: Boolean },
      bankersGuaranteeBChkBx: { type: Boolean },
      guaranteeAmountChkBx: { type: Boolean },
      guaranteeAmount2ChkBx: { type: Boolean },
      bankersGuaranteeB2ChkBx: { type: Boolean },
      principalChkBx: { type: Boolean },
      lisSponsersApplChkBx: { type: Boolean },
      companySearchesChkBx: { type: Boolean },
      pfiInternalCreditChkBx: { type: Boolean },
      inventoryTradeChkBx: { type: Boolean },
      latestSignedChkBx: { type: Boolean },
      additionalItemChkBx: { type: Boolean },
      forOverseasChkBx: { type: Boolean },
      inventoryTxt: { type: Number },
      overseaseWorkingTxt: { type: Number },
      tempIncreaseLimitTxt: { type: Number },
      inventoryTradeTxt: { type: Number },
      resourceFactoringTxt: { type: Number },
      additionalItemTxt: { type: String },
      beforeMidTermIncreaseLimitTxt: { type: Number },
      structuredWorkingCapTxt: { type: Number },
      decreaseLimitTxt: { type: Number },
      beforeDecreaseLimitTxt: { type: Number },
      midTermIncreaseLimitTxt: { type: Number },
      bankersGuaranteeTxt: { type: Number },
      latestSignedDt: { type: Date },
      latestAuditedDt: { type: Date },
      latestAuditFinanceChkBx: { type: Boolean },
      foreignCurrency: { type: String },
      appliedAmountDL: { type: Number },
      exceptionalCrrRate: { type: Number },

      uniqueEntityNumber: { type: String },
      uenNumber: { type: String },
      marshRefNo: { type: String },
      status: { type: String },
      app: { type: Number },
      typeOfLimit: { type: String },
      TypeOfLISPlusLimit: { type: String },
      natureOfApplication: { type: String },
      loanDomesticTrade1: { type: Number },
      loanDomesticTrade2: { type: Number },
      purposeOfLoan: { type: String },
      insurersApprovalDate: { type: Date },
      loAcceptanceDate: { type: Date },
      loanExpiryDate: { type: Date },
      dateSentForLISPlus: { type: Date },
      lISPlusApprovedDate: { type: Date },
      approvedPrimaryLayer: { type: Number },
      approvedAutoTopUpLayer: { type: Number },
      approvedBgLayer: { type: Number },
      approvedSGDLimitLISPlus: { type: Number },
      lis5TotalApprovedLimit: { type: Number },
      totalApprovedLimitincludingLISPLUS: { type: Number },
      totalApprovedPrimaryLimitInForce: { type: Number },
      totalApprovedAutoTopUpLimitInForce: { type: Number },
      totalApprovedBGlimitInForce: { type: Number },
      totalApprovedLISPlusLimitInForce: { type: Number },
      totalApprovedLimitInForce: { type: Number },
      totalRequstedLimitSGDForeignCurrency: { type: Number },
      approvedPrimaryLayerForeignCurrency: { type: Number },
      approvedAutoTopUpLayerForeignCurrency: { type: Number },
      approvedBgLayerForeignCurrency: { type: Number },
      approvedSGDLimitLISPlusForeignCurrency: { type: Number },
      lis5TotalApprovedLimitForeignCurrency: { type: Number },
      totalApprovedLimitincludingLISPLUSForeignCurrency: { type: Number },
      totalApprovedPrimaryLimitInForceForeignCurrency: { type: Number },
      totalApprovedAutoTopUpLimitInForceForeignCurrency: { type: Number },
      totalApprovedBGlimitInForceForeignCurrency: { type: Number },
      totalApprovedLISPlusLimitInForceForeignCurrency: { type: Number },
      totalApprovedLimitInForceForeignCurrency: { type: Number },
      LIS5ApprovalRatio: { type: Number },
      approvalRatioWithLISPLUS: { type: Number },
      LIS5TurnaroundDays: { type: Number },
      turnaroundWithLISPLUSDays: { type: Number },
      utilization: { type: String },
      reportedMonth: { type: Number },
      loanApplicationNumber: { type: String },
      internalRemark: { type: String },
      appliedIncAmountDL: { type: Number },
      appliedIncAmountBG: { type: Number },
      appliedDecAmountDL: { type: Number },
      appliedDecAmountBG: { type: Number },


      // borrowersGroup: [{
      //   _id: false,
      //   name: { type: String }
      // }],
      supportingDocs: [
        {
          _id: { type: String },
          name: { type: String },
          id: { type: String },
          status: { type: Boolean },
          files: { type: String }
        },
        {
          _id: { type: String },
          name: { type: String },
          id: { type: String },
          status: { type: Boolean },
          files: { type: String }
        },
        {
          _id: { type: String },
          name: { type: String },
          id: { type: String },
          status: { type: Boolean },
          files: { type: String }
        },
        {
          _id: { type: String },
          name: { type: String },
          id: { type: String },
          status: { type: Boolean },
          files: { type: String }
        },
        {
          _id: { type: String },
          name: { type: String },
          id: { type: String },
          status: { type: Boolean },
          files: { type: String }
        },
        {
          _id: { type: String },
          name: { type: String },
          id: { type: String },
          status: { type: Boolean },
          files: { type: String }
        },
        {
          _id: { type: String },
          name: { type: String },
          id: { type: String },
          status: { type: Boolean },
          files: { type: String }
        },
        {
          _id: { type: String },
          name: { type: String },
          id: { type: String },
          status: { type: Boolean },
          files: { type: String }
        },
        {
          _id: { type: String },
          name: { type: String },
          id: { type: String },
          status: { type: Boolean },
          files: { type: String }
        }
      ],

      //uob:

      toLIS5Insurer: { type: String },
      discretiolaryLimitDL: { type: Boolean },
      creditLimitCL: { type: Boolean },
      borrowersCrr: { type: Number },
      crrRate: { type: String },
      lisType: { type: String },
      inventoryStockChkBx: { type: Boolean },
      structuredWorkingCapitalChkBx: { type: Boolean },
      recourseFactoringBillChkBx: { type: Boolean },
      overseasWorkingCapitalChkBx: { type: Boolean },
      bankersGuarantee: { type: Boolean },
      //foreignCurrency: { type: String },
      borrowersGroup: [
        {
          _id: false,
          name: { type: String },
          limit: { type: Number }
        }
      ],
      inventoryUSDTxt: { type: Number },
      inventorySGDTxt: { type: Number },
      withRecourseUSDTxt: { type: Number },
      withRecourseSGDTxt: { type: Number },
      structuredWorkingCapitalUSDTxt: { type: Number },
      structuredWorkingCapitalSGDTxt: { type: Number },
      overseaseCapitalSGDTxt: { type: Number },
      overseaseCapitalUSDTxt: { type: Number },
      bankersGuaranteeAmountSGDTxt: { type: Number },
      bankersGuaranteeAmountUSDTxt: { type: Number },
      increaseLimitToSGD: { type: Number },
      increaseLimitToUSD: { type: Number },
      decreaseLimitToSGD: { type: Number },
      decreaseLimitToUSD: { type: Number },
      renewalFromSGDTxt: { type: Number },
      renewalFromUSDTxt: { type: Number },
      renewalToUSDTxt: { type: Number },
      renewalToSGDTxt: { type: Number },
      sgdCurrencyCurrentLIS: { type: Number },
      usdCurrencyCurrentLIS: { type: Number },
      uobInternalCreditChkBx: { type: Boolean },
      usdCurrency: { type: Number },
      sgdCurrency: { type: Number },
      currencyExchangeRate: { type: Number },
      usdCurrencyCurrent: { type: Number },
      sgdCurrencyCurrent: { type: Number },
      usdCurrencyCurrentLISP: { type: Number },
      sgdCurrencyCurrentLISP: { type: Number },
      bankersGuaranteeAmountChkBx: { type: Boolean },
      rocRefNo: { type: String },
      tenureMonths: { type: Number },

      totalAppliedLimitForLIS5: { type: Number },
      totalAppliedLimitForLIS5ForeignCurrency: { type: Number },
      approvedlimitPrimaryLayerForeignCurrency: { type: Number },
      approvedLimitAutoTopUpLayerForeignCurrency: { type: Number },
      approvedLimitBGLayerForeignCurrency: { type: Number }
      // supportingDocs: [
      //   { name: { type: String }, id: { type: String }, status: { type: Boolean }, files: { type: String } },
      //   { name: { type: String }, id: { type: String }, status: { type: Boolean }, files: { type: String } },
      //   { name: { type: String }, id: { type: String }, status: { type: Boolean }, files: { type: String } },
      //   { name: { type: String }, id: { type: String }, status: { type: Boolean }, files: { type: String } },
      //   { name: { type: String }, id: { type: String }, status: { type: Boolean }, files: { type: String } },
      //   { name: { type: String }, id: { type: String }, status: { type: Boolean }, files: { type: String } },
      //   { name: { type: String }, id: { type: String }, status: { type: Boolean }, files: { type: String } }
      // ]
    },
    adverseInfo: {
      adverseStatus: { type: String },
      additionalInfo: { type: String },
      overdue: { type: String },
      overdueDate: { type: Date },
      listOfOverdue: { type: Boolean },
      repaymentPlanAttached: { type: Boolean }
    }
  }
  // {
  //   timestamps: true
  // }
);
var diffHistory = require("mongoose-diff-history/diffHistory");
LoanSchema.plugin(diffHistory.plugin);

function hashPassword(password: string): string {
  if (!password) {
    return null;
  }

  return Bcrypt.hashSync(password, Bcrypt.genSaltSync(8));
}
LoanSchema.pre('save', function (next) {
  console.log('inside pre');
  // do something
  return next();
});
export const LoanModel = Mongoose.model<ILoan>('loan', LoanSchema);

