import * as Joi from "joi";

export const createSpringFormModel = Joi.object().keys({
    // email: Joi.string().email().trim().required(),
    // name: Joi.string().required(),
    // password: Joi.string().trim().required()
});

export const updateSpringFormModel = Joi.object().keys({
    email: Joi.string().email().trim(),
    name: Joi.string(),
    password: Joi.string().trim()
});

export const loginSpringFormModel = Joi.object().keys({
    email: Joi.string().email().required(),
    password: Joi.string().trim().required()
});

export const jwtValidator = Joi.object({'authorization': Joi.string().required()}).unknown();