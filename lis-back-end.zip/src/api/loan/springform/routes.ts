import * as Hapi from "hapi";
import * as Joi from "joi";
import SpringFormController from "./springform-controller";
import { SpringFormModel } from "./springform";
import * as SpringFormValidator from "./springform-validator";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import * as LoanValidator from "../loan-validator";
import DocumentService from "../../../services/document-service";


export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const docService: DocumentService = new DocumentService();
  const springformController = new SpringFormController(serverConfigs, database, docService , server);
  server.bind(springformController);

  server.route({
    method: "GET",
    path: "/springforms/info",
    options: {
      handler: springformController.infoSpringForm,
      auth: "jwt",
      tags: ["api", "springforms"],
      description: "Get springform info.",
      validate: {
        headers: SpringFormValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "SpringForm founded."
            },
            "401": {
              description: "Please login."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/springforms",
    options: {
      handler: springformController.deleteSpringForm,
      tags: ["api", "springforms"],
      description: "Delete current springform.",
      validate: {
        //headers: SpringFormValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "SpringForm deleted."
            },
            "401": {
              description: "SpringForm does not have authorization."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/springforms/{id}",
    options: {
      handler: springformController.updateSpringForm,
      auth: false,
      tags: ["api", "springforms"],
      description: "Update current springform info.",
      validate: {
        payload: LoanValidator.createLoanModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated info."
            },
            "401": {
              description: "SpringForm does not have authorization."
            }
          }
        }
      }
    }
  });





  server.route({
    method: "POST",
    path: "/springforms",
    options: {
      handler: springformController.createSpringForm,
      auth: false,
      tags: ["api", "springforms"],
      description: "Create a user.",
      validate: {
        payload: LoanValidator.createLoanModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "User created."
            }
          }
        }
      }
    }
  });



  server.route({
    method: "POST",
    path: "/springforms/uploadspringeform/{id}",
    options: {
      handler: springformController.uploadSpringEform,
      auth: false,
      tags: ["api", "springforms"],
      description: "Create a springform.",
      payload: {
        output: "stream",
        parse: true,
        allow: "multipart/form-data",
        maxBytes: 2 * 1000 * 1000
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "SpringForm created."
            }
          }
        }
      }
    }
  });
}
