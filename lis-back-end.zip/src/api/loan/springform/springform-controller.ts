import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { ISpringForm, SpringFormModel } from "./springform";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest, Ispring, FileMetaData, ILoginRequest } from "../../../interfaces/request";
import DocumentService from "../../../services/document-service";
const fs = require("fs");
const pdfextracter = require('../../../utils/pdfextracter');
const path = require('path');
const tempFile = "/opt/apps/lis/springforms/";
const util = require('util');
var parseString = require('xml2js').parseString;



export default class SpringFormController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  private docService: DocumentService;
  private server: Hapi.Server;

  constructor(configs: IServerConfigurations, database: IDatabase, docService: DocumentService, server: Hapi.Server) {
    this.database = database;
    this.configs = configs;
    this.docService = docService;
    this.server = server;

  }

  private generateToken(springform: ISpringForm) {
    const jwtSecret = this.configs.jwtSecret;
    const jwtExpiration = this.configs.jwtExpiration;
    const payload = { id: springform._id };

    return Jwt.sign(payload, jwtSecret, { expiresIn: jwtExpiration });
  }

  public async createSpringForm(request: IRequest, h: Hapi.ResponseToolkit) {
    try {


      // let objectToSave = { "data": request.payload };


      //console.log(objectToSave);

      let springform: any = await this.database.loanModel.create(request.payload);
      console.log(springform);
      //return h.response(springform).code(201);
      return h.response({ "_id": springform._id }).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateSpringForm(request: IRequest, h: Hapi.ResponseToolkit) {
    console.log(JSON.stringify(request.params.id));
    const id = request.params.id;

    try {
      let springform: ISpringForm = await this.database.loanModel.findByIdAndUpdate(
        id,
        { $set: request.payload },
        { new: true }
      );
      return springform;
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteSpringForm(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.auth.credentials.id;
    let springform: ISpringForm = await this.database.springformModel.findByIdAndRemove(id);

    return springform;
  }

  public async infoSpringForm(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.auth.credentials.id;
    let springform: ISpringForm = await this.database.springformModel.findById(id);

    return springform;
  }

  public async uploadSpringEform(request, h: Hapi.ResponseToolkit) {
    try {
      console.log("__________________________");
      console.log(request.payload);
      let result: any;
      let files = [request.payload["file"]];
      let i = 0;
      // result.push(files[i].hapi);
      let date = new Date();
      const fileName = "eSpringForm" + date.getDay() + date.getMonth()
        + date.getFullYear() + date.getHours() + date.getMinutes()
        + date.getSeconds() + date.getMilliseconds() + ".pdf";
      console.log("spring form name:: " + fileName);
      console.log("original file name:: " + files[i].hapi.filename);
      let pathofFile = tempFile + path.join(fileName); // files[i].hapi.filename
      // var pathofFile = path.join(files[i].hapi.filename);
      console.log("pathofFile:: " + pathofFile);
      files[i].pipe(fs.createWriteStream(pathofFile));
      result = pdfextracter.extraxtPDF(pathofFile).then(data => {
        // return data;
        if (data[0].data) {
          // console.log("file data:: " + JSON.stringify(data));
          return new Promise(function (resolve, reject) {
            parseString(data[0].data, function (err, result) {
              if (err) {
                return reject(err);
              } else {
                return resolve(result);
              }
            });
          }).then(
            data => {
              //var file = [request.payload["uploads"]];
              // var fileName = request.payload["fileName"];
              // var contentType = file[0].headers.content_type;
              var contentType = 'binary/octet-stream';
              var fileData = files[0]._data;
              let fileMetaData: FileMetaData = new FileMetaData();
              fileMetaData.contentType = contentType;
              fileMetaData.file = fileData;
              fileMetaData.fileName = fileName;
              fileMetaData.refAppId = request.params['id'];
              fileMetaData.collectionName = "LOAN";
              fileMetaData.documentType = "Sponsor form";
              fileMetaData.uploadedBy = 'SYSTEM';
              // fileMetaData.uploadedBy = request.auth.credentials.id;

              let uploadedFile = this.docService.uploadFile(fileMetaData);
              console.log("uploadedFile:" + uploadedFile);
              this.deleteFile(pathofFile);
              console.log("file deleted ");
              return this.mapPDFToJSON(data);
            });
        } else {
          // throw valid error message
          this.deleteFile(pathofFile);
          console.log("error in extract pdf payload");
          return Boom.preconditionFailed("Spring form application configuration issue. Please contact server admin.");
        }

      });
      console.log("spring form JSON mapped data::" + result);
      return result;
    } catch (error) {
      console.log(error);
      return Boom.badImplementation("Internal server error. Please contact admin.");
    }
  }


  private deleteFile(filePath) {
    fs.unlink(filePath, (err) => {
      if (err) {
        throw err;
      }
      console.log('successfully deleted:: ' + filePath);
    });
  }

  private mapPDFToJSON(result: any) {

    console.log(result);
    this.server.log("INFO", result);
    let springForm: ISpringForm = <ISpringForm>{};
    var section = result["xfa:data"].form1[0].CompanyData1[0];
    var section1 = section.ComMainSub1[0];

    console.log("____________________________________________________");
    if (!(section.ErrorMessage[0].ErrorMessageText[0] === 'Validation Pass! Please proceed to submit this eForm.')) {
      throw "Please validate the Spring eForm";
    }
    springForm.regComName = section.ComNameSub[0].RegComName[0];
    springForm.ACRANo = section1.ACRANo[0];
    springForm.corrAddress1 = section1.CorrAddress1[0];
    springForm.corrAddress2 = section1.CorrAddress2[0];
    springForm.corrAddress3 = section1.CorrAddress3[0];
    springForm.contactPerson = section1.ContactPerson[0];
    springForm.corrAddress3 = section1.CorrAddress3[0];
    springForm.contactPersonEmail = section1.ContactPersonEmail[0];
    springForm.contactPersonNo = section1.ContactPersonNo[0];

    springForm.businessActivity = result["xfa:data"].form1[0].CompanyData1[0].BusActSub[0].BusinessActivity[0];

    springForm.numStaff = result["xfa:data"].form1[0].CompanyData1[0].ComMainSub2[0].NumStaff[0];

    // let dateArray: number[] = result["xfa:data"].form1[0].CompanyData1[0].ComMainSub2[0].DateOfIncorporation[0].split("-");
    // springForm.dateofIncorporation = { year: Number(dateArray[0]), month: Number(dateArray[1]), day: Number(dateArray[2]) };

    springForm.dateofIncorporation = result["xfa:data"].form1[0].CompanyData1[0].ComMainSub2[0].DateOfIncorporation[0];

    //Table data
    console.log("___________________________________________________");
    // springForm.ACRANo = result["xfa:data"].form1[0].CompanyData1[0].Performance[0].PastPerformanceTable[0];
    springForm.appLFY = Number(result["xfa:data"].form1[0].CompanyData1[0].Performance[0].PastPerformanceTable[0].YearRow[0].AppLFY[0].replace(/\,/g, ''));
    springForm.appSubLFY = Number(result["xfa:data"].form1[0].CompanyData1[0].Performance[0].PastPerformanceTable[0].YearRow[0].AppSubLFY[0].replace(/\,/g, ''));

    springForm.appSales = Number(result["xfa:data"].form1[0].CompanyData1[0].Performance[0].PastPerformanceTable[0].SalesRow[0].AppSales[0].replace(/\,/g, ''));
    springForm.appSubSales = Number(result["xfa:data"].form1[0].CompanyData1[0].Performance[0].PastPerformanceTable[0].SalesRow[0].AppSubSales[0].replace(/\,/g, ''));

    springForm.appNetProfit = Number(result["xfa:data"].form1[0].CompanyData1[0].Performance[0].PastPerformanceTable[0].NetProfitRow[0].AppNetProfit[0].replace(/\,/g, ''));
    springForm.appSubNetProfit = Number(result["xfa:data"].form1[0].CompanyData1[0].Performance[0].PastPerformanceTable[0].NetProfitRow[0].AppSubNetProfit[0].replace(/\,/g, ''));
    console.log("___END______________SECTION1__________________________________");
    //Table data
    console.log("___START_______________SECTION 2_________________________________");
    springForm.shareholdingSub = [];
    let shareholdingSub = result["xfa:data"].form1[0].CompanyData1[0].ShareholdingSub[0].ShareholdingDetails1Table[0].ShareholdingDetails1Row;
    // springForm.ACRANo = table1[0].Level;
    shareholdingSub.forEach(function (value) {
      let shareholdingSub: any = {};
      // springForm.ACRANo = value;
      shareholdingSub.level = value.Level[0];
      shareholdingSub.name = value.Name[0];
      shareholdingSub.aCRA = value.ACRA[0];
      shareholdingSub.type = value.Type[0];
      shareholdingSub.country = value.Country[0];
      shareholdingSub.share = value.Share[0];
      shareholdingSub.parentUEN = value.ParentUEN[0];
      shareholdingSub.turnover = value.Turnover[0];
      shareholdingSub.noOfStaff = value.NoOfStaff[0];

      springForm.shareholdingSub.push(shareholdingSub);
    });


    let subsidiariesTable = result["xfa:data"].form1[0].CompanyData1[0].ShareholdingSub[0].SubsidiariesDetails[0].SubsidiariesTable[0].SubsidiariesRow;
    springForm.subsidiaries = [];

    subsidiariesTable.forEach(function (value) {
      let subsidiaries: any = {};
      subsidiaries.subsidLevel = value.SubsidLevel[0];
      subsidiaries.name = value.Name[0];
      subsidiaries.sharePercent = value.SharePercent[0];
      subsidiaries.noStaff = value.NoStaff[0];
      subsidiaries.UEN = value.UEN[0];

      springForm.subsidiaries.push(subsidiaries);
    });

    let loanAppliedTable = result["xfa:data"].form1[0].Declarations[0].TypeOfLoan[0].LoanApplied[0];

    springForm.invStockFinancing = Number(loanAppliedTable.InvStockFinancing[0].InvStockFinancingAmt[0]);
    springForm.workingCapital = Number(loanAppliedTable.WorkingCapital[0].WorkingCapitalAmt[0]);
    springForm.aRDiscount = Number(loanAppliedTable.ARDiscount[0].ARDiscountAmt[0]);
    springForm.capitalLoan = Number(loanAppliedTable.CapitalLoan[0].CapitalLoanAmt[0]);
    springForm.bankerGuarantee = Number(loanAppliedTable.BankerGuarantee[0].BankerGuranteeAmt[0]);
    springForm.total = Number(loanAppliedTable.Total[0].TotalLoanFacilityAmt[0]);



    springForm.loanDomesticTrade1 = Number(result["xfa:data"].form1[0].Declarations[0].TypeOfLoan[0].PurposeLoan[0].Row2[0].LoanDomesticTrade[0]);
    springForm.loanDomesticTrade2 = Number(result["xfa:data"].form1[0].Declarations[0].TypeOfLoan[0].PurposeLoan[0].Row2[0].LoanOverseasTrade[0]);


    return springForm;
  }

  /*

interface MyObj {
    myString: string;
    myNumber: number;
}

let obj: MyObj = JSON.parse('{ "myString": "string", "myNumber": 4 }');
console.log(obj.myString);
console.log(obj.myNumber);


  */

}

