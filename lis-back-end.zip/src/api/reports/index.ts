import * as Hapi from "hapi";
import Routes from "./routes";
import { IDatabase } from "../../database";
import { IServerConfigurations } from "../../configurations";
import EmailService from "../../services/email-service";
import GenerateReportService from "../../services/generater-report-service";

export function init(server: Hapi.Server, configs: IServerConfigurations, database: IDatabase, generateReportService: GenerateReportService) {
    Routes(server, configs, database, generateReportService);
}