import * as Hapi from "hapi";
import * as Joi from "joi";

import { jwtValidator } from "../users/user-validator";
import { IDatabase } from "../../database";
import { IServerConfigurations } from "../../configurations";
import * as ReportsValidator from './reports-validator';
import DocumentService from "../../services/document-service";
import GenerateReportService from "../../services/generater-report-service";
import ReportsController from "./reports-controller";

export default function (
  server: Hapi.Server,
  configs: IServerConfigurations,
  database: IDatabase,
  generateReportService: GenerateReportService
) {
  // const docService = new DocumentService();
  const reportsController = new ReportsController(configs, database, generateReportService);
  server.bind(reportsController);

  server.route({
    method: 'POST',
    path: '/report/generateReport',
    options: {
      handler: reportsController.generateReport,
      auth: false,
      tags: ['api', 'report'],
      description: 'Create a new other Claim request.',
      validate: {
        payload: ReportsValidator.generateReportModel,
        // headers: ClaimValidator.jwtValidator,
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '201': {
              description: 'Report Generated.'
            },
            '401': {
              description: 'User does not have authorization.'
            }
          }
        }
      }
    }
  });
}