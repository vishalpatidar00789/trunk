export class UobExportWeeklyOutstanding {
  uobAcraRefNo: string;
  uobNameofBorrower: string;
  uobInsurersApprovalDate: string;
  uobNatureOfApplication: string;
  uobLisApprovedLimit: string;
  uobLisPlusApprovalDate: string;
  uobLisPlusApprovedLimit: string;
  uobRemarks: string;
}

export class PfiExportWeeklyOutstanding {
  pfiAcraRefNo: string;
  pfiName: string;
  pfiNameofBorrower: string;
  pfiInsurersApprovalDate: string;
  pfiNatureOfApplication: string;
  pfiLisApprovedLimit: string;
  pfiLisPlusApprovalDate: string;
  pfiTopUpApprovedLimit: string;
  pfiLisPlusApprovedLimit: string;
  pfiRemarks: string;
}

export const fieldRequired = {
  'creditInfo.aCRArefNo': 1,
  'sponsorForm.ACRANo': 1,
  'creditInfo.lisType': 1,
  'creditInfo.internalRemark': 1,
  'creditInfo.insurersApprovalDate': 1,
  'creditInfo.lISPlusApprovedDate': 1,
  'creditInfo.lis5TotalApprovedLimit': 1,
  'creditInfo.pfiCode': 1,
  'creditInfo.primary': 1,
  'creditInfo.bg': 1,
  'creditInfo.autoTopUp': 1,
  'creditInfo.lisPlus': 1,
  'creditInfo.borrowerRegName': 1,
  'creditInfo.approvedAutoTopUpLayer': 1,
  _id: 0
};

export const styles: any = {
  headerDark: {
    fill: {
      fgColor: {
        rgb: 'FF000000'
      }
    },
    font: {
      color: {
        rgb: 'FFFFFFFF'
      },
      sz: 14,
      bold: true,
      underline: true
    }
  },
  cellPink: {
    fill: {
      fgColor: {
        rgb: 'FFFFCCFF'
      }
    }
  },
  cellGreen: {
    fill: {
      fgColor: {
        rgb: 'FF00FF00'
      }
    }
  }
};

export const uobHeaders = [
  {
    fieldName: 'uobAcraRefNo',
    displayName: 'ACRA Ref. No',
    headerStyle: this.styles.headerDark,
    width: 120
  },
  {
    fieldName: 'uobNameofBorrower',
    displayName: 'Name of Borrower',
    headerStyle: this.styles.headerDark,
    width: '10'
  },
  {
    fieldName: 'uobInsurersApprovalDate',
    displayName:
      "Insurer's Approval Date(per decision date in UOI endorsement)",
    headerStyle: this.styles.headerDark,
    type: 'date',
    width: 120
  },
  {
    fieldName: 'uobNatureOfApplication',
    displayName: 'Nature of Application',
    headerStyle: this.styles.headerDark,
    width: '22'
  },
  {
    fieldName: 'uobLisApprovedLimit',
    displayName: 'LIS 5 Approved Limit (UOI)',
    headerStyle: this.styles.headerDark,
    type: 'number',
    width: '22'
  },
  {
    fieldName: 'uobLisPlusApprovalDate',
    displayName: 'LIS+ Approval Date',
    headerStyle: this.styles.headerDark,
    type: 'date',
    width: '22'
  },
  {
    fieldName: 'uobLisPlusApprovedLimit',
    displayName: 'LIS+ Approval Limit',
    headerStyle: this.styles.headerDark,
    type: 'number',
    width: '22'
  },
  {
    fieldName: 'uobRemarks',
    displayName: 'LIS+ Approved Limit',
    headerStyle: this.styles.headerDark,
    width: '22'
  }
];

export const pfiHeaders = [
  {
    fieldName: 'pfiAcraRefNo',
    displayName: 'ACRA Ref. No', // <- Here you specify the column header
    headerStyle: this.styles.headerDark, // <- Header style
    width: 120
  },
  {
    fieldName: 'pfiName',
    displayName: 'PFI',
    headerStyle: this.styles.headerDark,
    width: 120
  },
  {
    fieldName: 'pfiNameofBorrower',
    displayName: 'Name of Borrower',
    headerStyle: this.styles.headerDark,
    width: '10'
  },
  {
    fieldName: 'pfiInsurersApprovalDate',
    displayName:
      "Insurers' Approval Date(per decision date in Coface endorsement)",
    headerStyle: this.styles.headerDark,
    type: 'date',
    width: 120
  },
  {
    fieldName: 'pfiNatureOfApplication',
    displayName: 'Nature of Application',
    headerStyle: this.styles.headerDark,
    width: '22'
  },
  {
    fieldName: 'pfiLisApprovedLimit',
    displayName: 'Approved LIS 5 Primary Limit',
    headerStyle: this.styles.headerDark,
    type: 'number',
    width: '22'
  },
  {
    fieldName: 'pfiLisPlusApprovalDate',
    displayName: 'LIS+ Approval Date',
    headerStyle: this.styles.headerDark,
    type: 'date',
    width: '22'
  },
  {
    fieldName: 'pfiTopUpApprovedLimit',
    displayName: 'Top Up Approved Limit',
    headerStyle: this.styles.headerDark,
    type: 'number',
    width: '22'
  },
  {
    fieldName: 'pfiLisPlusApprovedLimit',
    displayName: 'LIS+ Approval Limit',
    headerStyle: this.styles.headerDark,
    type: 'number',
    width: '22'
  },
  {
    fieldName: 'pfiRemarks',
    displayName: 'Remarks',
    headerStyle: this.styles.headerDark,
    width: '22'
  }
];
