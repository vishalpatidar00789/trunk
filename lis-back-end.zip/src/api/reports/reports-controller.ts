import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IServerConfigurations } from "../../configurations";
import { IDatabase } from "../../database";
import GenerateReportService from "../../services/generater-report-service";
import { IRequest } from "../../interfaces/request";
import { IApp } from "../master-data/app-management/app-management";
var xl = require('excel4node');


export default class ReportsController {

    constructor(private configs: IServerConfigurations, private database: IDatabase, private generateReportService: GenerateReportService) {
    }

    public async generateReport(request: IRequest, h: Hapi.ResponseToolkit) {
        console.log('Report generation starts');
        try {
            let payload = request.payload;
            let report = await this.generateReportService.generateReport(payload);
            // console.log('Report:' + JSON.stringify(report));
            if (report) {
                let workbook = report['filename'];
                console.log('Sending report starts');
                const date = new Date();
                const fileName = "app-report-" + date.getDay() + date.getMonth()
                    + date.getFullYear() + date.getHours() + date.getMinutes()
                    + date.getSeconds() + date.getMilliseconds() + ".xlsx";
                console.log("Approval ratio by APP file name:: " + fileName);
                // workbook.write(fileName);
                // console.log('Response: ' + JSON.stringify(response));
                console.log('Sending report ends');
                let response = h.response(workbook);
                response.header('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                response.header('Content-disposition', 'attachment; filename=' + fileName);
                return h.response({ status: 'Ok' });
            } else {
                console.log('Error generating report');
                return Boom.badData("Internal Server Error While generating report.");
            }
        } catch (err) {
            console.log(err);
            return Boom.badImplementation("Internal server error. Please contact admin.");
        }
    }
}
