import * as Hapi from "hapi";
import * as Joi from "joi";
import { IDatabase } from "../../database";
import { IServerConfigurations } from "../../configurations";
import SearchController from "./search-controller";
import * as SearchValidator from "./search-validator";
import SearchService from "../../services/search-service";
import SearchClaimService from "../../services/search-claim-service";

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const searchService = new SearchService(serverConfigs, database);
  const searchClaimService = new SearchClaimService(serverConfigs, database);
  const searchController = new SearchController(serverConfigs, database, searchService, searchClaimService);
  server.bind(searchController);

  server.route({
    method: 'POST',
    path: '/search-loan-adhoc-midterm',
    options: {
      handler: searchController.searchLoan,
      //auth: "jwt",
      auth: false,
      tags: ['api', 'search'],
      description: 'Search for loan/adhoc/midterm applications.',
      validate: {
        payload: SearchValidator.searchPayloadModel
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'list of all loan/adhoc/midterm applications.'
            },
            '401': {
              description: 'Please Login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/search-claim',
    options: {
      handler: searchController.searchClaim,
      //auth: "jwt",
      auth: false,
      tags: ['api', 'search'],
      description: 'Search for claims applications.',
      validate: {
        payload: SearchValidator.searchClaimPayloadModel
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'list of all claim applications.'
            },
            '401': {
              description: 'Please Login.'
            }
          }
        }
      }
    }
  });
}
