import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IDatabase } from "../../database";
import { IServerConfigurations } from "../../configurations";
import { IRequest, ILoginRequest, IUserCreate, IUserUpdate } from "../../interfaces/request";
import { ILoan } from "../loan/loan";
import SearchService from "../../services/search-service";
import SearchClaimService from "../../services/search-claim-service";

export default class SearchController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  private searchService: SearchService;
  private searchClaimService: SearchClaimService;

  constructor(configs: IServerConfigurations, database: IDatabase, searchService: SearchService, searchClaimService: SearchClaimService) {
    this.database = database;
    this.configs = configs;
    this.searchService = searchService;
    this.searchClaimService = searchClaimService;
  }

  public async searchLoan(request: IRequest, h: Hapi.ResponseToolkit) {
    let requestPayload: any = request['payload'];
    let query: any = {};

    console.log(requestPayload);

    const pfiCode: string[] = requestPayload.pfiCode;

    query = await this.searchService.buildQuery(requestPayload);
    if (query) {
      let result = [];
      let loans: any[] = await this.searchService.searchLoanDocuments(query);
      if (loans && loans.length > 0) {
        result = result.concat(loans);
      }
      let adhocs: any[] = await this.searchService.searchAdhocDocuments(query);
      if (adhocs && adhocs.length > 0) {
        result = result.concat(adhocs);
      }
      let midTerms: any[] = await this.searchService.searchMidTermDocuments(query);
      if (midTerms && midTerms.length > 0) {
        result = result.concat(midTerms);
      }
      // if (result && result.length > 1) {
      //   result = result.sort((a: any, b: any) => {
      //     let date1 = new Date(a["creditInfo.submissionDate"]),
      //       date2 = new Date(b["creditInfo.submissionDate"]);
      //     if (date1 < date2) { return -1; }
      //     if (date1 > date2) { return 1; }
      //     return 0;
      //   });
      // }
      return result;
    } else {
      return Boom.badData("Invalid Search Parameters");
    }

  }

  public async searchClaim(request: IRequest, h: Hapi.ResponseToolkit) {
    let requestPayload: any = request['payload'];
    let query: any = {};

    console.log(requestPayload);

    const pfiCode: string[] = requestPayload.pfiCode;

    query = await this.searchClaimService.buildQuery(requestPayload);
    if (query) {
      let result = [];
      let claims: any[] = await this.searchClaimService.searchClaimDocuments(query);
      if (claims && claims.length > 0) {
        result = result.concat(claims);
      }
      return result;
    } else {
      return Boom.badData("Invalid Search Parameters");
    }
  }

  // private async sortResults(results: any[]): Promise<any> {
  //   return new Promise<any>((resolve, reject) => {
  //     if (results && results.length > 1) {
  //       results.sort((a: any, b: any) => {
  //         let date1 = new Date(a["creditInfo.submissionDate"]),
  //           date2 = new Date(b["creditInfo.submissionDate"]);
  //         if (date1 < date2) { return -1; }
  //         if (date1 > date2) { return 1; }
  //         return 0;
  //       });
  //     }
  //   });
  // }
}
