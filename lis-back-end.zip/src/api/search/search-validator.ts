import * as Joi from "joi";
export const searchPayloadModel = Joi.object().keys({
    marshRefNo: Joi.string().allow("").allow(null).optional(),
    borrowerName: Joi.string().allow("").allow(null).optional(),
    uenNumber: Joi.string().allow("").allow(null).optional(),
    pfiCode: Joi.array().allow(null).optional(),
    consortium: Joi.string().allow("").allow(null).optional(),
    adverseStatus: Joi.string().allow("").allow(null).optional(),
    typeOfDate: Joi.string().allow("").allow(null).optional(),
    fromDate: Joi.any().allow("").allow(null).optional(),
    toDate: Joi.any().allow("").allow(null).optional(),
    natureOfApplication: Joi.array().allow(null).allow("").optional(),
    marshLoanApplicationStatus: Joi.array().allow(null).allow("").optional(),
    excludeExpiredApplications: Joi.boolean().allow("").allow(null).optional(),
    app: Joi.array().allow(null).optional(),
});

export const searchClaimPayloadModel = Joi.object().keys({
    marshRefNo: Joi.string().allow("").allow(null).optional(),
    borrowerName: Joi.string().allow("").allow(null).optional(),
    uenNumber: Joi.string().allow("").allow(null).optional(),
    pfiCode: Joi.array().allow(null).optional(),
    consortium: Joi.string().allow("").allow(null).optional(),
    tranche: Joi.number().allow(null).optional(),
    adverseStatus: Joi.string().allow("").allow(null).optional(),
    typeOfDate: Joi.string().allow("").allow(null).optional(),
    fromDate: Joi.any().allow("").allow(null).optional(),
    toDate: Joi.any().allow("").allow(null).optional(),
    natureOfApplication: Joi.array().allow(null).allow("").optional(),
    marshClaimApplicationStatus: Joi.array().allow(null).allow("").optional(),
    excludeExpiredApplications: Joi.boolean().allow("").allow(null).optional(),
    app: Joi.array().allow(null).optional(),
});
export const jwtValidator = Joi.object({ 'authorization': Joi.string().required() }).unknown();