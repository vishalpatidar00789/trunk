import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IPolicy } from "./policy";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest, ILoginRequest, } from "../../../interfaces/request";

export default class CapacityController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }


  public async createPolicy(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let policy: any = await this.database.policyModel.create(request.payload);
      return h.response(policy).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updatePolicy(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params["id"];
    try {
      let policy: IPolicy = await this.database.policyModel.findOneAndUpdate(
        { "_id": id },
        { $set: request.payload },
        { new: true }
      );
      return h.response(policy).code(202);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deletePolicy(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    let policy: IPolicy = await this.database.policyModel.findByIdAndRemove(id);

    return policy;
  }

  public async infoPolicy(request: IRequest, h: Hapi.ResponseToolkit) {

    const id = request.params.id;
    let policy: IPolicy = await this.database.policyModel.findById(id);
    if (policy) {
      return policy;
    } else {
      return Boom.notFound();
    }
  }

  public async getAllPolicies(request: IRequest, h: Hapi.ResponseToolkit) {
    let policy: IPolicy[] = await this.database.policyModel.find().lean(true);
    if (policy) {
      return policy;
    } else {
      return Boom.notFound();
    }
  }

  public async getLoanByPfiCode(request: IRequest, h: Hapi.ResponseToolkit) {
    const pfiCode = request.params['pfiCode'];
    try {
      let policy: IPolicy = await this.database.policyModel.findOne({ "pfiCode": pfiCode }).lean(true);
      if (policy) {
        return policy;
      } else {
        return Boom.notFound();
      }
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }


}
