import * as Joi from "joi";

export const createPolicyModel = Joi.object().keys({
    trancheId: Joi.string(),
    consortiumId: Joi.string(),
    pfiCode: Joi.string(),
    primaryLayer:Joi.number(),
    autoTopUpLayer: Joi.string(),
    bgLayer: Joi.string(),
    lisPlusLayer: Joi.string(),
    activated: Joi.boolean(),
    createdBy: Joi.string(),
    createdDate: Joi.string(),
    lastModifiedBy: Joi.string(),
    lastModifiedDate: Joi.string()
});

export const jwtValidator = Joi.object({ 'authorization': Joi.string().required() }).unknown();