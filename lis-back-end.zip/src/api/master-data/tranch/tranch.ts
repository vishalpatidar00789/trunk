import * as Mongoose from "mongoose";

export interface ITranch extends Mongoose.Document {
  trancheName: string;
  fromDate: string;
  toDate: string;
  activated: boolean;
  createdBy: string;
  createdDate: string;
  lastModifiedBy: string;
  lastModifiedDate: string;
}

export const TranchSchema = new Mongoose.Schema(
  {
    trancheName: { type: String },
    fromDate: { type: String },
    toDate: { type: String },
    activated: { type: Boolean },
    createdBy: { type: String },
    createdDate: { type: String },
    lastModifiedBy: { type: String },
    lastModifiedDate: { type: String }
  }
);
var diffHistory = require("mongoose-diff-history/diffHistory");
TranchSchema.plugin(diffHistory.plugin);
export const TranchModel = Mongoose.model<ITranch>("Tranch", TranchSchema);
