import * as Hapi from "hapi";
import * as Joi from "joi";
import CapacityController from "./capacity-controller";
import * as CapacityValidator from "./capacity-validator";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import EmailService from "../../../services/email-service";

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase,
  emailService: EmailService
) {
  const capacityController = new CapacityController(serverConfigs, database, emailService);
  server.bind(capacityController);

  server.route({
    method: "GET",
    path: "/master-data/capacity/{id}",
    options: {
      handler: capacityController.infoCapacity,
      auth: false,
      tags: ["api", "capacity"],
      description: "Get capacity info.",
      validate: {
        params: {
          id: Joi.string().required()
        }
        //headers: CapacityValidator.createCapacityModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Capacity found."
            },
            "404": {
              description: "Capacity does not exists."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/master-data/capacity/{id}",
    options: {
      handler: capacityController.deleteCapacity,
      auth: false,
      tags: ["api", "capacity"],
      description: "Delete current capacity.",
      validate: {
        payload: CapacityValidator.createCapacityModel,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Capacity deleted."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/master-data/capacity/{id}",
    options: {
      handler: capacityController.updateCapacity,
      auth: false,
      tags: ["api", "capacity"],
      description: "Update capacity info.",
      validate: {
        params: {
          id: Joi.string().required()
        },
        payload: CapacityValidator.createCapacityModel
        //headers: CapacityValidator.createCapacityModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated info."
            }

          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/master-data/capacity",
    options: {
      handler: capacityController.createCapacity,
      auth: false,
      tags: ["api", "capacity"],
      description: "Create a capacity.",
      validate: {
        payload: CapacityValidator.createCapacityModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "Capacity created."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/master-data/capacity",
    options: {
      handler: capacityController.getAllCapacities,
      auth: false,
      tags: ["api", "capacity"],
      description: "Get list of capacities",
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "capacity list is fetched"
            }
          }
        }
      }
    }
  });
}
