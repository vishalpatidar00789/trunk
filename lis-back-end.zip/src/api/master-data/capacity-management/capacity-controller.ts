import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { ICapacity } from "./capacity";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest, ILoginRequest, IMailOptions, } from "../../../interfaces/request";
import EmailService from "../../../services/email-service";

export default class CapacityController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  constructor(configs: IServerConfigurations, database: IDatabase, private emailService: EmailService) {
    this.database = database;
    this.configs = configs;
  }


  public async createCapacity(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let capacity: any = await this.database.capacityModel.create(request.payload);
      return h.response(capacity).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateCapacity(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    try {
      let capacity: ICapacity = await this.database.capacityModel.findOneAndUpdate(
        { "_id": id },
        { $set: request.payload },
        { new: true }
      );
      return h.response(capacity).code(202);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  private sendCapacityExceedAlertMail() {
    let consortiumName = '';
    let allocatedCapacity = '';
    let usedCapacity = '';
    let app = '';

    //TO MARSH USER
    let emailOptions2 = new IMailOptions();
    emailOptions2.from = this.configs.systemEmail;
    emailOptions2.to = 'Upendra.Krishtam01@marsh.com';
    emailOptions2.subject = `QA- ${consortiumName} - Capacity allocation alert`;
    emailOptions2.html = `Dear Marsh Users<br><br>
                    ${consortiumName} has exceeded over 70% of the allocated capacity on <DD MMM YYYY>.<br>
                    APP:                ${app} <br>
                    Consortium Name:    ${consortiumName}<br>
                    Allocated Capacity: ${allocatedCapacity}<br>
                    Used Capacity:      ${usedCapacity}<br>
                    <br><br>
                    Note: This is an automated email sent from Marsh's Loan Insurance Scheme Portal. Please do not reply to this email.`;
    this.emailService.sendEmail(emailOptions2);
  }

  public async deleteCapacity(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    let capacity: ICapacity = await this.database.capacityModel.findByIdAndRemove(id);

    return capacity;
  }

  public async infoCapacity(request: IRequest, h: Hapi.ResponseToolkit) {

    const id = request.params.id;
    let capacity: ICapacity = await this.database.capacityModel.findById(id);
    if (capacity) {
      return capacity;
    } else {
      return Boom.notFound();
    }
  }

  public async getAllCapacities(request: IRequest, h: Hapi.ResponseToolkit) {
    let capacity: ICapacity[] = await this.database.capacityModel.find().lean(true);
    if (capacity) {
      return capacity;
    } else {
      return Boom.notFound();
    }
  }
}
