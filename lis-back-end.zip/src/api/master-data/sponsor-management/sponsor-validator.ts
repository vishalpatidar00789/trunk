import * as Joi from "joi";

export const createSponsorModel = Joi.object().keys({
    trancheId: Joi.string(),
    sponsorName: Joi.string(),
    sponsorPremiumSubsidyPercentage: Joi.number(),
    activated: Joi.boolean(),
    sponsorList: Joi.array().items({
        _id: false,
        consortiumId: Joi.string(),
        initialLISCapacity: Joi.number(),
        primaryPolicyPremiumRate: Joi.number(),
        OTDPercentage: Joi.number(),
        OTDAmount: Joi.number()
    }),
    createdBy: Joi.string(),
    createdDate: Joi.string(),
    lastModifiedBy: Joi.string(),
    lastModifiedDate: Joi.string()
});

export const jwtValidator = Joi.object({ 'authorization': Joi.string().required() }).unknown();