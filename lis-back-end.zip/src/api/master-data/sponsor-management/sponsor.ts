import * as Mongoose from "mongoose";

export interface ISponsor extends Mongoose.Document {

  trancheId: string;
  sponsorName: string;
  sponsorPremiumSubsidyPercentage: number;
  activated: boolean;
  sponsorList: [{
    _id: boolean,
    consortiumId: string,
    initialLISCapacity: number,
    primaryPolicyPremiumRate: number,
    OTDPercentage: number,
    OTDAmount: number
  }];
  createdBy: string;
  createdDate: string;
  lastModifiedBy: string;
  lastModifiedDate: string;
}

export const SponsorSchema = new Mongoose.Schema(
  {
    trancheId: { type: String },
    sponsorName: { type: String },
    sponsorPremiumSubsidyPercentage: { type: Number },
    activated: { type: Boolean },
    sponsorList: [{
      _id: false,
      consortiumId: { type: String },
      initialLISCapacity: { type: Number },
      primaryPolicyPremiumRate: { type: Number },
      OTDPercentage: { type: Number },
      OTDAmount: { type: Number }
    }],
    createdBy: { type: String },
    createdDate: { type: String },
    lastModifiedBy: { type: String },
    lastModifiedDate: { type: String }
  }
);

var diffHistory = require("mongoose-diff-history/diffHistory");
SponsorSchema.plugin(diffHistory.plugin);
export const SponsorModel = Mongoose.model<ISponsor>("Sponsor", SponsorSchema);
