import * as Hapi from "hapi";
import * as Joi from "joi";
import SponsorController from "./sponsor-controller";
import * as SponsorValidator from "./sponsor-validator";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const sponsorController = new SponsorController(serverConfigs, database);
  server.bind(sponsorController);

  server.route({
    method: "GET",
    path: "/master-data/sponsor/{id}",
    options: {
      handler: sponsorController.infoSponsor,
      auth: false,
      tags: ["api", "sponsor"],
      description: "Get Sponsor info.",
      validate: {
        params: {
          id: Joi.string().required()
        }
        //headers: SponsorValidator.createSponsorModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Sponsor found."
            },
            "404": {
              description: "Sponsor does not exists."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/master-data/sponsor/{id}",
    options: {
      handler: sponsorController.deleteSponsor,
      auth: false,
      tags: ["api", "sponsor"],
      description: "Delete current Sponsor .",
      validate: {
        params: {
          id: Joi.string().required()
        },
       },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Sponsor deleted."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/master-data/sponsor/{id}",
    options: {
      handler: sponsorController.updateSponsor,
      auth: false,
      tags: ["api", "sponsor"],
      description: "Update Sponsor info.",
      validate: {
        payload: SponsorValidator.createSponsorModel,
        params: {
          id: Joi.string().required()
        }
 },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated info."
            }

          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/master-data/sponsor",
    options: {
      handler: sponsorController.createSponsor,
      auth: false,
      tags: ["api", "sponsor"],
      description: "Create a Sponsor.",
      validate: {
        payload: SponsorValidator.createSponsorModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "Sponsor created."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/master-data/sponsor",
    options: {
      handler: sponsorController.getAllSponsors,
      auth: false,
      tags: ["api", "sponsor"],
      description: "Get list of Sponsor",
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "Sponsor list is fetched"
            }
          }
        }
      }
    }
  });
}
