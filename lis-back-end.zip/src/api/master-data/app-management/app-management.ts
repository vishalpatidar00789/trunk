import * as Mongoose from "mongoose";

export interface IApp extends Mongoose.Document {
  trancheId: string;
  app: number;
  appFrom: string;
  appto: string;
  activated: boolean;
  createdBy: string;
  lastModifiedBy: string;
  createdDate: string;
  lastModifiedDate: string;
}

export const AppSchema = new Mongoose.Schema(
  {
    trancheId: { type: String },
    app: { type: Number },
    appFrom: { type: String },
    appto: { type: String },
    activated: { type: Boolean },
    createdBy: { type: String },
    lastModifiedBy: { type: String },
    createdDate: { type: String },
    lastModifiedDate: { type: String }
  }
);
var diffHistory = require("mongoose-diff-history/diffHistory");
AppSchema.plugin(diffHistory.plugin);

export const AppModel = Mongoose.model<IApp>("App", AppSchema);
