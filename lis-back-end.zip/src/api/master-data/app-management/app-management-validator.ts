import * as Joi from "joi";

export const createAppModel = Joi.object().keys({

    trancheId: Joi.string(),
    app: Joi.number(),
    appFrom: Joi.string(),
    appto: Joi.string(),
    activated: Joi.boolean(),
    createdBy: Joi.string(),
    lastModifiedBy: Joi.string(),
    createdDate: Joi.string(),
    lastModifiedDate: Joi.string()
});

export const jwtValidator = Joi.object({ 'authorization': Joi.string().required() }).unknown();