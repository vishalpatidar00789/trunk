import * as Hapi from "hapi";
import * as Joi from "joi";
import AppController from "./app-management-controller";
import { AppModel } from "./app-management";
import * as AppValidator from "./app-management-validator";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const appController = new AppController(serverConfigs, database);
  server.bind(appController);

  server.route({
    method: "GET",
    path: "/master-data/app-management/{id}",
    options: {
      handler: appController.infoApp,
      auth: false,
      tags: ["api", "app"],
      description: "Get app info.",
      validate: {
        params: {
          id: Joi.string().required()
        }
        //headers: AppValidator.createAppModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "App found."
            },
            "404": {
              description: "App does not exists."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/master-data/app-management/{id}",
    options: {
      handler: appController.deleteApp,
      auth: false,
      tags: ["api", "app"],
      description: "Delete current app.",
      validate: {
        //headers: AppValidator.createAppModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "App deleted."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/master-data/app-management/{id}",
    options: {
      handler: appController.updateApp,
      auth: false,
      tags: ["api", "app"],
      description: "Update app info.",
      validate: {
        params: {
          id: Joi.string().required()
        },
        payload: AppValidator.createAppModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated info."
            }

          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/master-data/app-management",
    options: {
      handler: appController.createApp,
      auth: false,
      tags: ["api", "app"],
      description: "Create a app.",
      validate: {
        payload: AppValidator.createAppModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "App created."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/master-data/app-management",
    options: {
      handler: appController.getAllApps,
      auth: false,
      tags: ["api", "app"],
      description: "Get list of apps",
      validate: {
       // headers: AppValidator.createAppModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "app list is fetched"
            }
          }
        }
      }
    }
  });
}
