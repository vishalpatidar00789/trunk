import * as Mongoose from "mongoose";

export interface IConsortium extends Mongoose.Document {
  consortiumName: string;
  pfis: string[];
  activated: boolean;
  createdBy: string;
  createdDate: string;
  lastModifiedBy: string;
  lastModifiedDate: string;
}

export const ConsortiumSchema = new Mongoose.Schema(
  {
    consortiumName: { type: String },
    activated: { type: Boolean },
    pfis: { type: [] },
    createdBy: { type: String },
    createdDate: { type: String },
    lastModifiedBy: { type: String },
    lastModifiedDate: { type: String }
  }
);
var diffHistory = require("mongoose-diff-history/diffHistory");
ConsortiumSchema.plugin(diffHistory.plugin);
export const ConsortiumModel = Mongoose.model<IConsortium>("Consortium", ConsortiumSchema);
