import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IBrokerage } from "./brokerage";
import { IDatabase } from "../../../../database";
import { IServerConfigurations } from "../../../../configurations";
import { IRequest, ILoginRequest, } from "../../../../interfaces/request";

export default class BrokerageController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }


  public async createBrokerage(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let brokerage: any = await this.database.brokerageModel.create(request.payload);
      return h.response(brokerage).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateBrokerage(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    try {
      let brokerage: IBrokerage = await this.database.brokerageModel.findOneAndUpdate(
        { "_id": id },
        { $set: request.payload },
        { new: true }
      );
      return h.response(brokerage).code(202);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteBrokerage(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    let brokerage: IBrokerage = await this.database.brokerageModel.findByIdAndRemove(id);

    return brokerage;
  }

  public async infoBrokerage(request: IRequest, h: Hapi.ResponseToolkit) {

    const id = request.params.id;
    let brokerage: IBrokerage = await this.database.brokerageModel.findById(id);
    if (brokerage) {
      return brokerage;
    } else {
      return Boom.notFound();
    }
  }

  public async getAllBrokerages(request: IRequest, h: Hapi.ResponseToolkit) {
    let brokerage: IBrokerage[] = await this.database.brokerageModel.find().lean(true);
    if (brokerage) {
      return brokerage;
    } else {
      return Boom.notFound();
    }
  }
}
