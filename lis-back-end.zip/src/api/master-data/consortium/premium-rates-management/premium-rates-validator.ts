import * as Joi from "joi";

export const createPremiumRatesModel = Joi.object().keys({
    trancheId: Joi.string(),
    consortiumId: Joi.string(),
    primaryLayer: Joi.string(),
    topUpLayer: Joi.string(),
    BGLayer: Joi.string(),
    LISPlusLayer: Joi.string(),
    activated: Joi.boolean(),
    createdBy: Joi.string(),
    createdDate: Joi.string(),
    lastModifiedBy: Joi.string(),
    lastModifiedDate: Joi.string()
});

export const jwtValidator = Joi.object({ 'authorization': Joi.string().required() }).unknown();