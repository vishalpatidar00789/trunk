import * as Mongoose from "mongoose";

export interface IPremiumRates extends Mongoose.Document {

  trancheId: string;
  consortiumId: string;
  primaryLayer: string;
  TopUpLayer: string;
  BGLayer: string;
  LISPlusLayer: string;
  activated: boolean;
  createdBy: string;
  createdDate: string;
  lastModifiedBy: string;
  lastModifiedDate: string;
}

export const PremiumRatesSchema = new Mongoose.Schema(
  {
    trancheId: { type: String },
    consortiumId: { type: String },
    primaryLayer: { type: String },
    TopUpLayer: { type: String },
    BGLayer: { type: String },
    LISPlusLayer: { type: String },
    activated: { type: Boolean },
    createdBy: { type: String },
    createdDate: { type: String },
    lastModifiedBy: { type: String },
    lastModifiedDate: { type: String }
  }
);

var diffHistory = require("mongoose-diff-history/diffHistory");
PremiumRatesSchema.plugin(diffHistory.plugin);
export const PremiumRatesModel = Mongoose.model<IPremiumRates>("PremiumRates", PremiumRatesSchema);
