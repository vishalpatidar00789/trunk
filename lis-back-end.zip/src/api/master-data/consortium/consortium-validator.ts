import * as Joi from "joi";

export const consortiumModel = Joi.object().keys({
    consortiumName: Joi.string().required(),
    activated: Joi.boolean().required(),
    pfis: Joi.array().items(Joi.string()),
    createdBy: Joi.string(),
    createdDate: Joi.string(),
    lastModifiedBy: Joi.string(),
    lastModifiedDate: Joi.string()
});

export const jwtValidator = Joi.object({'authorization': Joi.string().required()}).unknown();