import * as Joi from "joi";

export const createTierRatingModel = Joi.object().keys({
    trancheId: Joi.string(),
    consortiumId: Joi.string(),
    tierRatingDescription: Joi.string(),
    from: Joi.number(),
    to: Joi.number(),
    premiumRatePercentage: Joi.number(),
    activated: Joi.boolean(),
    createdBy: Joi.string(),
    createdDate: Joi.string(),
    lastModifiedBy: Joi.string(),
    lastModifiedDate: Joi.string()
});

export const jwtValidator = Joi.object({ 'authorization': Joi.string().required() }).unknown();