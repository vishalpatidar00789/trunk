import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { ITierRating } from "./tier-rating";
import { IDatabase } from "../../../../database";
import { IServerConfigurations } from "../../../../configurations";
import { IRequest, ILoginRequest, } from "../../../../interfaces/request";

export default class TierRatingController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }


  public async createTierRating(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let tierRating: any = await this.database.tierRatingModel.create(request.payload);
      return h.response(tierRating).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateTierRating(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    try {
      let tierRating: ITierRating = await this.database.tierRatingModel.findOneAndUpdate(
        { "_id": id },
        { $set: request.payload },
        { new: true }
      );
      return h.response(tierRating).code(202);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteTierRating(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    let tierRating: ITierRating = await this.database.tierRatingModel.findByIdAndRemove(id);

    return tierRating;
  }

  public async infoTierRating(request: IRequest, h: Hapi.ResponseToolkit) {

    const id = request.params.id;
    let tierRating: ITierRating = await this.database.tierRatingModel.findById(id);
    if (tierRating) {
      return tierRating;
    } else {
      return Boom.notFound();
    }
  }

  public async getAllTierRatings(request: IRequest, h: Hapi.ResponseToolkit) {
    let tierRating: ITierRating[] = await this.database.tierRatingModel.find().lean(true);
    if (tierRating) {
      return tierRating;
    } else {
      return Boom.notFound();
    }
  }
}
