import * as Mongoose from "mongoose";

export interface ITierRating extends Mongoose.Document {

  trancheId: string;
  consortiumId: string;
  tierRatingDescription: string;
  from: number;
  to: number;
  premiumRatePercentage: number;
  activated: boolean;
  createdBy: string;
  createdDate: string;
  lastModifiedBy: string;
  lastModifiedDate: string;
}

export const TierRatingSchema = new Mongoose.Schema(
  {
    trancheId: { type: String },
    consortiumId: { type: String },
    tierRatingDescription: { type: String },
    from: { type: Number },
    to: { type: Number },
    premiumRatePercentage: { type: Number },
    activated: { type: Boolean },
    createdBy: { type: String },
    createdDate: { type: String },
    lastModifiedBy: { type: String },
    lastModifiedDate: { type: String }
  }
);

var diffHistory = require("mongoose-diff-history/diffHistory");
TierRatingSchema.plugin(diffHistory.plugin);
export const TierRatingModel = Mongoose.model<ITierRating>("TierRating", TierRatingSchema);
