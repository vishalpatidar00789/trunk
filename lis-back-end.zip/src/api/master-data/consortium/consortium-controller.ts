import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest, IConsortiumPayload } from "../../../interfaces/request";
import { IConsortium } from "./consortium";

export default class ConsortiumController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }

  public async createConsortium(request: IConsortiumPayload, h: Hapi.ResponseToolkit) {
    try {
      let consortium: any = await this.database.consortiumModel.create(request.payload);
      return consortium;
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateConsortium(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    try {
      let consortium: IConsortium = await this.database.consortiumModel.findOneAndUpdate(
        { "_id": id },
        { $set: request.payload },
        { new: true }
      );
      return h.response(consortium).code(202);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteConsortium(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    let consortium: IConsortium = await this.database.consortiumModel.findByIdAndRemove(id);

    return consortium;
  }

  public async infoConsortium(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    let consortium: IConsortium = await this.database.consortiumModel.findById(id);
    if (consortium) {
      delete consortium["__v"];
      return consortium;
    } else {
      return Boom.notFound();
    }
  }

  public async getAllConsortiumes(request: IRequest, h: Hapi.ResponseToolkit) {
    let consortium: IConsortium[] = await this.database.consortiumModel.find().lean(true);
    if (consortium) {
      return consortium;
    } else {
      return Boom.notFound();
    }
  }
}
