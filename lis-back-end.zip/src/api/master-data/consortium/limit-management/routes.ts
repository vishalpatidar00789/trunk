import * as Hapi from "hapi";
import * as Joi from "joi";
import LimitController from "./limit-controller";
import * as LimitValidator from "./limit-validator";
import { IDatabase } from "../../../../database";
import { IServerConfigurations } from "../../../../configurations";

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const limitController = new LimitController(serverConfigs, database);
  server.bind(limitController);

  server.route({
    method: "GET",
    path: "/master-data/consortium/limit/{id}",
    options: {
      handler: limitController.infoLimit,
      auth: false,
      tags: ["api", "limit"],
      description: "Get limit info.",
      validate: {
        params: {
          id: Joi.string().required()
        }
        //headers: LimitValidator.createLimitModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Limit found."
            },
            "404": {
              description: "Limit does not exists."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/master-data/consortium/limit/{id}",
    options: {
      handler: limitController.deleteLimit,
      auth: false,
      tags: ["api", "limit"],
      description: "Delete current limit.",
      validate: {
        params: {
          id: Joi.string().required()
        },
       },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Limit deleted."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/master-data/consortium/limit/{id}",
    options: {
      handler: limitController.updateLimit,
      auth: false,
      tags: ["api", "limit"],
      description: "Update limit info.",
      validate: {
        params: {
          id: Joi.string().required()
        },
        payload: LimitValidator.createLimitModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated info."
            }

          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/master-data/consortium/limit",
    options: {
      handler: limitController.createLimit,
      auth: false,
      tags: ["api", "limit"],
      description: "Create a limit.",
      validate: {
        payload: LimitValidator.createLimitModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "Limit created."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/master-data/consortium/limit",
    options: {
      handler: limitController.getAllLimits,
      auth: false,
      tags: ["api", "limit"],
      description: "Get list of limits",
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "Limit list is fetched"
            }
          }
        }
      }
    }
  });
}
