import * as Mongoose from "mongoose";

export interface ILimit extends Mongoose.Document {

  trancheId: string;
  consortiumId: string;
  applicationType: string;
  maximumLimit: number;
  activated: boolean;
  createdBy: string;
  createdDate: string;
  lastModifiedBy: string;
  lastModifiedDate: string;
}

export const LimitSchema = new Mongoose.Schema(
  {
    trancheId: { type: String },
    consortiumId: { type: String },
    applicationType: { type: String },
    maximumLimit: { type: Number },
    premiumRatePercentage: { type: Number },
    activated: { type: Boolean },
    createdBy: { type: String },
    createdDate: { type: String },
    lastModifiedBy: { type: String },
    lastModifiedDate: { type: String }
  }
);

var diffHistory = require("mongoose-diff-history/diffHistory");
LimitSchema.plugin(diffHistory.plugin);
export const LimitModel = Mongoose.model<ILimit>("Limit", LimitSchema);
