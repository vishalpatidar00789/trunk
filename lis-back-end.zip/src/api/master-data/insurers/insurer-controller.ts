import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest, IInsurerPayload } from "../../../interfaces/request";
import { IInsurer } from "./insurer";

export default class InsurerController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }

  public async createInsurer(request: IInsurerPayload, h: Hapi.ResponseToolkit) {
    try {
      let insurer: any = await this.database.insurerModel.create(request.payload);
      return insurer;
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateInsurer(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    try {
      let insurer: IInsurer = await this.database.insurerModel.findOneAndUpdate(
        { "_id": id },
        { $set: request.payload },
        { new: true }
      );
      return h.response(insurer).code(202);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteInsurer(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    let insurer: IInsurer = await this.database.insurerModel.findByIdAndRemove(id);

    return insurer;
  }

  public async infoInsurer(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    let insurer: IInsurer = await this.database.insurerModel.findById(id);
    if (insurer) {
      delete insurer["__v"];
      return insurer;
    } else {
      return Boom.notFound();
    }
  }

  public async getAllInsureres(request: IRequest, h: Hapi.ResponseToolkit) {
    let insurer: IInsurer[] = await this.database.insurerModel.find().lean(true);
    if (insurer) {
      return insurer;
    } else {
      return Boom.notFound();
    }
  }
}
