import * as Hapi from "hapi";
import * as Joi from "joi";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import InsurerController from "./insurer-controller";
import * as InsurerValidator from "./insurer-validator";

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const insurerController = new InsurerController(serverConfigs, database);
  server.bind(insurerController);

  server.route({
    method: "GET",
    path: "/master-data/insurer/{id}",
    options: {
      handler: insurerController.infoInsurer,
      auth: false,
      tags: ["api", "insurer"],
      description: "Get insurer info.",
      validate: {
        params: {
          id: Joi.string().required()
        }
       // headers: InsurerValidator.insurerModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Insurer found."
            },
            "404": {
              description: "Insurer does not exists."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/master-data/insurer/{id}",
    options: {
      handler: insurerController.deleteInsurer,
      auth: false,
      tags: ["api", "insureres"],
      description: "Delete current insurer.",
      validate: {
        params: {
          id: Joi.string().required()
        }
       // headers: InsurerValidator.insurerModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Insurer deleted."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/master-data/insurer/{id}",
    options: {
      handler: insurerController.updateInsurer,
      auth: false,
      tags: ["api", "insurer"],
      description: "Update insurer info.",
      validate: {
        payload: InsurerValidator.insurerModel,
        params: {
          id: Joi.string().required()
        }
       // headers: InsurerValidator.insurerModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated info."
            }

          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/master-data/insurer",
    options: {
      handler: insurerController.createInsurer,
      auth: false,
      tags: ["api", "insurer"],
      description: "Create a insurer.",
      validate: {
        payload: InsurerValidator.insurerModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "insurer created."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/master-data/insurer",
    options: {
      handler: insurerController.getAllInsureres,
      auth: false,
      tags: ["api", "insurer"],
      description: "Get list of insurers",
      validate: {
        //headers: InsurerValidator.insurerModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "insurer list is fetched"
            }
          }
        }
      }
    }
  });
}
