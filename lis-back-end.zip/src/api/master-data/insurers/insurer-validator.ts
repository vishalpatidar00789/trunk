import * as Joi from "joi";

export const insurerModel = Joi.object().keys({
    insurerName: Joi.string().required(),
    registrationNUmber: Joi.string().required(),
    isLead: Joi.boolean().required(),
    isCoInsurer: Joi.boolean().required(),
    coInsurerProportion: Joi.number(),
    consortiumId: Joi.string(),
    activated: Joi.boolean().required(),
    createdBy: Joi.string(),
    createdDate: Joi.string(),
    lastModifiedBy: Joi.string(),
    lastModifiedDate: Joi.string()
});

export const jwtValidator = Joi.object({'authorization': Joi.string().required()}).unknown();