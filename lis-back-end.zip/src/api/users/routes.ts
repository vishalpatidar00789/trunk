import * as Hapi from "hapi";
import * as Joi from "joi";
import UserController from "./user-controller";
import { UserModel } from "./user";
import * as UserValidator from "./user-validator";
import { IDatabase } from "../../database";
import { IServerConfigurations, ILdapConfigurations, IMfaConfiguration } from "../../configurations";
import UserService from "../../services/user-service";
import EmailService from "../../services/email-service";
import LDAPAuthService from "../../services/ldap-auth-service";
import MfaService from "../../services/mfa-service";

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase,
  emailService: EmailService,
  ldapConfig: ILdapConfigurations,
  mfaConfig: IMfaConfiguration
) {
  const ldapService = new LDAPAuthService(ldapConfig);
  const userService = new UserService(serverConfigs, database, emailService, ldapService);
  const mfaService = new MfaService(emailService, mfaConfig);
  const userController = new UserController(serverConfigs, database, userService, emailService, mfaService);
  server.bind(userController);

  server.route({
    method: "GET",
    path: "/users/{id}",
    options: {
      handler: userController.infoUser,
      auth: "jwt",
      tags: ["api", "users"],
      description: "Get user info.",
      validate: {
        params: {
          id: Joi.string().required()
        },
        headers: UserValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "User found."
            },
            "401": {
              description: "Please login."
            },
            "404": {
              description: "User does not exists."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/users/{id}",
    options: {
      handler: userController.deleteUser,
      auth: "jwt",
      tags: ["api", "users"],
      description: "Delete current user.",
      validate: {
        params: {
          id: Joi.string().required()
        },
        headers: UserValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "User deleted."
            },
            "401": {
              description: "User does not have authorization."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/users",
    options: {
      handler: userController.updateUser,
      auth: "jwt",
      tags: ["api", "users"],
      description: "Update current user info.",
      validate: {
        payload: UserValidator.updateUserModel,
        headers: UserValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated info."
            },
            "401": {
              description: "User does not have authorization."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/users",
    options: {
      handler: userController.createUser,
      auth: false,
      tags: ["api", "users"],
      description: "Create a user.",
      validate: {
        // headers: UserValidator.jwtValidator,
        payload: UserValidator.createUserModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "User created."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/users",
    options: {
      handler: userController.getAllUsers,
      auth: "jwt",
      tags: ["api", "users"],
      description: "Get list of users",
      validate: {
        headers: UserValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "user list is fetched"
            }
          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/authenticate",
    options: {
      handler: userController.loginUser,
      auth: false,
      tags: ["api", "users"],
      description: "Login a user.",
      validate: {
        payload: UserValidator.loginUserModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "User found."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/useraccount",
    options: {
      handler: userController.getUserAccount,
      auth: "jwt",
      tags: ["api", "users"],
      description: "get user account.",
      validate: {
        headers: UserValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "User account found."
            }
          }
        }
      }
    }
  });
  server.route({
    method: "POST",
    path: "/users/change-password",
    options: {
      handler: userController.changePassword,
      auth: "jwt",
      tags: ["api", "users"],
      description: "Change Password.",
      validate: {
        payload: UserValidator.changePasswordModel,
        headers: UserValidator.jwtValidator
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Password changed."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/users/reset-password/{user}",
    options: {
      handler: userController.resetPassword,
      auth: false,
      tags: ["api", "users"],
      description: "Reset Password.",
      validate: {
        payload: UserValidator.accountModel,
        params: {
          user: Joi.string().required()
        },
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Password reset."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/users/lock-account",
    options: {
      handler: userController.lockAccount,
      auth: false,
      tags: ["api", "users"],
      description: "Lock Account.",
      validate: {
        payload: UserValidator.accountModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Account locked."
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/users/generate-otp',
    options: {
      handler: userController.generateOTP,
      auth: "jwt",
      tags: ['api', 'users'],
      description: 'MFA Generate OTP',
      validate: {
        headers: UserValidator.jwtValidator,
        payload: UserValidator.genOtpPayload
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'OTP Generated.'
            },
            '401': {
              description: 'Please login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/users/verify-otp',
    options: {
      handler: userController.verifyOTP,
      auth: "jwt",
      tags: ['api', 'loan'],
      description: 'MFA Test',
      validate: {
        headers: UserValidator.jwtValidator,
        payload: UserValidator.verifyOtpPayload
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'OTP Verified'
            },
            '401': {
              description: 'Please login.'
            }
          }
        }
      }
    }
  });
}
