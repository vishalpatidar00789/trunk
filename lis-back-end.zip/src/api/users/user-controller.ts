import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IUser } from "./user";
import { IDatabase } from "../../database";
import { IServerConfigurations } from "../../configurations";
import { IRequest, ILoginRequest, IUserCreate, IUserUpdate, IChangePassword, IAccount, IMailOptions, IGenOTP, IOTPVerify } from "../../interfaces/request";
import UserService from "../../services/user-service";
import EmailService from "../../services/email-service";
import MfaService from "../../services/mfa-service";

export default class UserController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase, private userService: UserService,
    private emailService: EmailService, private mfaService: MfaService) {
    this.database = database;
    this.configs = configs;
  }

  private generateToken(user: IUser) {
    const jwtSecret = this.configs.jwtSecret;
    const jwtExpiration = this.configs.jwtExpiration;
    const payload = { id: user.login };

    return Jwt.sign(payload, jwtSecret, { expiresIn: jwtExpiration });
  }

  public async loginUser(request: ILoginRequest, h: Hapi.ResponseToolkit) {
    try {
      const { userId, password } = request.payload;
      const result: any = await this.userService.authenticateUser(userId, password);
      if (result && result.opCode === 200) {
        return { token: this.generateToken(result.data) };
      } else if (result && result.opCode === 404) {
        return Boom.notFound(result.msg);
      } else if (result && result.opCode === 401) {
        return Boom.unauthorized(result.msg);
      } else if (result && result.opCode === 423) {
        return Boom.locked(result.msg);
      } else if (result && result.opCode === 500) {
        return Boom.internal(result.msg);
      } else {
        return Boom.internal("Internal server error.");
      }
    } catch (error) {
      return Boom.badImplementation("Internal server error.");
    }
  }

  public async getUserAccount(request: ILoginRequest, h: Hapi.ResponseToolkit) {
    try {
      const userId = request.auth.credentials.id;
      console.log("user id from decoded token:: " + JSON.stringify(userId));
      let user: IUser = await this.database.userModel.findOne({ login: userId });
      if (!user) {
        return Boom.unauthorized("User not found.");
      }
      delete user["__v"]; delete user["password"];
      const response = h.response(user);
      response.header("Authorization", request.headers.Authorization);
      return response;
    } catch (error) {
      return Boom.badImplementation("Internal server error.");
    }
  }

  public async createUser(request: IUserCreate, h: Hapi.ResponseToolkit) {
    try {
      console.log(request.payload);
      const result: any = await this.userService.createUser(request.payload);
      if (result && result.opCode === 200) {
        return result.data;
      } else if (result && result.opCode === 406) {
        return Boom.notFound(result.msg);
      } else if (result && result.opCode === 500) {
        return Boom.internal(result.msg);
      } else {
        return Boom.internal("Internal server error.");
      }
    } catch (error) {
      console.log(error);
      return Boom.badImplementation(error);
    }
  }

  public async updateUser(request: IUserUpdate, h: Hapi.ResponseToolkit) {
    // const id = request.auth.credentials.id;
    const userId = request.payload.login;
    request.payload.lastModifiedDate = new Date();
    console.log(request.payload);
    try {
      let user: IUser = await this.database.userModel.findOneAndUpdate(
        { login: userId },
        { $set: request.payload },
        { new: true }
      );
      if (user) {
        delete user.password;
        delete user["__v"];
        return user;
      } else {
        return Boom.notFound();
      }
    } catch (error) {
      // log error
      return Boom.badImplementation("Internal server error.");
    }
  }

  public async deleteUser(request: IRequest, h: Hapi.ResponseToolkit) {
    // const id = request.auth.credentials.id;
    const userId = request.params.id;
    try {
      let user: IUser = await this.database.userModel.findOneAndRemove({ login: userId });
      if (user) {
        delete user.password;
        delete user["__v"];
        return user;
      } else {
        return Boom.notFound("User not found.");
      }
    } catch (error) {
      return Boom.badImplementation("Internal server error");
    }
  }

  public async infoUser(request: IRequest, h: Hapi.ResponseToolkit) {
    // const id = request.auth.credentials.id;
    const userId = request.params.id;
    console.log("user id:" + userId);
    try {
      let user: IUser = await this.database.userModel.findOne({ login: userId }).lean(true);
      if (user) {
        delete user.password;
        delete user["__v"];
        return user;
      } else {
        return Boom.notFound("User not found.");
      }
    } catch (error) {
      return Boom.badImplementation("Internal server error");
    }
  }

  public async getAllUsers(request: IRequest, h: Hapi.ResponseToolkit) {
    // const id = request.auth.credentials.id;
    const bank = request.query['bank'];
    let filter = {};
    try {
      if (bank && bank !== 'null' && bank !== null) {
        filter = { bank: bank };
      }
      let users: IUser[] = await this.database.userModel.find(filter).lean(true);
      return users;
    } catch (error) {
      return Boom.badImplementation("Internal server error");
    }
  }

  public async changePassword(request: IChangePassword, h: Hapi.ResponseToolkit) {
    const login = request.auth.credentials.id;
    // const login = 'dbsuser1@dbs.com';
    request.payload["login"] = login;
    try {
      const msg: any = await this.userService.changePassword(request.payload);
      if (msg) {
        console.log(msg);
        return msg;
      } else {
        return Boom.badImplementation("Internal server error");
      }
    } catch (error) {
      return Boom.badImplementation("Internal server error");
    }
  }

  public async resetPassword(request: IAccount, h: Hapi.ResponseToolkit) {
    try {
      const login = request.payload.userId;
      const who = request.params.user;
      const msg: any = await this.userService.resetPassword(login, who);
      if (msg) {
        console.log(msg);
        return msg;
      } else {
        return Boom.badImplementation("Internal server error");
      }
    } catch (error) {
      return Boom.badImplementation("Internal server error");
    }
  }

  public async lockAccount(request: IAccount, h: Hapi.ResponseToolkit) {
    // const id = request.auth.credentials.id;
    const userId = request.payload.userId;
    console.log(request.payload);
    try {
      let user: IUser = await this.database.userModel.findOneAndUpdate(
        { login: userId },
        { $set: { activated: false, lastModifiedDate: new Date(), lastModifiedBy: userId } },
        { new: true }
      );
      if (user) {
        console.log("account got locked");
        return Boom.locked('Your account is locked. Please contact administrator.');
      } else {
        return Boom.notFound();
      }
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async generateOTP(request: IGenOTP, h: Hapi.ResponseToolkit) {

    const username = request.payload.username;
    let userData = {
      "username": request.payload.username,
      "userEmail": request.payload.userEmail,
      "orgName": "Marsh_Dev",
      "ipAddress": request.payload.ipAddress,
      "clientGenCookie": request.payload.clientGenCookie,
      "groups": ["Clients", "MFA"]

    };
    try {
      let otp = await this.mfaService.generateOTP(userData, this.emailService);
      if (otp) {
        console.log('result from server 1:: ' + otp);
        console.log('result from server 1:: ' + JSON.stringify(otp));
      }
      return otp;
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }
  public async verifyOTP(request: IOTPVerify, h: Hapi.ResponseToolkit) {

    const otp = request.payload.otp;
    const userData = request.payload.userData;
    const sessionId = request.payload.sessionId;
    const transactionId = request.payload.TransactionId;
    try {
      let test = await this.mfaService.verifyOTP(otp, userData, sessionId, transactionId);
      return test;
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }
}
