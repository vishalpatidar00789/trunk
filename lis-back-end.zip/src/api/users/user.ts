import * as Mongoose from "mongoose";
import * as Bcrypt from "bcryptjs";

export interface IUser extends Mongoose.Document {
  login: string;
  firstName: string;
  lastName: string;
  email: string;
  activated: Boolean;
  langKey: string;
  authorities: string[];
  createdBy: string;
  createdDate: Date;
  lastModifiedBy: string;
  lastModifiedDate: Date;
  password: string;
  bank: string;
  department: string;
  userType: string;
  lastUsedPasswords: string[];
  isForceResetPassword: boolean;
  // Password policy: Not allowed to change password more than twice per day
  changePasswordCount: number;
  changePasswordDateTime: Date;
  // Password plicy: Lock account after multiple failed attempts in 24hrs.
  failedLoginAttempts: number;
  lastFailedAttemptTime: Date;
  lastResetPassswordCount: number;
  lastResetPasswordDateTime: Date;
  validatePassword(requestPassword): boolean;
}

export const UserSchema = new Mongoose.Schema(
  {
    login: { type: String, unique: true, required: true },
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, unique: true, required: true },
    activated: { type: Boolean, required: false },
    langKey: { type: String, required: false },
    authorities: { type: [], required: false },
    createdBy: { type: String, required: true },
    createdDate: { type: Date, required: true },
    lastModifiedBy: { type: String, required: false },
    lastModifiedDate: { type: Date, required: false },
    password: { type: String, required: false },
    bank: { type: String, required: false },
    department: { type: String, required: false },
    userType: { type: String, required: false },
    lastUsedPasswords: { type: [], required: false },
    isForceResetPassword: { type: Boolean, required: false, default: false },

    // Password policy: Not allowed to change password more than twice per day.
    changePasswordCount: { type: Number, required: false, default: 0 },
    changePasswordDateTime: { type: Date, required: false },

    // Password plicy: Lock account after multiple failed attempts in 24hrs.
    failedLoginAttempts: { type: Number, required: false, default: 0 },
    lastFailedAttemptTime: { type: Date, required: false },

    lastResetPassswordCount: { type: Number, required: false, default: 0 },
    lastResetPasswordDateTime: { type: Date, required: false },
  }
);

function hashPassword(password: string): string {
  if (!password) {
    return null;
  }

  return Bcrypt.hashSync(password, Bcrypt.genSaltSync(8));
}

UserSchema.methods.validatePassword = function (requestPassword) {
  return Bcrypt.compareSync(requestPassword, this.password);
};

// UserSchema.pre("save", function (next) {
//   const user = this;

//   if (!user.isModified("password")) {
//     return next();
//   }
//   console.log("password before hashed:: " + user["password"]);
//   const hashedPassword = hashPassword(user["password"]);
//   console.log("password after hashed:: " + hashedPassword);
//   user["password"] = hashedPassword;
//   if (user["lastUsedPasswords"]) {
//     user["lastUsedPasswords"] = [];
//   }
//   if (user["lastUsedPasswords"] && user["lastUsedPasswords"].length === 8) {
//     user["lastUsedPasswords"].shift();
//   }
//   user["lastUsedPasswords"].push(hashedPassword);

//   return next();
// });

// UserSchema.pre("findOneAndUpdate", function () {
//   const password = hashPassword(this.getUpdate().$set.password);
//   console.log("password before update:: " +password);
//   if (!password) {
//     return;
//   }
//   this.findOneAndUpdate({}, { password: password });
// });

export const UserModel = Mongoose.model<IUser>("User", UserSchema);
