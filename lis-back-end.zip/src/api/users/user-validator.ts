import * as Joi from "joi";

export const createUserModel = Joi.object().keys({
    login: Joi.string().trim().required(),
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    email: Joi.string().email().trim().required(),
    langKey: Joi.string().default("en"),
    // password: Joi.string().trim().required(),
    authorities: Joi.array().items(Joi.string()),
    createdBy: Joi.string().required(),
    bank: Joi.string().allow(null).optional(),
    activated: Joi.boolean().optional(),
    createdDate: Joi.any().allow(null).optional(),
    lastModifiedBy: Joi.any().allow(null).optional(),
    lastModifiedDate: Joi.any().allow(null).optional(),
    department: Joi.string().allow(null).optional(),
    userType: Joi.string().required(),
    isForceResetPassword: Joi.boolean().default(true).optional()
});
// lastName: Joi.string().optional(), authorities: Joi.array().items(Joi.string())
export const updateUserModel = Joi.object().keys({
    login: Joi.string().trim().required(),
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    email: Joi.string().email().trim().required(),
    langKey: Joi.string().default("en"),
    // password: Joi.string().trim().required(),
    // createdBy: Joi.string().required(),
    // createdDate: Joi.date().required(),
    authorities: Joi.array().items(Joi.string()),
    bank: Joi.string().allow(null).optional(),
    activated: Joi.boolean().optional(),
    lastModifiedBy: Joi.string().required(),
    lastModifiedDate: Joi.any().allow(null).optional(),
    department: Joi.string().allow(null).optional(),
    userType: Joi.string().required(),
    lastUsedPasswords: Joi.array().items(Joi.string()),
    isForceResetPassword: Joi.boolean().optional(),
    // Password policy: Not allowed to change password more than twice per day
    changePasswordCount: Joi.number().optional(),
    changePasswordDateTime: Joi.date().allow(null).optional(),
    // Password plicy: Lock account after multiple failed attempts in 24hrs.
    failedLoginAttempts: Joi.number().optional(),
    lastFailedAttemptTime: Joi.date().allow(null).optional(),

    lastResetPassswordCount: Joi.number().optional(),
    lastResetPasswordDateTime: Joi.date().allow(null).optional(),
});

export const loginUserModel = Joi.object().keys({
    userId: Joi.string().trim().required(),
    password: Joi.string().trim().required()
});

export const changePasswordModel = Joi.object().keys({
    newPassword: Joi.string().trim().required()
});

export const accountModel = Joi.object().keys({
    userId: Joi.string().trim().required()
});

export const verifyOtpPayload = Joi.object().keys({
    //userData: Joi.any().required(),
    sessionId: Joi.string().required(),
    TransactionId: Joi.string().required(),
    otp: Joi.string().required(),
    userData: Joi.object().keys({
        username: Joi.string().required(),
        userEmail: Joi.string().required(),
        orgName: Joi.string().required(),
        ipAddress: Joi.string().required(),
        clientGenCookie: Joi.string().required(),
        groups: Joi.array().required(),
        hashedUsername: Joi.string().required()
    })
});

export const genOtpPayload = Joi.object().keys({
    username: Joi.string().required(),
    userEmail: Joi.string().required(),
    ipAddress: Joi.string().required(),
    clientGenCookie: Joi.string().required()
});

export const jwtValidator = Joi.object({ 'authorization': Joi.string().required() }).unknown();