import * as Hapi from 'hapi';
import * as Joi from 'joi';
import ClaimController from './claim-controller';
import { ClaimModel } from './claim';
import * as ClaimValidator from './claim-validator';
import { IDatabase } from '../../database';
import { IServerConfigurations } from '../../configurations';
import ConfigurationService from '../../services/configuration-service';
import ClaimService from '../../services/claim-service';
import EmailService from '../../services/email-service';

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase,
  emailService: EmailService
) {
  const configService = new ConfigurationService(serverConfigs, database);
  const claimService = new ClaimService(serverConfigs, database, server, configService);
  const claimController = new ClaimController(serverConfigs, database, server, claimService, emailService);
  server.bind(claimController);

  server.route({
    method: 'GET',
    path: '/claim/info/{id}',
    options: {
      handler: claimController.getClaim,
      auth: "jwt",
      tags: ['api', 'claim'],
      description: 'Get Claim info.',
      validate: {
        headers: ClaimValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Claim found.'
            },
            '401': {
              description: 'Please login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/claim/create-claim',
    options: {
      handler: claimController.createClaim,
      auth: "jwt",
      tags: ['api', 'claim'],
      description: 'Create a new other Claim request.',
      validate: {
        payload: ClaimValidator.claimPayload,
        headers: ClaimValidator.jwtValidator,
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '201': {
              description: 'Claim created.'
            },
            '401': {
              description: 'User does not have authorization.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'PUT',
    path: '/claim/saveAsDraft/{id}',
    options: {
      handler: claimController.saveAsDraft,
      auth: "jwt",
      tags: ['api', 'claim'],
      description: 'Update current Claim info.',
      validate: {
        payload: ClaimValidator.claimPayload,
        headers: ClaimValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Updated Claim request.'
            },
            '401': {
              description: 'User does not have authorization.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'PUT',
    path: '/claim/submitClaim/{id}',
    options: {
      handler: claimController.submitClaim,
      auth: "jwt",
      tags: ['api', 'claim'],
      description: 'Update current Claim info.',
      validate: {
        payload: ClaimValidator.claimPayload,
        headers: ClaimValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Submit Claim request.'
            },
            '401': {
              description: 'User does not have authorization.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'DELETE',
    path: '/claim/delete/{id}',
    options: {
      handler: claimController.deleteClaim,
      auth: "jwt",
      tags: ['api', 'claim'],
      description: 'Delete Current Claim.',
      validate: {
        headers: ClaimValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Claim deleted.'
            },
            '401': {
              description: 'User does not have authorization.'
            }
          }
        }
      }
    }
  });
}
