import * as Hapi from 'hapi';
import * as Boom from 'boom';
import * as Jwt from 'jsonwebtoken';
import { IClaim, ClaimModel } from './claim';
import { IDatabase } from '../../database';
import { IServerConfigurations } from '../../configurations';
import { IRequest, ILoginRequest, IMailOptions } from '../../interfaces/request';
import { getHeapSpaceStatistics } from 'v8';
import { IApp } from '../master-data/app-management/app-management';
import { ObjectId } from 'mongodb';
import { ILoan } from '../loan/loan';
import ClaimService from '../../services/claim-service';
import EmailService from '../../services/email-service';

export default class ClaimController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  private server: Hapi.Server;

  constructor(configs: IServerConfigurations, database: IDatabase, server: Hapi.Server, private claimService: ClaimService, private emailService: EmailService) {
    this.database = database;
    this.configs = configs;
    this.server = server;
  }

  public async createClaim(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let requestPayload: any = request['payload'];
      const userId = request.auth.credentials.id;
      requestPayload['createdBy'] = userId;
      requestPayload['createdDate'] = new Date();
      requestPayload['status'] = 'Draft';
      // indicator column typeOfRequest added by vishal p
      // requestPayload['typeOfRequest'] = "claim";

      let claim: any = await this.database.claimModel.create(requestPayload);
      if (claim) {
        return h.response({ _id: claim._id, status: claim.status }).code(201);
      } else {
        return Boom.badData("Internal Server Error While Creating Adhoc Application.");
      }

    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteClaim(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params['id'];
    console.log("Deleting application for id: " + id);
    let claim: IClaim = await this.database.claimModel.findByIdAndRemove(id);
    if (claim) {
      return { success: "Claim Information Deleted Successfully." };
    } else {
      return Boom.notFound('No Claim Application Exists For Given Id.');
    }
  }

  public async getClaim(request: IRequest, h: Hapi.ResponseToolkit) {
    const claimId = request.params.id;
    console.log("Claim id:" + claimId);
    try {
      let claim: IClaim = await this.database.claimModel.findById(claimId).lean(true);
      if (claim) {
        delete claim['typeOfRequest'];
        return claim;
      } else {
        return Boom.notFound('No Claim Application Exists For Given Id.');
      }
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async saveAsDraft(request: IRequest, h: Hapi.ResponseToolkit) {
    console.log(JSON.stringify(request.params.id));
    const id = request.params.id;

    let requestPayload: any = request['payload'];
    let app = await this.getCurrentApp();
    requestPayload['app'] = app;

    try {
      const userId = request.auth.credentials.id;
      let claim: IClaim = await this.database.claimModel.findByIdAndUpdate(
        id,
        { $set: requestPayload },
        { new: true }
      ).lean(true);
      if (claim) {
        requestPayload['lastmodifiedBy'] = userId;
        requestPayload['lastModifiedDate'] = new Date();
        delete claim['typeOfRequest'];
        return { success: "Claim Information Saved Successfully." };
        // return claim;
      } else {
        return Boom.notFound('Can Not Update The Non-Existing Claim Application.');
      }
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async submitClaim(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params['id'];

    try {
      const userId = request.auth.credentials.id;
      this.server.log("INFO", "Inside submitClaim");
      let requestPayload: any = request['payload'];
      // let app = await this.getCurrentApp();
      // requestPayload['app'] = app;
      let bankCd = requestPayload['pfiCode'];
      console.log("bankCd::" + bankCd);
      // let marshRefNo = await this.generateMarshReferenceNumber(bankCd);

      let marshRefNo = await this.claimService.generateClaimMarshReferenceNumber(bankCd);
      if (!marshRefNo) {
        return Boom.badData("Internal Server Error While Generating Marsh Reference Number");
      }
      requestPayload['marshRefNo'] = marshRefNo;
      requestPayload['lastmodifiedBy'] = userId;
      requestPayload['lastModifiedDate'] = new Date();
      requestPayload['status'] = 'Submitted';
      let claim: IClaim = await this.database.claimModel.findByIdAndUpdate(
        { _id: id },
        { $set: requestPayload },
        { new: true }
      ).lean(true);
      if (claim) {
        let loan:ILoan = await this.database.loanModel.findOneAndUpdate(
          {marshRefNo: claim.loanMarshRefNo},
          { $set: { isClaimSubmitted: true }}
        ).lean(true);
        if (loan) {
          console.log("Loan updated isClaimSubmitted with true");
        }
        delete claim["typeOfRequest"];
        this.sendClaimAcknowledmentMail(claim, userId);
        return claim;
      } else {
        return Boom.notFound('Can Not Update The Non-Existing Claim Application.');
      }
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  private sendClaimAcknowledmentMail(claim: IClaim, userId: string) {
    let date1 = claim['createdDate'].toString().substr(4, 11);
    let m = date1.substr(0, 3);
    let d = date1.substr(4, 2);
    let y = date1.substr(7, 4);

    let pfiName = claim['pfiName'];
    let regComName = claim['regCompanyName'];
    let ACRANo = claim['uen'];
    let loanMarshRefNo = claim['loanMarshRefNo'];
    let claimMarshRefNo = claim['marshRefNo'];

    console.log('CLAIM:::', pfiName, regComName, ACRANo, claimMarshRefNo, loanMarshRefNo);
    //TO PFI USER
    let emailOptions = new IMailOptions();
    emailOptions.from = this.configs.systemEmail;
    emailOptions.to = userId;
    emailOptions.subject = `QA - Acknowledgement for New Claim Submission- ${regComName} - ${claimMarshRefNo}`;
    emailOptions.html = `Dear ${userId}<br><br>
                      This is an acknowledgement email for your Claim submission over  Loan application ${loanMarshRefNo} in LIS portal. Please find the details below:<br>
                      Marsh Reference number:   ${claimMarshRefNo}<br>
                      Marsh Submission Date:    ${d} ${m} ${y}<br>
                      PFI Name:                 ${pfiName}<br>
                      Registered Company Name:  ${regComName}<br>
                      UEN No:                   ${ACRANo}<br>
                      <br><br>
                      Disclaimer: Users can submit applications and track the status of requests at any time, but processing of applications would only be during regular business hours from 8.30 AM to 5.30 PM, Monday – Friday.
                      Note: This is an automated email sent from Marsh's Loan Insurance Scheme Portal.  Please do not reply to this email.`;
    this.emailService.sendEmail(emailOptions);

    //TO MARSH USER
    let emailOptions2 = new IMailOptions();
    emailOptions2.from = this.configs.systemEmail;
    emailOptions2.to = 'Upendra.Krishtam01@marsh.com;Amit.Kumar02@marsh.com';
    emailOptions2.subject = `QA - New Claim Application Submission - ${userId}- ${regComName} - ${claimMarshRefNo}`;
    emailOptions2.html = `Dear Marsh Users<br><br>
                      A new claim has been submitted  over loan application ${loanMarshRefNo}in Marsh's Loan Insurance Scheme Portal. Please find the details below:<br>
                      Marsh Reference number:   ${claimMarshRefNo}<br>
                      Marsh Submission Date:    ${d} ${m} ${y}<br>
                      PFI Name:                 ${pfiName}<br>
                      Registered Company Name:  ${regComName}<br>
                      UEN No:                   ${ACRANo}<br>
                      <br><br>
                      Note: This is an automated email sent from Marsh's Loan Insurance Scheme Portal.  Please do not reply to this email.`;
    this.emailService.sendEmail(emailOptions2);
  }

  private async getCurrentApp() {
    let appManagement: IApp = await this.database.appModel.findOne({
      activated: true
    });
    return appManagement.app;
  }
}
