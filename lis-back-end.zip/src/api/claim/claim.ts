import * as Mongoose from "mongoose";
import * as Bcrypt from "bcryptjs";

export interface IClaim extends Mongoose.Document {
  _id: string;
  status: string;
  marshRefNo: string;
  loanMarshRefNo: string;
  baseLoanId: string;
  consortium: string;
  // app: number;
  createdBy: string;
  createdDate: Date;
  lastModifiedBy: string;
  lastModifiedDate: Date;

  pfiCode: string;
  pfiName?: string;
  policyNumber?: string;
  insurers?: string;
  tranche?: number;
  app?: number;
  nameOfStaff?: string;
  dateReportedToMarsh?: Date;
  nameOfPerson?: string;
  jobTitle?: string;
  regCompanyName?: string;
  uen?: string;
  businessActivity?: string;
  loAcceptanceDate?: Date;
  approvedPrimaryLimit?: number;
  approvedTopUpLimit?: number;
  approvedBGLimit?: number;
  approvedLisPlusLimit?: number;
  outstandingPrincipal?: number;
  interest?: number;
  legalFees?: number;
  remarks?: string;

  pfiANL?: string;
  pfiANLTxt?: string;
  invoice?: string;
  deliveryOrder?: string;
  purchaseOrder?: string;
  purchaseOrderTxt?: string;
  applicationForInvoice?: string;
  facilityDetails?: string;
  facilityDetailsTxt?: string;
  financeNotification?: string;
  financeAdviceNote?: string;
  financeAdviceNoteTxt?: string;
  limitRequestForm?: string;
  limitEndorsementForm?: string;
  currentStatement?: string;
  tradeStatement?: string;
  tradeStatementTxt?: string;
  creditApplication?: string;
  writeOffMemo?: string;
  letterOfAcceptance?: string;
  guarantee?: string;
  guaranteeTxt?: string;
  acraSearch?: string;
  individualSearch?: string;
  individualSearchTxt?: string;
  demandLetter?: string;
  demandLetterTxt?: string;
  statutoryDemand?: string;
  statutoryDemandTxt?: string;
  originatingSummon?: string;
  originatingSummonTxt?: string;
  windingUpOrder?: string;
  windingUpOrderTxt?: string;
  bankruptcyApplication?: string;
  bankruptcyApplicationTxt?: string;
  bankruptcyOrder?: string;
  bankruptcyOrderTxt?: string;
  borrower?: string;
  guarantors?: string;
  guarantorsTxt?: string;
  legalCostInvoices?: string;
  legalCostInvoicesTxt?: string;
  recoveryDetails?: string;
  recoveryDetailsTxt?: string;
  approvedSuppliers?: string;
  approvedSuppliersTxt?: string;
  beneficiaryDemandLetter?: string;
  beneficiaryDemandLetterTxt?: string;
  pfiGuarantee?: string;
  pfiGuaranteeTxt?: string;
  letterOfAward?: string;
  letterOfAwardTxt?: string;
  claimProgressPayment?: string;
  claimProgressPaymentTxt?: string;
  lossesSuffered?: string;
  lossesSufferedTxt?: string;
  otherDocuments?: string;
}

export const ClaimSchema = new Mongoose.Schema(
  {
    status: { type: String },
    marshRefNo: { type: String },
    // adhocMarshRefNo: { type: String }, // Change it to marshRefNo
    loanMarshRefNo: { type: String }, //marshRefNo
    baseLoanId: { type: String },
    consortium: { type: String },
    // app: { type: Number },
    createdBy: { type: String },
    createdDate: { type: Date },
    lastModifiedBy: { type: String },
    lastModifiedDate: { type: Date },

    pfiCode: { type: String },
    pfiName: { type: String },
    policyNumber: { type: String },
    insurers: { type: String },
    tranche: { type: Number },
    app: { type: Number },
    nameOfStaff: { type: String },
    dateReportedToMarsh: { type: Date },
    nameOfPerson: { type: String },
    jobTitle: { type: String },
    regCompanyName: { type: String },
    uen: { type: String },
    businessActivity: { type: String },
    loAcceptanceDate: { type: Date },
    approvedPrimaryLimit: { type: Number },
    approvedTopUpLimit: { type: Number },
    approvedBGLimit: { type: Number },
    approvedLisPlusLimit: { type: Number },
    outstandingPrincipal: { type: Number },
    interest: { type: Number },
    legalFees: { type: Number },
    remarks: { type: String },

    pfiANL: { type: String },
    pfiANLTxt: { type: String },
    invoice: { type: String },
    deliveryOrder: { type: String },
    purchaseOrder: { type: String },
    purchaseOrderTxt: { type: String },
    applicationForInvoice: { type: String },
    facilityDetails: { type: String },
    facilityDetailsTxt: { type: String },
    financeNotification: { type: String },
    financeAdviceNote: { type: String },
    financeAdviceNoteTxt: { type: String },
    limitRequestForm: { type: String },
    limitEndorsementForm: { type: String },
    currentStatement: { type: String },
    tradeStatement: { type: String },
    tradeStatementTxt: { type: String },
    creditApplication: { type: String },
    writeOffMemo: { type: String },
    letterOfAcceptance: { type: String },
    guarantee: { type: String },
    guaranteeTxt: { type: String },
    acraSearch: { type: String },
    individualSearch: { type: String },
    individualSearchTxt: { type: String },
    demandLetter: { type: String },
    demandLetterTxt: { type: String },
    statutoryDemand: { type: String },
    statutoryDemandTxt: { type: String },
    originatingSummon: { type: String },
    originatingSummonTxt: { type: String },
    windingUpOrder: { type: String },
    windingUpOrderTxt: { type: String },
    bankruptcyApplication: { type: String },
    bankruptcyApplicationTxt: { type: String },
    bankruptcyOrder: { type: String },
    bankruptcyOrderTxt: { type: String },
    borrower: { type: String },
    guarantors: { type: String },
    guarantorsTxt: { type: String },
    legalCostInvoices: { type: String },
    legalCostInvoicesTxt: { type: String },
    recoveryDetails: { type: String },
    recoveryDetailsTxt: { type: String },
    approvedSuppliers: { type: String },
    approvedSuppliersTxt: { type: String },
    beneficiaryDemandLetter: { type: String },
    beneficiaryDemandLetterTxt: { type: String },
    pfiGuarantee: { type: String },
    pfiGuaranteeTxt: { type: String },
    letterOfAward: { type: String },
    letterOfAwardTxt: { type: String },
    claimProgressPayment: { type: String },
    claimProgressPaymentTxt: { type: String },
    lossesSuffered: { type: String },
    lossesSufferedTxt: { type: String },
    otherDocuments: { type: String },
  });

var diffHistory = require("mongoose-diff-history/diffHistory");
ClaimSchema.plugin(diffHistory.plugin);

export const ClaimModel = Mongoose.model<IClaim>('claim', ClaimSchema);
