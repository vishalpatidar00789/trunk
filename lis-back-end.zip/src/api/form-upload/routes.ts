import * as Hapi from 'hapi';
import * as Joi from 'joi';
import FormUploadController from './form-upload-controller';
import { FormUploadModel } from './form-upload';
import * as FormUploadValidator from './form-upload-validator';
import { IDatabase } from '../../database';
import { IServerConfigurations } from '../../configurations';
import DocumentService from '../../services/document-service';

export default function(
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const docService: DocumentService = new DocumentService();
  const formUploadController = new FormUploadController(
    serverConfigs,
    database,
    docService,
    server
  );
  server.bind(formUploadController);

  server.route({
    method: 'GET',
    path: '/form-upload/{pfiCode}',
    options: {
      handler: formUploadController.infoFormUpload,
      auth: 'jwt',
      tags: ['api', 'form-upload'],
      description: 'Get form-upload info.',
      validate: {
        headers: FormUploadValidator.jwtValidator,
        params: {
          pfiCode: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'form-upload founded.'
            },
            '401': {
              description: 'Please login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'PUT',
    path: '/form-upload/{id}',
    options: {
      handler: formUploadController.updateFormUpload,
      auth: 'jwt',
      tags: ['api', 'form-upload'],
      description: 'Update current form-upload info.',
      validate: {
        payload: FormUploadValidator.createFormUploadModel,
        headers: FormUploadValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Updated info.'
            },
            '401': {
              description: 'form-upload does not have authorization.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/form-upload',
    options: {
      handler: formUploadController.createFormUpload,
      auth: 'jwt',
      tags: ['api', 'form-upload'],
      description: 'Create a Form upload.',
      validate: {
        payload: FormUploadValidator.createFormUploadModel,
        headers: FormUploadValidator.jwtValidator
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '201': {
              description: 'Form upload created.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/form-upload/uploadForm1',
    options: {
      handler: formUploadController.uploadForm1,
      auth: 'jwt',
      tags: ['api', 'form-upload'],
      description: 'Create a form-upload.',
      payload: {
        output: 'stream',
        parse: true,
        allow: 'multipart/form-data',
        maxBytes: 2 * 1000 * 1000
      },
      validate: {
        headers: FormUploadValidator.jwtValidator
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '201': {
              description: 'form-upload created.'
            }
          }
        }
      }
    }
  });
}
