import * as Joi from "joi";

export const createFormUploadModel = Joi.object().keys({
  _id: Joi.string().allow("").optional(),
  pfiCode:Joi.string().required(),
  lastCommitedDate: Joi.date().allow("").allow(null).optional(),
  lastCommitedBy: Joi.string().allow("").optional(),
});

export const jwtValidator = Joi.object({'authorization': Joi.string().required()}).unknown();
