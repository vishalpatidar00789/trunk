import * as Joi from "joi";

export const createFormUploadModel = Joi.object().keys({
  _id: Joi.string().allow("").optional(),
  pfiCode:Joi.string().required(),
  lastCommitedDate: Joi.date().allow("").allow(null).optional(),
  lastCommitedBy: Joi.string().allow("").optional(),
});

export const updateCommitChanges = Joi.array().items(Joi.object().keys({
    _id: Joi.string().allow("").allow(null).optional(),
    lisAppNo: Joi.string().allow("").allow(null).optional(),
    lis5Primary:Joi.number().allow(null).optional(),
    lis5Auto: Joi.number().allow(null).optional(),
    lis5BG: Joi.number().allow(null).optional(),
    lisPlusS9: Joi.number().allow(null).optional(),
    isMidTerm: Joi.boolean(),
  }));

export const jwtValidator = Joi.object({'authorization': Joi.string().required()}).unknown();
