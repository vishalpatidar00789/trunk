import * as Hapi from 'hapi';
import * as Boom from 'boom';
import * as Jwt from 'jsonwebtoken';
import {
  IFormUpload,
  FormUploadModel,
  FormUploadExportData,
  ValidationSummary
} from './form-upload';
import { IDatabase } from '../../database';
import { IServerConfigurations } from '../../configurations';
import {
  IRequest,
  Ispring,
  FileMetaData,
  ILoginRequest
} from '../../interfaces/request';
import DocumentService from '../../services/document-service';
import { ILoan } from '../loan/loan';
import { IMidTerm } from '../mid-term/mid-term';
const fs = require('fs');
const pdfextracter = require('../../utils/pdfextracter');
const path = require('path');
const tempFile = '/opt/apps/lis/springforms/';
const util = require('util');
var parseString = require('xml2js').parseString;
const excelToJson = require('convert-excel-to-json');
const XLSX = require('xlsx');

export default class FormUploadController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  private docService: DocumentService;
  private server: Hapi.Server;

  constructor(
    configs: IServerConfigurations,
    database: IDatabase,
    docService: DocumentService,
    server: Hapi.Server
  ) {
    this.database = database;
    this.configs = configs;
    this.docService = docService;
    this.server = server;
  }

  public async createFormUpload(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      const userId = request.auth.credentials.id;
      let requestPayload: any = request['payload'];
      requestPayload['lastCommitedBy'] = userId;
      requestPayload['lastCommitedDate'] = new Date();
      let formUpload: any = await this.database.formUploadModel.create(
        requestPayload
      );
      delete formUpload['__v'];
      console.log(formUpload);
      //return h.response(springform).code(201);
      return h.response(formUpload).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateFormUpload(request: IRequest, h: Hapi.ResponseToolkit) {
    console.log(JSON.stringify(request.params.id));
    const id = request.params.id;
    const userId = request.auth.credentials.id;
    let requestPayload: any = request['payload'];
    requestPayload['lastCommitedBy'] = userId;
    requestPayload['lastCommitedDate'] = new Date();

    try {
      let formUpload: IFormUpload = await this.database.formUploadModel.findByIdAndUpdate(
        id,
        { $set: requestPayload },
        { new: true }
      );
      delete formUpload['__v'];
      return formUpload;
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async infoFormUpload(request: IRequest, h: Hapi.ResponseToolkit) {
    const pfiCode = request.params.pfiCode;
    let formUpload: IFormUpload = await this.database.formUploadModel.findOne({
      pfiCode: pfiCode
    });
    if (formUpload) {
      delete formUpload['__v'];
      return formUpload;
    } else {
      return Boom.notFound('Not Found');
    }
  }

  public async uploadForm1(request, h: Hapi.ResponseToolkit) {
    try {
      console.log('__________________________');
      console.log(request.payload);
      let result: any;
      let files = [request.payload['file']];
      if (files && files.length > 0) {
        result = await this.getFormUploadData(files[0]._data);
        if (result) {
          const userId = request.auth.credentials.id;
          let date = new Date();
          const fileName =
            'form-upload' +
            date.getDay() +
            date.getMonth() +
            date.getFullYear() +
            date.getHours() +
            date.getMinutes() +
            date.getSeconds() +
            date.getMilliseconds() +
            '.xlsx';
          var contentType = 'binary/octet-stream';
          var fileData = files[0]._data;
          let fileMetaData: FileMetaData = new FileMetaData();
          fileMetaData.contentType = contentType;
          fileMetaData.file = fileData;
          fileMetaData.fileName = fileName;
          fileMetaData.refAppId = result.pfi;
          fileMetaData.collectionName = 'FORM1UPLOAD';
          fileMetaData.documentType = 'Form 1 Upload';
          fileMetaData.uploadedBy = userId;
          // fileMetaData.uploadedBy = request.auth.credentials.id;

          let uploadedFile = this.docService.uploadFile(fileMetaData);
          console.log('uploadedFile:' + uploadedFile);
        }
        return result;
      } else {
        return Boom.badImplementation(
          'Upload File error. Please contact admin.'
        );
      }
    } catch (error) {
      console.log(error);
      return Boom.badImplementation(
        'Internal server error. Please contact admin.'
      );
    }
  }

  private async getFormUploadData(data: FormUploadExportData) {
    let formUploadExportData: FormUploadExportData = new FormUploadExportData();
    const workbook = XLSX.read(data, { type: 'buffer' });
    const sheet_name_list = workbook.SheetNames;
    /* Get worksheet */
    let worksheet = workbook.Sheets[sheet_name_list[0]];

    let address_of_policy = 'B4';
    /* Find desired cell */
    let policy_cell = worksheet[address_of_policy];

    /* Get the value */
    let policy_value = policy_cell ? policy_cell.v : null;
    if (policy_value && policy_value === 'Policy Number: ') {
      let address_of_policyNo = 'C4';
      let address_of_pfi = 'C5';
      let address_of_reportingMonth = 'M3';

      let policyNo_cell = worksheet[address_of_policyNo];
      let pfi_cell = worksheet[address_of_pfi];
      let reportingMonth_cell = worksheet[address_of_reportingMonth];
      // console.log(
      //   JSON.stringify(
      //     new Date((reportingMonth_cell.v - (25567 + 2)) * 86400 * 1000)
      //   )
      // );

      formUploadExportData.policyNumber = policyNo_cell
        ? policyNo_cell.v
        : null;
      formUploadExportData.pfi = pfi_cell ? pfi_cell.v : null;
      formUploadExportData.reportingMonth = reportingMonth_cell
        ? reportingMonth_cell.w
        : null;

      // Check Valid File & Header Details
      // range.s.c = 0; // 0 == XLSX.utils.decode_col("A")
      // range.s.r = 0;
      // range.e.c = 13; // 6 == XLSX.utils.decode_col("N")
      // range.e.r = 4;
      // let headerRange = XLSX.utils.encode_range(range);

      // let resultHeader = await XLSX.utils.sheet_to_json(worksheet, {
      //   header: 'A',
      //   blankRows: false,
      //   defval: null,
      //   range: headerRange
      // });

      let range = XLSX.utils.decode_range(worksheet['!ref']);
      range.s.c = 0; // 0 == XLSX.utils.decode_col("A")
      range.s.r = 10;
      range.e.c = 43; // 6 == XLSX.utils.decode_col("AR")
      var new_range = XLSX.utils.encode_range(range);

      let lisData = await XLSX.utils.sheet_to_json(
        workbook.Sheets[sheet_name_list[0]],
        {
          header: 'A',
          blankRows: false,
          defval: null,
          cellDates: true,
          range: new_range
        }
      );
      if (lisData) {
        let validationSummaryList: ValidationSummary[] = [];
        for (const excelData of lisData) {
          let validationSummary: ValidationSummary;
          if (excelData['B']) {
            // if (excelData['B'] && excelData['C']) {
            validationSummary = await this.validateExcelData(excelData);
            if (validationSummary) {
              validationSummaryList.push(validationSummary);
            }
          }
        }
        // await lisData.forEach(async (excelData) => {

        // });
        formUploadExportData.validationSummary = validationSummaryList;
      }

      if (formUploadExportData) {
        return formUploadExportData;
      }
    }

    return Boom.preconditionFailed(
      'Form1 Upload application configuration issue. Please contact server admin.'
    );

    // return formUploadExportData;
  }

  async validateExcelData(excelData: any) {
    let validationSummary = new ValidationSummary();
    validationSummary.pfi = excelData['B'];
    validationSummary.lisAppNo = excelData['C'];
    validationSummary.domesticLIS = excelData['D'];
    validationSummary.exportLIS = excelData['E'];
    validationSummary.tradeFacilities = excelData['F'];
    validationSummary.bgFacility = excelData['G'];
    validationSummary.totalLISLimitApplied = excelData['H'];
    validationSummary.LOAcceptanceDate = excelData['I'];
    validationSummary.borrowerName = excelData['J'];
    validationSummary.UENNumber = excelData['K'];
    validationSummary.latestYearTurnover = excelData['L'];
    validationSummary.latestYearNPBT = excelData['M'];
    validationSummary.limitsApprovedPrimaryOnly = excelData['N'];
    validationSummary.limitsApprovedAuto = excelData['O'];
    validationSummary.limitsApprovedPrimaryBGOnly = excelData['P'];
    validationSummary.tenureBGS3 = excelData['Q'];
    validationSummary.limitsApprovedLISPlus = excelData['R'];
    validationSummary.lisPrimaryS3 = excelData['S'];
    validationSummary.lisAutoS3 = excelData['T'];
    validationSummary.lisBGS3 = excelData['U'];
    validationSummary.typeOfLimit = excelData['V'];
    validationSummary.totalAppliedLimit = excelData['W'];
    validationSummary.approvedLimitChangesPrimary = excelData['X'];
    validationSummary.approvedLimitChangesAuto = excelData['Y'];
    validationSummary.approvedLimitChangesBG = excelData['Z'];
    validationSummary.tenureBGS5 = excelData['AA'];
    validationSummary.proRateChange = excelData['AB'];
    validationSummary.date1Limit = excelData['AC'];
    validationSummary.date2Limit = excelData['AD'];
    validationSummary.lisPrimaryS5 = excelData['AE'];
    validationSummary.lisAutoS5 = excelData['AF'];
    validationSummary.lisBGS5 = excelData['AG'];
    validationSummary.totalApprovedLimit = excelData['AH'];
    validationSummary.appliedMidTerm = excelData['AI'];
    validationSummary.approvedMidTerm = excelData['AJ'];
    validationSummary.limitIncreaseDate = excelData['AK'];
    validationSummary.remarks = excelData['AL'];
    validationSummary.totalLIS5LimitsApproved = excelData['AM'];
    validationSummary.totalLISPlusLimitsApproved = excelData['AN'];
    validationSummary.lis5Primary = excelData['AO'];
    validationSummary.lis5Auto = excelData['AP'];
    validationSummary.lis5BG = excelData['AQ'];
    validationSummary.lisPlusS9 = excelData['AR'];

    // Basic Validation to check PFI,UEN & Borrower Name
    if (
      !validationSummary.pfi ||
      !validationSummary.borrowerName ||
      !validationSummary.UENNumber
    ) {
      validationSummary.validatationType = 'invalid';
      return validationSummary;
    }

    // Check record request type and check LO Acceptance for Loan and Limit Start Date for Mid Term
    if (
      validationSummary.typeOfLimit ||
      validationSummary.totalAppliedLimit ||
      validationSummary.approvedLimitChangesPrimary ||
      validationSummary.approvedLimitChangesAuto ||
      validationSummary.approvedLimitChangesBG ||
      validationSummary.tenureBGS5 ||
      validationSummary.proRateChange ||
      validationSummary.date1Limit ||
      validationSummary.date2Limit ||
      validationSummary.totalApprovedLimit ||
      validationSummary.appliedMidTerm ||
      validationSummary.approvedMidTerm ||
      validationSummary.limitIncreaseDate
    ) {
      validationSummary.isMidTerm = true;
      if (!validationSummary.date1Limit) {
        validationSummary.validatationType = 'invalid';
        return validationSummary;
      } else {
        let midTerm: IMidTerm = await this.database.midTermModel
          .findOne({
            'creditInfo.pfiCode': validationSummary.pfi,
            'creditInfo.borrowerRegName': validationSummary.borrowerName,
            'creditInfo.aCRArefNo': validationSummary.UENNumber
            // 'creditInfo.consortium': validationSummary.date1Limit
          })
          .lean(true);
        if (midTerm) {
          validationSummary = await this.checkDiscrepancy(
            validationSummary,
            midTerm
          );
          return validationSummary;
        } else {
          validationSummary.validatationType = 'invalid';
          return validationSummary;
        }
      }
    } else {
      if (!validationSummary.LOAcceptanceDate) {
        validationSummary.validatationType = 'invalid';
        return validationSummary;
      } else {
        let loan: ILoan = await this.database.loanModel
          .findOne({
            'creditInfo.pfiCode': validationSummary.pfi,
            'creditInfo.borrowerRegName': validationSummary.borrowerName,
            'creditInfo.aCRArefNo': validationSummary.UENNumber
            //'creditInfo.loAcceptanceDate': validationSummary.LOAcceptanceDate
          })
          .lean(true);
        if (loan) {
          validationSummary = await this.checkDiscrepancy(
            validationSummary,
            loan
          );
          return validationSummary;
        } else {
          validationSummary.validatationType = 'invalid';
          return validationSummary;
        }
      }
    }

    // validationSummary.discrepancyList = [];
    // validationSummary.discrepancyList.push('pfi');
    // return validationSummary;
  }

  async checkDiscrepancy(validationSummary: ValidationSummary, lisData: any) {
    //validationSummary.validatationType = 'pass';
    let formattedData: ValidationSummary = await this.getFormattedValidationSummary(
      validationSummary
    );
    //console.log(formattedData);
    return validationSummary;
  }

  removeDefaultTxt(data: string, type?: string) {
    if (data) {
      switch (type) {
        case 'currency':
          data = data
            .replace('$', '')
            .replace('-', '')
            .replace(',', '');
          break;
        case 'percentage':
          data = data.replace('%', '');
          break;
      }
      data = data.trim();
    }
    return data;
  }

  getFormattedValidationSummary(validationSummary: ValidationSummary) {
    let formatData: ValidationSummary = new ValidationSummary();
    formatData = Object.assign({}, validationSummary);
    formatData.pfi = this.removeDefaultTxt(formatData.pfi);
    formatData.lisAppNo = this.removeDefaultTxt(formatData.lisAppNo);
    formatData.domesticLIS = this.removeDefaultTxt(
      formatData.domesticLIS,
      'percentage'
    );
    formatData.exportLIS = this.removeDefaultTxt(
      formatData.exportLIS,
      'percentage'
    );
    formatData.tradeFacilities = this.removeDefaultTxt(
      formatData.tradeFacilities
    );
    formatData.bgFacility = this.removeDefaultTxt(formatData.bgFacility);
    formatData.totalLISLimitApplied = this.removeDefaultTxt(
      formatData.totalLISLimitApplied,
      'currency'
    );
    formatData.LOAcceptanceDate = this.removeDefaultTxt(
      formatData.LOAcceptanceDate
    ); // Date
    formatData.borrowerName = this.removeDefaultTxt(formatData.borrowerName);
    formatData.UENNumber = this.removeDefaultTxt(formatData.UENNumber);
    formatData.latestYearTurnover = this.removeDefaultTxt(
      formatData.latestYearTurnover,
      'currency'
    );
    formatData.latestYearNPBT = this.removeDefaultTxt(
      formatData.latestYearNPBT,
      'currency'
    );
    formatData.limitsApprovedPrimaryOnly = this.removeDefaultTxt(
      formatData.limitsApprovedPrimaryOnly,
      'currency'
    );
    formatData.limitsApprovedAuto = this.removeDefaultTxt(
      formatData.limitsApprovedAuto,
      'currency'
    );
    formatData.limitsApprovedPrimaryBGOnly = this.removeDefaultTxt(
      formatData.limitsApprovedPrimaryBGOnly,
      'currency'
    );
    formatData.tenureBGS3 = this.removeDefaultTxt(
      formatData.tenureBGS3,
      'currency'
    );
    formatData.limitsApprovedLISPlus = this.removeDefaultTxt(
      formatData.limitsApprovedLISPlus,
      'currency'
    );
    formatData.lisPrimaryS3 = this.removeDefaultTxt(
      formatData.lisPrimaryS3,
      'percentage'
    );
    formatData.lisAutoS3 = this.removeDefaultTxt(
      formatData.lisAutoS3,
      'percentage'
    );
    formatData.lisBGS3 = this.removeDefaultTxt(
      formatData.lisBGS3,
      'percentage '
    );
    formatData.typeOfLimit = this.removeDefaultTxt(formatData.typeOfLimit);
    formatData.totalAppliedLimit = this.removeDefaultTxt(
      formatData.totalAppliedLimit,
      'currency'
    );
    formatData.approvedLimitChangesPrimary = this.removeDefaultTxt(
      formatData.approvedLimitChangesPrimary,
      'currency'
    );
    formatData.approvedLimitChangesAuto = this.removeDefaultTxt(
      formatData.approvedLimitChangesAuto,
      'currency'
    );
    formatData.approvedLimitChangesBG = this.removeDefaultTxt(
      formatData.approvedLimitChangesBG,
      'currency'
    );
    formatData.tenureBGS5 = this.removeDefaultTxt(formatData.tenureBGS5);
    formatData.proRateChange = this.removeDefaultTxt(
      formatData.proRateChange,
      'percentage'
    );
    formatData.date1Limit = this.removeDefaultTxt(formatData.date1Limit); // Date
    formatData.date2Limit = this.removeDefaultTxt(formatData.date2Limit); // Date
    formatData.lisPrimaryS5 = this.removeDefaultTxt(
      formatData.lisPrimaryS5,
      'percentage '
    );
    formatData.lisAutoS5 = this.removeDefaultTxt(
      formatData.lisAutoS5,
      'percentage '
    );
    formatData.lisBGS5 = this.removeDefaultTxt(
      formatData.lisBGS5,
      'percentage '
    );
    formatData.totalApprovedLimit = this.removeDefaultTxt(
      formatData.totalApprovedLimit,
      'currency'
    );
    formatData.appliedMidTerm = this.removeDefaultTxt(
      formatData.appliedMidTerm,
      'currency'
    );
    formatData.approvedMidTerm = this.removeDefaultTxt(
      formatData.approvedMidTerm,
      'currency'
    );
    formatData.limitIncreaseDate = this.removeDefaultTxt(
      formatData.limitIncreaseDate
    ); // Date
    formatData.remarks = this.removeDefaultTxt(formatData.remarks);
    formatData.totalLIS5LimitsApproved = this.removeDefaultTxt(
      formatData.totalLIS5LimitsApproved,
      'currency'
    );
    formatData.totalLISPlusLimitsApproved = this.removeDefaultTxt(
      formatData.totalLISPlusLimitsApproved,
      'currency'
    );
    formatData.lis5Primary = this.removeDefaultTxt(
      formatData.lis5Primary,
      'currency'
    );
    formatData.lis5Auto = this.removeDefaultTxt(
      formatData.lis5Auto,
      'currency'
    );
    formatData.lis5BG = this.removeDefaultTxt(formatData.lis5BG, 'currency');
    formatData.lisPlusS9 = this.removeDefaultTxt(
      formatData.lisPlusS9,
      'currency'
    );
    return formatData;
  }

  public async uploadForm12(request, h: Hapi.ResponseToolkit) {
    try {
      console.log('__________________________');
      console.log(request.payload);
      let result: any;
      let files = [request.payload['file']];
      let i = 0;
      // result.push(files[i].hapi);
      let date = new Date();
      const fileName =
        'formUpload' +
        date.getDay() +
        date.getMonth() +
        date.getFullYear() +
        date.getHours() +
        date.getMinutes() +
        date.getSeconds() +
        date.getMilliseconds() +
        '.pdf';
      console.log('form upload name:: ' + fileName);
      console.log('original file name:: ' + files[i].hapi.filename);
      let pathofFile = tempFile + path.join(fileName); // files[i].hapi.filename
      // var pathofFile = path.join(files[i].hapi.filename);
      console.log('pathofFile:: ' + pathofFile);
      files[i].pipe(fs.createWriteStream(pathofFile));
      result = pdfextracter.extraxtPDF(pathofFile).then((data) => {
        // return data;
        if (data[0].data) {
          // console.log("file data:: " + JSON.stringify(data));
          return new Promise(function(resolve, reject) {
            parseString(data[0].data, function(err, result) {
              if (err) {
                return reject(err);
              } else {
                return resolve(result);
              }
            });
          }).then((data) => {
            //var file = [request.payload["uploads"]];
            // var fileName = request.payload["fileName"];
            // var contentType = file[0].headers.content_type;
            var contentType = 'binary/octet-stream';
            var fileData = files[0]._data;
            let fileMetaData: FileMetaData = new FileMetaData();
            fileMetaData.contentType = contentType;
            fileMetaData.file = fileData;
            fileMetaData.fileName = fileName;
            fileMetaData.refAppId = request.params['id'];
            fileMetaData.collectionName = 'LOAN';
            fileMetaData.documentType = 'Sponsor form';
            fileMetaData.uploadedBy = 'SYSTEM';
            // fileMetaData.uploadedBy = request.auth.credentials.id;

            let uploadedFile = this.docService.uploadFile(fileMetaData);
            console.log('uploadedFile:' + uploadedFile);
            this.deleteFile(pathofFile);
            console.log('file deleted ');
            return this.mapPDFToJSON(data);
          });
        } else {
          // throw valid error message
          this.deleteFile(pathofFile);
          console.log('error in extract pdf payload');
          return Boom.preconditionFailed(
            'Spring form application configuration issue. Please contact server admin.'
          );
        }
      });
      console.log('spring form JSON mapped data::' + result);
      return result;
    } catch (error) {
      console.log(error);
      return Boom.badImplementation(
        'Internal server error. Please contact admin.'
      );
    }
  }

  private mapSheetToJSON(data: any) {}

  private deleteFile(filePath) {
    fs.unlink(filePath, (err) => {
      if (err) {
        throw err;
      }
      console.log('successfully deleted:: ' + filePath);
    });
  }

  private mapPDFToJSON(result: any) {
    console.log(result);
    this.server.log('INFO', result);
    let springForm: IFormUpload = <IFormUpload>{};
    var section = result['xfa:data'].form1[0].CompanyData1[0];
    var section1 = section.ComMainSub1[0];

    console.log('____________________________________________________');
    if (
      !(
        section.ErrorMessage[0].ErrorMessageText[0] ===
        'Validation Pass! Please proceed to submit this eForm.'
      )
    ) {
      throw 'Please validate the Spring eForm';
    }
    //springForm.regComName = section.ComNameSub[0].RegComName[0];
    //springForm.ACRANo = section1.ACRANo[0];
    //springForm.corrAddress1 = section1.CorrAddress1[0];
    //springForm.corrAddress2 = section1.CorrAddress2[0];
    //springForm.corrAddress3 = section1.CorrAddress3[0];
    //springForm.contactPerson = section1.ContactPerson[0];
    //springForm.corrAddress3 = section1.CorrAddress3[0];
    //springForm.contactPersonEmail = section1.ContactPersonEmail[0];
    //springForm.contactPersonNo = section1.ContactPersonNo[0];

    //springForm.businessActivity = result["xfa:data"].form1[0].CompanyData1[0].BusActSub[0].BusinessActivity[0];

    //springForm.numStaff = result["xfa:data"].form1[0].CompanyData1[0].ComMainSub2[0].NumStaff[0];

    // let dateArray: number[] = result["xfa:data"].form1[0].CompanyData1[0].ComMainSub2[0].DateOfIncorporation[0].split("-");
    // springForm.dateofIncorporation = { year: Number(dateArray[0]), month: Number(dateArray[1]), day: Number(dateArray[2]) };

    //springForm.dateofIncorporation = result["xfa:data"].form1[0].CompanyData1[0].ComMainSub2[0].DateOfIncorporation[0];

    //Table data
    console.log('___________________________________________________');
    // springForm.ACRANo = result["xfa:data"].form1[0].CompanyData1[0].Performance[0].PastPerformanceTable[0];
    //springForm.appLFY = Number(result["xfa:data"].form1[0].CompanyData1[0].Performance[0].PastPerformanceTable[0].YearRow[0].AppLFY[0].replace(/\,/g, ''));
    //springForm.appSubLFY = Number(result["xfa:data"].form1[0].CompanyData1[0].Performance[0].PastPerformanceTable[0].YearRow[0].AppSubLFY[0].replace(/\,/g, ''));
    //
    //springForm.appSales = Number(result["xfa:data"].form1[0].CompanyData1[0].Performance[0].PastPerformanceTable[0].SalesRow[0].AppSales[0].replace(/\,/g, ''));
    //springForm.appSubSales = Number(result["xfa:data"].form1[0].CompanyData1[0].Performance[0].PastPerformanceTable[0].SalesRow[0].AppSubSales[0].replace(/\,/g, ''));
    //
    //springForm.appNetProfit = Number(result["xfa:data"].form1[0].CompanyData1[0].Performance[0].PastPerformanceTable[0].NetProfitRow[0].AppNetProfit[0].replace(/\,/g, ''));
    //springForm.appSubNetProfit = Number(result["xfa:data"].form1[0].CompanyData1[0].Performance[0].PastPerformanceTable[0].NetProfitRow[0].AppSubNetProfit[0].replace(/\,/g, ''));
    console.log(
      '___END______________SECTION1__________________________________'
    );
    //Table data
    console.log(
      '___START_______________SECTION 2_________________________________'
    );
    //springForm.shareholdingSub = [];
    let shareholdingSub =
      result['xfa:data'].form1[0].CompanyData1[0].ShareholdingSub[0]
        .ShareholdingDetails1Table[0].ShareholdingDetails1Row;
    // springForm.ACRANo = table1[0].Level;
    shareholdingSub.forEach(function(value) {
      let shareholdingSub: any = {};
      // springForm.ACRANo = value;
      shareholdingSub.level = value.Level[0];
      shareholdingSub.name = value.Name[0];
      shareholdingSub.aCRA = value.ACRA[0];
      shareholdingSub.type = value.Type[0];
      shareholdingSub.country = value.Country[0];
      shareholdingSub.share = value.Share[0];
      shareholdingSub.parentUEN = value.ParentUEN[0];
      shareholdingSub.turnover = value.Turnover[0];
      shareholdingSub.noOfStaff = value.NoOfStaff[0];

      //springForm.shareholdingSub.push(shareholdingSub);
    });

    let subsidiariesTable =
      result['xfa:data'].form1[0].CompanyData1[0].ShareholdingSub[0]
        .SubsidiariesDetails[0].SubsidiariesTable[0].SubsidiariesRow;
    //springForm.subsidiaries = [];

    subsidiariesTable.forEach(function(value) {
      let subsidiaries: any = {};
      subsidiaries.subsidLevel = value.SubsidLevel[0];
      subsidiaries.name = value.Name[0];
      subsidiaries.sharePercent = value.SharePercent[0];
      subsidiaries.noStaff = value.NoStaff[0];
      subsidiaries.UEN = value.UEN[0];

      //springForm.subsidiaries.push(subsidiaries);
    });

    let loanAppliedTable =
      result['xfa:data'].form1[0].Declarations[0].TypeOfLoan[0].LoanApplied[0];

    //springForm.invStockFinancing = Number(loanAppliedTable.InvStockFinancing[0].InvStockFinancingAmt[0]);
    //springForm.workingCapital = Number(loanAppliedTable.WorkingCapital[0].WorkingCapitalAmt[0]);
    //springForm.aRDiscount = Number(loanAppliedTable.ARDiscount[0].ARDiscountAmt[0]);
    //springForm.capitalLoan = Number(loanAppliedTable.CapitalLoan[0].CapitalLoanAmt[0]);
    //springForm.bankerGuarantee = Number(loanAppliedTable.BankerGuarantee[0].BankerGuranteeAmt[0]);
    //springForm.total = Number(loanAppliedTable.Total[0].TotalLoanFacilityAmt[0]);
    //
    //
    //
    //springForm.loanDomesticTrade1 = Number(result["xfa:data"].form1[0].Declarations[0].TypeOfLoan[0].PurposeLoan[0].Row2[0].LoanDomesticTrade[0]);
    //springForm.loanDomesticTrade2 = Number(result["xfa:data"].form1[0].Declarations[0].TypeOfLoan[0].PurposeLoan[0].Row2[0].LoanOverseasTrade[0]);

    return springForm;
  }
}
