import * as Hapi from 'hapi';
import * as Boom from 'boom';
import * as Jwt from 'jsonwebtoken';
import {
  IFormUpload,
  FormUploadModel,
  FormUploadExportData,
  ValidationSummary
} from './form-upload';
import { IDatabase } from '../../database';
import { IServerConfigurations } from '../../configurations';
import {
  IRequest,
  Ispring,
  FileMetaData,
  ILoginRequest
} from '../../interfaces/request';
import DocumentService from '../../services/document-service';
import { ILoan } from '../loan/loan';
import { IMidTerm } from '../mid-term/mid-term';
import { IConsortium } from '../master-data/consortium/consortium';
import { BADRESP } from 'dns';
const fs = require('fs');
const XLSX = require('xlsx');

export default class FormUploadController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  private docService: DocumentService;
  private server: Hapi.Server;

  constructor(
    configs: IServerConfigurations,
    database: IDatabase,
    docService: DocumentService,
    server: Hapi.Server
  ) {
    this.database = database;
    this.configs = configs;
    this.docService = docService;
    this.server = server;
  }

  public async createFormUpload(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      const userId = request.auth.credentials.id;
      let requestPayload: any = request['payload'];
      requestPayload['lastCommitedBy'] = userId;
      requestPayload['lastCommitedDate'] = new Date();
      let formUpload: any = await this.database.formUploadModel.create(
        requestPayload
      );
      delete formUpload['__v'];
      console.log(formUpload);
      //return h.response(springform).code(201);
      return h.response(formUpload).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateFormUpload(request: IRequest, h: Hapi.ResponseToolkit) {
    console.log(JSON.stringify(request.params.id));
    const id = request.params.id;
    const userId = request.auth.credentials.id;
    let requestPayload: any = request['payload'];
    requestPayload['lastCommitedBy'] = userId;
    requestPayload['lastCommitedDate'] = new Date();

    try {
      let formUpload: IFormUpload = await this.database.formUploadModel.findByIdAndUpdate(
        id,
        { $set: requestPayload },
        { new: true }
      );
      delete formUpload['__v'];
      return formUpload;
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }
  public async updateCommitChanges(request: IRequest, h: Hapi.ResponseToolkit) {
    let commitChangesData: any = request['payload'];
    console.log(JSON.stringify(commitChangesData));
    const userId = request.auth.credentials.id;
    const lastModifiedDate = new Date();

    let errorCommit;
    for (const commitData of commitChangesData) {
      let queryUpdate = {
        'creditInfo.loanApplicationNumber': commitData.lisAppNo,
        grossSGDPremiumPL: commitData.lis5Primary,
        grossSGDPremiumTUL: commitData.lis5Auto,
        grossSGDPremiumBG: commitData.lis5BG,
        grossSGDPremiumLISPlus: commitData.lisPlusS9,
        lastCommitedDate: lastModifiedDate,
        lastCommitedBy: userId
      };
      try {
        if (commitData.isMidTerm) {
          let midTerm: IMidTerm = await this.database.midTermModel.updateOne(
            { _id: commitData._id },
            {
              $set: queryUpdate
            }
          );
        } else {
          let loan: ILoan = await this.database.loanModel.updateOne(
            { _id: commitData._id },
            {
              $set: queryUpdate
            }
          );
        }
      } catch (error) {
        errorCommit = error;
      }
    }
    if (errorCommit) {
      return Boom.badImplementation(errorCommit);
    } else {
      return true;
    }
  }

  public async infoFormUpload(request: IRequest, h: Hapi.ResponseToolkit) {
    const pfiCode = request.params.pfiCode;
    let formUpload: IFormUpload = await this.database.formUploadModel.findOne({
      pfiCode: pfiCode
    });
    if (formUpload) {
      delete formUpload['__v'];
      return formUpload;
    } else {
      return Boom.notFound('Not Found');
    }
  }

  public async uploadForm1(request, h: Hapi.ResponseToolkit) {
    try {
      console.log('__________________________');
      console.log(request.payload);
      let result: any;
      let files = [request.payload['file']];
      if (files && files.length > 0) {
        result = await this.getFormUploadData(files[0]._data);
        if (result) {
          const userId = request.auth.credentials.id;
          let date = new Date();
          const fileName =
            'form-upload' +
            date.getDay() +
            date.getMonth() +
            date.getFullYear() +
            date.getHours() +
            date.getMinutes() +
            date.getSeconds() +
            date.getMilliseconds() +
            '.xlsx';
          var contentType = 'binary/octet-stream';
          var fileData = files[0]._data;
          let fileMetaData: FileMetaData = new FileMetaData();
          fileMetaData.contentType = contentType;
          fileMetaData.file = fileData;
          fileMetaData.fileName = fileName;
          fileMetaData.refAppId = result.pfi;
          fileMetaData.collectionName = 'FORM1UPLOAD';
          fileMetaData.documentType = 'Form 1 Upload';
          fileMetaData.uploadedBy = userId;
          // fileMetaData.uploadedBy = request.auth.credentials.id;

          let uploadedFile = this.docService.uploadFile(fileMetaData);
          console.log('uploadedFile:' + uploadedFile);
        }
        return result;
      } else {
        return Boom.badImplementation(
          'Upload File error. Please contact admin.'
        );
      }
    } catch (error) {
      console.log(error);
      return Boom.badImplementation(
        'Internal server error. Please contact admin.'
      );
    }
  }

  private async getFormUploadData(data: FormUploadExportData) {
    let formUploadExportData: FormUploadExportData = new FormUploadExportData();
    const workbook = XLSX.read(data, { type: 'buffer' });
    const sheet_name_list = workbook.SheetNames;
    /* Get worksheet */
    let worksheet = workbook.Sheets[sheet_name_list[0]];

    let address_of_policy = 'B4';
    /* Find desired cell */
    let policy_cell = worksheet[address_of_policy];

    /* Get the value */
    let policy_value = policy_cell ? policy_cell.v : null;
    if (policy_value && policy_value === 'Policy Number: ') {
      let address_of_policyNo = 'C4';
      let address_of_pfi = 'C5';
      let address_of_reportingMonth = 'M3';

      let policyNo_cell = worksheet[address_of_policyNo];
      let pfi_cell = worksheet[address_of_pfi];
      let reportingMonth_cell = worksheet[address_of_reportingMonth];
      // console.log(
      //   JSON.stringify(
      //     new Date((reportingMonth_cell.v - (25567 + 2)) * 86400 * 1000)
      //   )
      // );

      formUploadExportData.policyNumber = policyNo_cell
        ? policyNo_cell.v
        : null;
      formUploadExportData.pfi = pfi_cell ? pfi_cell.v : null;
      formUploadExportData.reportingMonth = reportingMonth_cell
        ? reportingMonth_cell.w
        : null;

      // Check Valid File & Header Details
      // range.s.c = 0; // 0 == XLSX.utils.decode_col("A")
      // range.s.r = 0;
      // range.e.c = 13; // 6 == XLSX.utils.decode_col("N")
      // range.e.r = 4;
      // let headerRange = XLSX.utils.encode_range(range);

      // let resultHeader = await XLSX.utils.sheet_to_json(worksheet, {
      //   header: 'A',
      //   blankRows: false,
      //   defval: null,
      //   range: headerRange
      // });

      let range = XLSX.utils.decode_range(worksheet['!ref']);
      range.s.c = 0; // 0 == XLSX.utils.decode_col("A")
      range.s.r = 10;
      range.e.c = 43; // 6 == XLSX.utils.decode_col("AR")
      var new_range = XLSX.utils.encode_range(range);

      let lisData = await XLSX.utils.sheet_to_json(
        workbook.Sheets[sheet_name_list[0]],
        {
          header: 'A',
          blankRows: false,
          defval: null,
          cellDates: true,
          range: new_range
        }
      );
      if (lisData) {
        let validationSummaryList: ValidationSummary[] = [];
        for (const excelData of lisData) {
          let validationSummary: ValidationSummary;
          if (excelData['B']) {
            // if (excelData['B'] && excelData['C']) {
            validationSummary = await this.validateExcelData(excelData);
            if (validationSummary) {
              validationSummaryList.push(validationSummary);
            }
          }
        }
        // await lisData.forEach(async (excelData) => {

        // });
        formUploadExportData.validationSummary = validationSummaryList;
      }

      if (formUploadExportData) {
        return formUploadExportData;
      }
    }

    return Boom.preconditionFailed(
      'Form1 Upload application configuration issue. Please contact server admin.'
    );

    // return formUploadExportData;
  }

  async validateExcelData(excelData: any) {
    let validationSummary = new ValidationSummary();
    validationSummary.pfi = excelData['B'];
    validationSummary.lisAppNo = excelData['C'];
    validationSummary.domesticLIS = excelData['D'];
    validationSummary.exportLIS = excelData['E'];
    validationSummary.tradeFacilities = excelData['F'];
    validationSummary.bgFacility = excelData['G'];
    validationSummary.totalLISLimitApplied = excelData['H'];
    validationSummary.LOAcceptanceDate = excelData['I'];
    validationSummary.borrowerName = excelData['J'];
    validationSummary.UENNumber = excelData['K'];
    validationSummary.latestYearTurnover = excelData['L'];
    validationSummary.latestYearNPBT = excelData['M'];
    validationSummary.limitsApprovedPrimaryOnly = excelData['N'];
    validationSummary.limitsApprovedAuto = excelData['O'];
    validationSummary.limitsApprovedPrimaryBGOnly = excelData['P'];
    validationSummary.tenureBGS3 = excelData['Q'];
    validationSummary.limitsApprovedLISPlus = excelData['R'];
    validationSummary.lisPrimaryS3 = excelData['S'];
    validationSummary.lisAutoS3 = excelData['T'];
    validationSummary.lisBGS3 = excelData['U'];
    validationSummary.typeOfLimit = excelData['V'];
    validationSummary.totalAppliedLimit = excelData['W'];
    validationSummary.approvedLimitChangesPrimary = excelData['X'];
    validationSummary.approvedLimitChangesAuto = excelData['Y'];
    validationSummary.approvedLimitChangesBG = excelData['Z'];
    validationSummary.tenureBGS5 = excelData['AA'];
    validationSummary.proRateChange = excelData['AB'];
    validationSummary.date1Limit = excelData['AC'];
    validationSummary.date2Limit = excelData['AD'];
    validationSummary.lisPrimaryS5 = excelData['AE'];
    validationSummary.lisAutoS5 = excelData['AF'];
    validationSummary.lisBGS5 = excelData['AG'];
    validationSummary.totalApprovedLimit = excelData['AH'];
    validationSummary.appliedMidTerm = excelData['AI'];
    validationSummary.approvedMidTerm = excelData['AJ'];
    validationSummary.limitIncreaseDate = excelData['AK'];
    validationSummary.remarks = excelData['AL'];
    validationSummary.totalLIS5LimitsApproved = excelData['AM'];
    validationSummary.totalLISPlusLimitsApproved = excelData['AN'];
    validationSummary.lis5Primary = excelData['AO'];
    validationSummary.lis5Auto = excelData['AP'];
    validationSummary.lis5BG = excelData['AQ'];
    validationSummary.lisPlusS9 = excelData['AR'];

    // Basic Validation to check PFI,UEN & Borrower Name
    if (
      !validationSummary.pfi ||
      !validationSummary.borrowerName ||
      !validationSummary.UENNumber
    ) {
      validationSummary.validatationType = 'invalid';
      return validationSummary;
    }

    // Check record request type and check LO Acceptance for Loan and Limit Start Date for Mid Term
    if (
      validationSummary.typeOfLimit ||
      validationSummary.totalAppliedLimit ||
      validationSummary.approvedLimitChangesPrimary ||
      validationSummary.approvedLimitChangesAuto ||
      validationSummary.approvedLimitChangesBG ||
      validationSummary.tenureBGS5 ||
      validationSummary.proRateChange ||
      validationSummary.date1Limit ||
      validationSummary.date2Limit ||
      validationSummary.totalApprovedLimit ||
      validationSummary.appliedMidTerm ||
      validationSummary.approvedMidTerm ||
      validationSummary.limitIncreaseDate
    ) {
      validationSummary.isMidTerm = true;
      if (!validationSummary.date1Limit) {
        validationSummary.validatationType = 'invalid';
        return validationSummary;
      } else {
        let date1LimitDate: any = validationSummary.date1Limit;
        date1LimitDate = date1LimitDate.split('/');
        let startQuerydate1LimitDate = new Date(
          date1LimitDate[2],
          date1LimitDate[1] - 1,
          date1LimitDate[0]
        );
        let endQuerydate1LimitDate = new Date(
          startQuerydate1LimitDate.getTime()
        );
        endQuerydate1LimitDate.setDate(endQuerydate1LimitDate.getDate() + 1);
        let midTerm: IMidTerm = await this.database.midTermModel
          .findOne({
            'creditInfo.pfiCode': validationSummary.pfi,
            'creditInfo.borrowerRegName': validationSummary.borrowerName,
            'creditInfo.aCRArefNo': validationSummary.UENNumber,
            status: { $nin: ['Draft', 'Duplicate'] },
            'creditInfo.effectiveStartDate': {
              $gte: startQuerydate1LimitDate,
              $lt: endQuerydate1LimitDate
            }
          })
          .lean(true);
        if (midTerm) {
          validationSummary = await this.checkDiscrepancy(
            validationSummary,
            midTerm
          );
          return validationSummary;
        } else {
          validationSummary.validatationType = 'invalid';
          return validationSummary;
        }
      }
    } else {
      if (!validationSummary.LOAcceptanceDate) {
        validationSummary.validatationType = 'invalid';
        return validationSummary;
      } else {
        let loAcceptanceDate: any = validationSummary.LOAcceptanceDate;
        loAcceptanceDate = loAcceptanceDate.split('/');
        let startQueryLODate = new Date(
          loAcceptanceDate[2],
          loAcceptanceDate[1] - 1,
          loAcceptanceDate[0]
        );
        let endQueryLODate = new Date(startQueryLODate.getTime());
        endQueryLODate.setDate(endQueryLODate.getDate() + 1);

        // console.log('LOA Date ' + validationSummary.LOAcceptanceDate);
        // console.log('start ' + startQueryLODate);
        // console.log('end ' + endQueryLODate);
        let loan: ILoan = await this.database.loanModel
          .findOne({
            'creditInfo.pfiCode': validationSummary.pfi,
            'creditInfo.borrowerRegName': validationSummary.borrowerName,
            'creditInfo.aCRArefNo': validationSummary.UENNumber,
            status: { $nin: ['Draft', 'Duplicate'] },
            'creditInfo.loAcceptanceDate': {
              $gte: startQueryLODate,
              $lt: endQueryLODate
            }
          })
          .lean(true);
        if (loan) {
          validationSummary = await this.checkDiscrepancy(
            validationSummary,
            loan
          );
          return validationSummary;
        } else {
          validationSummary.validatationType = 'invalid';
          return validationSummary;
        }
      }
    }

    // validationSummary.discrepancyList = [];
    // validationSummary.discrepancyList.push('pfi');
    // return validationSummary;
  }

  async checkDiscrepancy(validationSummary: ValidationSummary, lisData: any) {
    validationSummary._id = lisData._id;
    validationSummary.discrepancyList = [];
    let formattedData: ValidationSummary = await this.getFormattedValidationSummary(
      validationSummary
    );
    //console.log(formattedData);
    let consortium: IConsortium = await this.database.consortiumModel.findById(
      lisData.consortium
    );
    let baseLoan: ILoan;
    if (validationSummary.isMidTerm && lisData.loanBaseId) {
      baseLoan = await this.database.loanModel.findById(lisData.loanBaseId);
    }

    // Declare Base Loan variable
    let lisAppNo: string;
    let domesticLIS: string;
    let exportLIS: string;
    let tradeFacilities: boolean;
    let bgFacility: boolean;
    let totalLISLimitApplied: string;
    let loAcceptanceDate: string;
    let latestYearTurnover: string;
    let latestYearNPBT: string;
    let limitsApprovedPrimaryOnly: string;
    let limitsApprovedAuto: string;
    let limitsApprovedPrimaryBGOnly: string;
    let tenureBGS3: string;
    let limitsApprovedLISPlus: string;

    // Declare Mid-Term Loan variable
    let typeOfLimit: boolean;
    let totalAppliedLimit: string;
    let approvedLimitChangesPrimary: string;
    let approvedLimitChangesAuto: string;
    let approvedLimitChangesBG: string;
    let tenureBGS5: string;
    let proRateChange: string;
    let date1Limit: string;
    let date2Limit: string;
    let totalApprovedLimit: string;
    let appliedMidTerm: string;
    let approvedMidTerm: string;
    let limitIncreaseDate: string;

    lisAppNo = this.getFormattedValue(
      lisData.creditInfo,
      'loanApplicationNumber'
    );
    domesticLIS = this.getFormattedValue(
      validationSummary.isMidTerm && baseLoan
        ? baseLoan.sponsorForm
        : lisData.sponsorForm,
      'loanDomesticTrade1'
    );
    exportLIS = this.getFormattedValue(
      validationSummary.isMidTerm && baseLoan
        ? baseLoan.sponsorForm
        : lisData.sponsorForm,
      'loanDomesticTrade2'
    );

    loAcceptanceDate = this.getFormattedValue(
      validationSummary.isMidTerm && baseLoan
        ? baseLoan.creditInfo
        : lisData.creditInfo,
      'loAcceptanceDate'
    );

    tradeFacilities = await this.checkFacilityValues(
      validationSummary.isMidTerm && baseLoan
        ? baseLoan.creditInfo
        : lisData.creditInfo,
      consortium,
      formattedData.tradeFacilities
    );
    bgFacility = await this.checkFacilityValues(
      validationSummary.isMidTerm && baseLoan
        ? baseLoan.creditInfo
        : lisData.creditInfo,
      consortium,
      formattedData.bgFacility,
      'BG'
    );
    // tradeFacilities = this.getFormattedValue(
    //   validationSummary.isMidTerm && baseLoan
    //     ? baseLoan.creditInfo
    //     : lisData.creditInfo,
    //   'loAcceptanceDate'
    // );

    // bgFacility = this.getFormattedValue(
    //   validationSummary.isMidTerm && baseLoan
    //     ? baseLoan.creditInfo
    //     : lisData.creditInfo,
    //   'loAcceptanceDate'
    // );

    if (consortium && consortium.consortiumName === 'UOB') {
      totalLISLimitApplied = this.getFormattedValue(
        validationSummary.isMidTerm && baseLoan
          ? baseLoan.creditInfo
          : lisData.creditInfo,
        'sgdCurrency'
      );
    } else {
      totalLISLimitApplied = this.getFormattedValue(
        validationSummary.isMidTerm && baseLoan
          ? baseLoan.creditInfo
          : lisData.creditInfo,
        'totalRequstedLimitSGD'
      );
    }

    latestYearTurnover = this.getFormattedValue(
      validationSummary.isMidTerm && baseLoan
        ? baseLoan.sponsorForm
        : lisData.sponsorForm,
      'appSales'
    );

    latestYearNPBT = this.getFormattedValue(
      validationSummary.isMidTerm && baseLoan
        ? baseLoan.sponsorForm
        : lisData.sponsorForm,
      'appNetProfit'
    );

    limitsApprovedPrimaryOnly = this.getFormattedValue(
      validationSummary.isMidTerm && baseLoan
        ? baseLoan.creditInfo
        : lisData.creditInfo,
      'approvedPrimaryLayer'
    );

    limitsApprovedAuto = this.getFormattedValue(
      validationSummary.isMidTerm && baseLoan
        ? baseLoan.creditInfo
        : lisData.creditInfo,
      'approvedAutoTopUpLayer'
    );

    limitsApprovedPrimaryBGOnly = this.getFormattedValue(
      validationSummary.isMidTerm && baseLoan
        ? baseLoan.creditInfo
        : lisData.creditInfo,
      'approvedBgLayer'
    );

    tenureBGS3 = this.getFormattedValue(
      validationSummary.isMidTerm && baseLoan
        ? baseLoan.creditInfo
        : lisData.creditInfo,
      'tenureMonths'
    );

    limitsApprovedLISPlus = this.getFormattedValue(
      validationSummary.isMidTerm && baseLoan
        ? baseLoan.creditInfo
        : lisData.creditInfo,
      'approvedSGDLimitLISPlus'
    );

    if (validationSummary.isMidTerm && baseLoan) {
      typeOfLimit = await this.checkTypeOfLimitChanges(
        lisData.creditInfo,
        formattedData.typeOfLimit
      );

      // typeOfLimit = this.getFormattedValue(
      //   lisData.creditInfo,
      //   'approvedSGDLimitLISPlus'
      // );

      if (consortium && consortium.consortiumName === 'UOB') {
        totalAppliedLimit = this.getFormattedValue(
          lisData.creditInfo,
          'sgdCurrency'
        );
      } else {
        totalAppliedLimit = this.getFormattedValue(
          lisData.creditInfo,
          'totalRequstedLimitSGD'
        );
      }

      approvedLimitChangesPrimary = this.getFormattedValue(
        lisData.creditInfo,
        'approvedPrimaryLayer'
      );
      approvedLimitChangesAuto = this.getFormattedValue(
        lisData.creditInfo,
        'approvedAutoTopUpLayer'
      );
      approvedLimitChangesBG = this.getFormattedValue(
        lisData.creditInfo,
        'approvedBgLayer'
      );
      tenureBGS5 = this.getFormattedValue(lisData.creditInfo, 'tenureMonths');
      proRateChange = this.getFormattedValue(
        lisData.creditInfo,
        'proRateRatio'
      );
      date1Limit = this.getFormattedValue(
        lisData.creditInfo,
        'effectiveStartDate'
      );
      date2Limit = this.getFormattedValue(
        lisData.creditInfo,
        'effectiveEndDate'
      );

      let sumApprovedLimit = lisData.creditInfo
        ? lisData.creditInfo.approvedPrimaryLayer +
          lisData.creditInfo.approvedAutoTopUpLayer
        : null;
      totalApprovedLimit = sumApprovedLimit
        ? sumApprovedLimit.toString()
        : null;

      appliedMidTerm = totalAppliedLimit; // Same as total applied limit

      approvedMidTerm = this.getFormattedValue(
        lisData.creditInfo,
        'approvedSGDLimitLISPlus'
      );
      limitIncreaseDate = this.getFormattedValue(
        lisData.creditInfo,
        'lISPlusApprovedDate'
      );
    }

    // Check Discrepancy
    if (formattedData.lisAppNo !== lisAppNo) {
      validationSummary.discrepancyList.push('lisAppNo');
    }

    if (formattedData.domesticLIS !== domesticLIS) {
      validationSummary.discrepancyList.push('domesticLIS');
    }
    if (formattedData.exportLIS !== exportLIS) {
      validationSummary.discrepancyList.push('exportLIS');
    }

    if (!tradeFacilities) {
      validationSummary.discrepancyList.push('tradeFacilities');
    }

    if (!bgFacility) {
      validationSummary.discrepancyList.push('bgFacility');
    }

    if (formattedData.totalLISLimitApplied !== totalLISLimitApplied) {
      validationSummary.discrepancyList.push('totalLISLimitApplied');
    }

    if (
      formattedData.LOAcceptanceDate !==
      this.removeDefaultTxt(loAcceptanceDate, 'date')
    ) {
      validationSummary.discrepancyList.push('LOAcceptanceDate');
    }

    // console.log('formattedData::' + formattedData.latestYearTurnover);
    // console.log('LISData::' + latestYearTurnover);

    if (formattedData.latestYearTurnover !== latestYearTurnover) {
      validationSummary.discrepancyList.push('latestYearTurnover');
    }
    if (formattedData.latestYearNPBT !== latestYearNPBT) {
      validationSummary.discrepancyList.push('latestYearNPBT');
    }

    if (formattedData.limitsApprovedPrimaryOnly !== limitsApprovedPrimaryOnly) {
      validationSummary.discrepancyList.push('limitsApprovedPrimaryOnly');
    }

    if (consortium && consortium.consortiumName !== 'UOB') {
      if (formattedData.limitsApprovedAuto !== limitsApprovedAuto) {
        validationSummary.discrepancyList.push('limitsApprovedAuto');
      }
    }

    if (
      formattedData.limitsApprovedPrimaryBGOnly !== limitsApprovedPrimaryBGOnly
    ) {
      validationSummary.discrepancyList.push('limitsApprovedPrimaryBGOnly');
    }

    if (formattedData.tenureBGS3 !== tenureBGS3) {
      validationSummary.discrepancyList.push('tenureBGS3');
    }

    if (formattedData.limitsApprovedLISPlus !== limitsApprovedLISPlus) {
      validationSummary.discrepancyList.push('limitsApprovedLISPlus');
    }

    // mid-term section 5 & 6
    if (validationSummary.isMidTerm) {
      if (!typeOfLimit) {
        validationSummary.discrepancyList.push('typeOfLimit');
      }

      if (formattedData.totalAppliedLimit !== totalAppliedLimit) {
        validationSummary.discrepancyList.push('totalAppliedLimit');
      }

      if (
        formattedData.approvedLimitChangesPrimary !==
        approvedLimitChangesPrimary
      ) {
        validationSummary.discrepancyList.push('approvedLimitChangesPrimary');
      }

      if (formattedData.approvedLimitChangesAuto !== approvedLimitChangesAuto) {
        validationSummary.discrepancyList.push('approvedLimitChangesAuto');
      }

      if (formattedData.approvedLimitChangesBG !== approvedLimitChangesBG) {
        validationSummary.discrepancyList.push('approvedLimitChangesBG');
      }

      if (formattedData.tenureBGS5 !== tenureBGS5) {
        validationSummary.discrepancyList.push('tenureBGS5');
      }

      if (formattedData.proRateChange !== proRateChange) {
        validationSummary.discrepancyList.push('proRateChange');
      }

      if (
        formattedData.date1Limit !== this.removeDefaultTxt(date1Limit, 'date')
      ) {
        validationSummary.discrepancyList.push('date1Limit');
      }

      if (
        formattedData.date2Limit !== this.removeDefaultTxt(date2Limit, 'date')
      ) {
        validationSummary.discrepancyList.push('date2Limit');
      }

      if (formattedData.totalApprovedLimit !== totalApprovedLimit) {
        validationSummary.discrepancyList.push('totalApprovedLimit');
      }

      if (formattedData.appliedMidTerm !== appliedMidTerm) {
        validationSummary.discrepancyList.push('appliedMidTerm');
      }
      if (formattedData.approvedMidTerm !== approvedMidTerm) {
        validationSummary.discrepancyList.push('approvedMidTerm');
      }
      if (
        formattedData.limitIncreaseDate !==
        this.removeDefaultTxt(limitIncreaseDate, 'date')
      ) {
        validationSummary.discrepancyList.push('limitIncreaseDate');
      }
    }

    validationSummary.lis5Primary = formattedData.lis5Primary;
    validationSummary.lis5Auto = formattedData.lis5Auto;
    validationSummary.lis5BG = formattedData.lis5BG;
    validationSummary.lisPlusS9 = formattedData.lisPlusS9;

    if (
      Array.isArray(validationSummary.discrepancyList) &&
      validationSummary.discrepancyList.length === 0
    ) {
      validationSummary.validatationType = 'pass';
    }
    return validationSummary;
  }

  removeDefaultTxt(data: string, type?: string) {
    if (data) {
      switch (type) {
        case 'currency':
          data = data
            .replace('$', '')
            .replace('-', '')
            .replace(',', '');
          const formattedData = parseFloat(data);
          if (formattedData && formattedData !== NaN) {
            data = formattedData.toString();
          }
          break;
        case 'percentage':
          data = data.replace('%', '');
          break;
        case 'date':
          data = this.convertDate(data);
          break;
      }
      data = data.trim();
    }
    return data;
  }

  getFormattedValue(data: any, field: string) {
    if (data) {
      return data[field] ? data[field].toString() : null;
    } else {
      return null;
    }
  }

  convertDate(inputFormat) {
    function pad(s) {
      return s < 10 ? '0' + s : s;
    }
    var d = new Date(inputFormat);
    return [pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join('/');
  }

  async checkFacilityValues(
    data: any,
    consortium: IConsortium,
    formattedValue: string,
    fieldType?: string
  ) {
    let result = false;
    if (data && consortium) {
      let IsIF_SF: boolean;
      let IsSPWC: boolean;
      let IsF_ARF: boolean;
      let IsOWCL: boolean;
      let IsBG: boolean;
      if (consortium.consortiumName === 'UOB') {
        IsIF_SF = data.inventoryStockChkBx;
        IsSPWC = data.structuredWorkingCapitalChkBx;
        IsF_ARF = data.recourseFactoringBillChkBx;
        IsOWCL = data.overseasWorkingCapitalChkBx;
        IsBG = data.bankersGuaranteeAmountChkBx;
      } else {
        IsIF_SF = data.inventoryTradeChkBx;
        IsSPWC = data.workingCapChkBx;
        IsF_ARF = data.resourceFactoringChkBx;
        IsOWCL = data.overseaseWorkingChkBx;
        IsBG = data.bankersGuaranteeChkBx;
      }

      if (!fieldType || fieldType !== 'BG') {
        if (formattedValue) {
          let splitData = formattedValue.split(',');
          if (splitData) {
            let IF_SFResult: boolean;
            let SPWCResult: boolean;
            let F_ARCResult: boolean;
            let OWCLResult: boolean;
            for (const typeValue of splitData) {
              switch (typeValue.trim()) {
                case 'IF/SF':
                  IF_SFResult = true;
                  if (!IsIF_SF) {
                    return false;
                  } else {
                    result = true;
                  }
                  break;
                case 'SPWC':
                  SPWCResult = true;
                  if (!IsSPWC) {
                    return false;
                  } else {
                    result = true;
                  }
                  break;
                case 'F/ARC':
                  F_ARCResult = true;
                  if (!IsF_ARF) {
                    return false;
                  } else {
                    result = true;
                  }
                  break;
                case 'OWCL':
                  OWCLResult = true;
                  if (!IsOWCL) {
                    return false;
                  } else {
                    result = true;
                  }
                  break;
                case '':
                  break;
                default:
                  return false;
              }
            }

            if (IsIF_SF && !IF_SFResult) {
              return false;
            }

            if (IsSPWC && !SPWCResult) {
              return false;
            }

            if (IsF_ARF && !F_ARCResult) {
              return false;
            }

            if (IsOWCL && !OWCLResult) {
              return false;
            }
          } else {
            if (!IsIF_SF && !IsSPWC && !IsF_ARF && !IsOWCL) {
              result = true;
            }
          }
        }
      } else {
        if (IsBG) {
          console.log('formattedValue::' + formattedValue);
          if (formattedValue && formattedValue.trim() !== ' '  && formattedValue.trim() !== '-') {
            result = true;
          }
        } else {
          if (!formattedValue || formattedValue.trim() !== ' ' || formattedValue.trim() === '-') {
            result = true;
          }
        }
      }
    }

    return result;
  }

  async checkTypeOfLimitChanges(data: any, formattedValue: string) {
    let result = false;
    if (data && formattedValue) {
      let natureOfApplication = data.natureOfApplication;
      if (formattedValue === 'Mid-Term') {
        if (
          natureOfApplication === 'MID-TERM INCR - UN-UTILISED' ||
          natureOfApplication === 'DECREASE UTILISED' ||
          natureOfApplication === 'MID-TERM INCR - UTILISED'
        ) {
          result = true;
        }
      } else if (formattedValue === 'Temp (excl. Auto & BG)') {
        if (natureOfApplication === 'Temporary Increase') {
          result = true;
        }
      }
    }
    return result;
  }

  getFormattedValidationSummary(validationSummary: ValidationSummary) {
    let formatData: ValidationSummary = new ValidationSummary();
    formatData = Object.assign({}, validationSummary);
    formatData.pfi = this.removeDefaultTxt(formatData.pfi);
    formatData.lisAppNo = this.removeDefaultTxt(formatData.lisAppNo);
    formatData.domesticLIS = this.removeDefaultTxt(
      formatData.domesticLIS,
      'percentage'
    );
    formatData.exportLIS = this.removeDefaultTxt(
      formatData.exportLIS,
      'percentage'
    );
    formatData.tradeFacilities = this.removeDefaultTxt(
      formatData.tradeFacilities
    );
    formatData.bgFacility = this.removeDefaultTxt(formatData.bgFacility);
    formatData.totalLISLimitApplied = this.removeDefaultTxt(
      formatData.totalLISLimitApplied,
      'currency'
    );
    formatData.LOAcceptanceDate = this.removeDefaultTxt(
      formatData.LOAcceptanceDate
    ); // Date
    formatData.borrowerName = this.removeDefaultTxt(formatData.borrowerName);
    formatData.UENNumber = this.removeDefaultTxt(formatData.UENNumber);
    formatData.latestYearTurnover = this.removeDefaultTxt(
      formatData.latestYearTurnover,
      'currency'
    );
    formatData.latestYearNPBT = this.removeDefaultTxt(
      formatData.latestYearNPBT,
      'currency'
    );
    formatData.limitsApprovedPrimaryOnly = this.removeDefaultTxt(
      formatData.limitsApprovedPrimaryOnly,
      'currency'
    );
    formatData.limitsApprovedAuto = this.removeDefaultTxt(
      formatData.limitsApprovedAuto,
      'currency'
    );
    formatData.limitsApprovedPrimaryBGOnly = this.removeDefaultTxt(
      formatData.limitsApprovedPrimaryBGOnly,
      'currency'
    );
    formatData.tenureBGS3 = this.removeDefaultTxt(
      formatData.tenureBGS3,
      'currency'
    );
    formatData.limitsApprovedLISPlus = this.removeDefaultTxt(
      formatData.limitsApprovedLISPlus,
      'currency'
    );
    formatData.lisPrimaryS3 = this.removeDefaultTxt(
      formatData.lisPrimaryS3,
      'percentage'
    );
    formatData.lisAutoS3 = this.removeDefaultTxt(
      formatData.lisAutoS3,
      'percentage'
    );
    formatData.lisBGS3 = this.removeDefaultTxt(
      formatData.lisBGS3,
      'percentage '
    );
    formatData.typeOfLimit = this.removeDefaultTxt(formatData.typeOfLimit);
    formatData.totalAppliedLimit = this.removeDefaultTxt(
      formatData.totalAppliedLimit,
      'currency'
    );
    formatData.approvedLimitChangesPrimary = this.removeDefaultTxt(
      formatData.approvedLimitChangesPrimary,
      'currency'
    );
    formatData.approvedLimitChangesAuto = this.removeDefaultTxt(
      formatData.approvedLimitChangesAuto,
      'currency'
    );
    formatData.approvedLimitChangesBG = this.removeDefaultTxt(
      formatData.approvedLimitChangesBG,
      'currency'
    );
    formatData.tenureBGS5 = this.removeDefaultTxt(formatData.tenureBGS5);
    formatData.proRateChange = this.removeDefaultTxt(
      formatData.proRateChange,
      'percentage'
    );
    formatData.date1Limit = this.removeDefaultTxt(formatData.date1Limit); // Date
    formatData.date2Limit = this.removeDefaultTxt(formatData.date2Limit); // Date
    formatData.lisPrimaryS5 = this.removeDefaultTxt(
      formatData.lisPrimaryS5,
      'percentage '
    );
    formatData.lisAutoS5 = this.removeDefaultTxt(
      formatData.lisAutoS5,
      'percentage '
    );
    formatData.lisBGS5 = this.removeDefaultTxt(
      formatData.lisBGS5,
      'percentage '
    );
    formatData.totalApprovedLimit = this.removeDefaultTxt(
      formatData.totalApprovedLimit,
      'currency'
    );
    formatData.appliedMidTerm = this.removeDefaultTxt(
      formatData.appliedMidTerm,
      'currency'
    );
    formatData.approvedMidTerm = this.removeDefaultTxt(
      formatData.approvedMidTerm,
      'currency'
    );
    formatData.limitIncreaseDate = this.removeDefaultTxt(
      formatData.limitIncreaseDate
    ); // Date
    formatData.remarks = this.removeDefaultTxt(formatData.remarks);
    formatData.totalLIS5LimitsApproved = this.removeDefaultTxt(
      formatData.totalLIS5LimitsApproved,
      'currency'
    );
    formatData.totalLISPlusLimitsApproved = this.removeDefaultTxt(
      formatData.totalLISPlusLimitsApproved,
      'currency'
    );
    formatData.lis5Primary = this.removeDefaultTxt(
      formatData.lis5Primary,
      'currency'
    );
    formatData.lis5Auto = this.removeDefaultTxt(
      formatData.lis5Auto,
      'currency'
    );
    formatData.lis5BG = this.removeDefaultTxt(formatData.lis5BG, 'currency');
    formatData.lisPlusS9 = this.removeDefaultTxt(
      formatData.lisPlusS9,
      'currency'
    );
    return formatData;
  }
}
