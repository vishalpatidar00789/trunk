import * as Mongoose from 'mongoose';
import * as Bcrypt from 'bcryptjs';

export interface IFormUpload extends Mongoose.Document {
  _id: string;
  pfiCode: string;
  lastCommitedDate?: Date;
  lastCommitedBy?: string;
}

export const FormUploadSchema = new Mongoose.Schema({
  pfiCode: { type: String, required: true },
  lastCommitedDate: { type: Date, required: true },
  lastCommitedBy: { type: String, required: true }
});

var diffHistory = require("mongoose-diff-history/diffHistory");
FormUploadSchema.plugin(diffHistory.plugin);

export class FormUploadExportData {
  policyNumber: string;
  pfi: string;
  reportingMonth: string;
  validationSummary: ValidationSummary[];
}
export class ValidationSummary {
  _id?: string;
  pfi?: string;
  lisAppNo?: string;
  domesticLIS?: string;
  exportLIS?: string;
  tradeFacilities?: string;
  bgFacility?: string;
  totalLISLimitApplied?: string;
  LOAcceptanceDate?: string;
  borrowerName?: string;
  UENNumber?: string;
  latestYearTurnover?: string;
  latestYearNPBT?: string;
  limitsApprovedPrimaryOnly?: string;
  limitsApprovedAuto?: string;
  limitsApprovedPrimaryBGOnly?: string;
  tenureBGS3?: string;
  limitsApprovedLISPlus?: string;
  lisPrimaryS3?: string;
  lisAutoS3?: string;
  lisBGS3?: string;
  typeOfLimit?: string;
  totalAppliedLimit?: string;
  approvedLimitChangesPrimary?: string;
  approvedLimitChangesAuto?: string;
  approvedLimitChangesBG?: string;
  tenureBGS5?: string;
  proRateChange?: string;
  date1Limit?: string;
  date2Limit?: string;
  lisPrimaryS5?: string;
  lisAutoS5?: string;
  lisBGS5?: string;
  totalApprovedLimit?: string;
  appliedMidTerm?: string;
  approvedMidTerm?: string;
  limitIncreaseDate?: string;
  remarks?: string;
  totalLIS5LimitsApproved?: string;
  totalLISPlusLimitsApproved?: string;
  lis5Primary?: string;
  lis5Auto?: string;
  lis5BG?: string;
  lisPlusS9?: string;
  isMidTerm: boolean;
  validatationType: string;
  discrepancyList: any[];
  constructor() {
    this.isMidTerm = false;
    this.validatationType = 'fail';
  }
}

export const FormUploadModel = Mongoose.model<IFormUpload>(
  'form-upload',
  FormUploadSchema
);
