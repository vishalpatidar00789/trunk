import * as Hapi from 'hapi';
import * as Boom from 'boom';
import { IPlugin } from './plugins/interfaces';
import {
  IServerConfigurations,
  ISMTPServerConfigurations,
  ILdapConfigurations,
  IMfaConfiguration
} from './configurations';
import * as Logs from './plugins/logging';
import * as Users from './api/users';
import * as Banks from './api/lookup/banks';
import * as Authorities from './api/lookup/authorities';
import * as Departments from './api/lookup/departments';
// import * as PFI from "./api/loan/pfi";
// import * as UOB from "./api/loan/uob";
import * as Loan from './api/loan';
import * as SpringForm from './api/loan/springform';
// import * as AdditionalFields from "./api/loan/additionalfields";
import * as FileUpload from './api/file-upload';
import * as Currencies from './api/lookup/currencies';
//import * as Transactions from "./api/lookup/transactions";
import * as Tranches from './api/master-data/tranch';
import * as AppManagement from './api/master-data/app-management';
import * as Adhoc from './api/adhoc';
import * as Claim from './api/claim';
import * as MidTerm from './api/mid-term';
import * as Search from './api/search';
import * as Configuration from './api/lookup/configurations';
import * as FormUpload from './api/form-upload';

import * as BrokerageManagement from './api/master-data/consortium/brokerage-management';
import * as TierRatingManagement from './api/master-data/consortium/tier-rating-management';
import * as LimitManagement from './api/master-data/consortium/limit-management';
import * as CapacityManagement from './api/master-data/capacity-management';
import * as PolicyManagement from './api/master-data/policy-management';
import * as PremiumRatesManagement from './api/master-data/consortium/premium-rates-management';
import * as SponsorManagement from './api/master-data/sponsor-management';
import * as ConsortiumManagement from './api/master-data/consortium';
import * as InsurerManagement from './api/master-data/insurers';
// import LDAPAuthService from "./services/ldap-auth-server";
import { IDatabase } from './database';
import { IRequest } from './interfaces/request';
import ConfigurationService from './services/configuration-service';
import * as UserValidator from './api/users/user-validator';
import UserService from './services/user-service';
import EmailService from './services/email-service';
const Path = require('path');

export async function init(
  configs: IServerConfigurations,
  smtpConfigs: ISMTPServerConfigurations,
  database: IDatabase,
  ldapConfigs: ILdapConfigurations,
  mfaConfigs: IMfaConfiguration
): Promise<Hapi.Server> {
  try {
    const port = process.env.PORT || configs.port;
    const host = process.env.HOST || configs.host;
    const server = new Hapi.Server({
      debug: { request: ['error'] },
      host: host,
      port: port,
      routes: {
        cors: {
          origin: ['*']
        }
      }
    });

    if (configs.routePrefix) {
      server.realm.modifiers.route.prefix = configs.routePrefix;
    }

    //  Setup Hapi Plugins
    const plugins: Array<string> = configs.plugins;
    const pluginOptions = {
      database: database,
      serverConfigs: configs
    };

    let pluginPromises: Promise<any>[] = [];

    plugins.forEach((pluginName: string) => {
      var plugin: IPlugin = require('./plugins/' + pluginName).default();
      console.log(
        `Register Plugin ${plugin.info().name} v${plugin.info().version}`
      );
      pluginPromises.push(plugin.register(server, pluginOptions));
    });

    await Promise.all(pluginPromises);

    console.log('All plugins registered successfully.');

    await server.register(require('inert'));
    console.log('Register Routes');

    // define route for static content
    server.route({
      method: 'GET',
      path: '/{param*}',
      options: { auth: false },
      handler: {
        directory: {
          path: ['build/public'],
          listing: false,
          index: ['index.html']
        }
      }
    });

    // initialize email service and pass the service reference to routes
    const emailService = new EmailService(smtpConfigs);

    // all route init goes here
    Logs.init(server, configs, database);
    Users.init(server, configs, database, emailService, ldapConfigs, mfaConfigs);
    Banks.init(server, configs, database);
    Authorities.init(server, configs, database);
    Departments.init(server, configs, database);
    // PFI.init(server, configs, database);
    // UOB.init(server, configs, database);
    Loan.init(server, configs, database, emailService);
    // AdditionalFields.init(server, configs, database);
    SpringForm.init(server, configs, database);
    FileUpload.init(server, configs, database, emailService);
    Currencies.init(server, configs, database);
    Tranches.init(server, configs, database);
    AppManagement.init(server, configs, database);
    BrokerageManagement.init(server, configs, database);
    TierRatingManagement.init(server, configs, database);
    LimitManagement.init(server, configs, database);
    CapacityManagement.init(server, configs, database, emailService);
    PolicyManagement.init(server, configs, database);
    PremiumRatesManagement.init(server, configs, database);
    SponsorManagement.init(server, configs, database);
    ConsortiumManagement.init(server, configs, database);
    InsurerManagement.init(server, configs, database);
    //Transactions.init(server, configs, database);
    Adhoc.init(server, configs, database, emailService);
    MidTerm.init(server, configs, database, emailService);
    Search.init(server, configs, database);
    Claim.init(server, configs, database, emailService);
    Configuration.init(server, configs, database);
    FormUpload.init(server, configs, database);

    console.log('Routes registered sucessfully.');
    // route inits ends here

    // new LDAPAuthService(configs).loginUser();
    return server;
  } catch (err) {
    console.log('Error starting server: ', err);
    throw err;
  }
}
