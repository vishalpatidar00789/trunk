const PromiseExtracter = require('bluebird');
const path = require('path');
var parseString = require('xml2js').parseString;
var fs = require('fs');

const scope = {
    iTextPDF: path.join(__dirname, 'bin', 'itextpdf-5.5.9.jar'),
    binPath: path.join(__dirname, 'bin')
};


export const extraxtPDF = async (pdfPath: string) => {
    let xmlPDF = require('./pdfhelper').run(pdfPath, scope);
    return xmlPDF;
};

