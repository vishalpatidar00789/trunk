import * as Hapi from "hapi";

export interface ICredentials extends Hapi.AuthCredentials {
  id: string;
}

export interface IRequestAuth extends Hapi.RequestAuth {
  credentials: ICredentials;
}

export interface IRequest extends Hapi.Request {
  auth: IRequestAuth;
}

export interface IUserCreate extends Hapi.Request {
  payload: {
    login: string;
    firstName: string;
    lastName: string;
    email: string;
    activated: Boolean;
    authorities: string[];
    createdBy: string;
    password: string;
    bank: string;
    langKey: string;
    createdDate: Date;
  };
}

export interface IUserUpdate extends Hapi.Request {
  payload: {
    login: string;
    firstName: string;
    lastName: string;
    email: string;
    activated: Boolean;
    authorities: string[];
    createdBy: string;
    // password: string;
    bank: string;
    langKey: string;
    createdDate: Date;
    lastModifiedBy: string;
    lastModifiedDate: Date;
  };
}

export interface ILoginRequest extends IRequest {
  payload: {
    userId: string;
    password: string;
  };
}

export interface Ipfi extends IRequest {
  pfi: {
    _id: string;
    lisCoinsurer: string;
    pfiName: string;
    requestorName: string;
    //submissionDate: Date;
    aCRArefNo: string;
    regName: string;
    totalReqLimit: number;
  };

}
export interface Iuob extends IRequest {
  uob: {
    _id: string;
    toLIS5Insurer: string;
    requesterName: string;
    //submissionDate: Date;
    discretiolaryLimitDL: boolean;
    creditLimitCL: boolean;
    crrRate: number;
    forBorrowerGroup: boolean;
    nameOfEntity: string;
    newLIS: boolean;
    renewalAtSameAmount: boolean;
    renewalFromSGD: boolean;
    increaseLimitTo: boolean;
    decreaseLimitTo: boolean;
    inventoryStockFinancing: boolean;
    structuredPredeliveryWorkingCapital: boolean;
    withRecourseFactoringBill: boolean;
    overseasWorkingCapitalLoansSupport: boolean;
    bankersGuarantee: boolean;
    renewalFromUSD: boolean;
  };
}
export interface IaddFields extends IRequest {
  aFields: {
    _id: string;
    pfi: string;
    typeoflimit: boolean;
    typeofLimit_Lisplus: string;
    aCRARef_No: string;
    borrowername: string;
    marshLoanapplicationStatus: string;
    receiptDateByMarshFromPFI_UOB: any;
    insurersApprovaldateasperCofaceEndorsement: any;
    datesentforLISplusifapplicable: any;
    lisPlusApprovedDate: any;
    totalAppliedLimitforLIS5_orIncrementalLimitAmountApplied: number;
    approvedSGDlimit_primarylayer: number;
    approvedSGDlimit_auto_topuplayer: number;
    lis5ApprovedBGLimit_UOI: number;
    lisplusApprovedLimit: number;
    foreignCurrencyRequestedLimitsandExchangeRatebyPFI: number;
    approvedForeignCurrencyLimit_primarylayer: number;
    approvedForeignCurrencyLimit_auto_topuplayer: number;
    approvedForeignCurrencyLimit_BGlayer: number;
    approvedForeignCurrencyLimit_LISpluslayer: number;
    lisTotalApprovedLimit: number;
    lisApprovalRatio: number;
    lisTurnaround_Days: number;
    totalApprovedLimitincludingLISPLUS: number;
    approvalRatioWithLISPLUS: number;
    turnaroundWithLISPLUS_Days: number;
    natureofApplication: string;
    loAcceptancedate: any;
    loanExpiryDate_tocalculatefromLOacceptancedate: any;
    reportedMonth: string;
    loanType: string;
    purposeofLoan_todeterminefromenteredbyPFI: string;
    domestic: number;
    exportPercentage: number;
    utilization: string;
    internalRemarks: string;
    noOfApp: number;
    adverseInformation: string;
    additionalInformationforAdverseStatus: string;
    marshReferencenumber: string;
    loanApplicationNumber: string;
    grossSGDPremium_primarylayer: number;
    grossSGDPremium_AutoTopUplayer: number;
    grossSGDPremium_BGlayer: number;
    grossSGDPremium_LISpluslayer: number;
  };
}
export interface Ispring extends IRequest {
  springeform: {
    _id: string;
    regComName: string;
    contactPersonNo?: string;
    ACRANo: string;
    corrAddress1: string;
    corrAddress2: string;
    corrAddress3: string;
    contactPerson: string;
    contactPersonEmail: string;
    businessActivity: string;
    numStaff: string;
    dateofIncorporation: any;
    appLFY: number;
    appSubLFY: number;
    appSales: number;
    appSubSales: number;
    appNetProfit: number;
    appSubNetProfit: number;
    shareholdingSub: any[];
    level: number;
    name: string;
    aCRA: string;
    type: string;
    country: string;
    share: number;
    parentUEN: string;
    turnover: number;
    noOfStaff: number;
    subsidiaries: any[];
    //  [ { subsidLevel: string; name: string; sharePercent: string; noStaff: string } ];
    invStockFinancing: number;
    workingCapital: number;
    aRDiscount: number;
    capitalLoan: number;
    bankerGuarantee: number;
    total: number;
    loanDomesticTrade1: number;
    loanDomesticTrade2: number;
  };
}
export interface IBankPayload extends IRequest {
  payload: {
    bankCode: string;
    bankName: string;
    createdBy: string;
    createdDate: Date;
    lastModifiedBy: string;
    lastModifiedDate: Date;
    activated: boolean;
    // CHANGE ADDED
    registrationNumber: string;
  };
}

export interface IConsortiumPayload extends IRequest {
  payload: {
    consortiumName: string,
    pfis: string[],
    createdBy: string;
    createdDate: Date;
    lastModifiedBy: string;
    lastModifiedDate: Date;
    activated: boolean;
  };
}

export interface IInsurerPayload extends IRequest {
  payload: {
    insurerName: string;
    registrationNUmber: string;
    isLead: boolean;
    coInsurer: string;
    coInsurerProportion: number;
    consortium: string;
    createdBy: string;
    createdDate: Date;
    lastModifiedBy: string;
    lastModifiedDate: Date;
    activated: boolean;
  };
}

export interface ILoanSearchPayload extends IRequest {
  payload: {
    marshRefNo: string;
    borrowerName: string;
    uenNumber: string;
    pfiName: string[];
    consortium: string;
    adverseStatus: string;
    typeOfDate: string;
    fromDate: any;
    toDate: any;
    natureOfApplication: string[];
    marshLoanApplicationStatus: string[];
    excludeExpiredApplications: boolean;
    app: any[];
  };
}
export class FileMetaData {
  fileId: string;
  fileName: string;
  collectionName: string;
  contentType: string;
  file: any[];
  refAppId: string;
  title: string;
  documentType: string;
  uploadedBy: string;
}

export class IGridFsFile {
  _id: string;
  filename: string;
  contentType: string;
  uploadDate: string;
  metadata: any;
}

export class IFilesByDocTypeAndRefId {
  payload: {
    docType: string;
    refAppId: string;
  };
}

export class IMailOptions {
  from: string; // sender address
  to: string; // list of receivers
  subject: string; // Subject line
  text: string; // plain text body
  html: string; // html body
}

export interface IChangePassword extends IRequest {
  payload: {
    newPassword: string;
  };
}

export interface IAccount extends IRequest {
  payload: {
    userId: string;
  };
}

export interface IOTPVerify extends IRequest {
  payload: {
    sessionId: string;
    TransactionId: string;
    otp: string;
    userData: {
      username: string;
      userEmail: string;
      orgName: string;
      ipAddress: string;
      clientGenCookie: string;
      groups: any;
      hashedUsername: string;
    };
  };
}

export interface IGenOTP extends IRequest {
  payload: {
    username: string;
    userEmail: string;
    ipAddress: string;
    clientGenCookie: string;
  };
}