import { IPlugin } from "../interfaces";
import * as Hapi from "hapi";
import { IServerConfigurations, getServerConfigs } from "../../configurations";

let config: any = getServerConfigs();

const register = async (server: Hapi.Server): Promise<void> => {
  try {
    return server.register({
      plugin: require("hapi-authorization"),
      options:{
          roles: ['OWNER', 'MANAGER', 'EMPLOYEE']
      }
    });
  } catch (err) {
    console.log(`Error registering authorization plugin: ${err}`);
    throw err;
  }
};

export default (): IPlugin => {
  return {
    register,
    info: () => {
      return { name: "authorization", version: "1.0.0" };
    }
  };
};
