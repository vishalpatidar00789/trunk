import { IPlugin, IPluginInfo } from "../interfaces";
import * as Hapi from "hapi";

const register = async (server: Hapi.Server): Promise<void> => {
  try {
    return server.register([
      require("inert"),
      require("vision"),
      {
        plugin: require("hapi-swagger"),
        options: {
          info: {
            title: "LIS Api",
            description: "LIS Api Documentation",
            version: "1.0"
          },
          tags: [
            {
              name: "banks",
              description: "Api banks interface."
            },
            {
              name: "users",
              description: "Api users interface."
            },
            {
              name: "authorities",
              description: "Api departments interface."
            },
            {
              name: "departments",
              description: "Api departments interface."
            },
            {
              name: "springforms",
              description: "Spring Form tasks interface."
            },
            {
              name: "pfi",
              description: "Api PFI interface."
            },
            {
              name: "additionalfields",
              description: "Api Additional Fields interface."
            }
          ],
          swaggerUI: true,
          documentationPage: true,
          documentationPath: "/docs"
        }
      }
    ]);
  } catch (err) {
    console.log(`Error registering swagger plugin: ${err}`);
  }
};

export default (): IPlugin => {
  return {
    register,
    info: () => {
      return { name: "Swagger Documentation", version: "1.0.0" };
    }
  };
};
