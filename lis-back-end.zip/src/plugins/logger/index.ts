import { IPlugin } from "../interfaces";
import * as Hapi from "hapi";
import { IServerConfigurations, getServerConfigs } from "../../configurations";

let config: any = getServerConfigs();


let date = new Date();
const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
let day = date.getDate();
let month = monthNames[date.getMonth()];
let year = date.getFullYear();
let logfile = config["logFile"] + "_" + day + "_" + month + "_" + year;

const register = async (server: Hapi.Server): Promise<void> => {
  try {
    return server.register({
      plugin: require("good"),
      options: {
        ops: {
          interval: 1000
        },
        reporters: {
          consoleReporter: [
            {
              module: "good-squeeze",
              name: "Squeeze",
              args: [
                {
                  error: "*",
                  log: "*",
                  response: "*",
                  request: "*"
                }
              ]
            },
            {
              module: "good-console"
            },
            "stdout"
          ],
          myFileReporter: [{
            module: 'good-squeeze',
            name: 'Squeeze',
            args: [{
              error: "*",
              log: "*",
              response: "*",
              request: "*"
            }]
          }, {
            module: 'good-squeeze',
            name: 'SafeJson'
          }, {
            module: 'good-file',
            args: [logfile]

          }


          ]
        }
      }
    });
  } catch (err) {
    console.log(`Error registering logger plugin: ${err}`);
    throw err;
  }
};

export default (): IPlugin => {
  return {
    register,
    info: () => {
      return { name: "Good Logger", version: "1.0.0" };
    }
  };
};
