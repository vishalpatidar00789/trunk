import * as Hapi from 'hapi';
import { IDatabase } from "../database";
import { IServerConfigurations } from "../configurations";
import { ILoan } from "../api/loan/loan";
import ConfigurationService from "./configuration-service";
import { ILimit } from "../api/master-data/consortium/limit-management/limit";

export default class ClaimService {

    constructor(private configs: IServerConfigurations, private database: IDatabase, private server: Hapi.Server, private confgService: ConfigurationService) {
    }

    public async generateClaimMarshReferenceNumber(bankCode: string): Promise<any> {
        let seqNo = await this.confgService.getValueByCode("claimSeqNumber");
        return new Promise<any>((resolve, reject) => {
            let marshRefNumber: string = null;
            if (seqNo) {
                let trancheNo = '05';
                let seqNoPrefix = '';

                if (seqNo.length === 1) {
                    seqNoPrefix = '0000';
                } else if (seqNo.length === 2) {
                    seqNoPrefix = '000';
                } else if (seqNo.length === 3) {
                    seqNoPrefix = '00';
                } else if (seqNo.length === 4) {
                    seqNoPrefix = '0';
                }
                let sequenceNum = seqNoPrefix + seqNo;

                let fullDate: string;
                const date1: Date = new Date();
                let date = date1.getDate();
                if (date.toString().length === 1) {
                    fullDate = '0' + date;
                } else {
                    fullDate = date.toString();
                }
                let month: number = date1.getMonth() + 1;
                if (month.toString().length === 1) {
                    fullDate = fullDate + '0' + month;
                } else {
                    fullDate = fullDate + month.toString();
                }
                let year = date1
                    .getFullYear()
                    .toString()
                    .substr(2, 2);
                fullDate = fullDate + year;
                marshRefNumber = 'LO' + trancheNo + bankCode + fullDate + sequenceNum + '/01';
                console.log('MarshRefNo::' + marshRefNumber);
                if (marshRefNumber) {
                    let seqNumber: number = parseInt(seqNo, 10) + 1;
                    this.confgService.updateByCode("claimSeqNumber", seqNumber.toString());
                    resolve(marshRefNumber);
                } else {
                    reject(null);
                }
            } else {
                reject(null);
            }
        });
    }
}