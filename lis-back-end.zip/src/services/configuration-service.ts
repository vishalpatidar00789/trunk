import { IServerConfigurations } from "../configurations";
import { IDatabase } from "../database";
import { IConfigurations } from "../api/lookup/configurations/configurations";
import { ITranch } from "../api/master-data/tranch/tranch";

export default class ConfigurationService {

    constructor(private configs: IServerConfigurations, private database: IDatabase) {
    }

    public async getValueByCode(code: string): Promise<any> {
        let configurations: IConfigurations = await this.database.configurationsModel.findOne({ code: code });
        return new Promise<any>((resolve, reject) => {
            if (configurations) {
                resolve(configurations.value);
            } else {
                reject(null);
            }
        });
    }

    public async updateByCode(code: string, seqNo: string): Promise<any> {
        let configurations: IConfigurations = await this.database.configurationsModel.updateOne(
            { code: code },
            { $set: { value: seqNo } },
            { new: true });
        return new Promise<any>((resolve, reject) => {
            if (configurations) {
                resolve(configurations);
            } else {
                reject(null);
            }
        });
    }

    public async getCurrentTranch() {
        let tranch: ITranch = await this.database.tranchModel.findOne({ "activated": true });
        if (tranch) {
            let trancheNo = tranch.trancheName.substr(4);
            if (trancheNo.length === 1) {
                console.log('TranchNo::', trancheNo);
                return '0' + trancheNo;
            } else {
                return trancheNo;
            }
        }
    }
}
