'use strict';
import { ISMTPServerConfigurations } from "../configurations";
import { IMailOptions } from "../interfaces/request";
const nodemailer = require('nodemailer');

export default class EmailService {
    private configs: ISMTPServerConfigurations;
    private smtpTransporter: any;

    constructor(configs: ISMTPServerConfigurations) {
        this.configs = configs;
        this.createSMTPTransporter();
    }

    private createSMTPTransporter() {
        this.smtpTransporter = nodemailer.createTransport({
            host: this.configs.host,
            port: this.configs.port,
            secure: this.configs.secure
        });
    }

    public async sendEmail(mailOptions: IMailOptions): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            if (this.smtpTransporter) {
                // send mail with defined transport object
                this.smtpTransporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                        reject(error);
                    }
                    console.log('Message sent: %s', info.messageId);
                    resolve(info);
                });
            } else {
                resolve('Error while creating transporter');
            }
        });
    }

    public async prepareMailOptions() {

    }
}

// setup email data with unicode symbols
// let mailOptions = {
//     from: '"Patidar, Vishal" <vishal.patidar01@marsh.com>', // sender address
//     to: 'vishal.patidar01@marsh.com', // list of receivers
//     subject: 'Hello ✔', // Subject line
//     text: 'Hello world?', // plain text body
//     html: '<b>Hello world?</b>' // html body
// };
