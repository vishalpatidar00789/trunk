import { IDatabase } from "../database";
import { IServerConfigurations } from "../configurations";
import * as Bcrypt from "bcryptjs";
import { IUser } from "../api/users/user";
import EmailService from "./email-service";
import { IMailOptions, IUserCreate } from "../interfaces/request";
import { AsyncHook } from "async_hooks";
import LDAPAuthService from "./ldap-auth-service";
import * as Configs from "../configurations";
var generatePassword = require('password-generator');

export default class UserService {
    private database: IDatabase;
    private configs: IServerConfigurations;
    private emailService: EmailService;
    private ldapService: LDAPAuthService;
    private appConfigs: Configs.IApplicationConfigurations;
    private appMsgs: any;
    private maxLength: number;
    private minLength: number;
    private allowedResetHours: number;
    private uppercaseMinCount: number;
    private lowercaseMinCount: number;
    private numberMinCount: number;
    private specialMinCount: number;
    private lastUsedPasswordCount: number;
    private allowedChangePasswordAttempts: number;
    private allowedResetPasswordAttempts: number;
    private allowedLoginAttempts: number;
    private UPPERCASE_RE = /([A-Z])/g;
    private LOWERCASE_RE = /([a-z])/g;
    private NUMBER_RE = /([\d])/g;
    private SPECIAL_CHAR_RE = /([\!@#$%^&*?\-])/g;
    private NON_REPEATING_CHAR_RE = /([\w\d\!@#$%^&*?\-])\1{1,}/g;

    constructor(configs: IServerConfigurations, database: IDatabase,
        emailService: EmailService, ldapService: LDAPAuthService) {
        this.database = database;
        this.configs = configs;
        this.emailService = emailService;
        this.ldapService = ldapService;
        this.appConfigs = Configs.getApplicationConfigs();
        this.maxLength = this.appConfigs.maxLength;
        this.minLength = this.appConfigs.minlength;
        this.uppercaseMinCount = this.appConfigs.uppercaseMinCount;
        this.lowercaseMinCount = this.appConfigs.lowercaseMinCount;
        this.numberMinCount = this.appConfigs.numberMinCount;
        this.specialMinCount = this.appConfigs.specialMinCount;
        this.allowedResetHours = this.appConfigs.allowedResetHours;
        this.lastUsedPasswordCount = this.appConfigs.lastUsedPasswordCount;
        this.allowedChangePasswordAttempts = this.appConfigs.allowedChangePasswordAttempts;
        this.allowedResetPasswordAttempts = this.appConfigs.allowedResetPasswordAttempts;
        this.allowedLoginAttempts = this.appConfigs.allowedLoginAttempts;
        this.appMsgs = Configs.getAppMsgsConfigs();
        console.log('app msgs ::' + this.appMsgs);
    }

    // public async generatePassword(): Promise<any> {
    //     const password = generatePassword(8, false, /[\w\d\?\-]/);  //  /(?=^.{8,}$)(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s)[0-9a-zA-Z!@#$%^&*()]*$/
    //     console.log("generated password:: " + password);

    //     return new Promise<any>((resolve, reject) => {
    //         let hashedPassword = null;
    //         if (password) {
    //             hashedPassword = this.hashPassword(password);
    //             console.log("hash password:: " + hashedPassword);
    //             if (hashedPassword) {
    //                 resolve({ password: password, hasPassword: hashedPassword });
    //             } else {
    //                 resolve(null);
    //             }
    //         } else {
    //             resolve(null);
    //         }
    //     });
    // }

    public isStrongEnough(password) {
        var uc = password.match(this.UPPERCASE_RE);
        const lc = password.match(this.LOWERCASE_RE);
        const n = password.match(this.NUMBER_RE);
        const sc = password.match(this.SPECIAL_CHAR_RE);
        // const nr = password.match(this.NON_REPEATING_CHAR_RE);
        return password.length >= this.minLength &&
            uc && uc.length >= this.uppercaseMinCount &&
            lc && lc.length >= this.lowercaseMinCount &&
            n && n.length >= this.numberMinCount &&
            sc && sc.length >= this.specialMinCount;
    }

    public customPassword(): Promise<any> {
        let password = "";
        const randomLength = Math.floor(Math.random() * (this.maxLength - this.minLength)) + this.minLength;
        while (!this.isStrongEnough(password)) {
            password = generatePassword(randomLength, false, /[\w\d\!@#$%^&*?\-]/);
        }
        return new Promise<any>((resolve, reject) => {
            let hashedPassword = null;
            if (password) {
                console.log("password:: " + password);
                hashedPassword = this.hashPassword(password);
                console.log("hash password:: " + hashedPassword);
                if (hashedPassword) {
                    resolve({ password: password, hasPassword: hashedPassword });
                } else {
                    resolve(null);
                }
            } else {
                resolve(null);
            }
        });
    }


    private hashPassword(password: string): string {
        return Bcrypt.hashSync(password, Bcrypt.genSaltSync(8));
    }

    private isResetPasswordAllowedAtThisTime(lastResetDateTime: Date) {
        return (((new Date()).getTime() - new Date(lastResetDateTime).getTime()) / (1000 * 3600)) >= this.allowedResetHours;
    }

    public async resetPassword(userId: string, _who: string): Promise<any> {
        let successMsg, errorMsg, generatedPassword;
        // const allowedChangePasswordAttempt: Number = 1;
        let user: IUser = await this.database.userModel.findOne({ login: userId });
        if (user) {
            if (user.userType === 'EXT') {
                if (user.activated) {
                    const result = await this.customPassword();
                    if (result) {
                        user.password = result["hasPassword"];
                        generatedPassword = result["password"];
                        let lastUsedPasswords: string[] = user.lastUsedPasswords;
                        if (!lastUsedPasswords) {
                            lastUsedPasswords = [];
                        }
                        if (lastUsedPasswords.length === this.lastUsedPasswordCount) {
                            lastUsedPasswords.shift();
                        }
                        lastUsedPasswords.push(user.password);
                        user.lastUsedPasswords = lastUsedPasswords;
                        user.isForceResetPassword = true;
                        user.lastModifiedDate = new Date();
                        if (_who && _who !== "PFI_USER") {
                            // reset password without checking any time check
                            user.lastModifiedBy = _who;

                            console.log("admin reset password:: " + _who);
                            let updateduser: IUser = await this.updateUser(user);
                            if (updateduser) {
                                successMsg = this.appMsgs["P-SUCCESS"];
                            } else {
                                errorMsg = this.appMsgs["P-RESETERROR"];
                                console.log(errorMsg);
                            }
                        } else if (_who && _who === "PFI_USER") {
                            if (user.lastResetPasswordDateTime &&
                                !this.isResetPasswordAllowedAtThisTime(user.lastResetPasswordDateTime) &&
                                (user.lastResetPassswordCount === this.allowedResetPasswordAttempts)) {
                                errorMsg = this.appMsgs["P-RESETALLWDHRSLMT"];
                                console.log(errorMsg);
                            } else {
                                // allow user to reset password
                                console.log("user reset password:: " + _who);
                                if (this.isResetPasswordAllowedAtThisTime(user.lastResetPasswordDateTime) &&
                                    (user.lastResetPassswordCount === this.allowedResetPasswordAttempts)) {
                                    user.lastResetPassswordCount = 1;
                                } else {
                                    user.lastResetPassswordCount = user.lastResetPassswordCount + 1;
                                }

                                user.lastResetPasswordDateTime = new Date();
                                user.lastModifiedBy = user.login;
                                let updateduser: IUser = await this.updateUser(user);
                                if (updateduser) {
                                    successMsg = this.appMsgs["P-SUCCESS"];
                                } else {
                                    errorMsg = this.appMsgs["P-RESETERROR"];
                                    console.log(errorMsg);
                                }
                            }
                        }
                    } else {
                        errorMsg = this.appMsgs["P-ERRORHASHPWD"];
                        console.log(errorMsg);
                    }
                } else {
                    errorMsg = this.appMsgs["U-USERNOTACTIVE"];
                    console.log(errorMsg);
                }
            } else {
                errorMsg = this.appMsgs["P-NOTALLOWED"];
                console.log(errorMsg);
            }
        } else {
            errorMsg = this.appMsgs["U-USERNOTFOUND"];
            console.log(errorMsg);
        }
        return new Promise<any>((resolve, reject) => {
            if (successMsg) {
                let emailOptions = new IMailOptions();
                emailOptions.from = this.configs.systemEmail; // this should be configurable
                emailOptions.to = user.login + ", amit.kumar02@marsh.com";
                emailOptions.subject = "Password Reset";
                emailOptions.html = `<p>Dear User, <br> Your password has reset successfully. Your new password is ${generatedPassword}`;
                this.emailService.sendEmail(emailOptions);
                resolve({ success: successMsg });
            } else if (errorMsg) {
                resolve({ error: errorMsg });
            } else {
                resolve({ error: this.appMsgs["G-INTSERVERERR"] });
            }
        });
    }

    private isPasswordUsed(lastUsedPasswords: string[], requestPassword: string): boolean {
        if (lastUsedPasswords) {
            if (lastUsedPasswords && lastUsedPasswords.length > 0) {
                for (let i = 0; i < lastUsedPasswords.length; i++) {
                    if (Bcrypt.compareSync(requestPassword, lastUsedPasswords[i])) {
                        return true;
                    }
                }
            } else {
                return false;
            }
        }
        return false;
    }

    private async updatePassword(login: string, hashPassword: string, lastUsedPasswords: any, count: number, isForceResetPassword: boolean, lastModifiedBy: string) {
        let user: IUser = await this.database.userModel.findOneAndUpdate(
            { login: login },
            {
                $set: {
                    password: hashPassword, lastUsedPasswords: lastUsedPasswords,
                    lastModifiedBy: lastModifiedBy, lastModifiedDate: new Date(),
                    changePasswordCount: count,
                    changePasswordDateTime: new Date(),
                    isForceResetPassword: isForceResetPassword
                }
            },
            { new: true }
        );
        return user;
    }

    public async changePassword(payload: any): Promise<any> {
        // const allowedChangePasswordAttempt: Number = 1;
        let successMsg, errorMsg, changePassword, login;
        let user: IUser = null;
        changePassword = payload["newPassword"];
        login = payload["login"];
        if (payload && changePassword && this.isStrongEnough(changePassword)) {
            console.log("payload at server layer:: " + JSON.stringify(payload));
            user = await this.database.userModel.findOne({ login: login });
            if (user) {
                if (user.userType === 'EXT') {
                    let hashPassword = this.hashPassword(changePassword);
                    if (hashPassword) {
                        let lastUsedPasswords = user.lastUsedPasswords;
                        if (!this.isPasswordUsed(lastUsedPasswords, changePassword)) {
                            if (lastUsedPasswords.length === this.lastUsedPasswordCount) {
                                lastUsedPasswords.shift();
                            }
                            lastUsedPasswords.push(hashPassword);
                            user.password = hashPassword;
                            user.lastUsedPasswords = lastUsedPasswords;

                            user.lastModifiedBy = user.login;
                            user.lastModifiedDate = new Date();

                            if (!user.isForceResetPassword && user.changePasswordDateTime &&
                                !this.isResetPasswordAllowedAtThisTime(user.changePasswordDateTime) &&
                                (user.changePasswordCount === this.allowedChangePasswordAttempts)) {
                                errorMsg = this.appMsgs["P-CHNGALLWDHRSLMT"];
                                console.log(errorMsg);
                            } else {
                                if (this.isResetPasswordAllowedAtThisTime(user.changePasswordDateTime) &&
                                    (user.changePasswordCount === this.allowedChangePasswordAttempts)) {
                                    user.changePasswordCount = 1;
                                } else {
                                    user.changePasswordCount = user.changePasswordCount + 1;
                                }
                                user.changePasswordDateTime = new Date();
                                user.isForceResetPassword = false;
                                user.changePasswordCount = 1;
                                let updateduser: IUser = await this.updateUser(user);
                                if (updateduser) {
                                    successMsg = this.appMsgs["P-CHNGPWDSUCESS"];
                                } else {
                                    errorMsg = this.appMsgs["P-CHNGPWDERROR"];
                                    console.log(errorMsg);
                                }
                            }
                        } else {
                            errorMsg = this.appMsgs["P-LSTALLWDPASS"];
                            console.log(errorMsg);
                        }
                    } else {
                        errorMsg = this.appMsgs["P-ERRORHASHPWD"];
                        console.log(errorMsg);
                    }
                } else {
                    errorMsg = this.appMsgs["P-NOTALLOWED"];
                    console.log(errorMsg);
                }
            } else {
                errorMsg = this.appMsgs["U-USERNOTFOUND"];
                console.log(errorMsg);
            }
        } else {
            errorMsg = this.appMsgs["P-PWDNOTSTRNG"];
            console.log(errorMsg);
        }
        return new Promise<any>((resolve, reject) => {
            if (successMsg) {
                let emailOptions = new IMailOptions();
                emailOptions.from = "LIS System <no-reply@marsh.com>"; // this should be configurable
                emailOptions.to = user.login + ", amit.kumar02@marsh.com";
                emailOptions.subject = "Password Change";
                emailOptions.html = `<p>Dear User, <br> Your password has changed successfully.`;
                this.emailService.sendEmail(emailOptions);
                resolve({ success: successMsg });
            } else if (errorMsg) {
                resolve({ error: errorMsg });
            } else {
                resolve({ error: this.appMsgs["G-INTSERVERERR"] });
            }
        });
    }

    public async getUserByUserId(userId: string): Promise<any> {
        const user: IUser = await this.database.userModel.findOne({ login: userId });

        return new Promise<any>((resolve, reject) => {
            if (user) {
                if (user.activated) {
                    resolve({ opCode: 200, data: user });
                } else {
                    resolve({ opCode: 401, data: null, msg: this.appMsgs["G-USERDEACTIVE"] });
                }
            } else {
                resolve({ opCode: 404, data: null, msg: this.appMsgs["U-USERNOTFOUND"] });
            }
        });
    }

    public async updateUser(payload: IUser) {
        const user: IUser = await this.database.userModel.findOneAndUpdate(
            { login: payload.login },
            { $set: payload },
            { new: true }
        );
        return user;
    }

    public async authenticateUser(username, password): Promise<any> {
        let result: any = await this.getUserByUserId(username);
        let user: IUser = result.data;
        let success, error = null;
        const allowedLoginAttempts: number = this.allowedLoginAttempts;
        if (user) {
            if (user.userType === 'EXT') {
                // check for failed attempts
                if (user.failedLoginAttempts < allowedLoginAttempts - 1) {
                    // auth against local db
                    if (user.validatePassword(password)) {
                        // update user
                        user.lastModifiedBy = username;
                        user.lastModifiedDate = new Date();
                        user.failedLoginAttempts = 0,
                        user.lastFailedAttemptTime = null;
                        user.lastLogin = new Date();
                        user = await this.updateUser(user);
                        if (user) {
                            success = { opCode: 200, data: user, msg: this.appMsgs["G-AUTHSUCCESS"] };
                        } else {
                            error = { opCode: 500, data: null, msg: this.appMsgs["G-INTSERVERERR"] };
                        }
                    } else {
                        // update user
                        user.lastModifiedBy = username;
                        user.lastModifiedDate = new Date();
                        user.failedLoginAttempts = user.failedLoginAttempts + 1;
                        user.lastFailedAttemptTime = new Date();
                        user = await this.updateUser(user);
                        if (user) {
                            const attemptsLeft: number = allowedLoginAttempts - user.failedLoginAttempts;
                            error = { opCode: 401, data: null, msg: `Invalid password. ${attemptsLeft} attempts left now.` };
                        } else {
                            error = { opCode: 500, data: null, msg: this.appMsgs["G-INTSERVERERR"] };
                        }
                    }
                } else {
                    user.lastModifiedBy = username;
                    user.lastModifiedDate = new Date();
                    user.failedLoginAttempts = 0;
                    user.lastFailedAttemptTime = new Date();
                    user.activated = false;
                    user = await this.updateUser(user);
                    if (user) {
                        error = { opCode: 423, data: null, msg: this.appMsgs["P-EXCSVFAILDATTMPTS"] };
                    } else {
                        error = { opCode: 500, data: null, msg: this.appMsgs["G-INTSERVERERR"] };
                    }
                }
            } else if (user.userType === 'INT') {
                // auth against ad
                const result: any = await this.ldapService.authenticateMarshUserAgainstAD(username, password);
                if (result && result.opCode === 200) {
                    user.lastLogin = new Date();
                    user = await this.updateUser(user);
                    if (user) {
                        success = { opCode: 200, data: user, msg: this.appMsgs["G-AUTHSUCCESS"] };
                    } else {
                        error = { opCode: 500, data: null, msg: this.appMsgs["G-INTSERVERERR"] };
                    }
                } else {
                    error = { opCode: 401, data: null, msg: this.appMsgs["P-INVALIDPASS"] };
                }
            }
        } else {
            error = result;
        }
        return new Promise<any>((resolve, reject) => {
            if (success) {
                resolve(success);
            } else if (error) {
                resolve(error);
            } else {
                reject({ opCode: 500, data: null, msg: this.appMsgs["G-INTSERVERERR"] });
            }
        });
    }

    public async createUser(newUser: any): Promise<any> {
        let result: any = await this.getUserByUserId(newUser.login);
        let user: IUser = result.data;
        let success, error = null;
        if (!user) {
            newUser["createdDate"] = new Date();
            if (newUser["userType"] === 'EXT') {
                const result = await this.customPassword();
                if (result) {
                    const generatedPassword = result["password"];
                    console.log("GeneratedPassword::" + generatedPassword);
                    const hashPassword = result["hasPassword"];
                    newUser["password"] = hashPassword;
                    newUser["lastUsedPasswords"] = [hashPassword];
                    // set isForceResetPassword flag as true as the user has to reset the password
                    newUser["isForceResetPassword"] = true;
                    let user: any = await this.database.userModel.create(newUser);
                    if (user) {
                        let emailOptions = new IMailOptions();
                        emailOptions.from = this.configs.systemEmail; // this should be configurable
                        emailOptions.to = user.login + ", amit.kumar02@marsh.com";
                        emailOptions.subject = "User Account Creation";
                        emailOptions.html = `<p>Dear User, <br> Your account is successfully created in LIS. Your user id is ${user.login}`;
                        await this.emailService.sendEmail(emailOptions);

                        let emailOptions2 = new IMailOptions();
                        emailOptions2.from = this.configs.systemEmail;
                        emailOptions2.subject = "Password Generated";
                        emailOptions2.html = `<p>Dear User, <br> Your password has generated successfully. Your password is ${generatedPassword}`;
                        await this.emailService.sendEmail(emailOptions2);
                        delete user.password;
                        delete user["__v"];
                        success = { opCode: 200, data: user, msg: this.appMsgs["U-USERCREATED"] };
                    } else {
                        error = { opCode: 500, data: null, msg: this.appMsgs["G-INTSERVERERR"] };
                    }
                } else {
                    error = { opCode: 500, data: null, msg: this.appMsgs["P-PWDGENERROR"] };
                }
            } else if (newUser["userType"] === 'INT') {
                newUser["isForceResetPassword"] = false;
                let user: any = await this.database.userModel.create(newUser);
                if (user) {
                    let emailOptions = new IMailOptions();
                    emailOptions.from = this.configs.systemEmail; // this should be configurable
                    emailOptions.to = user.login + ", amit.kumar02@marsh.com";
                    emailOptions.subject = "User Account Creation";
                    emailOptions.html = `<p>Dear User, <br> Your account is successfully created in LIS. Your user id is ${user.login}`;
                    this.emailService.sendEmail(emailOptions);
                    delete user.password;
                    delete user["__v"];
                    success = { opCode: 200, data: user, msg: this.appMsgs["U-USERCREATED"] };
                } else {
                    error = { opCode: 500, data: null, msg: this.appMsgs["G-INTSERVERERR"] };
                }
            } else {
                error = { opCode: 500, data: null, msg: this.appMsgs["U-NOUSERTYPE"] };
            }
        } else {
            error = { opCode: 406, data: null, msg: this.appMsgs["U-USERALRDYEXIST"] };
        }
        return new Promise<any>((resolve, reject) => {
            if (success) {
                resolve(success);
            } else if (error) {
                resolve(error);
            } else {
                reject({ opCode: 500, data: null, msg: this.appMsgs["G-INTSERVERERR"] });
            }
        });
    }

    public async deactivateUsers() {
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - 90);
        console.log(cutoffDate);

        const user: IUser = await this.database.userModel.update(
            { lastLogin: cutoffDate },
            { $set: { activated: false, deactivateDate: new Date() } },
            { new: true }
        );
        return user;
    }

    public async deleteDeactivatedUsers() {
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - 90);
        console.log(cutoffDate);

        const user: IUser = await this.database.userModel.deleteMany({
            deactivatedDate: cutoffDate
        });
        return user;
    }
}