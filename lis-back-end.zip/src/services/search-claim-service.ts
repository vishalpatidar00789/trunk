import { IDatabase } from "../database";
import { IServerConfigurations } from "../configurations";
import { ILoan } from "../api/loan/loan";

export default class SearchClaimService {
    private database: IDatabase;
    private configs: IServerConfigurations;

    constructor(configs: IServerConfigurations, database: IDatabase) {
        this.database = database;
        this.configs = configs;
    }

    public async searchClaimDocuments(query: any): Promise<any> {
        let claim: any[] = await this.database.claimModel.find(query).sort({ dateReportedToMarsh: -1});
        return new Promise<any>((resolve, reject) => {
            if (claim) {
                resolve(claim);
            } else {
                reject(null);
            }
        });
    }

    public async buildQuery(requestPayload: any): Promise<any> {
        console.log('Building Query');
        let marshReferenceNumber: string = requestPayload.marshRefNo;
        let borrowerName: string = requestPayload.borrowerName;
        let uenNumber: string = requestPayload.uenNumber;
        const pfiCode: string[] = requestPayload.pfiCode;
        const consortium = requestPayload.consortium;
        const tranche = requestPayload.tranche;
        // const adverseStatus = requestPayload.adverseStatus;
        const typeOfDate = requestPayload.typeOfDate;
        const selectedFromDate: any = requestPayload.fromDate;
        const selectedToDate: any = requestPayload.toDate;
        let splittedCurrentDate = new Date().toISOString().split('T');
        let currentDateISO = new Date(splittedCurrentDate[0]);
        let fromDate;
        let toDate;
        if (typeof selectedFromDate !== 'undefined') {
            let splittedFromDate = selectedFromDate.split('T');
            fromDate = new Date(splittedFromDate[0]);
            console.log('fromDate ' + fromDate);
        }
        if (typeof selectedToDate !== 'undefined') {
            let splittedToDate = selectedToDate.split('T');
            console.log('splittedToDate ' + (splittedToDate[0] + 'T23:59:59.000Z'));
            toDate = new Date(splittedToDate[0] + 'T23:59:59.000Z');
            console.log('toDate ' + toDate);
        }
        // const natureOfApplication: string[] = requestPayload.natureOfApplication;
        const marshClaimApplicationStatus: string[] =
            requestPayload.marshClaimApplicationStatus;
        // const excludeExpiredApplications =
            // requestPayload.excludeExpiredApplications;
        const app: any[] = requestPayload.app;
        let query: any = {};
        let selectedDate: string;

        switch (typeOfDate) {
            case 'Marsh Submission Date':
                selectedDate = 'dateReportedToMarsh';
                break;

            // case 'COFANET Submission Date':
            //     selectedDate = 'creditInfo.submissionDate';
            //     break;

            case 'LO Acceptance Date':
                selectedDate = 'loAcceptanceDate';
                break;

            // case 'Loan Expiry Date':
            //     selectedDate = 'creditInfo.loanExpiryDate';
            //     break;

            default:
                selectedDate = 'dateReportedToMarsh';
        }
        console.log('Selected date type :' + selectedDate);
        if (
            typeof marshReferenceNumber !== 'undefined' &&
            marshReferenceNumber !== '' &&
            marshReferenceNumber !== '*' &&
            marshReferenceNumber !== '**'
        ) {
            marshReferenceNumber = marshReferenceNumber.trim();
            let marshReferenceRegex = marshReferenceNumber;
            if (marshReferenceNumber.includes('.')) {
                marshReferenceRegex = marshReferenceNumber.split('.').join('\\.');
            }
            marshReferenceRegex = marshReferenceRegex.split('%').join('*');
            marshReferenceRegex = marshReferenceRegex.split('*').join('.*');
            marshReferenceRegex = marshReferenceRegex.split('?').join('.?');
            query['marshRefNo'] = {
                $regex: '^' + marshReferenceRegex + '$',
                $options: 'si'
            };
        }
        if (
            typeof borrowerName !== 'undefined' &&
            borrowerName !== '' &&
            borrowerName !== '*' &&
            borrowerName !== '**'
        ) {
            borrowerName = borrowerName.trim();
            let borrowerNameRegex = borrowerName;
            if (borrowerName.includes('.')) {
                borrowerNameRegex = borrowerName.split('.').join('\\.');
            }
            borrowerNameRegex = borrowerNameRegex.split('%').join('*');
            borrowerNameRegex = borrowerNameRegex.split('*').join('.*');
            borrowerNameRegex = borrowerNameRegex.split('?').join('.?');
            query['regCompanyName'] = {
                $regex: '^' + borrowerNameRegex + '$',
                $options: 'si'
            };
        }
        if (
            typeof uenNumber !== 'undefined' &&
            uenNumber !== '' &&
            uenNumber !== '*' &&
            uenNumber !== '**'
        ) {
            uenNumber = uenNumber.trim();
            let uenNumberRegex = uenNumber;
            if (uenNumber.includes('.')) {
                uenNumberRegex = uenNumber.split('.').join('\\.');
            }
            uenNumberRegex = uenNumberRegex.split('%').join('*');
            uenNumberRegex = uenNumberRegex.split('*').join('.*');
            uenNumberRegex = uenNumberRegex.split('?').join('.?');
            query['uen'] = {
                $regex: '^' + uenNumberRegex + '$',
                $options: 'si'
            };
        }
        if (typeof pfiCode !== 'undefined') {
            query['pfiCode'] = { $in: pfiCode };
        }
        if (typeof consortium !== 'undefined' && consortium !== ''
            && consortium !== 'All') {
            query['consortium'] = consortium;
        }
        if (typeof consortium !== 'undefined' && consortium !== ''
            && consortium !== 'All') {
            query['tranche'] = tranche;
        }
        // if (
        //     typeof adverseStatus !== 'undefined' &&
        //     adverseStatus !== '' &&
        //     adverseStatus !== 'All'
        // ) {
        //     query['adverseInfo.adverseStatus'] = adverseStatus;
        // }
        if (
            typeof fromDate !== 'undefined' &&
            (typeof toDate === 'undefined' || toDate === null)
        ) {
            query[selectedDate] = { $gte: fromDate };
        }
        if (
            typeof toDate !== 'undefined' &&
            (typeof fromDate === 'undefined' || fromDate === null)
        ) {
            query[selectedDate] = { $lte: toDate };
        }
        if (typeof fromDate !== 'undefined' && typeof toDate !== 'undefined') {
            query[selectedDate] = { $gte: fromDate, $lte: toDate };
        }
        // if (
        //     typeof natureOfApplication !== 'undefined' &&
        //     natureOfApplication.length > 0
        // ) {
        //     query['creditInfo.natureOfApplication'] = {
        //         $in: natureOfApplication
        //     };
        // }
        if (
            typeof marshClaimApplicationStatus !== 'undefined' &&
            marshClaimApplicationStatus.length > 0
        ) {
            query['status'] = { $in: marshClaimApplicationStatus };
        }
        // if (
        //     excludeExpiredApplications === true &&
        //     selectedDate !== 'creditInfo.loanExpiryDate'
        // ) {
        //     query['creditInfo.loanExpiryDate'] = {
        //         $gte: currentDateISO
        //     };
        // }
        // if (
        //     excludeExpiredApplications === true &&
        //     selectedDate === 'creditInfo.loanExpiryDate'
        // ) {
        //     let fromLoanExpiryDate = fromDate;
        //     let toLoanExpiryDate = toDate;

        //     if (
        //         typeof fromDate !== 'undefined' &&
        //         fromLoanExpiryDate <= currentDateISO
        //     ) {
        //         fromLoanExpiryDate = currentDateISO;
        //         console.log('fromLoanExpiryDate ' + fromLoanExpiryDate);
        //     }
        //     if (typeof toDate !== 'undefined' && currentDateISO >= toLoanExpiryDate) {
        //         fromLoanExpiryDate = currentDateISO;
        //         toLoanExpiryDate = currentDateISO;
        //         console.log('toLoanExpiryDate ' + toLoanExpiryDate);
        //     }
        //     if (
        //         typeof fromLoanExpiryDate !== 'undefined' &&
        //         (typeof toLoanExpiryDate === 'undefined' || toLoanExpiryDate === null)
        //     ) {
        //         query[selectedDate] = { $gte: fromLoanExpiryDate };
        //     }
        //     if (
        //         typeof toLoanExpiryDate !== 'undefined' &&
        //         (typeof fromLoanExpiryDate === 'undefined' ||
        //             fromLoanExpiryDate === null)
        //     ) {
        //         query[selectedDate] = { $lte: toLoanExpiryDate };
        //     }
        //     if (
        //         typeof fromLoanExpiryDate !== 'undefined' &&
        //         typeof toLoanExpiryDate !== 'undefined'
        //     ) {
        //         console.log('Both dates seleted');
        //         query[selectedDate] = {
        //             $gte: new Date(fromLoanExpiryDate),
        //             $lte: new Date(toLoanExpiryDate)
        //         };
        //     }
        // }
        if (typeof app !== 'undefined' && app.length > 0) {
            query['app'] = { $in: app };
        }

        console.log(JSON.stringify(query));
        return new Promise<any>((resolve, reject) => {
            if (query) {
                resolve(query);
            } else {
                reject(null);
            }
        });
    }
}