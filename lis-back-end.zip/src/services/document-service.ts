import { FileMetaData } from '../interfaces/request';
import { ObjectId } from 'bson';
let Gridfs = require('gridfs-stream');
let mongoose = require('mongoose');
let conn = mongoose.connection;
Gridfs.mongo = mongoose.mongo;
let gfs;
conn.once("open", () => {
    gfs = Gridfs(conn.db);
});
export default class DocumentService {

    public async uploadFile(metadata: FileMetaData): Promise<any> {
        console.log("inside upload file");
        // console.log("file meata data::" + JSON.stringify(metadata));
        let result;
        let writeStream = gfs.createWriteStream({
            filename: metadata.fileName,
            mode: 'w',
            content_type: metadata.contentType,
            metadata: {
                collection: metadata.collectionName, refAppId: metadata.refAppId, fileName: metadata.fileName,
                documentType: metadata.documentType, uploadedBy: metadata.uploadedBy
            }
        });

        writeStream.write(metadata.file);
        writeStream.end();

        return new Promise((resolve, reject) => {
            writeStream.on("close", function (file) {
                console.log("file id::" + file._id);
                resolve(file);
            });
            writeStream.on('error', function (err) {
                console.log('An error occurred!', err);
                reject(err);
            });
        });

    }

    public async getSupportingDocsByRefAppId(refAppId: string): Promise<any> {
        return new Promise((resolve, reject) => {
            gfs.files.find({ "metadata.refAppId": refAppId }).toArray(function (err, files) {
                if (err) { console.log(err); reject(err); }

                if (files) {
                    console.log(JSON.stringify(files));
                    resolve(files);
                }
            });
        });
    }

    public async getSupportingDocsByDocType(docType: string): Promise<any> {
        return new Promise((resolve, reject) => {
            gfs.files.find({ "metadata.documentType": docType }).toArray(function (err, files) {
                if (err) { console.log(err); reject(err); }

                if (files) {
                    console.log(JSON.stringify(files));
                    resolve(files);
                }
            });
        });
    }

    public async getDocsByRefAppIdAndDocType(refAppId: string, docType: string): Promise<any> {
        return new Promise((resolve, reject) => {
            gfs.files.find({ "metadata.refAppId": refAppId, "metadata.documentType": docType }).toArray(function (err, files) {
                if (err) { console.log(err); reject(err); }

                if (files) {
                    resolve(files);
                } else {
                    resolve(null);
                }
            });
        });
    }

    public async validateSupportingDocumentForSubmission(refAppId: string, docType: string): Promise<any> {
        return new Promise((resolve, reject) => {
            gfs.exists.find({ "metadata.refAppId": refAppId, "metadata.documentType": docType }).toArray(function (err, files) {
                if (err) { console.log(err); reject(err); }

                if (files) {
                    console.log(JSON.stringify(files));
                    resolve(files);
                }
            });
        });
    }

    public async removeDocById(fileId: string): Promise<any> {
        return new Promise((resolve, reject) => {
            gfs.remove({ _id: fileId }, function (err) {
                if (err) { return reject(err); }
                resolve({ 'message': 'success' });
            });
        });
    }

    public async getDocById(fileId: string): Promise<any> {
        return new Promise((resolve, reject) => {
            gfs.files.find({ _id: new ObjectId(fileId) }).toArray(function (err, files) {
                if (err) { console.log(err); reject(err); }

                if (files && files.length > 0) {
                    console.log("file in server::" + JSON.stringify(files));
                    resolve({
                        'contentType': files[0].contentType,
                        'fileName': files[0].filename,
                        'fileStream': gfs.createReadStream({ _id: fileId })
                    });
                }
            });
        });
    }
}