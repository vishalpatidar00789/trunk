import { IDatabase } from "../database";
import { IServerConfigurations } from "../configurations";

export default class LookupService {

    constructor(private configs: IServerConfigurations, private database: IDatabase) {
    }

    public async getEmailTemplate(): Promise<any> {

    }

}