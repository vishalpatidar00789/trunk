import * as Hapi from 'hapi';
import { IDatabase } from "../database";
import { IServerConfigurations } from "../configurations";
import { ILoan } from "../api/loan/loan";
import ConfigurationService from "./configuration-service";
import { ILimit } from "../api/master-data/consortium/limit-management/limit";

export default class LoanService {

    constructor(private configs: IServerConfigurations, private database: IDatabase, private server: Hapi.Server, private confgService: ConfigurationService) {
    }

    public async generateOtherMarshRefNumber(marshRefNumber: string): Promise<any> {
        let loanModel: any = await this.database.loanModel.findOne({ marshRefNo: marshRefNumber }).lean(true);
        console.log("loan model ::" + loanModel);
        return new Promise<any>((resolve, reject) => {
            if (loanModel) {
                let seq = loanModel["loanRequestSeqNo"] + 1;
                let marshRefNoSubpart = marshRefNumber.split('/');
                if (seq < 10) {
                    resolve({ seqNumber: seq, marshRefNumber: marshRefNoSubpart[0] + "/0" + seq });
                } else {
                    resolve({ seqNumber: seq, marshRefNumber: marshRefNoSubpart[0] + "/" + seq });
                }
            } else {
                reject(null);
            }
        });

    }

    public async updateLoanRequestSeqNo(marshRefNumber: string, seqNumber: string): Promise<any> {
        let loan: any = await this.database.loanModel.findOneAndUpdate(
            { marshRefNo: marshRefNumber },
            { $set: { loanRequestSeqNo: seqNumber } },
            { new: true });
        return new Promise<any>((resolve, reject) => {
            if (loan) {
                resolve(true);
            } else {
                reject(false);
            }
        });
    }
    public async validation_DL(requestPayload, loanType) {
        console.log("Inside validation_DL");
        let isDLFail: boolean = true;
        let currentAmount;
        if (loanType === "LOAN") {
            console.log("loanType:" + loanType);
            currentAmount = requestPayload.creditInfo.appliedAmountDL;
            console.log("currentAmount:" + currentAmount);
        } else {
            currentAmount = requestPayload.creditInfo.appliedIncAmountDL;
            console.log("currentAmount:" + currentAmount);

        }
        let limitDL: ILimit = await this.database.limitModel.findOne(
            { activated: true, applicationType: 'Discretionary limit' },
            { maximumLimit: 1, _id: 0 }
        );

        //console.log('limitDL:' + limitDL.maximumLimit);
        let loan_applied: any = await this.database.loanModel.aggregate([
            {
                $match: {
                    'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
                    'creditInfo.consortium': requestPayload.creditInfo.consortium,
                    status: 'Processing'
                }
            },
            {
                $group: {
                    _id: null,
                    total: {
                        $sum: '$creditInfo.appliedAmountDL'
                    }
                }
            }


        ]);



        // to do - add loan expiry date in query

        let loan_approved: any = await this.database.loanModel.aggregate([
            {
                $match: {
                    'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
                    'creditInfo.consortium': requestPayload.creditInfo.consortium,
                    status: 'Answered'
                    // 'creditInfo.loanExpiryDate': { $gte : new Date()}
                }
            },
            {
                $group: {
                    _id: null,
                    total: {
                        $sum: '$creditInfo.approvedPrimaryLayer'
                    }
                }
            }
        ]);

        let midterm_approved_incremental: any = await this.database.midTermModel.aggregate([
            {
                $match: {
                    'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
                    'creditInfo.consortium': requestPayload.creditInfo.consortium,
                    status: 'Answered'
                }
            },
            {
                $group: {
                    _id: null,
                    total: {
                        $sum: '$creditInfo.approvedPrimaryLayer'  // to do after midterm edit completion
                    }
                }
            }
            // {
            //     $group: {
            //         _id: null,
            //         total_dec: {
            //             $sum: '$creditInfo.primary'     // to do after midterm edit completion
            //         }
            //     }
            // }
        ]);



        /* let midterm_approved_decremental: any = await this.database.midTermModel.aggregate([
             {
                 $match: {
                     'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
                     'creditInfo.consortium': requestPayload.creditInfo.consortium,
                     status: 'Answered'
                 }
             },
             {
                 $group: {
                     _id: null,
                     total: {
                         $sum: '$creditInfo.primary'     // to do after midterm edit completion
                     }
                 }
             }
         ]);*/

        let midterm_applied_incremental: any = await this.database.midTermModel.aggregate([
            {
                $match: {
                    'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
                    'creditInfo.consortium': requestPayload.creditInfo.consortium,
                    status: 'Processing'
                }
            },
            {
                $group: {
                    _id: null,
                    total: {
                        $sum: '$creditInfo.appliedIncAmountDL'  // to do after midterm edit completion
                    }
                }
            }
        ]);

        let midterm_applied_decremental: any = await this.database.midTermModel.aggregate([
            {
                $match: {
                    'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
                    'creditInfo.consortium': requestPayload.creditInfo.consortium,
                    status: 'Processing'
                }
            },

            {
                $group: {
                    _id: null,
                    total: {
                        $sum: '$creditInfo.appliedDecAmountDL'     // to do after midterm edit completion
                    }
                }
            }
        ]);


        if (midterm_approved_incremental.length > 0) {
            console.log("midterm_approved_incremental:" + midterm_approved_incremental[0].total);
            //console.log("midterm_approved_decremental2:" + midterm_approved_incremental[0].total_dec);
        }

        // if (midterm_approved_decremental.length > 0) {
        //     console.log("midterm_approved_decremental:" + midterm_approved_decremental[0].total);
        // }

        let totalAmount_applied_approved = currentAmount;

        if (loan_approved.length > 0) {
            console.log("loan_approved[0].total:" + loan_approved[0].total);
            totalAmount_applied_approved = totalAmount_applied_approved + loan_approved[0].total;

        }

        if (loan_applied.length > 0) {
            console.log("loan_applied[0].total:" + loan_applied[0].total);
            totalAmount_applied_approved = totalAmount_applied_approved + loan_applied[0].total;

        }

        if (midterm_approved_incremental.length > 0) {

            console.log("midterm_approved_incremental:" + midterm_approved_incremental[0].total);
            totalAmount_applied_approved = totalAmount_applied_approved + midterm_approved_incremental[0].total;
            //totalAmount_applied_approved = totalAmount_applied_approved + midterm_approved_incremental[0].total_dec;
        }

        if (midterm_applied_incremental.length > 0) {
            console.log("midterm_applied_incremental:" + midterm_applied_incremental[0].total);
            totalAmount_applied_approved = totalAmount_applied_approved + midterm_applied_incremental[0].total;
            // totalAmount_applied_approved = totalAmount_applied_approved - midterm_applied_incremental[0].total_dec;
        }

        if (midterm_applied_decremental.length > 0) {
            // console.log(midterm_applied_incremental);
            // totalAmount_applied_approved = totalAmount_applied_approved + midterm_applied_incremental[0].total;
            //totalAmount_applied_approved = totalAmount_applied_approved + midterm_applied_decremental[0].total;
        }



        if (totalAmount_applied_approved > limitDL.maximumLimit) {
            console.log(totalAmount_applied_approved + ">" + limitDL.maximumLimit);
            console.log("totalAmount_applied_approved:" + totalAmount_applied_approved);
            isDLFail = false;
        } else {
            console.log(totalAmount_applied_approved + "<" + limitDL.maximumLimit);
            isDLFail = true;
        }
        return isDLFail;
    }

    /*
            if (loan_approved.length > 0 && loan_applied.length > 0) {
                let totalAmount =
                loan_applied[0].total + loan_approved[0].total + currentAmount;
                if (totalAmount > limitDL.maximumLimit) {
                    isDLFail = false;
                } else {
                    isDLFail = true;
                }
            } else if (loan_applied.length > 0) {
                let totalAmount = loan_applied[0].total + currentAmount;
                if (totalAmount > limitDL.maximumLimit) {
                    isDLFail = false;
                } else {
                    isDLFail = true;
                }
            } else if (loan_approved.length > 0) {
                let totalAmount = loan_approved[0].total + currentAmount;
                if (totalAmount > limitDL.maximumLimit) {
                    isDLFail = false;
                } else {
                    isDLFail = true;
                }
            } else {
                console.log('case4');
                let totalAmount = currentAmount;
                if (totalAmount > limitDL.maximumLimit) {
                    isDLFail = false;
                } else {
                    isDLFail = true;
                }
            }
            return isDLFail;
        }
    */
    public async validation_BG(requestPayload, loanType) {
        console.log("Inside validation_BG");
        let appliedAmount;
        let currentBG;
        let totalBG = 0;


        let limitBG: ILimit = await this.database.limitModel.findOne(
            { activated: true, applicationType: 'Bankers Guarantee' },
            { maximumLimit: 1, _id: 0 }
        );
        //console.log('limitBG::' + limitBG.maximumLimit);
        if (loanType === "LOAN") {
            console.log("loanType_BG" + loanType);
            appliedAmount = requestPayload.creditInfo.appliedAmountDL;
            currentBG = requestPayload.creditInfo.bankersGuaranteeTxt;
            totalBG = currentBG;
        }
        if (loanType === "MIDTERM") {
            console.log("loanType_BG" + loanType);
            appliedAmount = requestPayload.creditInfo.appliedAmountDL;
            currentBG = requestPayload.creditInfo.appliedIncAmountBG;
            totalBG = currentBG;
        }


        console.log('currentBG::' + currentBG);
        console.log('appliedAmount ::' + appliedAmount);
        console.log('appliedAmount2 ::' + (appliedAmount) / 2);

        if (currentBG <= (appliedAmount / 2)) {
            let bg_applied: any = await this.database.loanModel.aggregate([
                {
                    $match: {
                        'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
                        'creditInfo.consortium': requestPayload.creditInfo.consortium,
                        status: 'Processing'
                    }
                },
                {
                    $group: {
                        _id: null,
                        total: {
                            $sum: '$creditInfo.bankersGuaranteeTxt'
                        }
                    }
                }
            ]);
            // to do - add loan expiry date in query
            //console.log('bg_applied::' + bg_applied[0].total);
            let bg_approved: any = await this.database.loanModel.aggregate([
                {
                    $match: {
                        'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
                        'creditInfo.consortium': requestPayload.creditInfo.consortium,
                        status: 'Answered'
                    }
                },
                {
                    $group: {
                        _id: null,
                        total: {
                            $sum: '$creditInfo.approvedBgLayer'
                        }
                    }
                }
            ]);

            let midterm_bg_approved_incremental: any = await this.database.midTermModel.aggregate([
                {
                    $match: {
                        'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
                        'creditInfo.consortium': requestPayload.creditInfo.consortium,
                        status: 'Answered'
                    }
                },
                {
                    $group: {
                        _id: null,
                        total: {
                            $sum: '$creditInfo.approvedBgLayer'  // for both inc anf dec
                        }
                    }
                }
            ]);

            // let midterm_bg_approved_decremental: any = await this.database.midTermModel.aggregate([
            //     {
            //         $match: {
            //             'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
            //             'creditInfo.consortium': requestPayload.creditInfo.consortium,
            //             status: 'Answered'
            //         }
            //     },
            //     {
            //         $group: {
            //             _id: null,
            //             total: {
            //                 $sum: '$creditInfo.bg'  // to do after midterm edit completion
            //             }
            //         }
            //     }
            // ]);

            let midterm_bg_applied_incremental: any = await this.database.midTermModel.aggregate([
                {
                    $match: {
                        'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
                        'creditInfo.consortium': requestPayload.creditInfo.consortium,
                        status: 'Processing'
                    }
                },
                {
                    $group: {
                        _id: null,
                        total: {
                            $sum: '$creditInfo.appliedIncAmountBG'
                        }
                    }
                }
            ]);

            let midterm_bg_applied_decremental: any = await this.database.midTermModel.aggregate([
                {
                    $match: {
                        'sponsorForm.regComName': requestPayload.sponsorForm.regComName,
                        'creditInfo.consortium': requestPayload.creditInfo.consortium,
                        status: 'Processing'
                    }
                },
                {
                    $group: {
                        _id: null,
                        total: {
                            $sum: '$creditInfo.appliedDecAmountBG'  // to do after midterm edit completion
                        }
                    }
                }
            ]);



            if (bg_approved.length > 0) {
                console.log("bg_approved[0].total:" + bg_approved[0].total);
                totalBG = totalBG + bg_approved[0].total;

            }
            if (bg_applied.length > 0) {
                console.log("bg_applied[0].total:" + bg_applied[0].total);
                totalBG = totalBG + bg_applied[0].total;

            }

            if (midterm_bg_approved_incremental.length > 0) {
                console.log("midterm_bg_approved_incremental:" + midterm_bg_approved_incremental[0].total);
                totalBG = totalBG + midterm_bg_approved_incremental.total;

            }

            // if (midterm_bg_approved_decremental.length > 0) {
            //     console.log("midterm_bg_approved_decremental:" + midterm_bg_approved_decremental[0].total);
            //     totalBG = totalBG - midterm_bg_approved_decremental.total;
            // }

            if (midterm_bg_applied_incremental.length > 0) {
                console.log("midterm_bg_applied_incremental:" + midterm_bg_applied_incremental[0].total);
                totalBG = totalBG + midterm_bg_applied_incremental.total;

            }

            // if (midterm_bg_applied_decremental.length > 0) {
            //     console.log("midterm_bg_applied_decremental:" + midterm_bg_applied_decremental[0].total);
            //     totalBG = totalBG + midterm_bg_applied_decremental.total;
            // }

            if (totalBG > limitBG.maximumLimit) {
                return 'BG2V_Fail';
            } else {
                return 'BG2V_PASS';
            }
        } else {
            return 'BG1V_Fail';

        }

        /*  if (bg_approved.length > 0 && bg_applied.length > 0) {
              console.log('bg_approved::' + bg_approved[0].total);
              console.log('bg_applied::' + bg_applied[0].total);
              console.log('currentBG::' + currentBG);
              console.log(
                  'total BG::' + bg_approved[0].total + bg_applied[0].total + currentBG
              );

              if ((bg_approved[0].total + bg_applied[0].total + currentBG) > limitBG.maximumLimit
              ) {
                  return 'BG2V_Fail';
              } else {
                  return 'BG2V_PASS';
              }
          } else if (bg_approved.length > 0) {
              console.log('bg_approved::' + bg_approved[0].total);
              console.log('currentBG::' + currentBG);
              console.log('total BG::' + (bg_approved[0].total + currentBG));
              if ((bg_approved[0].total + currentBG) > limitBG.maximumLimit) {
                  return 'BG2V_Fail';
              } else {
                  return 'BG2V_PASS';
              }
          } else if (bg_applied.length > 0) {
              console.log('bg_applied::' + bg_applied[0].total);
              console.log('currentBG::' + currentBG);
              console.log('total BG::' + (bg_applied[0].total + currentBG));

              if ((bg_applied[0].total + currentBG) > limitBG.maximumLimit) {
                  return 'BG2V_Fail';
              } else {
                  return 'BG2V_PASS';
              }
          } else {
              console.log('currentBG::' + currentBG);
              if (currentBG > limitBG.maximumLimit) {
                  return 'BG2V_Fail';
              } else {
                  return 'BG2V_PASS';
              }
          }
      } else {
          return 'BG1V_Fail';
      }*/
    }

    public async generateLoanMarshReferenceNumber(bankCode: string): Promise<any> {
        let seqNo = await this.confgService.getValueByCode("loanSeqNumber");
        return new Promise<any>((resolve, reject) => {
            let marshRefNumber: string = null;
            if (seqNo) {
                let trancheNo = '05';
                let seqNoPrefix = '';

                if (seqNo.length === 1) {
                    seqNoPrefix = '0000';
                } else if (seqNo.length === 2) {
                    seqNoPrefix = '000';
                } else if (seqNo.length === 3) {
                    seqNoPrefix = '00';
                } else if (seqNo.length === 4) {
                    seqNoPrefix = '0';
                }
                let sequenceNum = seqNoPrefix + seqNo;

                let fullDate: string;
                const date1: Date = new Date();
                let date = date1.getDate();
                if (date.toString().length === 1) {
                    fullDate = '0' + date;
                } else {
                    fullDate = date.toString();
                }
                let month: number = date1.getMonth() + 1;
                if (month.toString().length === 1) {
                    fullDate = fullDate + '0' + month;
                } else {
                    fullDate = fullDate + month.toString();
                }
                let year = date1
                    .getFullYear()
                    .toString()
                    .substr(2, 2);
                fullDate = fullDate + year;
                marshRefNumber = 'LO' + trancheNo + bankCode + fullDate + sequenceNum + '/01';
                console.log('MarshRefNo::' + marshRefNumber);
                if (marshRefNumber) {
                    let seqNumber: number = parseInt(seqNo, 10) + 1;
                    this.confgService.updateByCode("loanSeqNumber", seqNumber.toString());
                    resolve(marshRefNumber);
                } else {
                    reject(null);
                }
            } else {
                reject(null);
            }

        });
    }
}