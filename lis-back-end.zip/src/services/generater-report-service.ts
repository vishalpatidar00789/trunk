import * as Hapi from 'hapi';
import * as Boom from 'boom';
import { IDatabase } from '../database';
import { IServerConfigurations } from '../configurations';
import { IRequest } from '../interfaces/request';
import {
  fieldRequired,
  PfiExportWeeklyOutstanding,
  UobExportWeeklyOutstanding
} from '../api/reports/weekly-outstanding.config';
// import { buildReport } from "../utils/export-xl";
import {
  uobHeaders,
  pfiHeaders
} from '../api/reports/weekly-outstanding.config';
import { ITranch } from '../api/master-data/tranch/tranch';
import { IApp } from '../api/master-data/app-management/app-management';
var xl = require('excel4node');

export default class GenerateReportService {
  private database: IDatabase;
  private configs: IServerConfigurations;

  private styles: any = {
    headerDark: {
      fill: {
        type: 'pattern',
        patternType: 'none', //§18.18.55 ST_PatternType (Pattern Type)
        bgColor: 'red'
      },
      font: {
        color: {
          rgb: 'FFFFFFFF'
        },
        sz: 14,
        bold: true,
        underline: true
      }
    },
    cellPink: {
      fill: {
        fgColor: {
          rgb: 'FFFFCCFF'
        }
      }
    },
    cellGreen: {
      fill: {
        fgColor: '#4286f4'
      }
    }
  };

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }

  public async generateReport(payload: any): Promise<any> {
    console.log('Report generation is in progress');
    let heading: any;
    let specification: any;
    let result: any;
    let dataset: any;
    switch (payload.reportType) {
      case 'Approval Ratio by App':
        const tempresult = await this.createApprovalRatioByAppReport(payload);
        result = new Promise<any>((resolve, reject) => {
          if (tempresult.opCode === 200) {
            resolve(tempresult);
          } else {
            reject(tempresult);
          }
        });
        break;
      case 'Weekly Report for Outstanding Applications':
        result = this.weeklyReportForOutstanding(payload);
        break;
    }
    return result;
  }

  private async createApprovalRatioByAppReport(request): Promise<any> {
    console.log('Creating the approval ratio by app.');

    let payload: any = request;
    if (payload) {
      var app = payload.app;
      console.log('app: ' + app);

      var tranche = payload.tranche;
      console.log('tranche: ' + tranche);

      var pfiCode: any[] = payload.pfiCode;
      console.log('PFI Code:' + pfiCode);
      var pfiCount = pfiCode.length;
      console.log('PFI Code length:' + pfiCount);
    } else {
      console.log('Invalid input payload');
      return Boom.badData("Internal Server Error While generating report.");
    }

    var wb = new xl.Workbook();
    var bold_underline = wb.createStyle({
      font: {
        bold: true,
        underline: true,
      },
      alignment: {
        wrapText: true,
        horizontal: 'center',
      },
    });
    var bold = wb.createStyle({
      font: {
        bold: true,
        // underline: false,
      },
      alignment: {
        // wrapText: false,
        horizontal: 'center',
      },
    });
    var border_style = wb.createStyle({
      border: {
        left: {
          style: 'thin', //§18.18.3 ST_BorderStyle (Border Line Styles) ['none', 'thin', 'medium', 'dashed', 'dotted', 'thick', 'double', 'hair', 'mediumDashed', 'dashDot', 'mediumDashDot', 'dashDotDot', 'mediumDashDotDot', 'slantDashDot']
          color: '#000000' // HTML style hex value
        },
        right: {
          style: 'thin',
          color: '#000000'
        },
        top: {
          style: 'thin',
          color: '#000000'
        },
        bottom: {
          style: 'thin',
          color: '#000000'
        },
        outline: true
      }
    });

    // TODO: Get current tranche using master-data api
    var currentTranche = 5;
    // Getting current tranche
    let tranch: ITranch = await this.database.tranchModel.findOne({ "activated": true });
    let currentTrancheName;

    if (tranch && tranch.trancheName) {
      console.log('Current tranche name:' + currentTrancheName);
      currentTrancheName = tranch.trancheName;
    } else {
      console.log('Unable to get the current tranche');
      return new Promise<any>((resolve, reject) => {
        resolve({ opCode: 500 });
      });
    }

    // Getting APPS in that trache
    let apps: IApp[] = await this.database.appModel.find({ "trancheName": currentTrancheName });
    console.log('Apps:' + JSON.stringify(apps));
    if (apps && apps.length > 0) {
      for (let appIndex = 0; appIndex < apps.length; appIndex++) {
        var appFromDate = new Date(apps[appIndex].appFrom);
        var appToDate = new Date(apps[appIndex].appto);

        var appFirstDateOfTheMonth = new Date(appFromDate.getFullYear(), appFromDate.getMonth(), 1);
        var lastDateOfTheMonth = new Date(appFromDate.getFullYear(), appFromDate.getMonth() + 1, 0);

        console.log('appFirstDateOfTheMonth:' + appFirstDateOfTheMonth);
        console.log('lastDateOfTheMonth:' + appFirstDateOfTheMonth);
        while (lastDateOfTheMonth < appToDate) {
          // Write the logic to populate


        }
      }
    } else {
      console.log('Unable to get the APPS');
      return new Promise<any>((resolve, reject) => {
        resolve({ opCode: 500 });
      });
    }

    // TODO: Get current app using master-data api
    var currentApp = 3;
    var numberOfApp;
    var numberOfMonths;
    if (tranche > currentTranche) {
      console.log('Invalid tranche');
      return Boom.badData("Internal Server Error While generating report.");
    } else if (tranche === currentTranche) {
      console.log('Selected the current tranche');
      numberOfApp = currentApp;
      // TODO: check for current month and add that factor to reduce 12 till current month
      numberOfMonths = numberOfApp * 12;
    } else {
      console.log('Selected the tranche from the past');
      numberOfApp = 5;
      numberOfMonths = numberOfApp * 12;
    }
    // let appManagement: IApp = await this.database.appModel.findOne({
    //     activated: true
    // });

    var currentWorkSheet;
    var ws = wb.addWorksheet('9PFI');

    var currentPfiCount = 0;
    var currentPfi;
    // Loop for individual pfi rows (6 rows for each pfi)
    for (let i = 11; i < pfiCount * 6; i += 6) {

      currentPfi = pfiCode[currentPfiCount];
      console.log('currentPfiCount: ' + currentPfiCount);
      console.log('currentPfi: ' + pfiCode[currentPfiCount]);
      console.log('payload.consortium: ' + payload.consortium);
      var payloadConsortium = payload.consortium;
      // Query to get data add "tranche": "payload.tranche", tranche needs to be added in all applications
      // TODO: Write the logic to check for dates
      let query = [
        {
          $match: {
            "creditInfo.pfiCode": `${currentPfi}`, "consortium": `${payloadConsortium}`, 'status': { $in: ['Draft', 'Answered'] },
            'creditInfo.submissionDate': { $gte: appFirstDateOfTheMonth, $lte: lastDateOfTheMonth }
          }
        }, {
          $group:
            {
              _id: null,
              'Total Applied Limits': { $sum: "$creditInfo.totalRequstedLimitSGD" },
              'Total Approved Limits': { $sum: "$creditInfo.totalApprovedLimitincludingLISPLUS" },
              // 'Without LIS+': { $sum: "$creditInfo.lis5TotalApprovedLimit" },
              'Primary': { $sum: "$creditInfo.approvedPrimaryLayer" },
              'Top Up': { $sum: "$creditInfo.approvedAutoTopUpLayer" },
              'BG': { $sum: "$creditInfo.approvedBgLayer" },
              'LIS PLUS': { $sum: "$creditInfo.approvedSGDLimitLISPlus" },
              count: { $sum: 1 }
            }
        }
      ];
      console.log('query: ' + JSON.stringify(query));
      let pfiRatioByAppArray: any = await this.database.loanModel.aggregate(query);
      console.log('pfiRatioByApp: ' + JSON.stringify(pfiRatioByAppArray));
      console.log('pfiRatioByApp Length:' + pfiRatioByAppArray.length);
      console.log('pfiRatioByAppArray[0]:' + JSON.stringify(pfiRatioByAppArray[0]));
      var pfiRatioByApp;
      if (pfiRatioByAppArray && pfiRatioByAppArray.length > 0) {
        pfiRatioByApp = pfiRatioByAppArray[0];
      }
      if (pfiRatioByApp) {
        console.log("pfiRatioByApp['Total Applied Limits']" + pfiRatioByApp['Total Applied Limits']);
        console.log("pfiRatioByApp['count']" + pfiRatioByApp['count']);
        if (pfiRatioByApp['count'] > 0 && pfiRatioByApp['Total Applied Limits']) {
          pfiRatioByApp['Without LIS+'] = pfiRatioByApp['Primary'] + pfiRatioByApp['Top Up'] + pfiRatioByApp['BG'];
          if (pfiRatioByApp['Total Applied Limits'] === 0) {
            pfiRatioByApp['Total Approval Ratio'] = 'NA';
            pfiRatioByApp['Approval Ratio Without LIS+'] = 'NA';
          } else {
            pfiRatioByApp['Total Approval Ratio'] = Math.round((pfiRatioByApp['Total Approved Limits'] / pfiRatioByApp['Total Applied Limits']) * 100) + '%';
            pfiRatioByApp['Approval Ratio Without LIS+'] = Math.round((pfiRatioByApp['Without LIS+'] / pfiRatioByApp['Total Applied Limits']) * 100) + '%';
          }
        }
      } else {
        console.log('Unable to find pfiRatioByApp.');
        pfiRatioByApp['Total Applied Limits'] = 0;
        pfiRatioByApp['Total Approved Limits'] = 0;
        pfiRatioByApp['Without LIS+'] = 0;
        pfiRatioByApp['Primary'] = 0;
        pfiRatioByApp['Top Up'] = 0;
        pfiRatioByApp['BG'] = 0;
        pfiRatioByApp['LIS PLUS'] = 0;
        pfiRatioByApp['count'] = 0;
        pfiRatioByApp['Total Approval Ratio'] = 'NA';
        pfiRatioByApp['Approval Ratio Without LIS+'] = 'NA';
      }
      console.log('------------------------------------------------------------------------');
      console.log("pfiRatioByApp['Total Applied Limits']: " + pfiRatioByApp['Total Applied Limits']);
      console.log("pfiRatioByApp['Total Approved Limits']: " + pfiRatioByApp['Total Approved Limits']);
      console.log("pfiRatioByApp['Without LIS+']: " + pfiRatioByApp['Without LIS+']);
      console.log("pfiRatioByApp['Primary']: " + pfiRatioByApp['Primary']);
      console.log("pfiRatioByApp['Top Up']: " + pfiRatioByApp['Top Up']);
      console.log("pfiRatioByApp['BG']: " + pfiRatioByApp['BG']);
      console.log("pfiRatioByApp['LIS PLUS']: " + pfiRatioByApp['LIS PLUS']);
      console.log("pfiRatioByApp['count']: " + pfiRatioByApp['count']);
      console.log("pfiRatioByApp['Total Approval Ratio']: " + pfiRatioByApp['Total Approval Ratio']);
      console.log("pfiRatioByApp['Approval Ratio Without LIS+']: " + pfiRatioByApp['Approval Ratio Without LIS+']);
      console.log('------------------------------------------------------------------------');
      console.log('Starting with heading.');
      // Headings
      if (currentPfi === 'UOB') {
        var ws2 = wb.addWorksheet('UOB');
        currentWorkSheet = ws2;
      } else {
        currentWorkSheet = ws;
      }
      // Initializing headings before table
      // ws.cell(startRow, startColumn, [[endRow, endColumn], isMerged]);
      ws.cell(1, 1, 1, 3, true).string('LOAN INSURANCE SCHEME TRANCHE 5').style(bold_underline);
      ws.cell(2, 1, 2, 8, true).string('REPORT FOR APPROVAL RATIO - AGGREGATE 9 PFIs CONSORTIUM (COFACE, CHUBB, TOKIO MARINE KILN & TOKIO MARINE INSURANCE SINGAPORE)').style(bold_underline);
      // Empty row
      ws.cell(4, 1, 4, 8, true).string('Condition 4.  SERVICE LEVEL STANDARDS (of LIS5 Sponsors and Consortium Agreement, wef 1st April 2016)').style(bold_underline);
      ws.cell(5, 1, 5, 17, true).string('4.1. The Underwriters hereby warrant that they shall provide a definitive reply to any full and complete application submitted by the Lenders no later than five (5) working days after the receipt of a full and complete application from the Lenders.');
      ws.cell(6, 1, 6, 13, true).string('4.2. The Underwriters will maximise the approval ratio with the objective of reaching 85% of overall applied amount of the submitted applications by the Lenders for any Anniversary Policy Period');
      // Empty row
      ws.cell(8, 1, 8, 2, true).string('Aggregate 9 PFIs').style(bold).style(border_style);

      currentWorkSheet.cell(10, 1).string('PFI').style(bold).style(border_style);
      currentWorkSheet.cell(10, 2).string('Category').style(bold).style(border_style);
      console.log('NumberOfMonths: ' + numberOfMonths);
      console.log('Total numberOfMonths: ' + numberOfMonths * 4);
      for (let j = 3; j < numberOfMonths * 4; j = j + 4) {
        currentWorkSheet.cell(10, j).string('No. of Cases').style(border_style);
        currentWorkSheet.cell(10, j + 1).string('Total Applied Limits').style(border_style);
        currentWorkSheet.cell(10, j + 2).string('Total Approved Limits').style(border_style);
        currentWorkSheet.cell(10, j + 3).string('Total Approval Ratio').style(border_style);
        console.log('Fixed Data');
        // ------------------- Fixed Data-------------------
        currentWorkSheet.cell(i, 1).string(pfiCode[currentPfiCount]).style(bold).style(border_style); // PFI Code pfiCode[currentPfiCount]
        currentWorkSheet.cell(i, 2).string('Total').style(bold).style(border_style); // Category

        console.log('Calculated Data');
        // ------------------- Calculated Data ------------------
        currentWorkSheet.cell(i, j).number(pfiRatioByApp['count']).style(border_style); // pfiRatioByApp[count]
        currentWorkSheet.cell(i, j + 1).number(pfiRatioByApp['Total Applied Limits']).style(border_style); // pfiRatioByApp[Total Approved Limits]
        currentWorkSheet.cell(i, j + 2).number(pfiRatioByApp['Total Approved Limits']).style(border_style); // pfiRatioByApp[Total Approved Limits]
        currentWorkSheet.cell(i, j + 3).string(pfiRatioByApp['Total Approval Ratio']).style(border_style); // pfiRatioByApp

        console.log('Calculated WITHOUT LIS+');
        currentWorkSheet.cell(i + 1, 1).string('').style(bold_underline).style(border_style); // empty
        currentWorkSheet.cell(i + 1, 2).string('WITHOUT LIS+').style(bold).style(border_style);
        currentWorkSheet.cell(i + 1, 3).string('').style(border_style); // empty
        currentWorkSheet.cell(i + 1, 4).string('').style(border_style); // empty
        currentWorkSheet.cell(i + 1, j + 2).number(pfiRatioByApp['Without LIS+']).style(border_style);
        currentWorkSheet.cell(i + 1, j + 3).string(pfiRatioByApp['Approval Ratio Without LIS+']).style(border_style);

        console.log('Calculated PRIMARY');
        currentWorkSheet.cell(i + 1, 1).string('').style(bold_underline).style(border_style); // empty
        currentWorkSheet.cell(i + 2, 2).string('PRIMARY').style(bold).style(border_style);
        currentWorkSheet.cell(i + 1, 3).string('').style(border_style); // empty
        currentWorkSheet.cell(i + 1, 4).string('').style(border_style); // empty
        currentWorkSheet.cell(i + 2, j + 2).number(pfiRatioByApp['Primary']).style(border_style);
        currentWorkSheet.cell(i + 2, 6).string('').style(border_style); // empty

        console.log('Calculated TOP UP');
        currentWorkSheet.cell(i + 1, 1).string('').style(bold_underline).style(border_style); // empty
        currentWorkSheet.cell(i + 3, 2).string('TOP UP').style(bold).style(border_style);
        currentWorkSheet.cell(i + 1, 3).string('').style(border_style); // empty
        currentWorkSheet.cell(i + 1, 4).string('').style(border_style); // empty
        currentWorkSheet.cell(i + 3, j + 2).number(pfiRatioByApp['Top Up']).style(border_style);
        currentWorkSheet.cell(i + 2, 6).string('').style(border_style); // empty

        console.log('Calculated BG');
        currentWorkSheet.cell(i + 1, 1).string('').style(bold_underline).style(border_style); // empty
        currentWorkSheet.cell(i + 4, 2).string('BG').style(bold).style(border_style);
        currentWorkSheet.cell(i + 1, 3).string('').style(border_style); // empty
        currentWorkSheet.cell(i + 1, 4).string('').style(border_style); // empty
        currentWorkSheet.cell(i + 4, j + 2).number(pfiRatioByApp['BG']).style(border_style);
        currentWorkSheet.cell(i + 2, 6).string('').style(border_style); // empty

        console.log('Calculated LIS+');
        currentWorkSheet.cell(i + 1, 1).string('').style(bold_underline).style(border_style); // empty
        currentWorkSheet.cell(i + 5, 2).string('LIS+').style(bold).style(border_style);
        currentWorkSheet.cell(i + 1, 3).string('').style(border_style); // empty
        currentWorkSheet.cell(i + 1, 4).string('').style(border_style); // empty
        currentWorkSheet.cell(i + 5, j + 2).number(pfiRatioByApp['LIS PLUS']).style(border_style);
        currentWorkSheet.cell(i + 2, 6).string('').style(border_style); // empty
      }
      currentPfiCount++;
    }
    console.log('Excel Generation is in progress.');
    return new Promise<any>((resolve, reject) => {
      wb.write('ExcelFile.xlsx', function (err, stats) {
        if (err) {
          console.log('Error generating excel.');
          console.error(err);
          resolve({ opCode: 500 });
        } else {
          console.log('Excel writing in progress.');
          // let pathofFile = tempFile + path.join(fileName);
          // wb.write(fileName);
          // this.deleteFile(pathofFile);
          resolve({ opCode: 200, filename: wb });
          console.log(stats); // Prints out an instance of a node.js fs.Stats object
        }
      });
    });
  }

  public async weeklyReportForOutstanding(payload: any) {
    const searchCriteria = this.buildMatchCriteria(payload);
    const _uobDetails: Array<UobExportWeeklyOutstanding> = new Array<
      UobExportWeeklyOutstanding
      >();
    const _pfiDetails: Array<PfiExportWeeklyOutstanding> = new Array<
      PfiExportWeeklyOutstanding
      >();
    const data = await this.GetWeeklyReportForOutstandingData(searchCriteria);
    const midtermData = await this.GetWeeklyReportOutstandingMidterm(
      searchCriteria
    );
    if (data) {
      data.forEach(element => {
        if (element.creditInfo.pfiCode) {
          if (element.creditInfo.pfiCode === 'UOB') {
            _uobDetails.push(this.WeeklyOutstandingReportObject(element));
          } else {
            _pfiDetails.push(this.WeeklyOutstandingReportObject(element));
          }
        }
      });
    }
    if (midtermData) {
      midtermData.forEach(element => {
        if (element.creditInfo.pfiCode) {
          if (element.creditInfo.pfiCode === 'UOB') {
            _uobDetails.push(this.WeeklyOutstandingReportObject(element));
          } else {
            _pfiDetails.push(this.WeeklyOutstandingReportObject(element));
          }
        }
      });
    }
    return this.GenerateReportWeekly(_uobDetails, _pfiDetails);
  }

  WeeklyOutstandingReportObject(element): any {
    let uobDetails: UobExportWeeklyOutstanding;
    let pfiDetails: PfiExportWeeklyOutstanding;
    let primary = element.creditInfo.primary || 0;
    const bg = element.creditInfo.bg || 0;
    const autpTopUp = element.creditInfo.autoTopUp || 0;
    const lisPlus = element.creditInfo.lisPlus || 0;
    const totalApproved = primary + bg + lisPlus + autpTopUp;
    switch (element.creditInfo.pfiCode) {
      case 'UOB':
        uobDetails = new UobExportWeeklyOutstanding();
        const creditInfo = element.creditInfo;
        uobDetails.uobAcraRefNo = element.sponsorForm.ACRANo;
        uobDetails.uobNameofBorrower = creditInfo.borrowerRegName;
        uobDetails.uobInsurersApprovalDate =
          creditInfo.insurersApprovalDate || '';
        uobDetails.uobNatureOfApplication =
          creditInfo.natureOfApplication || '';
        uobDetails.uobLisApprovedLimit = totalApproved;
        uobDetails.uobLisPlusApprovalDate = creditInfo.lISPlusApprovedDate || 0;
        uobDetails.uobLisPlusApprovedLimit =
          creditInfo.totalApprovedLimitincludingLISPLUS || 0;
        uobDetails.uobRemarks = creditInfo.internalRemark || '';
        break;
      default:
        pfiDetails = new PfiExportWeeklyOutstanding();
        const pficreditInfo = element.creditInfo;
        pfiDetails.pfiAcraRefNo = element.sponsorForm.ACRANo;
        pfiDetails.pfiName = pficreditInfo.pfiCode;
        pfiDetails.pfiNameofBorrower = pficreditInfo.borrowerRegName;
        pfiDetails.pfiInsurersApprovalDate =
          pficreditInfo.insurersApprovalDate || '';
        pfiDetails.pfiNatureOfApplication =
          pficreditInfo.natureOfApplication || '';
        pfiDetails.pfiLisApprovedLimit = totalApproved;
        pfiDetails.pfiLisPlusApprovalDate =
          pficreditInfo.lISPlusApprovedDate || '';
        pfiDetails.pfiTopUpApprovedLimit =
          pficreditInfo.approvedAutoTopUpLayer || '';
        pfiDetails.pfiLisPlusApprovedLimit =
          pficreditInfo.totalApprovedLimitincludingLISPLUS || '';
        pfiDetails.pfiRemarks = pficreditInfo.internalRemark || '';
        break;
    }
    if (pfiDetails) {
      return pfiDetails;
    } else {
      return uobDetails;
    }
  }

  buildMatchCriteria(payload: any) {
    let matchCriteria = {};
    if (payload.marshRefNo) {
      matchCriteria['marshRefNo'] = payload.marshRefNo;
    }
    if (payload.borrowerName) {
      matchCriteria['creditInfo.borrowerRegName'] = payload.borrowerName;
    }
    if (payload.uenNumber) {
      matchCriteria['creditInfo.aCRArefNo'] = payload.uenNumber;
    }
    if (payload.pfiCode) {
      matchCriteria['creditInfo.pfiCode'] = { $in: payload.pfiCode };
    }
    if (payload.consortium) {
      matchCriteria['consortium'] = payload.consortium;
    }
    if (payload.typeofDate) {
      matchCriteria['creditInfo.submissionDate'] = this.GetDateQuery(payload);
    }

    if (payload.natureOfApplication) {
      matchCriteria['creditInfo.natureOfApplication'] = {
        $in: payload.natureOfApplication
      };
    }
    if (payload.marshLoanApplicationStatus) {
      matchCriteria['status'] = { $in: payload.marshLoanApplicationStatus };
    }
    if (payload.excludeExpiredApplications) {
      matchCriteria['excludeExpiredApplications'] =
        payload.excludeExpiredApplications;
    }
    if (payload.app) {
      matchCriteria['app'] = { $in: payload.app };
    }
    return matchCriteria;
  }

  GetDateQuery(payload: any) {
    let typeofDate: string;
    let formDateQuery: string;
    if (payload.typeofDate) {
      switch (payload.typeofDate) {
        case 'Marsh Submission Date':
          typeofDate = 'createdDate';
          break;
        case 'COFANET Submission Date':
          typeofDate = 'creditInfo.submissionDate';
          break;
        case 'LO Acceptance Date':
          typeofDate = 'creditInfo.loAcceptanceDate';
          break;
        case 'Loan Expiry Date':
          typeofDate = 'creditInfo.loanExpiryDate';
          break;
      }
      if (payload.fromDate) {
        formDateQuery = `{$gte:ISO(${payload.fromDate})`;
      }
      if (payload.toDate) {
        formDateQuery = formDateQuery + `,{$gte:ISO(${payload.toDate})`;
      }
      formDateQuery = formDateQuery + '}';
    }
    return formDateQuery;
  }

  public async GetWeeklyReportForOutstandingData(matchQuery: any) {
    let data: any;
    return this.database.loanModel
      .aggregate([{ $match: matchQuery }, { $project: fieldRequired }])
      .then(data => {
        return data;
      });
  }

  public async GetWeeklyReportOutstandingMidterm(matchQuery) {
    return this.database.midTermModel
      .aggregate([{ $match: matchQuery }, { $project: fieldRequired }])
      .then(data => {
        return data;
      });
  }

  public GenerateReportWeekly(
    uobData: Array<UobExportWeeklyOutstanding>,
    pfiData: Array<PfiExportWeeklyOutstanding>
  ) {
    const workBook = new xl.Workbook();
    let workSheet = workBook.addWorksheet(
      'Weekly Report for Outstanding Application'
    );
    uobHeaders.forEach((element, index) => {
      workSheet = this.GenerateCell(
        workSheet,
        2,
        index + 1,
        'headers',
        element.displayName
      );
    });
    uobData.forEach((dataElement, index) => {
      uobHeaders.forEach((fieldElement, headerIndex) => {
        workSheet = this.GenerateCell(
          workSheet,
          index + 3,
          headerIndex + 1,
          !fieldElement.type ? 'string' : fieldElement.type,
          dataElement[fieldElement.fieldName],
          this.styles.headerDark
        );
      });
    });
    const _uobHeadercount = uobHeaders.length + 1;
    pfiHeaders.forEach((element, index) => {
      workSheet = this.GenerateCell(
        workSheet,
        2,
        index + _uobHeadercount + 1,
        'headers',
        element.displayName
      );
    });
    pfiData.forEach((dataElement, index) => {
      pfiHeaders.forEach((fieldElement, headerIndex) => {
        console.log('Data' + dataElement[fieldElement.fieldName]);
        console.log('field' + fieldElement.fieldName);
        workSheet = this.GenerateCell(
          workSheet,
          index + 3,
          _uobHeadercount + headerIndex + 1,
          !fieldElement.type ? 'string' : fieldElement.type,
          dataElement[fieldElement.fieldName],
          this.styles.headerDark
        );
      });
    });
    return new Promise<any>((resolve, reject) => {
      workBook.write('Weekly-outstanding-report.xlsx', function (err, stats) {
        if (err) {
          console.log('Error generating excel.');
          console.error(err);
          resolve({ opCode: 500 });
        } else {
          console.log('Excel writing in progress.');
          const now = new Date();
          const fileName =
            'weekly-outstanding-' +
            now.getDay() +
            now.getMonth() +
            now.getTime() +
            '.xlsx';
          resolve({ opCode: 200, filename: fileName });
          console.log(stats); // Prints out an instance of a node.js fs.Stats object
        }
      });
    });
  }

  public GenerateCell(
    currentWorkSheet: any,
    row: number,
    column: number,
    cellType: string,
    data: any,
    style?: any
  ) {
    switch (cellType) {
      case 'string':
        if (!data) {
          data = '';
        }
        currentWorkSheet.cell(row, column).string(data);
        break;
      case 'date':
        if (cellType === 'date' && data === '') {
          data = '';
        } else {
          data = new Date(data).toString();
        }
        currentWorkSheet.cell(row, column).string(data);
        break;
      case 'number':
        if (!data) {
          data = 0;
        }
        currentWorkSheet.cell(row, column).number(data);
        break;
      case 'headers':
        {
          currentWorkSheet
            .cell(row, column)
            .string(data)
            .style(this.styles['headerDark']);
        }
        break;
      default:
        break;
    }
    return currentWorkSheet;
  }
}
