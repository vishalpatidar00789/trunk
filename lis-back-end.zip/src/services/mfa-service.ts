import * as Hapi from 'hapi';
import { IDatabase } from "../database";
import { IMfaConfiguration } from "../configurations";
import ConfigurationService from "./configuration-service";
import EmailService from './email-service';
import { IMailOptions } from '../interfaces/request';
import { ISMTPServerConfigurations } from "../configurations";
var nodemailer = require("nodemailer");

let Client = require('node-rest-client').Client;
var async = require("async");


export default class MfaService {
    private configs: IMfaConfiguration;
    private emailService: EmailService;
    private mfaUrl: string;

    constructor(emailService: EmailService, configs: IMfaConfiguration) {
        this.configs = configs;
        this.emailService = emailService;
        this.mfaUrl = configs.mfaUrl;

    }
    resourceUrl = this.mfaUrl;
    client = new Client();

    public async generateOTP(userData: any, emailService: EmailService): Promise<any> {
        let resourceUrl = this.mfaUrl;
        let client = new Client();
        let success, error: any;
        let sessionId: string;
        let transactionId: string;
        // let otp: string;

        return new Promise<any>((resolve, reject) => {
            async.waterfall([
                function getHashedId(callback) {
                    let hashedUsername: any = null;
                    console.log("inside getGashId");
                    let url = resourceUrl + '/hashid?userid=' + userData.username;
                    client.get(url, function (data, response) {
                        let dataInString = data.toString();
                        if (dataInString) {
                            let hashedId = dataInString.substring(dataInString.indexOf("is equal to =") + 1,
                                dataInString.indexOf("using hashid service") - 1).split('=')[1];
                            if (hashedId) {
                                hashedUsername = hashedId;
                                if (hashedUsername) {
                                    userData.hashedUsername = hashedUsername;
                                    return callback(null, userData);
                                } else {
                                    error = { opCode: 500, data: null, msg: '' };
                                    return callback(Error);
                                }
                            } else {
                                error = { opCode: 500, data: null, msg: '' };
                                return callback(Error);
                            }
                        } else {
                            error = { opCode: 500, data: null, msg: '' };
                            return callback(Error);
                        }

                    });
                },

                function getEncryptedPayloadService(userData, callback) {
                    console.log("getEncryptedPayloadService");
                    console.log("username=" + userData.username);
                    let hmacKey, otherString: string;
                    var args = {
                        headers: { "Content-Type": "application/json" },
                        // data: {
                        //     "username": userData.username,
                        //     "userEmail": "Test@marsh.com",
                        //     "orgName": "Marsh_Dev",
                        //     "ipAddress": "1.1.1.1",
                        //     "clientGenCookie": "someData",
                        //     "groups": ['Clients', 'MFA']

                        // }
                    };

                    let queryString = resourceUrl + "/encryptPayloadSvc?username=" + userData.hashedUsername +
                        "&userEmail=" + userData.userEmail + "&orgName=" + userData.orgName + "&ipAddress="
                        + userData.ipAddress + "&clientGenCookie=" + userData.clientGenCookie + "&groups="
                        + userData.groups[0] + "&groups=" + userData.groups[1];
                    console.log("queryString:" + queryString);

                    client.post(queryString, args, function (data, response) {
                        console.log("data from Enc:" + data);
                        let encString = data.toString();
                        if (encString) {
                            hmacKey = encString.toString().split(">>")[1];
                            hmacKey = hmacKey.toString().split("<<")[0];
                            otherString = encString.toString().split(">>")[2];
                            otherString = otherString.toString().split("<<")[0];
                            if (hmacKey && otherString) {
                                return callback(null, hmacKey, otherString, userData);
                            } else {
                                return callback(Error);
                            }
                        } else {
                            return callback(Error);
                        }
                    });
                },

                function analyzeService(hmacKey, otherString, userData, callback) {
                    console.log("inside analyzeService");
                    let args = {
                        headers: {
                            'Content-Type': 'application/json',
                            'Hmac': hmacKey,
                            'CHLocale': 'en_US'
                        },
                        data: otherString
                    };
                    client.post(resourceUrl + "/analyze", args, function (data, response) {
                        console.log("data:" + JSON.stringify(data));
                        console.log("hmacKey:" + hmacKey);
                        console.log("userData:" + JSON.stringify(userData));
                        if (data) {
                            sessionId = data.sessionId;
                            transactionId = data.transactionId;
                            return callback(null, hmacKey, otherString, sessionId, transactionId, userData);
                        } else {
                            return callback(Error);
                        }
                    });
                },

                function updateUserService(hmacKey, otherString, sessionId, transactionId, userData, callback) {
                    console.log("inside updateUserService");
                    console.log("HMAC Key:" + hmacKey);
                    console.log("REquest Data:" + otherString);
                    console.log("SessionId:" + sessionId);
                    console.log("TransactionId:" + transactionId);
                    var args = {
                        headers: {
                            "Content-Type": "applitransactionIdcation/json",
                            "Hmac": hmacKey.toString().trim(),
                            "SessionId": sessionId,
                            "TransactionID": transactionId
                        },
                        data: otherString
                    };
                    client.post(resourceUrl + "/updateuser", args, function (data, response) {
                        console.log("data from update user:" + JSON.stringify(data));
                        // console.log(response);
                        if (data) {
                            return callback(null, hmacKey, otherString, sessionId, transactionId, userData);
                        } else {
                            return callback(Error);
                        }
                    });
                },

                function challenge(hmacKey, otherString, sessionId, transactionId, userData, callback) {
                    console.log("inside challenge");
                    console.log("HMAC Key:" + hmacKey);
                    console.log("REquest Data:" + otherString);
                    console.log("SessionId:" + sessionId);
                    console.log("TransactionId:" + transactionId);
                    var args = {
                        headers: {
                            "Content-Type": "application/json",
                            "Hmac": hmacKey.toString().trim(),
                            "SessionId": sessionId,
                            "TransactionID": transactionId
                        },
                        data: otherString
                    };
                    client.post(resourceUrl + "/challenge", args, function (data, response) {
                        console.log("data from challenge:" + JSON.stringify(data));
                        if (data) {
                            return callback(null, userData, data.otp, sessionId, transactionId);
                        } else {
                            return callback(Error);
                        }
                    });
                },
                function sendOTPMail(userData, otp, sessionId, transactionId, callback) {
                    console.log("inside sendOTPMail");
                    let emailOptions = new IMailOptions();
                    emailOptions.from = "LIS, System <no-reply@marsh.com>"; // this should be configurable
                    emailOptions.to = userData.userEmail;
                    emailOptions.subject = "On Demand Token Code";
                    emailOptions.html = "On Demand Token code: " + otp;
                    try {
                        // emailService.sendEmail(emailOptions);
                        return callback(null, userData, otp, sessionId, transactionId); //Remove otp from here
                    } catch (error) {
                        return callback(Error); // set email error msg
                    }
                }
            ], function (error, userData, otp, sessionId, transactionId) {

                if (error) {
                    console.log(error);
                    return error;
                } else {
                    console.log("userData=" + JSON.stringify(userData));
                    console.log("sessionId:" + sessionId);
                    console.log("transactionId:" + transactionId);
                    sessionId = sessionId;
                    transactionId = transactionId;
                    userData = userData;
                    resolve({ sessionId: sessionId, txId: transactionId, userdata: userData }); //Remove otp from here
                }
            });
        });
    }


    //this function exicutes after entring OTP

    verifyOTP(otp: string, userData: any, sessionId: string, transactionId: string): Promise<any> {
        // userData: from previous function
        // sessionId: from previous function
        // transactionId: from previous function

        let resourceUrl = this.mfaUrl;
        let client = new Client();
        return new Promise<any>((resolve, reject) => {
            async.waterfall([

                function getEncryptedPayloadService(otp, userData, callback) {
                    console.log("getEncryptedPayloadService");
                    console.log("username=" + userData.username);
                    let hmacKey, otherString: string;
                    var args = {
                        headers: { "Content-Type": "application/json" },

                    };

                    let queryString = resourceUrl + "/encryptPayloadSvc?username=" + userData.hashedUsername +
                        "&userEmail=" + userData.userEmail + "&orgName=" + userData.orgName + "&ipAddress="
                        + userData.ipAddress + "&clientGenCookie=" + userData.clientGenCookie + "&groups="
                        + userData.groups[0] + "&groups=" + userData.groups[1] + "&otp=" + otp;
                    console.log("queryString:" + queryString);

                    client.post(queryString, args, function (data, response) {
                        console.log("data from Enc:" + data);
                        let encString = data.toString();
                        if (encString) {
                            hmacKey = encString.toString().split(">>")[1];
                            hmacKey = hmacKey.toString().split("<<")[0];
                            otherString = encString.toString().split(">>")[2];
                            otherString = otherString.toString().split("<<")[0];
                            if (hmacKey && otherString) {
                                return callback(null, hmacKey, otherString, userData);
                            } else {
                                return callback(Error);
                            }
                        } else {
                            return callback(Error);
                        }
                    });
                },

                function authenticateService(hmacKey, otherString, userData, sessionId, transactionId, callback) {
                    console.log("inside authenticateService");

                    console.log("HMAC Key:" + hmacKey);
                    console.log("REquest Data:" + otherString);
                    console.log("SessionId:" + sessionId);
                    console.log("TransactionId:" + transactionId);
                    var args = {
                        headers: {
                            "Content-Type": "application/json",
                            "Hmac": hmacKey.toString().trim(),
                            "SessionId": sessionId,
                            "TransactionID": transactionId
                        },
                        data: otherString
                    };
                    client.post(resourceUrl + "/authenticate", args, function (data, response) {
                        console.log("data from authenticate:" + JSON.stringify(data));
                        return callback(null, data);
                    });
                }
            ], function (error, data) {
                console.log("outside async waterfall");
                if (error) {
                    console.log(error);
                    reject(error);
                } else {
                    resolve(data);
                }

            });
        });

        // return new Promise<any>((resolve, reject) => {
        //     resolve({ result: data });
        // });

    }



}






// public sendOTPMail(email: string, otp: string) {

//     let emailOptions = new IMailOptions();
//     emailOptions.from = "System_admin"; // this should be configurable
//     emailOptions.to = email;
//     emailOptions.subject = "On Demand Token Code";
//     emailOptions.html = "On Demand Token code: " + otp;
//     this.emailService.sendEmail(emailOptions);

// }
        // var headers = {
        //     'Content-Type': 'application/x-www-form-urlencoded'
        // }
        // var options = {
        //     url: this.resourceUrl + '/encryptPayloadSvc',
        //     method: 'POST',
        //     headers: headers,
        //     form: userData
        // }
        // request(options, function (error, response, body) {
        //     if (!error && response.statusCode == 200) {
        //         console.log("response::" + response);
        //         console.log("body::" + body);
        //         this.userData.requestData = body;
        //     }
        // })



    // private async analyze(userData: MFA) {


    //     var args = {
    //         data: {},
    //         headers: { "Content-Type": "application/json" }
    //     };

    //     this.client.post(this.resourceUrl + '/analyze', args, function (data, response) {

    //         console.log(data);

    //         console.log(response);
    //     });


        // var headers = {
        //     'Content-Type': 'application/x-www-form-urlencoded'
        // }
        // var options = {
        //     url: this.resourceUrl + '/analyze',
        //     method: 'POST',
        //     headers: headers,
        //     form: userData
        // }
        // request(options, function (error, response, body) {
        //     if (!error && response.statusCode == 200) {
        //         console.log("response::" + response);
        //         console.log("body::" + body);
        //     }
        // })

