import * as Hapi from 'hapi';
import { IDatabase } from "../database";
import { IMfaConfiguration } from "../configurations";
import ConfigurationService from "./configuration-service";

import EmailService from './email-service';
import { IMailOptions } from '../interfaces/request';
import { ISMTPServerConfigurations } from "../configurations";
var nodemailer = require("nodemailer");

let Client = require('node-rest-client').Client;
var async = require("async");


export default class MfaService {
    private configs: IMfaConfiguration;
    private emailService: EmailService;
    private mfaUrl: string;

    //private resourceUrl = 'https://dev.tspv3.app.services.marsh.com/MFAServices/AA';

    constructor(emailService: EmailService, configs: IMfaConfiguration) {
        this.configs = configs;
        this.emailService = emailService;
        this.mfaUrl = configs.mfaUrl;

    }
    resourceUrl = this.mfaUrl;
    client = new Client();

    public async generateOTP(userdata: any, emailService: EmailService): Promise<any> {
        let resourceUrl = this.mfaUrl;
        let client = new Client();
        let success, error: any;
        let sessionId: string;
        let transactionId: string;
        // let otp: string;

        return new Promise<any>(async (resolve, reject) => {
            let result = await this.getHashedId(userdata, client);
            if (result.opCode === 200) {
                result = await this.getEncryptedPayloadService(result.data, client);
                if (result.opCode === 200) {
                    userdata = result.data;
                    let analyze = await this.analyzeService(client, result.hmacKey, result.otherString, result.data);
                    console.log("result form analyze " + JSON.stringify(result));
                    if (analyze.data.userStatus !== 'LOCKOUT' && analyze.data.userStatus !== 'DELETE') {

                        if (analyze.data.userStatus === 'UNVERIFIED') {
                            //hmacKey: string, otherString: string, sessionId: string, transactionId: string, userData: any
                            let updateUser = await this.updateUser(analyze.hmacKey, analyze.otherString, analyze.data.sessionId,
                                 analyze.data.transactionId);
                                 console.log("result form update ::" + JSON.stringify(updateUser));
                            if (analyze.data.actionCode === "CHALLENGE") {
                                if (analyze.data.userStatus === "UNVERIFIED") {
                                    let challenge = await this.challenge(updateUser.hmacKey, analyze.otherString,
                                        updateUser.data.sessionId, updateUser.data.transactionId);
                                    // resolve(challenge);
                                    console.log("result form challenge:: " + JSON.stringify(challenge));
                                    if (challenge.opCode === 200) {
                                        resolve ({ opCode: 201, otpdata: challenge.data, userdata: userdata, status: "VERIFIED" });
                                    } else {
                                        resolve({ opCode: 500, data: null, msg: "Internal server error." });
                                    }
                                } else {
                                    let challenge = await this.challenge(analyze.hmacKey, analyze.otherString,
                                        analyze.data.sessionId, analyze.data.transactionId);
                                    // await this.mfaService.sendOTPMail(analyze.userData, analyze.responseData.otp);
                                    console.log("result form challenge:: " + JSON.stringify(challenge));
                                    if (challenge.opCode === 200) {
                                        resolve ({ opCode: 201, otpdata: challenge.data, userdata: userdata, status: "VERIFIED" });
                                    } else {
                                        resolve({ opCode: 500, data: null, msg: "Internal server error." });
                                    }
                                }
                            } else if (analyze.data.actionCode === "ALLOW") {
                                return { opCode: 200, msg: "User allowed.", status: "ALLOW"};
                            }
                        }
                    } else if (analyze.responseData.userStatus === 'LOCKOUT') {
                        return { opCode: 423, msg: "User locked/deleted out. Please contact admin.", status: "LOCKOUT" };
                    } else if (analyze.responseData.userStatus === 'DELETE') {
                        return { opCode: 423, msg: "User locked/deleted out. Please contact admin.", status: "DELETE" };
                    }
                } else {
                    resolve(result);
                }
            } else {
                resolve(result);
            }
        });
    }

    public async getHashedId(userdata: any, client: any): Promise<any> {
        let hashedUsername: any = null;
        console.log("inside getGashId");
        let url = this.mfaUrl + '/hashid?userid=' + userdata.username;
        return new Promise<any>((resolve, reposne) => {
            client.get(url, function (data, response) {
                let dataInString = data.toString();
                if (dataInString) {
                    let hashedId = dataInString.substring(dataInString.indexOf("is equal to =") + 1,
                        dataInString.indexOf("using hashid service") - 1).split('=')[1];
                    if (hashedId) {
                        hashedUsername = hashedId;
                        if (hashedUsername) {
                            userdata.hashedUsername = hashedUsername;
                            resolve({ opCode: 200, data: userdata });
                        } else {
                            resolve({ opCode: 500, data: null, msg: 'Internal server error.' });
                        }
                    } else {
                        resolve({ opCode: 500, data: null, msg: 'Internal server error.' });
                    }
                } else {
                    resolve({ opCode: 500, data: null, msg: 'Internal server error.' });
                }
            });
        });
    }

    public async getEncryptedPayloadService(userdata, client: any): Promise<any> {
        console.log("getEncryptedPayloadService");
        console.log("username=" + userdata.username);
        let hmacKey, otherString: string;
        var args = {
            headers: { "Content-Type": "application/json" }
        };

        let queryString = this.mfaUrl + "/encryptPayloadSvc?username=" + userdata.hashedUsername +
            "&userEmail=" + userdata.userEmail + "&orgName=" + userdata.orgName + "&ipAddress="
            + userdata.ipAddress + "&clientGenCookie=" + userdata.clientGenCookie + "&groups="
            + userdata.groups[0] + "&groups=" + userdata.groups[1];
        console.log("queryString:" + queryString);
        return new Promise<any>((resolve, reject) => {
            client.post(queryString, args, function (data, response) {
                console.log("data from Enc:" + data);
                let encString = data.toString();
                if (encString) {
                    hmacKey = encString.toString().split(">>")[1];
                    hmacKey = hmacKey.toString().split("<<")[0];
                    otherString = encString.toString().split(">>")[2];
                    otherString = otherString.toString().split("<<")[0];
                    if (hmacKey && otherString) {
                        resolve({ opCode: 200, data: userdata, hmacKey: hmacKey, otherString: otherString });
                    } else {
                        resolve({ opCode: 500, data: null, msg: 'Internal server error.' });
                    }
                } else {
                    resolve({ opCode: 500, data: null, msg: 'Internal server error.' });
                }
            });
        });
    }

    public async updateUser(hmacKey: string, otherString: string, sessionId: string, transactionId: string): Promise<any> {
        let resourceUrl = this.mfaUrl;
        console.log("inside updateUserService");
        console.log("HMAC Key:" + hmacKey);
        console.log("REquest Data:" + otherString);
        console.log("SessionId:" + sessionId);
        console.log("TransactionId:" + transactionId);
        let client = new Client();
        var args = {
            headers: {
                "Content-Type": "applitransactionIdcation/json",
                "Hmac": hmacKey.toString().trim(),
                "SessionId": sessionId,
                "TransactionID": transactionId,
                "CHLocale": "en_US"
            },
            data: otherString
        };
        return new Promise<any>((resolve, reject) => {
            client.post(resourceUrl + "/updateuser", args, function (data, response) {
                console.log("data from update user:" + JSON.stringify(data));
                // console.log(response);
                if (data) {
                    resolve({ opCode: 200, data: data, hmacKey: hmacKey, otherString: otherString });
                } else {
                    resolve({ opCode: 500, data: null, msg: "Internal server error." });
                }
            });
        });

    }

    public async analyzeService(client: any, hmacKey, otherString, userData): Promise<any> {
        console.log("inside analyzeService");
        let args = {
            headers: {
                'Content-Type': 'application/json',
                'Hmac': hmacKey,
                'CHLocale': 'en_US'
            },
            data: otherString
        };
        return new Promise<any>((resolve, reject) => {
            client.post(this.mfaUrl + "/analyze", args, function (data, response) {
                console.log("data:" + JSON.stringify(data));
                console.log("hmacKey:" + hmacKey);
                console.log("userData:" + JSON.stringify(userData));
                if (data) {
                    resolve({ opCode: 200, data: data, hmacKey: hmacKey, otherString: otherString });
                } else {
                    resolve({ opCode: 500, data: null, msg: "Internal server error." });
                }
            });
        });
    }

    public async challenge(hmacKey: string, otherString: string, sessionId: string, transactionId: string): Promise<any> {
        let resourceUrl = this.mfaUrl;
        console.log("inside challenge");
        console.log("HMAC Key:" + hmacKey);
        console.log("REquest Data:" + otherString);
        console.log("SessionId:" + sessionId);
        console.log("TransactionId:" + transactionId);

        var args = {
            headers: {
                "Content-Type": "application/json",
                "Hmac": hmacKey.toString().trim(),
                "SessionId": sessionId,
                "TransactionID": transactionId,
                "CHLocale": "en_US"
            },
            data: otherString
        };
        return new Promise<any>((resolve, reject) => {
            const client = new Client();
            console.log(resourceUrl + "/challenge");
            console.log("args:" + args);
            client.post(resourceUrl + "/challenge", args, function (data, response) {
                console.log("data from challenge:" + JSON.stringify(data));
                if (data) {
                    resolve({ opCode: 200, data: data });
                } else {
                    resolve({ opCode: 500, data: null, msg: "Internal server error." });
                }
            });
        });
    }


    public async sendOTPMail(userdata: any, otp: string): Promise<any> {
        console.log("inside sendOTPMail");
        let emailOptions = new IMailOptions();
        emailOptions.from = "LIS, System <no-reply@marsh.com>"; // this should be configurable
        emailOptions.to = userdata.userEmail;
        emailOptions.subject = "On Demand Token Code";
        emailOptions.html = "On Demand Token code: " + otp;
        return new Promise<any>((resolve, reject) => {
            try {
                this.emailService.sendEmail(emailOptions);
                resolve(true); //Remove otp from here
            } catch (error) {
                resolve(Error); // set email error msg
            }
        });
    }

    //this function exicutes after entring OTP

    verifyOTP(otp: string, userData: any, sessionId: string, transactionId: string): Promise<any> {
        // userData: from previous function
        // sessionId: from previous function
        // transactionId: from previous function

        let resourceUrl = this.mfaUrl;
        let client = new Client();
        return new Promise<any>((resolve, reject) => {
            async.waterfall([

                function getEncryptedPayloadService(callback) {
                    console.log("getEncryptedPayloadService");
                    console.log("username=" + userData.username);
                    let hmacKey, otherString: string;
                    var args = {
                        headers: { "Content-Type": "application/json" },

                    };

                    let queryString = resourceUrl + "/encryptPayloadSvc?username=" + userData.hashedUsername +
                        "&userEmail=" + userData.userEmail + "&orgName=" + userData.orgName + "&ipAddress="
                        + userData.ipAddress + "&clientGenCookie=" + userData.clientGenCookie + "&groups="
                        + userData.groups[0] + "&groups=" + userData.groups[1] + "&otp=" + otp;
                    console.log("queryString:" + queryString);

                    client.post(queryString, args, function (data, response) {
                        console.log("data from Enc:" + data);
                        let encString = data.toString();
                        if (encString) {
                            hmacKey = encString.toString().split(">>")[1];
                            hmacKey = hmacKey.toString().split("<<")[0];
                            otherString = encString.toString().split(">>")[2];
                            otherString = otherString.toString().split("<<")[0];
                            if (hmacKey && otherString) {
                                return callback(null, hmacKey, otherString, sessionId, transactionId);
                            } else {
                                return callback(Error);
                            }
                        } else {
                            return callback(Error);
                        }
                    });
                },

                function authenticateService(hmacKey, otherString, sessionId, transactionId, callback) {
                    console.log("inside authenticateService");

                    console.log("HMAC Key:" + hmacKey);
                    console.log("REquest Data:" + otherString);
                    console.log("SessionId:" + sessionId);
                    console.log("TransactionId:" + transactionId);
                    var args = {
                        headers: {
                            "Content-Type": "application/json",
                            "Hmac": hmacKey.toString().trim(),
                            "SessionId": sessionId,
                            "TransactionID": transactionId
                        },
                        data: otherString
                    };
                    client.post(resourceUrl + "/authenticate", args, function (data, response) {
                        console.log("data from authenticate:" + JSON.stringify(data));
                        return callback(null, data);
                    });
                }
            ], function (error, data) {
                console.log("outside async waterfall");
                if (error) {
                    console.log(error);
                    reject(error);
                } else {
                    resolve(data);
                }

            });
        });

        // return new Promise<any>((resolve, reject) => {
        //     resolve({ result: data });
        // });

    }
}