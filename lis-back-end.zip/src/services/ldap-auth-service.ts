import * as Hapi from "hapi";
import { IPluginOptions } from "../plugins/interfaces";
import { IRequest, ILoginRequest } from "../interfaces/request";
import { ILdapConfigurations } from "../configurations";
var ActiveDirectory = require('activedirectory');
const fs = require('fs');
const path = require("path");
export default class LDAPAuthService {
    private ldapConfig: any;
    private ad: any;

    constructor(private configs: ILdapConfigurations) {
        this.ldapConfig = {
            url: this.configs.url,
            baseDN: this.configs.baseDN,
            tlsOptions: {
                rejectUnauthorized: true,
                ca: [fs.readFileSync(path.resolve(__dirname, '../utils/bin/rootCA.pem')),
                fs.readFileSync(path.resolve(__dirname, '../utils/bin/certificate-08.pem'))]
            },
            logging: {
                name: 'ActiveDirectory',
                streams: [
                    {
                        level: 'debug',
                        stream: process.stdout
                    }
                ]
            }
        };
        this.ad = new ActiveDirectory(this.ldapConfig);
    }

    public async authenticateMarshUserAgainstAD(username: string, password: string): Promise<any> {
        username = username + '@mgd.mrshmc.com';
        return new Promise<any>((resolve, reject) => {
            this.ad.authenticate(username, password, function (err, auth) {
                if (err) {
                    console.log('ERROR: ' + JSON.stringify(err));
                    resolve({ opCode: 401, data: null, error: err });
                }
                if (auth) {
                    console.log('Authenticated!');
                    resolve({ opCode: 200, data: auth });
                }
            });
        });
    }

    public async findUser(sAMAccountName: string): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            this.ad.findUser(sAMAccountName, function (err, user) {
                if (err) {
                    console.log('ERROR: ' + JSON.stringify(err));
                    return;
                }

                if (!user) {
                    console.log('User: ' + sAMAccountName + ' not found.');
                } else {
                    console.log(JSON.stringify(user));
                }
            });
        });
    }
}
