import * as nconf from "nconf";
import * as path from "path";

//Read Configurations
const configs = new nconf.Provider({
  env: true,
  argv: true,
  store: {
    type: "file",
    file: path.join(__dirname, `./config.${process.env.NODE_ENV || "dev"}.json`)
  }
});

const appConfig = new nconf.Provider({
  env: true,
  argv: true,
  store: {
    type: "file",
    file: path.join(__dirname, `./application-config.json`)
  }
});

export interface IServerConfigurations {
  port: number;
  plugins: Array<string>;
  jwtSecret: string;
  jwtExpiration: string;
  routePrefix: string;
  systemEmail: string;
  host: string;
  mfaUrl: string;
}

export interface IDataConfiguration {
  connectionString: string;
  replicaset: string;
  user: string;
  password: string;
}

export interface ISMTPServerConfigurations {
  host: string;
  port: number;
  secure: boolean;
  authUser: string;
  authPass: string;
  systemEmail: string;
}

export interface ILdapConfigurations {
  url: string;
  baseDN: string;
}

export interface IApplicationConfigurations {
  allowedChangePasswordAttempts: number;
  allowedResetPasswordAttempts: number;
  allowedLoginAttempts: number;
  allowedResetHours: number;
  minlength: number;
  maxLength: number;
  uppercaseMinCount: number;
  lowercaseMinCount: number;
  numberMinCount: number;
  specialMinCount: number;
  lastUsedPasswordCount: number;
}

export interface IMfaConfiguration {
  mfaUrl: string;
}

export function getDatabaseConfig(): IDataConfiguration {
  return configs.get("database");
}

export function getServerConfigs(): IServerConfigurations {
  return configs.get("server");
}

export function getSMTPServerConfigs(): ISMTPServerConfigurations {
  return configs.get("smtp");
}

export function getLdapServerConfigs(): ILdapConfigurations {
  return configs.get("ldap");
}

export function getApplicationConfigs(): IApplicationConfigurations {
  return appConfig.get("application");
}

export function getMfaConfigs(): IMfaConfiguration {
  return appConfig.get("mfa");
}