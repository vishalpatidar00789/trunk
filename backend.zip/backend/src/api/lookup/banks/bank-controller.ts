import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IBank } from "./bank";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest, IBankPayload } from "../../../interfaces/request";

export default class BankController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }

  public async getAllBanks(request: IRequest, h: Hapi.ResponseToolkit) {
    let banks: IBank[] = await this.database.bankModel.find({ activated: true }).lean(true);
    if (banks) {
      return banks;
    } else {
      return Boom.notFound();
    }
  }

  public async getBackByCode(request: IRequest, h: Hapi.ResponseToolkit) {
    const bankId = request.params['bankId'];
    let banks: IBank = await this.database.bankModel.findOne({ activated: true, bankCode: bankId });
    if (banks) {
      return banks;
    } else {
      return Boom.notFound();
    }
  }

  public async createBank(request: IBankPayload, h: Hapi.ResponseToolkit) {
    try {
      console.log(request.payload);
      request.payload.createdDate = new Date();
      let bank: IBank = await this.database.bankModel.create(request.payload);
      // return h.response({ token: this.generateToken(user) }).code(201);
      if (bank) {
        delete bank["__v"];
        return bank;
      } else {
        return Boom.notFound();
      }
    } catch (error) {
      console.log(error);
      return Boom.badImplementation(error);
    }
  }

  public async updateBank(request: IBankPayload, h: Hapi.ResponseToolkit) {
    // const id = request.auth.credentials.id;
    const bankCode  = request.payload.bankCode;
    request.payload.lastModifiedDate = new Date();
    console.log(request.payload);
    try {
      let bank: IBank = await this.database.bankModel.findOneAndUpdate(
        { bankCode: bankCode},
        { $set: request.payload },
        { new: true }
      );
      if (bank) {
        delete bank["__v"];
        return bank;
      } else {
        return Boom.notFound();
      }
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteBank(request: IRequest, h: Hapi.ResponseToolkit) {
    // const id = request.auth.credentials.id;
    const bankCode = request.params.bankCode;
    let bank: IBank = await this.database.bankModel.findOneAndRemove({bankCode: bankCode});
    return bank;
  }
}