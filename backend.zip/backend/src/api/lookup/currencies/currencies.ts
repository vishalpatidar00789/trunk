import * as Mongoose from "mongoose";

export interface ICurrencies extends Mongoose.Document {
  name: string;
  createdBy: string;
  createdDate: Date;
  lastModifiedBy: string;
  lastModifiedDate: Date;
}

export const CurrenciesSchema = new Mongoose.Schema(
  {
    name: { type: String, unique: true, required: true },
    createdBy: { type: String, required: true },
    createdDate: { type: Date, required: true },
    lastModifiedBy: { type: String, required: false },
    lastModifiedDate: { type: Date, required: false }
  }
);

export const CurrenciesModel = Mongoose.model<ICurrencies>("Currencies", CurrenciesSchema);
