import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { ICurrencies } from "./currencies";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest } from "../../../interfaces/request";
export default class CurrenciesController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }

  public async getAllCurrencies(request: IRequest, h: Hapi.ResponseToolkit) {
    let currencies: ICurrencies[] = await this.database.currenciesModel.find().lean(true);
    if (currencies) {
      return currencies;
    } else {
      return Boom.notFound();
    }
  }
}