import * as Hapi from "hapi";
import * as Joi from "joi";
import TransactionsController from "./transactions-controller";
import { TransactionsModel } from "./transactions";
import * as TransactionsValidator from "./transactions-validator";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";

export default function(
    server: Hapi.Server,
    serverConfigs: IServerConfigurations,
    database: IDatabase
  ) {
    const transactionsController = new TransactionsController(serverConfigs, database);
    server.bind(transactionsController);
    // routes starts from here
    server.route({
    method: "GET",
    path: "/lookup/sequenceNo",
    options: {
        handler: transactionsController.getSequenceNo,
        auth: false,
        tags: ["api", "departments"],
        description: "Get transactions sequesnce no",
        plugins: {
            "hapi-swagger": {
                responses: {
                    "201": {
                        description: "transactions sequesnce no is fetched"
                    }
                }
            }
        }
    }
    });
}