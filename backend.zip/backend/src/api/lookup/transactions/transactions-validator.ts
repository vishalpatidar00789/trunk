import * as Joi from "joi";

export const createTransactionsModel = Joi.object().keys({
    name: Joi.string().required()
    // createdBy: Joi.string().required(),
    // createdDate: Joi.any().allow(null).optional(),
    // lastModifiedBy: Joi.any().allow(null).optional(),
    // lastModifiedDate: Joi.any().allow(null).optional()
});

export const jwtValidator = Joi.object({ 'authorization': Joi.string().required() }).unknown();