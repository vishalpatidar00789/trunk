import * as Mongoose from "mongoose";

export interface ITransactions extends Mongoose.Document {
  seqNo: number;
  transNo: number;
}

export const TransactionsSchema = new Mongoose.Schema(
  {
    seqNo: { type: Number, unique: true, required: true },
    transNo: { type: Number, unique: false, required: false }
  }
);

export const TransactionsModel = Mongoose.model<ITransactions>("configurations", TransactionsSchema);
