import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { ITransactions } from "./transactions";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest } from "../../../interfaces/request";
export default class TransactionsController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }

  public async getSequenceNo() {
    let transactions: ITransactions[] = await this.database.transactionsModel.find().lean(true);
    if (transactions) {
      let seqnum: number;
      seqnum = transactions[0].seqNo;
      return (seqnum + 1);
    } else {
      return Boom.notFound();
    }
  }

  public async updateSequenceNo(seqNo) {
    try {
      let transactions: ITransactions = await this.database.transactionsModel.update(
        { "seqNo": seqNo - 1 },
        {
          $set: { "seqNo": seqNo }
        });
      return true;
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }
}