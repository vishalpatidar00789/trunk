import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { ISponsor } from "./sponsor";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest, ILoginRequest, } from "../../../interfaces/request";

export default class SponsorController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }


  public async createSponsor(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let sponsor: any = await this.database.sponsorModel.create(request.payload);
      return h.response(sponsor).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateSponsor(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params["id"];
    try {
      let sponsor: ISponsor = await this.database.sponsorModel.findByIdAndUpdate(
        { "_id": id },
        { $set: request.payload },
        { new: true }
      );
      return h.response(sponsor).code(202);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteSponsor(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    let sponsor: ISponsor = await this.database.sponsorModel.findByIdAndRemove(id);

    return sponsor;
  }

  public async infoSponsor(request: IRequest, h: Hapi.ResponseToolkit) {

    const id = request.params.id;
    let sponsor: ISponsor = await this.database.sponsorModel.findById(id);
    if (sponsor) {
      return sponsor;
    } else {
      return Boom.notFound();
    }
  }

  public async getAllSponsors(request: IRequest, h: Hapi.ResponseToolkit) {
    let sponsor: ISponsor[] = await this.database.sponsorModel.find().lean(true);
    if (sponsor) {
      return sponsor;
    } else {
      return Boom.notFound();
    }
  }
}
