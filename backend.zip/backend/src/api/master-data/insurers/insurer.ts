import * as Mongoose from "mongoose";

export interface IInsurer extends Mongoose.Document {
  insurerName: string;
  registrationNUmber: string;
  isLead: boolean;
  isCoInsurer: boolean;
  coInsurerProportion: number;
  consortiumId: string;
  activated: boolean;
  createdBy: string;
  createdDate: string;
  lastModifiedBy: string;
  lastModifiedDate: string;
}

export const InsurerSchema = new Mongoose.Schema(
  {
    insurerName: { type: String },
    activated: { type: Boolean },
    registrationNUmber: { type: String },
    isLead: { type: Boolean },
    isCoInsurer: { type: Boolean },
    coInsurerProportion: { type: Number },
    consortiumId: { type: String },
    createdBy: { type: String },
    createdDate: { type: String },
    lastModifiedBy: { type: String },
    lastModifiedDate: { type: String }
  }
);
export const InsurerModel = Mongoose.model<IInsurer>("Insurer", InsurerSchema);
