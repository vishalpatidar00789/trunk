import * as Mongoose from "mongoose";

export interface ICapacity extends Mongoose.Document {

  appId: string;
  consortiumId: string;
  capacity: number;
  activated: boolean;
  createdBy: string;
  createdDate: string;
  lastModifiedBy: string;
  lastModifiedDate: string;
}

export const CapacitySchema = new Mongoose.Schema(
  {
    appId: { type: String },
    consortiumId: { type: String },
    capacity: { type: Number },
    activated: { type: Boolean },
    createdBy: { type: String },
    createdDate: { type: String },
    lastModifiedBy: { type: String },
    lastModifiedDate: { type: String }
  }
);
export const CapacityModel = Mongoose.model<ICapacity>("Capacity", CapacitySchema);
