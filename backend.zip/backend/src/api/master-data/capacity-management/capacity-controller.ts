import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { ICapacity } from "./capacity";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest, ILoginRequest, } from "../../../interfaces/request";

export default class CapacityController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }


  public async createCapacity(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let capacity: any = await this.database.capacityModel.create(request.payload);
      return h.response(capacity).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateCapacity(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    try {
      let capacity: ICapacity = await this.database.capacityModel.findOneAndUpdate(
        { "_id": id },
        { $set: request.payload },
        { new: true }
      );
      return h.response(capacity).code(202);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteCapacity(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    let capacity: ICapacity = await this.database.capacityModel.findByIdAndRemove(id);

    return capacity;
  }

  public async infoCapacity(request: IRequest, h: Hapi.ResponseToolkit) {

    const id = request.params.id;
    let capacity: ICapacity = await this.database.capacityModel.findById(id);
    if (capacity) {
      return capacity;
    } else {
      return Boom.notFound();
    }
  }

  public async getAllCapacities(request: IRequest, h: Hapi.ResponseToolkit) {
    let capacity: ICapacity[] = await this.database.capacityModel.find().lean(true);
    if (capacity) {
      return capacity;
    } else {
      return Boom.notFound();
    }
  }
}
