import * as Joi from "joi";

export const createCapacityModel = Joi.object().keys({
    appId: Joi.string(),
    consortiumId: Joi.string(),
    capacity: Joi.number(),
    activated: Joi.boolean(),
    createdBy: Joi.string(),
    createdDate: Joi.string(),
    lastModifiedBy: Joi.string(),
    lastModifiedDate: Joi.string()
});

export const jwtValidator = Joi.object({ 'authorization': Joi.string().required() }).unknown();