import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IPremiumRates } from "./premium-rates";
import { IDatabase } from "../../../../database";
import { IServerConfigurations } from "../../../../configurations";
import { IRequest, ILoginRequest, } from "../../../../interfaces/request";

export default class PremiumRatesController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }


  public async createPremiumRates(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let premiumRates: any = await this.database.premiumRatesModel.create(request.payload);
      return h.response(premiumRates).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updatePremiumRates(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    try {
      let premiumRates: IPremiumRates = await this.database.premiumRatesModel.findOneAndUpdate(
        { "_id": id },
        { $set: request.payload },
        { new: true }
      );
      return h.response(premiumRates).code(202);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deletePremiumRates(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    let premiumRates: IPremiumRates = await this.database.premiumRatesModel.findByIdAndRemove(id);

    return premiumRates;
  }

  public async infoPremiumRates(request: IRequest, h: Hapi.ResponseToolkit) {

    const id = request.params.id;
    let premiumRates: IPremiumRates = await this.database.premiumRatesModel.findById(id);
    if (premiumRates) {
      return premiumRates;
    } else {
      return Boom.notFound();
    }
  }

  public async getAllPremiumRates(request: IRequest, h: Hapi.ResponseToolkit) {
    let premiumRates: IPremiumRates[] = await this.database.premiumRatesModel.find().lean(true);
    if (premiumRates) {
      return premiumRates;
    } else {
      return Boom.notFound();
    }
  }
}
