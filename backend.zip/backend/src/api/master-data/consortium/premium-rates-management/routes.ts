import * as Hapi from "hapi";
import * as Joi from "joi";
import PremiumRatesController from "./premium-rates-controller";
import * as PremiumRatesValidator from "./premium-rates-validator";
import { IDatabase } from "../../../../database";
import { IServerConfigurations } from "../../../../configurations";

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const premiumRatesController = new PremiumRatesController(serverConfigs, database);
  server.bind(premiumRatesController);

  server.route({
    method: "GET",
    path: "/master-data/consortium/premiumRates/{id}",
    options: {
      handler: premiumRatesController.infoPremiumRates,
      auth: false,
      tags: ["api", "premiumRates"],
      description: "Get PremiumRates info.",
      validate: {
        params: {
          id: Joi.string().required()
        }
        //headers: PremiumRatesValidator.createPremiumRatesModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Premium Rates found."
            },
            "404": {
              description: "Premium Rates does not exists."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/master-data/consortium/premiumRates/{id}",
    options: {
      handler: premiumRatesController.deletePremiumRates,
      auth: false,
      tags: ["api", "premiumRates"],
      description: "Delete current Premium Rates.",
      validate: {
        params: {
          id: Joi.string().required()
        },
       },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Premium Rates deleted."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/master-data/consortium/premiumRates/{id}",
    options: {
      handler: premiumRatesController.updatePremiumRates,
      auth: false,
      tags: ["api", "premiumRates"],
      description: "Update Premium Rates info.",
      validate: {
        params: {
          id: Joi.string().required()
        },
        payload: PremiumRatesValidator.createPremiumRatesModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated info."
            }

          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/master-data/consortium/premiumRates",
    options: {
      handler: premiumRatesController.createPremiumRates,
      auth: false,
      tags: ["api", "premiumRates"],
      description: "Create a Premium Rates.",
      validate: {
        payload: PremiumRatesValidator.createPremiumRatesModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "Premium Rates created."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/master-data/consortium/premiumRates",
    options: {
      handler: premiumRatesController.getAllPremiumRates,
      auth: false,
      tags: ["api", "premiumRates"],
      description: "Get list of Premium Rates",
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "Premium Rates list is fetched"
            }
          }
        }
      }
    }
  });
}
