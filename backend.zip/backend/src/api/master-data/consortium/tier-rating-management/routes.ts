import * as Hapi from "hapi";
import * as Joi from "joi";
import TierRatingController from "./tier-rating-controller";
import * as TierRatingValidator from "./tier-rating-validator";
import { IDatabase } from "../../../../database";
import { IServerConfigurations } from "../../../../configurations";

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const tierRatingController = new TierRatingController(serverConfigs, database);
  server.bind(tierRatingController);

  server.route({
    method: "GET",
    path: "/master-data/consortium/tier-rating/{id}",
    options: {
      handler: tierRatingController.infoTierRating,
      auth: false,
      tags: ["api", "tierRating"],
      description: "Get tierRating info.",
      validate: {
        params: {
          id: Joi.string().required()
        }
        //headers: TierRatingValidator.createTierRatingModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "TierRating found."
            },
            "404": {
              description: "TierRating does not exists."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/master-data/consortium/tier-rating/{id}",
    options: {
      handler: tierRatingController.deleteTierRating,
      auth: false,
      tags: ["api", "tierRating"],
      description: "Delete current tierRating.",
      validate: {
        params: {
          id: Joi.string().required()
        },
       },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "TierRating deleted."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/master-data/consortium/tier-rating/{id}",
    options: {
      handler: tierRatingController.updateTierRating,
      auth: false,
      tags: ["api", "TierRating"],
      description: "Update TierRating info.",
      validate: {
        params: {
          id: Joi.string().required()
        },
        payload: TierRatingValidator.createTierRatingModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated info."
            }

          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/master-data/consortium/tier-rating",
    options: {
      handler: tierRatingController.createTierRating,
      auth: false,
      tags: ["api", "tierRating"],
      description: "Create a tierRating.",
      validate: {
        payload: TierRatingValidator.createTierRatingModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "TierRating created."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/master-data/consortium/tier-rating",
    options: {
      handler: tierRatingController.getAllTierRatings,
      auth: false,
      tags: ["api", "tierRating"],
      description: "Get list of tierRatings",
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "TierRating list is fetched"
            }
          }
        }
      }
    }
  });
}
