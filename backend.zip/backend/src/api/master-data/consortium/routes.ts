import * as Hapi from "hapi";
import * as Joi from "joi";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import ConsortiumController from "./consortium-controller";
import * as ConsortiumValidator from "./consortium-validator";

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const consortiumController = new ConsortiumController(serverConfigs, database);
  server.bind(consortiumController);

  server.route({
    method: "GET",
    path: "/master-data/consortium/{id}",
    options: {
      handler: consortiumController.infoConsortium,
      auth: false,
      tags: ["api", "consortium"],
      description: "Get consortium info.",
      validate: {
        params: {
          id: Joi.string().required()
        }
        //headers: ConsortiumValidator.consortiumModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Consortium found."
            },
            "404": {
              description: "Consortium does not exists."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/master-data/consortium/{id}",
    options: {
      handler: consortiumController.deleteConsortium,
      auth: "jwt",
      tags: ["api", "consortiumes"],
      description: "Delete current consortium.",
      validate: {
        params: {
          id: Joi.string().required()
        },
        headers: ConsortiumValidator.consortiumModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Consortium deleted."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/master-data/consortium/{id}",
    options: {
      handler: consortiumController.updateConsortium,
      auth: false,
      tags: ["api", "consortium"],
      description: "Update consortium info.",
      validate: {
        params: {
          id: Joi.string().required()
        },
        payload: ConsortiumValidator.consortiumModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated info."
            }

          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/master-data/consortium",
    options: {
      handler: consortiumController.createConsortium,
      auth: false,
      tags: ["api", "consortium"],
      description: "Create a consortium.",
      validate: {
        payload: ConsortiumValidator.consortiumModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "consortium created."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/master-data/consortium",
    options: {
      handler: consortiumController.getAllConsortiumes,
      auth: false,
      tags: ["api", "consortium"],
      description: "Get list of consortiums",
      validate: {
       // headers: ConsortiumValidator.consortiumModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "consortium list is fetched"
            }
          }
        }
      }
    }
  });
}
