import * as Hapi from "hapi";
import * as Joi from "joi";
import BrokerageController from "./brokerage-controller";
import * as BrokerageValidator from "./brokerage-validator";
import { IDatabase } from "../../../../database";
import { IServerConfigurations } from "../../../../configurations";

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const brokerageController = new BrokerageController(serverConfigs, database);
  server.bind(brokerageController);

  server.route({
    method: "GET",
    path: "/master-data/consortium/brokerage/{id}",
    options: {
      handler: brokerageController.infoBrokerage,
      auth: false,
      tags: ["api", "brokerage"],
      description: "Get brokerage info.",
      validate: {
        params: {
          id: Joi.string().required()
        }
       // headers: BrokerageValidator.createBrokerageModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Brokerage found."
            },
            "404": {
              description: "Brokerage does not exists."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/master-data/consortium/brokerage/{id}",
    options: {
      handler: brokerageController.deleteBrokerage,
      auth: false,
      tags: ["api", "brokerage"],
      description: "Delete current brokerage.",
      validate: {
        params: {
          id: Joi.string().required()
        },
       },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Brokerage deleted."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/master-data/consortium/brokerage/{id}",
    options: {
      handler: brokerageController.updateBrokerage,
      auth: false,
      tags: ["api", "brokerage"],
      description: "Update brokerage info.",
      validate: {
        params: {
          id: Joi.string().required()
        },
        payload: BrokerageValidator.createBrokerageModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated info."
            }

          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/master-data/consortium/brokerage",
    options: {
      handler: brokerageController.createBrokerage,
      auth: false,
      tags: ["api", "brokerage"],
      description: "Create a brokerage.",
      validate: {
        payload: BrokerageValidator.createBrokerageModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "Brokerage created."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/master-data/consortium/brokerage",
    options: {
      handler: brokerageController.getAllBrokerages,
      auth: false,
      tags: ["api", "brokerage"],
      description: "Get list of brokerage",
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "Brokerage list is fetched"
            }
          }
        }
      }
    }
  });
}
