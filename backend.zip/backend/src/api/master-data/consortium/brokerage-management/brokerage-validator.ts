import * as Joi from "joi";

export const createBrokerageModel = Joi.object().keys({
    trancheId: Joi.string(),
    consortiumId: Joi.string(),
    brokeragePercentage: Joi.number(),
    startDate: Joi.string(),
    endDate: Joi.string(),
    activated: Joi.boolean(),
    createdBy: Joi.string(),
    createdDate: Joi.string(),
    lastModifiedBy: Joi.string(),
    lastModifiedDate: Joi.string()
});

export const jwtValidator = Joi.object({ 'authorization': Joi.string().required() }).unknown();