import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { ILimit } from "./limit";
import { IDatabase } from "../../../../database";
import { IServerConfigurations } from "../../../../configurations";
import { IRequest, ILoginRequest, } from "../../../../interfaces/request";

export default class LimitController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }


  public async createLimit(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let limit: any = await this.database.limitModel.create(request.payload);
      return h.response(limit).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateLimit(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    try {
      let limit: ILimit = await this.database.limitModel.findOneAndUpdate(
        { "_id": id },
        { $set: request.payload },
        { new: true }
      );
      return h.response(limit).code(202);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteLimit(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    let limit: ILimit = await this.database.limitModel.findByIdAndRemove(id);

    return limit;
  }

  public async infoLimit(request: IRequest, h: Hapi.ResponseToolkit) {

    const id = request.params.id;
    let limit: ILimit = await this.database.limitModel.findById(id);
    if (limit) {
      return limit;
    } else {
      return Boom.notFound();
    }
  }

  public async getAllLimits(request: IRequest, h: Hapi.ResponseToolkit) {
    let limit: ILimit[] = await this.database.limitModel.find().lean(true);
    if (limit) {
      return limit;
    } else {
      return Boom.notFound();
    }
  }
}
