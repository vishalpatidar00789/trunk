import * as Mongoose from "mongoose";

export interface IPolicy extends Mongoose.Document {

  trancheId: string;
  consortiumId: string;
  pfiCode: string;
  lisPlusLayer: string;
  primaryLayer: number;
  autoTopUpLayer: string;
  bgLayer: string;
  activated: boolean;
  createdBy: string;
  createdDate: string;
  lastModifiedBy: string;
  lastModifiedDate: string;
}

export const PolicySchema = new Mongoose.Schema(
  {
    trancheId: { type: String },
    consortiumId: { type: String },
    pfiCode: { type: String },
    lisPlusLayer: { type: String },
    primaryLayer: { type: Number },
    autoTopUpLayer: { type: String },
    bgLayer: { type: String },
    activated: { type: Boolean },
    createdBy: { type: String },
    createdDate: { type: String },
    lastModifiedBy: { type: String },
    lastModifiedDate: { type: String }
  }
);
export const PolicyModel = Mongoose.model<IPolicy>("Policy", PolicySchema);
