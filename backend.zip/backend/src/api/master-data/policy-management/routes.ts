import * as Hapi from "hapi";
import * as Joi from "joi";
import PolicyController from "./policy-controller";
import * as PolicyValidator from "./policy-validator";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const policyController = new PolicyController(serverConfigs, database);
  server.bind(policyController);

  server.route({
    method: "GET",
    path: "/master-data/policy/{id}",
    options: {
      handler: policyController.infoPolicy,
      auth: false,
      tags: ["api", "policy"],
      description: "Get policy info.",
      validate: {
        params: {
          id: Joi.string().required()
        }

      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Policy found."
            },
            "404": {
              description: "Policy does not exists."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/master-data/policy/{id}",
    options: {
      handler: policyController.deletePolicy,
      auth: false,
      tags: ["api", "policy"],
      description: "Delete current policy.",
      validate: {
        params: {
          id: Joi.string().required()
        },
       },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Policy deleted."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/master-data/policy/{id}",
    options: {
      handler: policyController.updatePolicy,
      auth: false,
      tags: ["api", "policy"],
      description: "Update policy info.",
      validate: {
        payload: PolicyValidator.createPolicyModel,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated info."
            }

          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/master-data/policy",
    options: {
      handler: policyController.createPolicy,
      auth: false,
      tags: ["api", "policy"],
      description: "Create a policy.",
      validate: {
        payload: PolicyValidator.createPolicyModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "Policy created."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/master-data/policy",
    options: {
      handler: policyController.getAllPolicies,
      auth: false,
      tags: ["api", "policy"],
      description: "Get list of policies",
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "policy list is fetched"
            }
          }
        }
      }
    }
  });
}
