import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IApp } from "./app-management";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest } from "../../../interfaces/request";

export default class AppController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }


  public async createApp(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let app: any = await this.database.appModel.create(request.payload);
      return h.response(app).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateApp(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    try {
      let app: IApp = await this.database.appModel.findOneAndUpdate(
        { "_id": id },
        { $set: request.payload },
        { new: true }
      );
      return h.response(app).code(202);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteApp(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    try {
      let app: IApp = await this.database.appModel.findByIdAndRemove(id);
      return app;
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async infoApp(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    try {
      let app: IApp = await this.database.appModel.findById(id);
      if (app) {
        return app;
      } else {
        return Boom.notFound();
      }
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async getAllApps(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let app: IApp[] = await this.database.appModel.find().lean(true);
      if (app) {
        return app;
      } else {
        return Boom.notFound();
      }
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }
}
