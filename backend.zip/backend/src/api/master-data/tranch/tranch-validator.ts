import * as Joi from "joi";

export const createTranchModel = Joi.object().keys({
    trancheName: Joi.string(),
    fromDate: Joi.string(),
    toDate: Joi.string(),
    activated: Joi.boolean(),
    createdBy: Joi.string(),
    createdDate: Joi.string(),
    lastModifiedBy: Joi.string(),
    lastModifiedDate: Joi.string()
});

export const jwtValidator = Joi.object({'authorization': Joi.string().required()}).unknown();