import * as Hapi from "hapi";
import * as Joi from "joi";
import TranchController from "./tranch-controller";
import { TranchModel } from "./tranch";
import * as TranchValidator from "./tranch-validator";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const tranchController = new TranchController(serverConfigs, database);
  server.bind(tranchController);

  server.route({
    method: "GET",
    path: "/master-data/tranch/{id}",
    options: {
      handler: tranchController.infoTranch,
      auth: false,
      tags: ["api", "tranch"],
      description: "Get tranch info.",
      validate: {
        params: {
          id: Joi.string().required()
        }
        //headers: TranchValidator.createTranchModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Tranch found."
            },
            "404": {
              description: "Tranch does not exists."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "DELETE",
    path: "/master-data/tranch/{id}",
    options: {
      handler: tranchController.deleteTranch,
      auth: false,
      tags: ["api", "tranches"],
      description: "Delete current tranch.",
      validate: {
        params: {
          id: Joi.string().required()
        }
        //headers: TranchValidator.createTranchModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Tranch deleted."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/master-data/tranch/{id}",
    options: {
      handler: tranchController.updateTranch,
      auth:false,
      tags: ["api", "tranch"],
      description: "Update tranch info.",
      validate: {
        params: {
          id: Joi.string().required()
        },
        payload: TranchValidator.createTranchModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated info."
            }

          }
        }
      }
    }
  });

  server.route({
    method: "POST",
    path: "/master-data/tranch",
    options: {
      handler: tranchController.createTranch,
      auth: false,
      tags: ["api", "tranch"],
      description: "Create a tranch.",
      validate: {
        payload: TranchValidator.createTranchModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "Tranche created."
            }
          }
        }
      }
    }
  });

  server.route({
    method: "GET",
    path: "/master-data/tranch",
    options: {
      handler: tranchController.getAllTranches,
      auth: false,
      tags: ["api", "tranch"],
      description: "Get list of tranches",
      validate: {
        //headers: TranchValidator.createTranchModel
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "tranche list is fetched"
            }
          }
        }
      }
    }
  });
}
