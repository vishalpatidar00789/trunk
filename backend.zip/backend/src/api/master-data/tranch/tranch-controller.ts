import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { ITranch } from "./tranch";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest, ILoginRequest, IUserCreate, IUserUpdate } from "../../../interfaces/request";

export default class TranchController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }


  public async createTranch(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let tranch: any = await this.database.tranchModel.create(request.payload);
      return h.response(tranch).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateTranch(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    try {
      let tranch: ITranch = await this.database.tranchModel.findOneAndUpdate(
        { "_id": id },
        { $set: request.payload },
        { new: true }
      );
      return h.response(tranch).code(202);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteTranch(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    let tranch: ITranch = await this.database.tranchModel.findByIdAndRemove(id);

    return tranch;
  }

  public async infoTranch(request: IRequest, h: Hapi.ResponseToolkit) {
    console.log("Test");
    const id = request.params.id;
    let tranch: ITranch = await this.database.tranchModel.findById(id);
    if (tranch) {
      return tranch;
    } else {
      return Boom.notFound();
    }
  }

  public async getAllTranches(request: IRequest, h: Hapi.ResponseToolkit) {
    let tranch: ITranch[] = await this.database.tranchModel.find().lean(true);
    if (tranch) {
      return tranch;
    } else {
      return Boom.notFound();
    }
  }
}
