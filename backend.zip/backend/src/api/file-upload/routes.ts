import * as Hapi from "hapi";
import * as Joi from "joi";
import FileUploadController from "./file-upload-controller";

import { jwtValidator } from "../users/user-validator";
import { IDatabase } from "../../database";
import { IServerConfigurations } from "../../configurations";

export default function (
  server: Hapi.Server,
  configs: IServerConfigurations,
  database: IDatabase
) {
  const fileUploadController = new FileUploadController(configs, database);
  server.bind(fileUploadController);

  server.route({
    method: "POST",
    path: "/upload",
    options: {
      handler: fileUploadController.upload,
      auth: false,
      tags: ["api", "fileupload"],
      description: "Uploaded file document.",
      payload: {
        output: "stream",
        parse: true,
        allow: "multipart/form-data",
        maxBytes: 20 * 1000 * 1000
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "201": {
              description: "Uploaded file document."
            }
          }
        }
      }
    }
  });
}
