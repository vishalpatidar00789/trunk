import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IDatabase } from "../../database";
import { IServerConfigurations } from "../../configurations";
import { IRequest } from "../../interfaces/request";
import * as Path from "path";
//import * as fs from "fs";
//import * as MongoClient from "mongoclient";
import * as Gridfs from "gridfs-stream";
import * as Configs from "../../configurations";

const dateTime = require('node-datetime');
var mongoose = require('mongoose');
var Gridfs = require('gridfs-stream');
const dbConfigs = Configs.getDatabaseConfig();

let conn = mongoose.connection;
Gridfs.mongo = mongoose.mongo;
let gfs;
conn.once("open", () => {
  gfs = Gridfs(conn.db);
});
var dbURI = process.env.DB_LINK || dbConfigs.connectionString;
mongoose.connect(dbURI)
  .then(() => {
    console.log(`[*] Connected to Database`);
  })
  .catch(err => {
    console.log(`[*] Error while connecting to DB, with error: ${err}`);
  });

export default class FileUploadController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  constructor(configs: IServerConfigurations, database: IDatabase) {
  }
  public async upload(request, h: Hapi.ResponseToolkit) {
    var file = [request.payload["uploads"]];
    var formatted = dateTime.create().format('Y-m-d H:M:S');
    var fileName = 'file_' + file[0].hapi.filename + '_' + formatted;
    var contentType = file[0].hapi.headers.content_type;
    var fileData = file[0]._data;

    let writeStream = gfs.createWriteStream({
      filename: fileName,
      mode: 'w',
      content_type: contentType
    });
    let result = writeStream.write(fileData);
    writeStream.end();
    return { 'message': "success" };
  }
}