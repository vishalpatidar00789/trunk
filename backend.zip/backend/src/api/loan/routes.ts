import * as Hapi from 'hapi';
import * as Joi from 'joi';
import LoanController from './loan-controller';
import { LoanModel } from './loan';
import * as LoanValidator from './loan-validator';
import { IDatabase } from '../../database';
import { IServerConfigurations } from '../../configurations';

export default function (
  server: Hapi.Server,
  serverConfigs: IServerConfigurations,
  database: IDatabase
) {
  const loanController = new LoanController(serverConfigs, database);
  server.bind(loanController);

  server.route({
    method: 'GET',
    path: '/loanform/info',
    options: {
      handler: loanController.infoLoan,
      //auth: "jwt",
      tags: ['api', 'loan'],
      description: 'Get Loan info.',
      validate: {
        headers: LoanValidator.jwtValidator
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Loan founded.'
            },
            '401': {
              description: 'Please login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'DELETE',
    path: '/loanform',
    options: {
      handler: loanController.deleteLoan,
      //auth: "jwt",
      tags: ['api', 'loan'],
      description: 'Delete current Loan.',
      validate: {
        headers: LoanValidator.jwtValidator
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Loan deleted.'
            },
            '401': {
              description: 'User does not have authorization.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/loanform/submit/{id}",
    options: {
      handler: loanController.updateLoan,
      auth: false,
      tags: ["api", "loan"],
      description: "Update current loan info.",
      validate: {
        payload: LoanValidator.createLoanModel,
        //headers: LoanValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated Loan info."
            },
            "401": {
              description: "User does not have authorization."
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/loanform',
    options: {
      handler: loanController.createLoan,
      auth: false,
      tags: ['api', 'loan'],
      description: 'Create a Loan.',
      validate: {
        payload: LoanValidator.createLoanModel
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '201': {
              description: 'Loan created.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/loanform/search',
    options: {
      handler: loanController.searchLoan,
      //auth: "jwt",
      auth: false,
      tags: ['api', 'loan'],
      description: 'Search for loan applications.',
      validate: {
        payload: LoanValidator.searchLoanPayload
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'List of all matching Loan applications.'
            },
            '401': {
              description: 'Please Login.'
            }
          }
        }
      }
    }
  });

  server.route({
    method: "PUT",
    path: "/loanform/adverseInfo/{marshRefNo}",
    options: {
      handler: loanController.updateLoanAdverseInfo,
      auth: false,
      tags: ["api", "loan"],
      description: "Update loan adverse info.",
      validate: {
        payload: LoanValidator.createAdverseInfo,
        //headers: LoanValidator.jwtValidator,
        params: {
          marshRefNo: Joi.string().required()
        }
      },
      plugins: {
        "hapi-swagger": {
          responses: {
            "200": {
              description: "Updated Loan adverse info."
            },
            "401": {
              description: "User does not have authorization."
            }
          }
        }
      }
    }
  });

  server.route({
    method: 'PUT',
    path: '/loanform/saveAsDraft/{id}',
    options: {
      handler: loanController.saveAsDraft,
      auth: false,
      tags: ['api', 'loan'],
      description: 'Update current loan info.',
      validate: {
        payload: LoanValidator.createLoanModel,
        //headers: LoanValidator.jwtValidator,
        params: {
          id: Joi.string().required()
        }
      },
      plugins: {
        'hapi-swagger': {
          responses: {
            '200': {
              description: 'Updated Loan info.'
            },
            '401': {
              description: 'User does not have authorization.'
            }
          }
        }
      }
    }
  });
}
