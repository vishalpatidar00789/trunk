import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IPFI } from "./pfi";
import { ILoan } from "../loan";

import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { Ipfi, IRequest, ILoginRequest } from "../../../interfaces/request";

export default class PFIController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }

  public async createPFI(request: IRequest, h: Hapi.ResponseToolkit) {
    try {
      let loan: any = await this.database.loanModel.create(request.payload);
      return h.response({ "_id": loan._id }).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updatePFI(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params.id;
    try {
      let loan: ILoan = await this.database.loanModel.findOneAndUpdate(
        { "_id": id },
        { $set: request.payload },
        { new: true }
      );
      return h.response(loan).code(202);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deletePFI(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.auth.credentials.id;
    let pfi: IPFI = await this.database.pfiModel.findByIdAndRemove(id);

    return pfi;
  }

  public async infoPFI(request: IRequest, h: Hapi.ResponseToolkit) {
    console.log("Test");
    const id = request.auth.credentials.id;
    let pfi: IPFI = await this.database.pfiModel.findById(id);

    return pfi;
  }
}
