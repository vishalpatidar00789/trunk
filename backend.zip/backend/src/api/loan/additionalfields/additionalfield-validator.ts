import * as Joi from "joi";

export const createAdditionalFieldModel = Joi.object().keys({
    aFields: {
        _id: Joi.string(),
        pfi: Joi.string(),
        marshReferenceNumber: Joi.string(),
        borrowerName: Joi.string(),
        applicationStatus: Joi.string(),
        acraRefNo: Joi.string(),
        typeoflimit: Joi.string(),
        applicationDate: Joi.string(),
        purposeofLoan: Joi.string(),
        domesticPercent: Joi.number(),
        exportPercent: Joi.number(),
        loanType: Joi.string(),
        totalAppliedLimit: Joi.string(),
        foreignCurrencyRequestedLimits: Joi.string(),
        foreignCurrencyType: Joi.string(),
        foreignCurrencyExchangeRate: Joi.string(),
        adverseInformation: Joi.string(),
        additionalInformationforAdverseStatus: Joi.string(),
        loanApplicationNumber: Joi.string(),
        reportedMonth: Joi.string(),
        grossSgdPremiumPrimary: Joi.number(),
        grossSgdPremiumAuto: Joi.number(),
        grossSgdPremiumBg: Joi.number(),
        grossSgdPremiumLisPlus: Joi.number(),
        natureofApplication: Joi.string(),
        noOfApp: Joi.string(),
        loAcceptanceDate: Joi.string(),
        insurersApprovalDate: Joi.string(),
        loanExpiryDateFromLoAcceptanceDate: Joi.string(),
        approvedSgdLimitPrimaryLayer: Joi.number(),
        approvedSgdLimitAutoTopup: Joi.number(),
        approvedSgdLimitBgLayer: Joi.number(),
        approvedForeignCurrencyLimitPrimaryLayer: Joi.number(),
        approvedForeignCurrencyPrimaryLayerType: Joi.string(),
        approvedForeignCurrencyPrimaryLayerExchangeRate: Joi.number(),
        approvedForeignCurrencyLimitAutoTopup: Joi.number(),
        approvedForeignCurrencyAutoTopupType: Joi.string(),
        approvedForeignCurrencyAutoTopupExchangeRate: Joi.number(),
        approvedForeignCurrencyLimitBgLayer: Joi.number(),
        approvedForeignCurrencyBgLayerType: Joi.string(),
        approvedForeignCurrencyBgLayerExchangeRate: Joi.number(),
        dateSentForLisPlus: Joi.string(),
        lisPlusApprovedDate: Joi.string(),
        lisPlusApprovedLimit: Joi.number(),
        approvedForeignCurrencyLimitLISPlusLayer: Joi.number(),
        approvedForeignCurrencyLISPlusType: Joi.string(),
        approvedForeignCurrencyLISPlusExchangeRate: Joi.number(),
        typeOfLimitLisplus: Joi.string(),
        lisTotalApprovedLimit: Joi.number(),
        lisApprovalRatioPrecent: Joi.number(),
        lisTurnAroundDays: Joi.number(),
        totalApprovedLimitIncludingLisPlus: Joi.number(),
        approvalRatioWithLisPlus: Joi.number(),
        turnAroundWithLisPlus: Joi.number(),
        utilization: Joi.string(),
        internalRemarks: Joi.string(),
    },


});

export const updateAdditionalFieldModel = Joi.object().keys({
    email: Joi.string().email().trim(),
    name: Joi.string(),
    password: Joi.string().trim()
});

export const loginAdditionalFieldModel = Joi.object().keys({
    email: Joi.string().email().required(),
    password: Joi.string().trim().required()
});

export const jwtValidator = Joi.object({ 'authorization': Joi.string().required() }).unknown();