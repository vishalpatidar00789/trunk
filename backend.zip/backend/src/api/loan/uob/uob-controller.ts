import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IUOB } from "./uob";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { Iuob, IRequest } from "../../../interfaces/request";
import { ILoan } from "../loan";

export default class UOBController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }

  public async createUOB(request: Iuob, h: Hapi.ResponseToolkit) {
    try {
      let uob: any = await this.database.loanModel.create(request.payload);
      return h.response({ "_id": uob._id }).code(201);
    } catch (error) {
      return error; //Boom.badImplementation(error);
    }
  }

  public async updateUOB(request: IRequest, h: Hapi.ResponseToolkit) {
    const _id = request.params._id;
    try {
      let loan: ILoan = await this.database.loanModel.findByIdAndUpdate(
        _id,
        { $set: request.payload },
        { new: true }
      );
      return h.response(loan).code(202);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteUOB(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.auth.credentials.id;
    let uob: IUOB = await this.database.uobModel.findByIdAndRemove(id);

    return uob;
  }

  public async infoUOB(request: IRequest, h: Hapi.ResponseToolkit) {
    console.log("Test");
    const id = request.auth.credentials.id;
    let uob: IUOB = await this.database.uobModel.findById(id);

    return uob;
  }
}
