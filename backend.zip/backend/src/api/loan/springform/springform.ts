import * as Mongoose from "mongoose";
import * as Bcrypt from "bcryptjs";

export interface ISpringForm extends Mongoose.Document {

  createdAt?: Date;
  updateAt?: Date;
  data?: any;
  regComName?: string;
  contactPersonNo?: string;
  ACRANo?: string;
  corrAddress1?: string;
  corrAddress2?: string;
  corrAddress3?: string;
  contactPerson?: string;
  contactPersonEmail?: string;
  businessActivity?: string;
  numStaff?: string;
  dateofIncorporation?: any;
  appLFY?: number;
  appSubLFY?: number;
  appSales?: number;
  appSubSales?: number;
  appNetProfit?: number;
  appSubNetProfit?: number;
  shareholdingSub?: any[];
  level?: number;
  name?: string;
  aCRA?: string;
  type?: string;
  country?: string;
  share?: number;
  parentUEN?: string;
  turnover?: number;
  noOfStaff?: number;
  subsidiaries?: any[];
  //  [ { subsidLevel?: string; name?: string; sharePercent?: string; noStaff?: string } ];
  invStockFinancing?: number;
  workingCapital?: number;
  aRDiscount?: number;
  capitalLoan?: number;
  bankerGuarantee?: number;
  total?: number;
  loanDomesticTrade1?: number;
  loanDomesticTrade2?: number;

}

export interface ISpringFormSave extends Mongoose.Document {

  createdAt?: Date;
  updateAt?: Date;
  data?: any;
}


// export const SpringFormSchema = new Mongoose.Schema(
//   {
//     data: { type: Mongoose.Schema.Types.Mixed }
//   },
//   {
//     timestamps: true
//   }
// );


export const SpringFormSchema = new Mongoose.Schema(
  {
    regComName: { type: String, required: true },
    contactPersonNo: { type: String, required: true },
    ACRANo: { type: String, required: true },
    corrAddress1: { type: String, required: true },
    corrAddress2: { type: String, required: true },
    corrAddress3: { type: String, required: true },
    contactPerson: { type: String, required: true },
    contactPersonEmail: { type: String, required: true },
    businessActivity: { type: String, required: true },
    numStaff: { type: String, required: true },
    dateOfIncorporation: { type: String, required: true },
    appLFY: { type: String, required: true },
    appSubLFY: { type: String, required: true },
    appSales: { type: Number, required: true },
    appSubSales: { type: Number, required: true },
    appNetProfit: { type: Number, required: true },
    appSubNetProfit: { type: Number, required: true },
    // shareholdingSub?: any[];
    level: { type: Number, required: true },
    name: { type: String, required: true },
    aCRA: { type: String, required: true },
    type: { type: String, required: true },
    country: { type: String, required: true },
    share: { type: Number, required: true },
    parentUEN: { type: String, required: true },
    turnover: { type: Number, required: true },
    noOfStaff: { type: Number, required: true },
    //subsidiaries?:any[];
    //  [ { subsidLevel:{ type: String, required: true } name:{ type: String, required: //true } sharePercent:{ type: String, required: true } noStaff?: string } ];
    //invStockFinancing:{ type: Number, required: true },
    workingCapital: { type: Number, required: true },
    aRDiscount: { type: Number, required: true },
    capitalLoan: { type: Number, required: true },
    bankerGuarantee: { type: Number, required: true },
    total: { type: Number, required: true },
    loanDomesticTrade1: { type: Number, required: true },
    loanDomesticTrade2: { type: Number, required: true }
  },
  {
    timestamps: true
  }
);





export const SpringFormModel = Mongoose.model<ISpringFormSave>("SpringForm", SpringFormSchema);
