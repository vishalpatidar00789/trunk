import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { ILoan } from "./loan";
import { IDatabase } from "../../database";
import { IServerConfigurations } from "../../configurations";
import { IRequest, ILoginRequest } from "../../interfaces/request";
import TransactionsController from "../lookup/transactions/transactions-controller";

export default class LoanController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }

  public async createLoan(request: IRequest, h: Hapi.ResponseToolkit) {
    try {

      let requestPayload: any = request["payload"];
      //let marshRefNo = await this.generateMarshReferenceNumber();
     // requestPayload["marshRefNo"] = marshRefNo;
     // console.log('*****' + marshRefNo + '*****');

      let loan: any = await this.database.loanModel.create(requestPayload);
      return h.response({ "_id": loan._id, "status": loan.status }).code(201);
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async updateLoan(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.params["id"];
    try {
      let requestPayload: any = request["payload"];
     // let marshRefNo = await this.generateMarshReferenceNumber();
      // requestPayload["marshRefNo"] = marshRefNo;
     // console.log('######' + marshRefNo + '######');

     requestPayload["marshRefNo"] = "abc123";

      let loan: ILoan = await this.database.loanModel.findByIdAndUpdate(
        { _id: id },
        { $set: requestPayload },
        { new: true }
      );
      return loan;
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteLoan(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.auth.credentials.id;
    let loan: ILoan = await this.database.loanModel.findByIdAndRemove(id);

    return loan;
  }

  private async generateMarshReferenceNumber() {

    let bankCode = 'DBS';
    const transactionsController = new TransactionsController(this.configs, this.database);
    let seqNo = await transactionsController.getSequenceNo();
    let trancheNo = '05';
    let seqNoPrefix = '';

    if (seqNo.toString().length === 1) {
      seqNoPrefix = '0000';
    } else if (seqNo.toString().length === 2) {
      seqNoPrefix = '000';
    } else if (seqNo.toString().length === 3) {
      seqNoPrefix = '00';
    } else if (seqNo.toString().length === 4) {
      seqNoPrefix = '0';
    }
    let sequenceNum = seqNoPrefix + seqNo;

    let fullDate: string;
    const date1: Date = new Date();
    let date = date1.getDate();
    if (date.toString().length === 1) {
      fullDate = '0' + date;
    } else {
      fullDate = date.toString();
    }
    let month: number = date1.getMonth() + 1;
    if (month.toString().length === 1) {
      fullDate = fullDate + '0' + month;
    } else {
      fullDate = fullDate + month.toString();
    }
    let year = date1.getFullYear().toString().substr(2, 2);
    fullDate = fullDate + year;

    let marshRefNumber: string = 'LO' + trancheNo + bankCode + fullDate + sequenceNum + '/01';
    console.log('MarshRefNo::' + marshRefNumber);
    await transactionsController.updateSequenceNo(seqNo);
    return marshRefNumber;
  }

  public async infoLoan(request: IRequest, h: Hapi.ResponseToolkit) {
    const id = request.auth.credentials.id;
    let loan: ILoan = await this.database.loanModel.findById(id);

    return loan;
  }

  public async saveAsDraft(request: IRequest, h: Hapi.ResponseToolkit) {
    console.log(JSON.stringify(request.params.id));
    const id = request.params.id;

    try {
      let loan: ILoan = await this.database.loanModel.findByIdAndUpdate(
        id,
        { $set: request.payload },
        { new: true }
      );
      return loan;
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async searchLoan(request: IRequest, h: Hapi.ResponseToolkit) {

    let requestPayload: any = request["payload"];
    let query: any = {};

    console.log(requestPayload);

    const pfiName: string[] = requestPayload.pfiName;

    // if (typeof pfiName !== 'undefined') {
    //   if (pfiName.length === 1) {
    //     if (pfiName.some(pfi => pfi !== 'UOB')) {
    //       console.log("PFI USER");
    //       query = this.buildPfiQuery(requestPayload);
    //     } else {
    //       console.log("UOB USER");
    //       query = this.buildUobQuery(requestPayload);
    //     }
    //   } else {
    //     console.log("MARSH USER");
    //     query = this.buildMarshQuery(requestPayload);
    //   }
    // } else {
    //   console.log("Please select the pfi");
    // }

    query = this.buildQuery(requestPayload);
    let loan: ILoan[] = await this.database.loanModel.find(query);

    return loan;
  }

  buildQuery(requestPayload: any) {

    console.log("Building Query");
    const marshReferenceNumber: string = requestPayload.marshRefNo;
    const borrowerName = requestPayload.borrowerName;
    const uenNumber = requestPayload.uenNumber;
    const pfiName: string[] = requestPayload.pfiName;
    const consortium = requestPayload.consortium;
    const adverseStatus = requestPayload.adverseStatus;
    const typeOfDate = requestPayload.typeOfDate;
    const fromDate = requestPayload.fromDate;
    const toDate = requestPayload.toDate;
    const natureOfApplication: string[] = requestPayload.natureOfApplication;
    const marshLoanApplicationStatus: string[] = requestPayload.marshLoanApplicationStatus;
    const excludeExpiredApplications = requestPayload.excludeExpiredApplications;
    const app: any[] = requestPayload.app;
    let query: any = {};
    let selectedDate: string;

    switch (typeOfDate) {
      case "Marsh Submission Date":
        selectedDate = "createdAt";
        break;

      case "COFANET Submission Date":
        selectedDate = "creditInfo.submissionDate";
        break;

      case "LO Acceptance Date":
        selectedDate = "additionalInfo.loAcceptanceDate";
        break;

      case "Loan Expiry Date":
        selectedDate = "additionalInfo.loanExpiryDateFromLoAcceptanceDate";
        break;

      default:
        selectedDate = "createdAt";
    }
    console.log("Selected date type :" + selectedDate);
    if (typeof marshReferenceNumber !== 'undefined' && marshReferenceNumber !== '') {
      let marshReferenceRegex = marshReferenceNumber;
      if (marshReferenceNumber.includes("*") || marshReferenceNumber.includes("?") || marshReferenceNumber.includes("%")) {
        if (marshReferenceNumber.includes(".")) {
          marshReferenceRegex = marshReferenceNumber.split(".").join("\\.");
        }
        // let marshReferenceRegex = marshReferenceNumber.replace('//*/g', '.*');
        marshReferenceRegex = marshReferenceRegex.split("%").join("*");
        marshReferenceRegex = marshReferenceRegex.split("*").join(".*");
        marshReferenceRegex = marshReferenceRegex.split("?").join(".?");
        query["marshRefNo"] = { '$regex': "^" + marshReferenceRegex + "$", $options: "s" };
      } else {
        query["marshRefNo"] = marshReferenceNumber;
      }
    }
    if (typeof borrowerName !== 'undefined' && borrowerName !== '') {
      let borrowerNameRegex = borrowerName;
      if (borrowerName.includes("*") || borrowerName.includes("?") || borrowerName.includes("%") ) {
        if (borrowerName.includes(".")) {
          borrowerNameRegex = borrowerName.split(".").join("\\.");
        }
        borrowerNameRegex = borrowerNameRegex.split("%").join("*");
        borrowerNameRegex = borrowerNameRegex.split("*").join(".*");
        borrowerNameRegex = borrowerNameRegex.split("?").join(".?");
        query["sponsorForm.regComName"] = { '$regex': "^" + borrowerNameRegex + "$", $options: "s" };
      } else {
        query["sponsorForm.regComName"] = borrowerName;
      }
    }
    if (typeof uenNumber !== 'undefined' && uenNumber !== '') {
      let uenNumberRegex = uenNumber;
      if (uenNumber.includes("*") || uenNumber.includes("?") || uenNumber.includes("%")) {
        if (uenNumber.includes(".")) {
          uenNumberRegex = uenNumber.split(".").join("\\.");
        }
        uenNumberRegex = uenNumberRegex.split("%").join("*");
        uenNumberRegex = uenNumberRegex.split("*").join(".*");
        uenNumberRegex = uenNumberRegex.split("?").join(".?");
        query["sponsorForm.ACRANo"] = { '$regex': "^" + uenNumberRegex + "$", $options: "s" };
      } else {
        query["sponsorForm.ACRANo"] = uenNumber;
      }
    }
    if (typeof pfiName !== 'undefined') {
      query["creditInfo.pfiName"] = { $in: pfiName };
    }
    if (typeof consortium !== 'undefined' && consortium !== '') {

      query["consortium"] = consortium;
    }
    if (typeof adverseStatus !== 'undefined' && adverseStatus !== '' && adverseStatus !== "All") {
      query["adverseInfo.adverseStatus"] = adverseStatus;
    }
    if (typeof adverseStatus !== 'undefined' && adverseStatus !== '' && adverseStatus === "All") {
      query["adverseInfo.adverseStatus"] = { $in: ["Yes", "No"] };
    }
    if (typeof fromDate !== 'undefined' && (typeof toDate === 'undefined' || toDate === null)) {
      query[selectedDate] = { "$gte": new Date(fromDate) };
    }
    if (typeof toDate !== 'undefined' && (typeof fromDate === 'undefined' || fromDate === null)) {
      query[selectedDate] = { "$lte": new Date(toDate) };
    }
    if (typeof fromDate !== 'undefined' && typeof toDate !== 'undefined') {
      query[selectedDate] = { "$gte": new Date(fromDate), "$lte": new Date(toDate) };
    }
    if (typeof natureOfApplication !== 'undefined' && natureOfApplication.length > 0) {
      query["additionalInfo.natureofApplication"] = { $in: natureOfApplication };
    }
    if (typeof marshLoanApplicationStatus !== 'undefined' && marshLoanApplicationStatus.length > 0) {
      query["status"] = { $in: marshLoanApplicationStatus };
    }
    if (excludeExpiredApplications === true) {
      query["additionalInfo.loanExpiryDateFromLoAcceptanceDate"] = { "$lte": new Date() };
    }

    if (typeof app !== 'undefined' && app.length > 0) {
      query["app"] = { $in: app };
    }

    console.log(JSON.stringify(query));
    return query;
  }

  public async updateLoanAdverseInfo(request: IRequest, h: Hapi.ResponseToolkit) {
    let marshRefNo = request.params["marshRefNo"];
    try {
      console.log('ADVERSE PAYLOAD: ' + request["payload"]);
      let requestPayload: any = request["payload"];
      marshRefNo = marshRefNo.replace('_', '/');
      console.log('marshRefNo', marshRefNo);
      let loan: ILoan = await this.database.loanModel.findOneAndUpdate(
        { marshRefNo: marshRefNo },
        { $set: requestPayload },
        { new: true }
      );
      return { "message": "success" };
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }
}
