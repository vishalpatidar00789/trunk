import * as Mongoose from "mongoose";
import { IDataConfiguration } from "./configurations";
import { ILogging, LoggingModel } from "./plugins/logging/logging";
import { IUser, UserModel } from "./api/users/user";
import { IBank, BankModel } from "./api/lookup/banks/bank";
import { IAuthority, AuthorityModel } from "./api/lookup/authorities/authority";
import { IDepartment, DepartmentModel } from "./api/lookup/departments/department";
import { ICurrencies, CurrenciesModel } from "./api/lookup/currencies/currencies";
import { ITransactions, TransactionsModel } from "./api/lookup/transactions/transactions";
import { IPFI, PFIModel } from "./api/loan/pfi/pfi";
import { IUOB, UOBModel } from "./api/loan/uob/uob";
import { ILoan, LoanModel } from "./api/loan/loan";
import { ISpringForm, SpringFormModel } from "./api/loan/springform/springform";
import { IAdditionalField, AdditionalFieldModel } from "./api/loan/additionalfields/additionalfield";
import { ITranch, TranchModel } from "./api/master-data/tranch/tranch";
import { IApp, AppModel } from "./api/master-data/app-management/app-management";
import { IConsortium, ConsortiumModel } from "./api/master-data/consortium/consortium";
import { IInsurer, InsurerModel } from "./api/master-data/insurers/insurer";
import { IBrokerage, BrokerageModel } from "./api/master-data/consortium/brokerage-management/brokerage";
import { ITierRating, TierRatingModel } from "./api/master-data/consortium/tier-rating-management/tier-rating";
import { ILimit, LimitModel } from "./api/master-data/consortium/limit-management/limit";
import { ICapacity, CapacityModel } from "./api/master-data/capacity-management/capacity";
import { IPolicy, PolicyModel } from "./api/master-data/policy-management/policy";
import { IPremiumRates, PremiumRatesModel } from "./api/master-data/consortium/premium-rates-management/premium-rates";
import { ISponsor, SponsorModel } from "./api/master-data/sponsor-management/sponsor";

export interface IDatabase {
  loggingModel: Mongoose.Model<ILogging>;
  userModel: Mongoose.Model<IUser>;
  bankModel: Mongoose.Model<IBank>;
  authorityModel: Mongoose.Model<IAuthority>;
  departmentModel: Mongoose.Model<IDepartment>;
  pfiModel: Mongoose.Model<IPFI>;
  uobModel: Mongoose.Model<IUOB>;
  springformModel: Mongoose.Model<ISpringForm>;
  additionalfieldModel: Mongoose.Model<IAdditionalField>;
  loanModel: Mongoose.Model<ILoan>;
  currenciesModel: Mongoose.Model<ICurrencies>;
  transactionsModel: Mongoose.Model<ITransactions>;
  tranchModel: Mongoose.Model<ITranch>;
  appModel: Mongoose.Model<IApp>;
  consortiumModel: Mongoose.Model<IConsortium>;
  insurerModel: Mongoose.Model<IInsurer>;
  brokerageModel: Mongoose.Model<IBrokerage>;
  tierRatingModel: Mongoose.Model<ITierRating>;
  limitModel: Mongoose.Model<ILimit>;
  capacityModel: Mongoose.Model<ICapacity>;
  policyModel: Mongoose.Model<IPolicy>;
  premiumRatesModel: Mongoose.Model<IPremiumRates>;
  sponsorModel: Mongoose.Model<ISponsor>;

}

export function init(config: IDataConfiguration): IDatabase {
  (<any>Mongoose).Promise = Promise;
  Mongoose.connect(process.env.MONGO_URL || config.connectionString);

  let mongoDb = Mongoose.connection;

  mongoDb.on("error", () => {
    console.log(`Unable to connect to database: ${config.connectionString}`);
  });

  mongoDb.once("open", () => {
    console.log(`Connected to database: ${config.connectionString}`);
  });

  return {
    loggingModel: LoggingModel,
    userModel: UserModel,
    bankModel: BankModel,
    authorityModel: AuthorityModel,
    departmentModel: DepartmentModel,
    pfiModel: PFIModel,
    uobModel: UOBModel,
    springformModel: SpringFormModel,
    additionalfieldModel : AdditionalFieldModel,
    loanModel:LoanModel,
    currenciesModel:CurrenciesModel,
    transactionsModel:TransactionsModel,
    tranchModel: TranchModel,
    appModel: AppModel,
    consortiumModel: ConsortiumModel,
    insurerModel: InsurerModel,
    brokerageModel: BrokerageModel,
    tierRatingModel: TierRatingModel,
    limitModel: LimitModel,
    capacityModel: CapacityModel,
    policyModel:PolicyModel,
    premiumRatesModel:PremiumRatesModel,
    sponsorModel:SponsorModel,
  };
}
