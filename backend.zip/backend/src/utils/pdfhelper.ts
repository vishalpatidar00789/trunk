const PromiseExtracter = require('bluebird');
const path = require('path');
var parseString = require('xml2js').parseString;
var fs = require('fs');

const childProcess = PromiseExtracter.promisifyAll(require('child_process'));

const _runPdfExtracts = function _runPdfExtracts(files, scope) {
    const _runPdfExtract = (file) => {
        var cmdString;
        if (process.platform === 'win32') {
            cmdString = `java -cp "${scope.iTextPDF};${scope.binPath};" pdfExtract < "${file}"`;
        } else {
            cmdString = `java -cp ${scope.iTextPDF}:${scope.binPath}:  pdfExtract < ${file}`;
        }

        console.log("++++++++++++++++++++++" + cmdString);
        return childProcess.execAsync(cmdString)
            .then((data) => {
                return { file: file, data: data };
            })
            .catch((err) => {
                return { file: file, error: err };
            });
    };

    if (!files) {
        return PromiseExtracter.resolve([]);
    }

    if (Object.prototype.toString.call(files) === '[object Array]') {
        return PromiseExtracter
            .map(files, _runPdfExtract);
    }

    return PromiseExtracter
        .map([files], _runPdfExtract);
};

module.exports = { run: _runPdfExtracts };

