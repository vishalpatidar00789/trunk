import './vendor.ts';

import { NgModule, Injector } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import {
  Ng2Webstorage,
  LocalStorageService,
  SessionStorageService
} from 'ngx-webstorage';
import { JhiEventManager } from 'ng-jhipster';
import { AuthInterceptor } from './blocks/interceptor/auth.interceptor';
import { AuthExpiredInterceptor } from './blocks/interceptor/auth-expired.interceptor';
import { ErrorHandlerInterceptor } from './blocks/interceptor/errorhandler.interceptor';
import { NotificationInterceptor } from './blocks/interceptor/notification.interceptor';
import {
  LisAppSharedModule,
  UserRouteAccessService,
  FileUploadComponent,
  DateUtil
} from './shared';
import { LisAppAppRoutingModule } from './app-routing.module';
import { LisAppHomeModule } from './home/home.module';
import { LisAppAdminModule } from './admin/admin.module';
import { LisAppAccountModule } from './account/account.module';
import { LisAppEntityModule } from './entities/entity.module';
import { PaginationConfig } from './blocks/config/uib-pagination.config';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LisAppClaimModule } from './claim/claim.module';
import { ClaimComponent } from './claim/claim.component';
import { LoanApplicationModule } from './loan/loan.module';
import { LoanAdhocApplicationModule } from './loan/adhoc/adhoc.module';
import {
  JhiMainComponent,
  NavbarComponent,
  FooterComponent,
  ProfileService,
  PageRibbonComponent,
  ErrorComponent
} from './layouts';
import { MatInputModule } from '@angular/material/input';
import { MatTabsModule } from '@angular/material/tabs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CdkTableModule } from '@angular/cdk/table';
import { GrowlModule } from 'primeng/growl';
import { MessageService } from 'primeng/components/common/messageservice';
import { NgxSpinnerModule } from 'ngx-spinner';
import {
  BsDatepickerModule,
  BsDatepickerConfig
} from 'ngx-bootstrap/datepicker';

export function getDatepickerConfig(): BsDatepickerConfig {
  return Object.assign(new BsDatepickerConfig(), {
    dateInputFormat: 'DD-MM-YYYY',
    containerClass: 'theme-dark-blue',
    showWeekNumbers: false
  });
}

@NgModule({
  imports: [
    NgbModule.forRoot(),
    BrowserModule,
    BrowserAnimationsModule,
    LisAppAppRoutingModule,
    Ng2Webstorage.forRoot({ prefix: 'jhi', separator: '-' }),
    LisAppSharedModule,
    LisAppHomeModule,
    LisAppAdminModule,
    LisAppAccountModule,
    LisAppEntityModule,
    LoanApplicationModule,
    LoanAdhocApplicationModule,
    LisAppClaimModule,
    GrowlModule,
    NgxSpinnerModule,
    BsDatepickerModule.forRoot()
  ],
  declarations: [
    JhiMainComponent,
    NavbarComponent,
    ErrorComponent,
    PageRibbonComponent,
    FooterComponent
  ],
  entryComponents: [FileUploadComponent],
  providers: [
    ProfileService,
    PaginationConfig,
    UserRouteAccessService,
    MessageService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true,
      deps: [LocalStorageService, SessionStorageService]
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthExpiredInterceptor,
      multi: true,
      deps: [Injector]
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ErrorHandlerInterceptor,
      multi: true,
      deps: [JhiEventManager]
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: NotificationInterceptor,
      multi: true,
      deps: [Injector]
    },
    {
      provide: BsDatepickerConfig,
      useFactory: getDatepickerConfig
    }
  ],
  bootstrap: [JhiMainComponent]
})
export class LisAppAppModule {}
