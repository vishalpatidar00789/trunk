import { Routes, Route } from '@angular/router';

import { UserRouteAccessService } from '../shared';

import {
    checklistRoute,
    additionalRoute,
    ClaimComponent,
    ChecklistComponent,
} from './';

const defaultClaimRoute: Route = {
    path: '',
    pathMatch: 'full',
    redirectTo: 'additional',
    data: {
        pageTitle: 'Additional'
    },
};

const CLAIM_ROUTES = [
    checklistRoute,
    additionalRoute,
    defaultClaimRoute
];

export const claimState: Routes = [{
    path: 'claim',
    component: ClaimComponent,
    data: {
        authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN']
    },
    children: CLAIM_ROUTES,
    canActivate: [UserRouteAccessService],
}];
