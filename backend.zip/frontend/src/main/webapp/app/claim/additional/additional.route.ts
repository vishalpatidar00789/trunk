import { Route } from '@angular/router';

import { AdditionalComponent } from './additional.component';
import { UserRouteAccessService } from '../../shared';

export const additionalRoute: Route = {
    path: 'additional',
    component: AdditionalComponent,
    data: {
        pageTitle: 'Claim'
    },
    canActivate: [UserRouteAccessService]
};
