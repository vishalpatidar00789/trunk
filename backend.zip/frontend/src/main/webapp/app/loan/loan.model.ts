import { PFICreditLimit } from './pfi/pfi-credit-limit.model';
import { UobCreditLimit } from './uob/uob-credit-limit.model';
import { SponsorEForm, Subsideries } from './sponsor-eform/sponsor-eform.model';
import { AdditionalFields } from './additional-fields/additionalFields.model';

export class Loan {
  public _id: string;
  public marshRefNo: string;
  public status: string;
  public sponsorForm: SponsorEForm;
  constructor() {
    this.status = 'Draft';
  }
}

export class PFILoan extends Loan {
  public creditInfo: PFICreditLimit;
}

export class UOBLoan extends Loan {
  public creditInfo: UobCreditLimit;
}

export class LoanProcess {
  id: string;
  status?: string;
  tranchName?: string;
  marshRefNo: string;
  completedStep: number;
  constructor() {
    this.status = 'Draft';
    this.tranchName = 'Tranch LIS5';
  }
}

export enum CompletedStep {
  stepOne = 1,
  stepTwo,
  stepCompleted
}
