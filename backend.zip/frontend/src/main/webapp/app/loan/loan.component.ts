import { Component, OnInit } from '@angular/core';
import { LoanService } from './loan.service';
import { Router, NavigationEnd } from '@angular/router';
import { Account, Principal } from '../shared';
import { SponsorEFormService } from './sponsor-eform/sponsor-eform.service';
import { PFICreditLimit } from './pfi/pfi-credit-limit.model';
import { UobCreditLimit } from './uob/uob-credit-limit.model';
import { SponsorEForm } from './sponsor-eform/sponsor-eform.model';
import { AdditionalFields } from './additional-fields/additionalfields.model';
import { PFICreditLimitService } from './pfi/pfi-credit-limit.service';
import { UobCreditLimitService } from './uob/uob-credit-limit.service';
import { LoanProcess, Loan } from './loan.model';

@Component({
  selector: 'lis-loan',
  templateUrl: './loan.component.html',
  styles: []
})
export class LoanComponent implements OnInit {
  currentAccount: Account;
  loanUserType = 'pfi-user';
  loan: Loan;
  loanProcess: LoanProcess;
  status: any;

  constructor(
    private loanService: LoanService,
    private router: Router,
    private principal: Principal,
    private sponsorEFormService: SponsorEFormService,
    private pfiCreditLimitService: PFICreditLimitService,
    private uobCreditLimitService: UobCreditLimitService
  ) {
    this.loanService.status.subscribe((res) => {
      this.status = res;
    });
    this.loanService.loanProcess$.subscribe((loanProcess) => {
      this.loanProcess = Object.assign({}, loanProcess);
    });
    this.clearLoanApplication();
  }

  ngOnInit() {
    this.status = 'Draft';
    this.principal.identity().then((account) => {
      this.currentAccount = account;
      this.loanUserType =
        this.currentAccount.bank &&
        this.currentAccount.bank !== 'null' &&
        this.currentAccount.bank === 'UOB'
          ? 'uob-user'
          : 'pfi-user';
    });

    this.router.events.subscribe((event) => {
      if (!(event instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
  }

  public clearLoanApplication() {
    this.loanService.loanId = '';
    this.pfiCreditLimitService.setPFICreditLimit(new PFICreditLimit());
    this.uobCreditLimitService.setUOBCreditLimit(new UobCreditLimit());
    this.sponsorEFormService.setSponsorEForm(new SponsorEForm());
    this.loanService.changeAdditionalFields(new AdditionalFields());
  }
}
