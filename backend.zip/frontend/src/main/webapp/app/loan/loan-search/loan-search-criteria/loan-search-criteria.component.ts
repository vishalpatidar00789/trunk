import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LoanSearchCriteria } from './loan-search-criteria.model';
import { LoanSearchResults } from './../loan-search-results/loan-search-results.model';
import { LoanSearchCriteriaService } from './loan-search-criteria.service';
import { LookupService, Account, DateUtil, Principal } from '../../../shared';
import { MasterdataService } from '../../../shared/masterdata/masterdata.service';
import { Router } from '@angular/router';
import { MultiSelectModule } from 'primeng/multiselect';
import { DropdownModule } from 'primeng/dropdown';
import { CheckboxModule } from 'primeng/checkbox';

@Component({
    selector: 'loan-search-criteria',
    templateUrl: './loan-search-criteria.component.html'
})
export class LoanSearchCriteriaComponent implements OnInit, OnDestroy {

    displayMessage: boolean;
    userMessage: string;
    searchModel: LoanSearchCriteria;
    banks: any[];
    consortiums: any[];
    currentAccount: Account;
    isMarshUser: boolean;
    app: any[];
    loanResultList: LoanSearchResults[];
    natureOfApp: any[];
    marshAppStatus: any[];
    showTblData: boolean = false;
    defaultAdverseOptoin: string;
    dateTypes: any[];
    adverseStatus: any[];

    constructor(
        private lookupService: LookupService,
        private masterdataService: MasterdataService,
        private principal: Principal,
        private loanSearchCriteriaService: LoanSearchCriteriaService,
        private router: Router) {     
    }

    ngOnInit() {
        this.init();
        this.loadBanks();
        this.loadConsortiums();
        this.getAccount();
        this.loadApp();
    }

    init(){
        this.displayMessage = false;
        this.searchModel = new LoanSearchCriteria();
        this.isMarshUser = false;
        this.loanResultList = [];
        this.dateTypes = [
            { label: 'Marsh Submission Date', value: 'Marsh Submission Date' },
            { label: 'COFANET Submission Date', value: 'COFANET Submission Date' },
            { label: 'LO Acceptance Date', value: 'LO Acceptance Date' },
            { label: 'Loan Expiry Date', value: 'Loan Expiry Date' }
        ];
        this.natureOfApp = [
            { label: 'New', value: 'New' },
            { label: 'Cancel Utilised', value: 'Cancel Utilised' },
            { label: 'Cancel Un-Utilised', value: 'Cancel Un-Utilised' },
            { label: 'Decrease Un-Utilised', value: 'Decrease Un-Utilised' },
            { label: 'Renewal', value: 'Renewal' },
            { label: 'Mid-Term INCR Un-Utilised', value: 'Mid-Term INCR Un-Utilised' },
            { label: 'Mid-Term INCR Utilised', value: 'Mid-Term INCR Utilised' },
            { label: 'Decrease Utilised', value: 'Decrease Utilised' },
            { label: 'Temporary Increase', value: 'Temporary Increase' }
        ];
        this.marshAppStatus = [
            { label: 'Draft', value: 'Draft' },
            { label: 'Processing', value: 'Processing' },
            { label: 'Answered', value: 'Answered' }
        ];
        this.adverseStatus = [
            { label: 'All', value: 'All' },
            { label: 'Yes', value: 'Yes' },
            { label: 'No', value: 'No' }
        ];
        this.app = [];
        this.banks = [];
        this.consortiums = [];
    }

    ngOnDestroy() {
    }

    getAccount() {
        this.principal.identity().then((account) => {
            if (account) {
                this.currentAccount = account;
                if (!this.currentAccount.bank) {
                    this.isMarshUser = true;
                } else {
                    this.isMarshUser = false;
                    this.searchModel.pfiName = [];
                    this.searchModel.pfiName[0] = this.currentAccount.bank;
                }
            }
        });
    }

    loadBanks() {
        this.lookupService.banks().subscribe((banks) => {
            const bankList = banks;
            bankList.forEach(val => {
                let bank = { label: val.bankCode, value: val.bankCode };
                this.banks.push(bank);
            })
        });
    }

    loadConsortiums() {
        this.masterdataService.consortiums().subscribe((consortiums) => {
            const consoList = consortiums;
            consoList.forEach(val => {
                let conso = { label: val.consortiumName, value: val.consortiumName };
                this.consortiums.push(conso);
            });
        });
    }

    loadApp() {
        this.masterdataService.app().subscribe((app) => {
            const appResult = app;
            appResult.forEach(val => {
                let ap = { label: val.app, value: val.app };
                this.app.push(ap);
            });
        })
    }

    search() {
        if (this.searchModel) {
            this.changeDateFormatForDB();
            let searchResult;
            this.loanResultList = [];

            if (!this.searchModel.adverseStatus) {
                delete this.searchModel.adverseStatus;
            }
            if (!this.searchModel.consortium) {
                delete this.searchModel.consortium;
            }
            if (!this.searchModel.typeOfDate) {
                delete this.searchModel.typeOfDate;
            }
            if (!this.searchModel.fromDate) {
                delete this.searchModel.fromDate;
            }
            if (!this.searchModel.toDate) {
                delete this.searchModel.toDate;
            }

            this.loanSearchCriteriaService.searchLoanApplication(this.searchModel).subscribe((res) => {
                console.log('loan criteria:', res);
                searchResult = res;
                searchResult.forEach(element => {
                    let loanResult = new LoanSearchResults();
                    loanResult.marshRefNo = element.marshRefNo;
                    loanResult.status = element.status;
                    loanResult.marshSubmissionDate = element.createdAt;
                    loanResult.app = element.app;

                    let sponserForm = element.sponsorForm;
                    if(sponserForm){
                        loanResult.borrowerRegName = sponserForm.regComName;
                        loanResult.aCRArefNo = sponserForm.ACRANo;
                    }                    

                    let creditInfo = element.creditInfo;
                    if(creditInfo){
                        loanResult.pfiName = creditInfo.pfiName;
                        loanResult.totalRequstedLimitSGD = creditInfo.totalRequstedLimitSGD;
                        loanResult.submissionDate = creditInfo.submissionDate;
                        loanResult.primary = creditInfo.primary;
                        loanResult.autoTopUp = creditInfo.autoTopUp;
                        loanResult.bg = creditInfo.bg;
                        loanResult.lisPlus = creditInfo.lisPlus;
                    }                    

                    let additionalInfo = element.additionalInfo;
                    if(additionalInfo){
                        loanResult.natureOfApplication = additionalInfo.natureofApplication;
                        loanResult.loAcceptanceDate = additionalInfo.loAcceptanceDate;
                        loanResult.loanExpiryDate = additionalInfo.loanExpiryDateFromLoAcceptanceDate;
                    }                    

                    let adverseInfo = element.adverseInfo;
                    if(adverseInfo){
                        loanResult.adverseStatus = adverseInfo.adverseStatus;
                    }                    

                    this.loanResultList.push(loanResult);
                });
                this.showTblData = true;
                //this.setDateFormatForUI();
            });

            this.setDateFormatForUI();
        }
    }

    changeDateFormatForDB() {
        if (this.searchModel.fromDate) {
            this.searchModel.fromDate = new DateUtil().getDBDate(this.searchModel.fromDate);
        }
        if (this.searchModel.toDate) {
            this.searchModel.toDate = new DateUtil().getDBDate(this.searchModel.toDate);
        }
    }

    setDateFormatForUI() {
        if (this.searchModel.fromDate) {
            this.searchModel.fromDate = new DateUtil().setUIDate(this.searchModel.fromDate);
        }
        if (this.searchModel.toDate) {
            this.searchModel.toDate = new DateUtil().setUIDate(this.searchModel.toDate);
        }
    }

    clearDate() {
        if (!this.searchModel.typeOfDate) {
            this.searchModel.fromDate = '';
            this.searchModel.toDate = '';
        }
    }

    clear() {
        let pfi = '';
        if (!this.isMarshUser)
            pfi = this.searchModel.pfiName[0];

        this.searchModel = new LoanSearchCriteria();
        if (!this.isMarshUser) {
            this.searchModel.pfiName = [];
            this.searchModel.pfiName[0] = pfi;
        }
        this.loanResultList = [];
    }

    cancel() {
        this.router.navigate(['']);
    }
}