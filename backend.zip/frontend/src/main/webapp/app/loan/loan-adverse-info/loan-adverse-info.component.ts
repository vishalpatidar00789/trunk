import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotificationService } from '../../shared/alert/notification.service';
import { LoanAdverseInfo, LoanAdverseInfo_ } from './loan-adverse-info.model';
import { LoanSearchResults } from '../loan-search/loan-search-results/loan-search-results.model';
import { LoanAdverseInfoService } from './loan-adverse-info.service';
import { DateUtil } from '../../shared';

@Component({
    selector: 'loan-adverse-info',
    templateUrl: './loan-adverse-info.component.html'
})
export class LoanAdverseInfoComponent implements OnInit, OnChanges {

    displayMessage: boolean;
    userMessage: string;
    adverseStatus: any[];
    adverseInfoModel: LoanAdverseInfo;
    adverseInfoModel_: LoanAdverseInfo_;
    @Input() selectedLoanResult: LoanSearchResults;
    @Output() closePopUp = new EventEmitter<boolean>();

    constructor(
        private loanAdverseInfoService: LoanAdverseInfoService,
        private notificationService: NotificationService,
        private spinner: NgxSpinnerService) {
    }

    ngOnChanges() {
        if (this.selectedLoanResult) {
            this.adverseInfoModel_ = new LoanAdverseInfo_();
            this.adverseInfoModel_.marshRefNo = this.selectedLoanResult.marshRefNo;
            this.adverseInfoModel_.uenNumber = this.selectedLoanResult.aCRArefNo;
            this.adverseInfoModel_.borrowerRegName = this.selectedLoanResult.borrowerRegName;
            this.adverseInfoModel_.pfiName = this.selectedLoanResult.pfiName;
            this.adverseInfoModel_.status = this.selectedLoanResult.status
        }
    }

    ngOnInit() {
        console.log(this.selectedLoanResult);
        this.adverseInfoModel = new LoanAdverseInfo();
        this.displayMessage = false;
        this.adverseStatus = [
            { label: 'Yes', value: 'Yes' },
            { label: 'No', value: 'No' }
        ];
    }

    cancel() {
        this.closePopUp.emit(true);
    }

    save() {
        this.spinner.show();
        this.changeDateToDbDate();
        this.loanAdverseInfoService.upldateLoanAdverseInfo(this.adverseInfoModel, this.selectedLoanResult.marshRefNo).subscribe((res) => {
            console.log(res);
            this.spinner.hide();
            this.notificationService.showNotification();
        });
        this.changeDateToUIDate();
    }

    changeDateToDbDate() {
        if (this.adverseInfoModel.adverseInfo.lessOverDueDate) {
            this.adverseInfoModel.adverseInfo.lessOverDueDate = new DateUtil().getDBDate(this.adverseInfoModel.adverseInfo.lessOverDueDate);
        }
        if (this.adverseInfoModel.adverseInfo.moreOverDueDate) {
            this.adverseInfoModel.adverseInfo.moreOverDueDate = new DateUtil().getDBDate(this.adverseInfoModel.adverseInfo.moreOverDueDate);
        }
    }

    changeDateToUIDate() {
        if (this.adverseInfoModel.adverseInfo.lessOverDueDate) {
            this.adverseInfoModel.adverseInfo.lessOverDueDate = new DateUtil().setUIDate(this.adverseInfoModel.adverseInfo.lessOverDueDate);
        }
        if (this.adverseInfoModel.adverseInfo.moreOverDueDate) {
            this.adverseInfoModel.adverseInfo.moreOverDueDate = new DateUtil().setUIDate(this.adverseInfoModel.adverseInfo.moreOverDueDate);
        }
    }

}