export class LoanAdverseInfo{
    constructor(    
    public adverseInfo?: 
        { adverseStatus: string,
          additionalInfo :string,
          moreOverDue?:boolean,
          lessOverDue?:boolean,
          moreOverDueDate?:any,
          lessOverDueDate?:any,
          listOfOverdue?:boolean,
          repaymentPlanAttached?:boolean
        }
    ){  
        this.adverseInfo=  {
            adverseStatus: '',
            additionalInfo:'',
            moreOverDue:false,
            lessOverDue:false,
            listOfOverdue:false,
            repaymentPlanAttached:false
        } 
    }
}

export class LoanAdverseInfo_{
    constructor(
    public marshRefNo?:string,
    public status?: string,
    public borrowerRegName?:string,
    public pfiName?: string,
    public uenNumber?: string    
    ){          
    }
}