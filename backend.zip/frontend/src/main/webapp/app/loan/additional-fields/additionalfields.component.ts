import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';
import { Loan } from '../loan.model';
import { AdditionalFields } from './additionalFields.model';
import { AdditionalFieldsService } from './additionalFields.service';
import { Principal, UserService, LookupService } from '../../shared';
import { LoanService } from '../loan.service';
import { DateUtil } from '../../shared/date-formatter/date-util';
import { SponsorEForm } from '../sponsor-eform/sponsor-eform.model';

@Component({
    selector: 'jhi-additional-fields',
    templateUrl: './additionalFields.component.html'
})
export class AdditionalFieldsComponent implements OnInit, OnDestroy {

    additionalFields: AdditionalFields = new AdditionalFields();
    springForm: SponsorEForm = new SponsorEForm();

    loan: Loan = new Loan();
    currencies = ['AUD', 'CNY', 'EUR', 'HKD', 'IDR', 'INR', 'JPY', 'KRW', 'MYR', 'NOK', 'PHP', 'THB', 'TWD', 'USD'];
    typesOfLimit = ['DL', 'CL', 'BG'];

    currentAccount: any;
    eventSubscriber: Subscription;
    isSaving: Boolean;
    routeData: any;
    links: any;
    totalItems: any;
    queryCount: any;
    itemsPerPage: any;
    page: any;
    predicate: any;
    previousPage: any;
    reverse: any;
    _id: string;
    pfiUser: boolean;
    uobUser: boolean;
    marshUser: boolean = false;    
    displayMessage: boolean = false;
    userMessage:string;

    constructor(
        private additionalFieldsService: AdditionalFieldsService,
        private parseLinks: JhiParseLinks,
        private jhiAlertService: JhiAlertService,
        private eventManager: JhiEventManager,
        private principal: Principal,
        private loanService: LoanService,
        private router: Router,
        private userService: UserService,
        private lookup: LookupService,
    ) {
        this.userMessage="";
    }

    onOptionsSelected(event) {
        console.log(event); //option value will be sent as event
    }

    additionalFieldDateMap(additionalFields: AdditionalFields) {
        if (additionalFields.applicationDate) {
            additionalFields.applicationDate = new DateUtil().getDBDate(additionalFields.applicationDate);
        }

        if (additionalFields.loAcceptanceDate) {
            additionalFields.loAcceptanceDate = new DateUtil().getDBDate(additionalFields.loAcceptanceDate);
        }

        if (additionalFields.loanExpiryDateFromLoAcceptanceDate) {
            additionalFields.loanExpiryDateFromLoAcceptanceDate = new DateUtil().getDBDate(additionalFields.loanExpiryDateFromLoAcceptanceDate);
        }

        if (additionalFields.dateSentForLisPlus) {
            additionalFields.dateSentForLisPlus = new DateUtil().getDBDate(additionalFields.dateSentForLisPlus);
        }

        if (additionalFields.lisPlusApprovedDate) {
            additionalFields.lisPlusApprovedDate = new DateUtil().getDBDate(additionalFields.lisPlusApprovedDate);
        }
    }

    save() {

        this._id = this.loanService.getId();
        let additionalFieldData: any = {};

        let datePickerApplicationDate = this.additionalFields.applicationDate;
        let loAcceptanceDate = this.additionalFields.loAcceptanceDate;
        let insurersApprovalDate = this.additionalFields.insurersApprovalDate;
        let loanExpiryDateFromLoAcceptanceDate = this.additionalFields.loanExpiryDateFromLoAcceptanceDate;
        let dateSentForLisPlus = this.additionalFields.dateSentForLisPlus;
        let lisPlusApprovedDate = this.additionalFields.lisPlusApprovedDate;

        this.additionalFieldDateMap(this.additionalFields);
        additionalFieldData.aFields = this.additionalFields;
        this.isSaving = true;
        console.log(JSON.stringify(additionalFieldData));
        if (!this._id) {
            this.additionalFieldsService.create(additionalFieldData).subscribe((res) => {
                this.loanService.setId(res._id);
                window.scrollTo(0, 0);
                this.userMessage="Additional information saved succesfully."
                this.showMessage();   
            });
        } else {
            this.additionalFields._id = this._id;
            additionalFieldData.aFields = this.additionalFields;

            this.additionalFieldsService.update(additionalFieldData).subscribe((res) => {
                console.log(this.loanService.getId());
                window.scrollTo(0, 0);
                this.userMessage="Additional information saved succesfully."
                this.showMessage();
            });
        }
        this.additionalFields.applicationDate = datePickerApplicationDate;
        this.additionalFields.loAcceptanceDate = loAcceptanceDate;
        this.additionalFields.insurersApprovalDate = insurersApprovalDate;
        this.additionalFields.loanExpiryDateFromLoAcceptanceDate = loanExpiryDateFromLoAcceptanceDate;
        this.additionalFields.dateSentForLisPlus = dateSentForLisPlus;
        this.additionalFields.lisPlusApprovedDate = lisPlusApprovedDate;
    }

    clear() {
        this.additionalFields = new AdditionalFields();
    }

    private subscribeToSaveResponse(result: Observable<AdditionalFields>) {
        result.subscribe((res: AdditionalFields) =>
            this.onSaveSuccess(res), (res: Response) => this.onSaveError());
    }

    private onSaveSuccess(result: AdditionalFields) {
        this.eventManager.broadcast({ name: 'additionalFieldsListModification', content: 'OK' });
        this.isSaving = false;
    }

    private onSaveError() {
        this.isSaving = false;
    }

    ngOnInit() {

        this.loanService.currentAdditionalFields.subscribe(Result => this.additionalFields = Result);
        this.principal.identity().then((account) => {
            if (account) {
                this.currentAccount = account;
                if (this.currentAccount.bank && this.currentAccount.bank !== 'null' && this.currentAccount.bank === 'UOB') {
                    this.uobUser = true;
                    this.pfiUser = false;
                } else if (this.currentAccount.bank && this.currentAccount.bank !== 'null' && this.currentAccount.bank !== 'UOB') {
                    this.pfiUser = true;
                    this.uobUser = false;
                }
                if (this.currentAccount.bank) {
                    this.lookup.getBankByCode(this.currentAccount.bank).subscribe((bank) => {
                        if (bank) {
                            this.additionalFields.pfi = bank.bankName;
                        } else {
                            //
                        }
                    })
                }
            }
        });

        // this.loanService.currentsponsorForm.subscribe(result => {
        //     this.springForm = result;
        //     if (this.springForm) {
        //         if (!this.additionalFields.borrowerName) {
        //             this.additionalFields.borrowerName = this.springForm.regComName;
        //         }
        //         if (!this.additionalFields.acraRefNo) {
        //             this.additionalFields.acraRefNo = this.springForm.ACRANo;
        //         }
        //         if (this.springForm.loanDomesticTrade1) {
        //             this.additionalFields.domesticPercent = String(this.springForm.loanDomesticTrade1);
        //         }
        //         if (this.springForm.loanDomesticTrade2) {
        //             this.additionalFields.exportPercent = String(this.springForm.loanDomesticTrade2);
        //         }
        //     }
        // })

        // this.loanService.currentPFICreditLimit.subscribe(Result => this.loan.pfi = Result);
        // this.loanService.currentUobCreditLimit.subscribe(Result => this.loan.uob = Result);
        // this.loanService.currentsponsorForm.subscribe(Result => this.loan.sponsorForm = Result);
        //this.loanService.currentAdditionalFields.subscribe(Result => this.loan.aFields = Result);
    }

    ngOnDestroy() {

    }

    sort() {
        const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
        if (this.predicate !== 'id') {
            result.push('id');
        }
        return result;
    }
    private onError(error) {
        this.jhiAlertService.error(error.message, null, null);
    }

    previous() {
        if (this.pfiUser) {
            this.loanService.changeAdditionalFields(this.additionalFields);
            this.router.navigate(['/loan/loan-pfiuser']);
        }
        if (this.uobUser) {
            this.loanService.changeAdditionalFields(this.additionalFields);
            this.router.navigate(['/loan/loan-uobuser']);
        }
    }

    loanDateMap(loan: Loan) {
        if (loan.sponsorForm.dateofIncorporation) {
            loan.sponsorForm.dateofIncorporation = new DateUtil().getDBDate(loan.sponsorForm.dateofIncorporation);
        }

        // /* CREDIT LIMIT FORM DATE*/
        // if (loan.pfi.submissionDate) {
        //     loan.pfi.submissionDate = new DateUtil().getDBDate(loan.pfi.submissionDate);
        // }
        // if (loan.pfi.latestAuditedDt) {
        //     loan.pfi.latestAuditedDt = new DateUtil().getDBDate(loan.pfi.latestAuditedDt);
        // }
        // if (loan.pfi.latestSignedDt) {
        //     loan.pfi.latestSignedDt = new DateUtil().getDBDate(loan.pfi.latestSignedDt);
        // }

        // if (loan.uob.submissionDate) {
        //     loan.uob.submissionDate = new DateUtil().getDBDate(loan.uob.submissionDate);
        // }
        // if (loan.uob.latestAuditedDt) {
        //     loan.uob.latestAuditedDt = new DateUtil().getDBDate(loan.uob.latestAuditedDt);
        // }
        // if (loan.uob.latestSignedDt) {
        //     loan.uob.latestSignedDt = new DateUtil().getDBDate(loan.uob.latestSignedDt);
        // }
        // /* ENDS HERE */
        // if (loan.aFields.applicationDate) {
        //     loan.aFields.applicationDate = new DateUtil().getDBDate(loan.aFields.applicationDate);
        // }

        // if (loan.aFields.loAcceptanceDate) {
        //     loan.aFields.loAcceptanceDate = new DateUtil().getDBDate(loan.aFields.loAcceptanceDate);
        // }

        // if (loan.aFields.loanExpiryDateFromLoAcceptanceDate) {
        //     loan.aFields.loanExpiryDateFromLoAcceptanceDate = new DateUtil().getDBDate(loan.aFields.loanExpiryDateFromLoAcceptanceDate);
        // }

        // if (loan.aFields.dateSentForLisPlus) {
        //     loan.aFields.dateSentForLisPlus = new DateUtil().getDBDate(loan.aFields.dateSentForLisPlus);
        // }

        // if (loan.aFields.lisPlusApprovedDate) {
        //     loan.aFields.lisPlusApprovedDate = new DateUtil().getDBDate(loan.aFields.lisPlusApprovedDate);
        // }
    }

    remapLoanDate(loan:Loan){
        // if (loan.pfi.submissionDate) {
        //     loan.pfi.submissionDate = new DateUtil().setUIDate(loan.pfi.submissionDate);
        // }
        // if (loan.pfi.latestAuditedDt) {
        //     loan.pfi.latestAuditedDt = new DateUtil().setUIDate(loan.pfi.latestAuditedDt);
        // }
        // if (loan.pfi.latestSignedDt) {
        //     loan.pfi.latestSignedDt = new DateUtil().setUIDate(loan.pfi.latestSignedDt);
        // }
        // if (loan.uob.submissionDate) {
        //     loan.uob.submissionDate = new DateUtil().setUIDate(loan.uob.submissionDate);
        // }
        // if (loan.uob.latestAuditedDt) {
        //     loan.uob.latestAuditedDt = new DateUtil().setUIDate(loan.uob.latestAuditedDt);
        // }
        // if (loan.uob.latestSignedDt) {
        //     loan.uob.latestSignedDt = new DateUtil().setUIDate(loan.uob.latestSignedDt);
        // }
    }

    showMessage(){
        this.displayMessage = true;
        setTimeout(() => { this.displayMessage = false; }, 2000); 
    }

    showMessageAndNavigate() {
        this.displayMessage = true;
        setTimeout(() => { this.displayMessage = false; 
            this.router.navigate(['']);
        }, 4000); 
    }

    submitLIS() {

        let datePickerApplicationDate = this.additionalFields.applicationDate;
        this._id = this.loanService.getId();
        this.isSaving = true;
        if (!this._id) {
            //this.loan.status = "Submitted";
            //this.loan.aFields = this.additionalFields;
            this.loanDateMap(this.loan);
            this.additionalFieldsService.createLoan(this.loan).subscribe((res) => {
                this.loanService.setId(res._id);
                this.additionalFields.applicationStatus = 'In Processing';
                window.scrollTo(0, 0);
                let marshRefNo= res.marshRefNo;
                this.userMessage="Application submitted successfully. \n Marsh Reference Id is " + marshRefNo;
                this.showMessageAndNavigate();
                this.remapLoanDate(this.loan);
            });
        } else {
            this.loan._id = this._id;
            this.loan.status = "In Processing";
            console.log(JSON.stringify(this.loan));
            //this.loan.aFields = this.additionalFields;
            this.loanDateMap(this.loan);
            this.additionalFieldsService.updateLoan(this.loan).subscribe((res) => {
                console.log(this.loanService.getId());
                //this.loanService.setStatus(res.status);
                this.additionalFields.applicationStatus = 'In Processing';
                window.scrollTo(0, 0);
                let marshRefNo= res.marshRefNo;
                this.userMessage="Application submitted successfully. \n Marsh Reference Id is " + marshRefNo;
                this.showMessageAndNavigate();
                this.remapLoanDate(this.loan);
            });
        }
        this.additionalFields.applicationDate = datePickerApplicationDate;
    }
}
