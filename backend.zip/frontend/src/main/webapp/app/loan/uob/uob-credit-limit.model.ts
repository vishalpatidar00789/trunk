
export class UobCreditLimit {
    constructor(
        public _id?: string,
        //uobPolicyNo?:string,
        public pfiName?: string,
        public requesterName?: string,
        public submissionDate?: any,
        public discretiolaryLimitDL?: boolean,
        public creditLimitCL?: boolean,
        public borrowersCrr?:number,
        public crrRate?: number,  
        public currencyExchangeRate?: number,      
        public borrowerRegName?:string,
        public rocRefNo?:string,
        public lisType?:string,            
        public increaseLimitToSGD?: number,
        public increaseLimitToUSD?: number,
        public decreaseLimitToSGD?: number,
        public decreaseLimitToUSD?: number,
        public renewalFromSGDTxt?: number,
        public renewalFromUSDTxt?: number,
        public renewalToUSDTxt?: number,
        public renewalToSGDTxt?: number,
        public sgdCurrency?:number,
        public usdCurrency?:number,
        public usdCurrencyCurrent?:number,
        public sgdCurrencyCurrent?:number,
        public sgdCurrencyCurrentLIS?: number,
        public usdCurrencyCurrentLIS?: number,
        public usdCurrencyCurrentLISP?: number,
        public sgdCurrencyCurrentLISP?: number,
        public lisSponsersApplChkBx?: boolean,
        public companySearchesChkBx?: boolean,
        public uobInternalCreditChkBx?: boolean,
        public latestAuditedChkBx?: boolean,
        public latestAuditedDt?: any,
        public latestSignedChkBx?: boolean,
        public latestSignedDt?: any,
        public additionalItemChkBx?: boolean,
        public additionalItemTxt?: string,
        public forOverseasChkBx?: boolean,
        public pfiInternalCreditChkBx?: boolean,       
        public bankersGuaranteeAmountChkBx?:boolean,
        public inventoryStockChkBx?: boolean,
        public structuredWorkingCapitalChkBx?: boolean,
        public recourseFactoringBillChkBx?: boolean,
        public overseasWorkingCapitalChkBx?: boolean,
        public bankersGuarantee?: boolean,
        public tenureMonths?:number,
        public inventoryUSDTxt?:number,
        public inventorySGDTxt?:number,
        public withRecourseUSDTxt?:number,
        public withRecourseSGDTxt?:number,
        public structuredWorkingCapitalUSDTxt?:number,
        public structuredWorkingCapitalSGDTxt?:number,
        public overseaseCapitalSGDTxt?:number,
        public overseaseCapitalUSDTxt?:number,
        public bankersGuaranteeAmountSGDTxt?:number,
        public bankersGuaranteeAmountUSDTxt?:number,
        public supportingDocs?:any,        
        public borrowersGroup?: [{"name":string,"limit":number}],
        public foreignCurrency?:string
    ) {
        this.pfiName = "United Overseas Insurance Limited";

        this.requesterName = "United Overseas Bank Limited";

        this.borrowersGroup = [{ name: '', limit: null}];

        this.foreignCurrency="USD";

        this.supportingDocs= [
            {name: 'sponsersApplication', id: '', status: false,files:''},
            {name: 'companySearches', id: '', status: false,files:''},
            {name: 'pfiInternalCreditMemo', id: '', status: false,files:''},
            {name: 'latestAudited', id: '', status: false,files:''},
            {name: 'latestSigned', id: '', status: false,files:''},
            {name: 'additionalItems', id: '', status: false,files:''},
            {name: 'overseasCapital2', id: '', status: false,files:''}
    ]
    }
}
