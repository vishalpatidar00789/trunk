import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  ElementRef
} from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';
import { LoanService } from '../loan.service';

import { UobCreditLimit } from './uob-credit-limit.model';
import { UobCreditLimitService } from './uob-credit-limit.service';
import { Principal, LookupService, Currencies } from '../../shared';
import { SponsorEForm } from '../sponsor-eform/sponsor-eform.model';
import { DateUtil } from '../../shared/date-formatter/date-util';
import { SponsorEFormService } from '../sponsor-eform/sponsor-eform.service';
import { Message } from 'primeng/components/common/api';
import { NotificationService } from '../../shared/alert/notification.service';
import { UOBLoan } from '../loan.model';

@Component({
  selector: 'jhi-uob-credit-limit',
  templateUrl: './uob-credit-limit.component.html',
  host: {
    '(document:click)': 'onClick($event)'
  }
})
export class UobCreditLimitComponent implements OnInit, OnDestroy {
  uobCreditLimit: UobCreditLimit = new UobCreditLimit();
  sponsorForm: SponsorEForm = new SponsorEForm();
  currentAccount: any;
  eventSubscriber: Subscription;
  isSaving: Boolean;
  routeData: any;
  links: any;
  totalItems: any;
  queryCount: any;
  itemsPerPage: any;
  page: any;
  predicate: any;
  previousPage: any;
  reverse: any;
  loanId = '';
  successMessage: boolean;
  errorMessage: boolean;
  isExceptionalCrrRate: boolean;
  crrRate: string;
  currencyList: Currencies[];
  uobLoan: UOBLoan;

  @ViewChild('submissionDateDp') datePicker1;
  @ViewChild('latestAuditedDateRef') datePicker2;
  @ViewChild('latestSignedDateRef') datePicker3;

  constructor(
    private sponsorEFormService: SponsorEFormService,
    private uobCreditLimitService: UobCreditLimitService,
    private parseLinks: JhiParseLinks,
    private jhiAlertService: JhiAlertService,
    private eventManager: JhiEventManager,
    private principal: Principal,
    private loanService: LoanService,
    private lookup: LookupService,
    private router: Router,
    private _eref: ElementRef,
    private notificationService: NotificationService
  ) {
    this.isExceptionalCrrRate = false;
    this.crrRate = '';
  }
  public onClick(event) {
    // close the datepicker when user clicks outside the element
    if (this._eref.nativeElement.contains(event.target)) {
      if (event.target.children != undefined) {
        if (event.target.children.length > 0) {
          if (event.target.children[0].className != 'fa fa-calendar') {
            this.datePicker1.close();
            this.datePicker2.close();
            this.datePicker3.close();
          }
        }
      }
    }
  }

  callAfterSaveAsDraft() {
    window.scrollTo(0, 0);
    this.successMessage = true;
    setTimeout(() => {
      this.successMessage = false;
    }, 2000);

    if (this.crrRate != '0' && this.isExceptionalCrrRate) {
      this.uobCreditLimit.crrRate = 0;
    }
    // if(this.uobCreditLimit.crrRate )
    // { this.uobCreditLimit.crrRate=this.uobCreditLimit.crrRate.toString();}

    this.setUIDate();
  }

  getDBDate() {
    if (this.uobCreditLimit.submissionDate) {
      this.uobCreditLimit.submissionDate = new DateUtil().getDBDate(
        this.uobCreditLimit.submissionDate
      );
    }
    if (this.uobCreditLimit.latestAuditedDt) {
      this.uobCreditLimit.latestAuditedDt = new DateUtil().getDBDate(
        this.uobCreditLimit.latestAuditedDt
      );
    }
    if (this.uobCreditLimit.latestSignedDt) {
      this.uobCreditLimit.latestSignedDt = new DateUtil().getDBDate(
        this.uobCreditLimit.latestSignedDt
      );
    }
  }

  setUIDate() {
    if (this.uobCreditLimit.submissionDate) {
      this.uobCreditLimit.submissionDate = new DateUtil().setUIDate(
        this.uobCreditLimit.submissionDate
      );
    }
    if (this.uobCreditLimit.latestAuditedDt) {
      this.uobCreditLimit.latestAuditedDt = new DateUtil().setUIDate(
        this.uobCreditLimit.latestAuditedDt
      );
    }
    if (this.uobCreditLimit.latestSignedDt) {
      this.uobCreditLimit.latestSignedDt = new DateUtil().setUIDate(
        this.uobCreditLimit.latestSignedDt
      );
    }
  }

  clear() {
    this.uobCreditLimit = new UobCreditLimit();
  }

  sort() {
    const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
    if (this.predicate !== 'id') {
      result.push('id');
    }
    return result;
  }

  private onSaveError() {
    this.isSaving = false;
  }

  private onError(error) {
    this.jhiAlertService.error(error.message, null, null);
  }

  ngOnDestroy() {}

  ngOnInit() {
    this.uobCreditLimitService.uobCreditLimit$.subscribe(
      (uobForm) => (this.uobCreditLimit = uobForm)
    );
    this.principal.identity().then((account) => {
      this.currentAccount = account;
    });

    if (this.uobCreditLimit.crrRate) {
      const crr = this.uobCreditLimit.crrRate.toString();
      if (
        crr == '1.375' ||
        crr == '1.650' ||
        crr == '1.925' ||
        crr == '2.200' ||
        crr == '1.9250'
      ) {
      } else {
        this.crrRate = this.uobCreditLimit.crrRate.toString();
        this.uobCreditLimit.crrRate = 0;
      }
    }

    this.lookup.getCurrencyList().subscribe((data) => {
      this.currencyList = data;
    });

    this.autoPopulateFromSponserForm();
  }

  autoPopulateFromSponserForm() {
    this.sponsorEFormService.springEForm$.subscribe((sponsorForm) => {
      this.sponsorForm = sponsorForm;
      if (this.sponsorForm) {
        this.uobCreditLimit.borrowerRegName = this.sponsorForm.regComName;
        this.uobCreditLimit.rocRefNo = this.sponsorForm.ACRANo;
        this.uobCreditLimit.sgdCurrency = this.sponsorForm.total;

        this.uobCreditLimit.inventorySGDTxt = this.sponsorForm.invStockFinancing;
        this.uobCreditLimit.inventoryStockChkBx = this.sponsorForm.invStockFinancingChecked;

        this.uobCreditLimit.structuredWorkingCapitalSGDTxt = this.sponsorForm.workingCapital;
        this.uobCreditLimit.structuredWorkingCapitalChkBx = this.sponsorForm.workingCapitalChecked;

        this.uobCreditLimit.withRecourseSGDTxt = this.sponsorForm.aRDiscount;
        this.uobCreditLimit.recourseFactoringBillChkBx = this.sponsorForm.aRDiscountChecked;

        this.uobCreditLimit.overseaseCapitalSGDTxt = this.sponsorForm.capitalLoan;
        this.uobCreditLimit.overseasWorkingCapitalChkBx = this.sponsorForm.capitalLoanChecked;

        this.uobCreditLimit.bankersGuaranteeAmountSGDTxt = this.sponsorForm.bankerGuarantee;
        this.uobCreditLimit.bankersGuaranteeAmountChkBx = this.sponsorForm.bankerGuaranteeChecked;
      }
    });
  }

  auditDateChange() {
    this.datePicker2.close();
    this.uobCreditLimit.latestAuditedDt = '';
  }

  signedDateChage() {
    this.datePicker3.close();
    this.uobCreditLimit.latestSignedDt = ';';
  }

  changeCrr() {
    if (this.uobCreditLimit.crrRate == 0) {
      this.isExceptionalCrrRate = true;
      //this.uobCreditLimit.crrRate=this.crrRate;
    } else {
      this.isExceptionalCrrRate = false;
      this.crrRate = null;
    }
  }

  changeLisType() {
    if (this.uobCreditLimit.lisType) {
      switch (this.uobCreditLimit.lisType) {
        case 'new':
          this.uobCreditLimit.renewalFromSGDTxt = null;
          this.uobCreditLimit.renewalFromUSDTxt = null;
          this.uobCreditLimit.renewalToSGDTxt = null;
          this.uobCreditLimit.renewalToUSDTxt = null;
          this.uobCreditLimit.increaseLimitToSGD = null;
          this.uobCreditLimit.increaseLimitToUSD = null;
          this.uobCreditLimit.decreaseLimitToSGD = null;
          this.uobCreditLimit.decreaseLimitToUSD = null;
          break;
        case 'renewalAtSameAmount':
          this.uobCreditLimit.renewalFromSGDTxt = null;
          this.uobCreditLimit.renewalFromUSDTxt = null;
          this.uobCreditLimit.renewalToSGDTxt = null;
          this.uobCreditLimit.renewalToUSDTxt = null;
          this.uobCreditLimit.increaseLimitToSGD = null;
          this.uobCreditLimit.increaseLimitToUSD = null;
          this.uobCreditLimit.decreaseLimitToSGD = null;
          this.uobCreditLimit.decreaseLimitToUSD = null;
          break;
        case 'renewalFrom':
          this.uobCreditLimit.increaseLimitToSGD = null;
          this.uobCreditLimit.increaseLimitToUSD = null;
          this.uobCreditLimit.decreaseLimitToSGD = null;
          this.uobCreditLimit.decreaseLimitToUSD = null;
          break;
        case 'increaseLimitTo':
          this.uobCreditLimit.renewalFromSGDTxt = null;
          this.uobCreditLimit.renewalFromUSDTxt = null;
          this.uobCreditLimit.renewalToSGDTxt = null;
          this.uobCreditLimit.renewalToUSDTxt = null;
          this.uobCreditLimit.decreaseLimitToSGD = null;
          this.uobCreditLimit.decreaseLimitToUSD = null;
          break;
        case 'decreaseLimitTo':
          this.uobCreditLimit.renewalFromSGDTxt = null;
          this.uobCreditLimit.renewalFromUSDTxt = null;
          this.uobCreditLimit.renewalToSGDTxt = null;
          this.uobCreditLimit.renewalToUSDTxt = null;
          this.uobCreditLimit.increaseLimitToSGD = null;
          this.uobCreditLimit.increaseLimitToUSD = null;
          break;
        default:
          return true;
      }
    } else {
    }
  }

  add() {
    if (this.uobCreditLimit.borrowersGroup) {
      if (this.uobCreditLimit.borrowersGroup.length < 99) {
        this.uobCreditLimit.borrowersGroup.push({ name: '', limit: null });
      } else {
        alert('99 Borrowers Group can bee added.!');
      }
    }
  }

  remove() {
    if (this.uobCreditLimit.borrowersGroup) {
      this.uobCreditLimit.borrowersGroup.pop();
    }
  }

  removeMe(me) {
    for (var i = 0; this.uobCreditLimit.borrowersGroup.length; i++) {
      let borrower = this.uobCreditLimit.borrowersGroup[i];
      if (borrower['name'] === me.name) {
        this.uobCreditLimit.borrowersGroup.splice(i, 1);
        return;
      }
    }
  }

  updateStack(event, supportDoc) {
    if (event.status === 'success') {
      this.uobCreditLimit.supportingDocs.forEach((element) => {
        if (element.name === supportDoc) {
          element.status = true;
          element.files += event.filename + ', ';
        }
      });
    }
  }

  isSupportingDocValidate() {
    let uploadDocumentFor = '';
    this.uobCreditLimit.supportingDocs.forEach((element) => {
      let field = element.name;
      switch (field) {
        case 'sponsersApplication':
          if (!element.status && this.uobCreditLimit.lisSponsersApplChkBx) {
            uploadDocumentFor += '\n -Sponsors’ Application Form.';
          }
          break;

        case 'companySearches':
          if (!element.status && this.uobCreditLimit.companySearchesChkBx) {
            uploadDocumentFor +=
              '\n -Company searches and/or individual searches.';
          }
          break;

        case 'pfiInternalCreditMemo':
          if (!element.status && this.uobCreditLimit.pfiInternalCreditChkBx) {
            uploadDocumentFor += '\n -PFI’s internal Credit Memo Approval.';
          }
          break;

        case 'latestAudited':
          if (!element.status && this.uobCreditLimit.latestAuditedChkBx) {
            uploadDocumentFor += '\n -Latest Audited Financials from Borrower.';
          }
          break;

        case 'latestSigned':
          if (!element.status && this.uobCreditLimit.latestSignedChkBx) {
            uploadDocumentFor +=
              '\n -Latest signed Management Accounts from Borrower';
          }
          break;

        case 'additionalItems':
          if (!element.status && this.uobCreditLimit.additionalItemChkBx) {
            uploadDocumentFor += '\n -Additional Items.';
          }
          break;

        case 'overseasCapital2':
          if (!element.status && this.uobCreditLimit.forOverseasChkBx) {
            uploadDocumentFor += '\n -Oversease working capital.';
          }
          break;

        default:
          break;
      }
    });

    if (uploadDocumentFor) {
      alert('Please upload document for' + uploadDocumentFor);
      return false;
    } else return true;
  }

  validateExchangeCurrency() {
    if (
      this.uobCreditLimit.usdCurrency &&
      !this.uobCreditLimit.currencyExchangeRate
    ) {
      alert('Please enter currency exchange rate as well.');
      return false;
    } else if (
      !this.uobCreditLimit.usdCurrency &&
      this.uobCreditLimit.currencyExchangeRate
    ) {
      alert('Please enter Foreign Currency Amount to endorse.');
      return false;
    }
    return true;
  }

  validateLisType() {
    if (this.uobCreditLimit.lisType) {
      switch (this.uobCreditLimit.lisType) {
        case 'new':
          return true;
        case 'renewalAtSameAmount':
          return true;
        case 'renewalFrom':
          if (
            !this.uobCreditLimit.renewalFromSGDTxt &&
            !this.uobCreditLimit.renewalToSGDTxt
          ) {
            alert('Please enter renewal amount for Type of Application');
            return false;
          } else if (
            this.uobCreditLimit.renewalFromSGDTxt &&
            !this.uobCreditLimit.renewalToSGDTxt
          ) {
            alert('Please enter amount for renewal to SGD.');
            return false;
          } else if (
            !this.uobCreditLimit.renewalFromSGDTxt &&
            this.uobCreditLimit.renewalToSGDTxt
          ) {
            alert('Please enter amount for renewal From SGD.');
            return false;
          } else return true;
        case 'increaseLimitTo':
          if (
            !this.uobCreditLimit.increaseLimitToSGD &&
            !this.uobCreditLimit.increaseLimitToUSD
          ) {
            alert('Please enter increase limit amount for Type of Application');
            return false;
          } else if (
            this.uobCreditLimit.increaseLimitToSGD &&
            this.uobCreditLimit.increaseLimitToUSD
          ) {
            alert(
              'Please enter increase limit amount either for SGD or ' +
                this.uobCreditLimit.foreignCurrency
            );
            return false;
          } else return true;
        case 'decreaseLimitTo':
          if (
            !this.uobCreditLimit.decreaseLimitToSGD &&
            !this.uobCreditLimit.decreaseLimitToUSD
          ) {
            alert('Please enter decrease limit amount for Type of Application');
            return false;
          } else if (
            this.uobCreditLimit.decreaseLimitToSGD &&
            this.uobCreditLimit.decreaseLimitToUSD
          ) {
            alert(
              'Please enter decrease limit amount either for SGD or ' +
                this.uobCreditLimit.foreignCurrency
            );
            return false;
          } else return true;
        default:
          return true;
      }
    } else {
      alert('Please select type of Application.');
      return false;
    }
  }

  onlyNumberKey(event) {
    return event.charCode == 8 || event.charCode == 0 || event.charCode == 46
      ? null
      : event.charCode >= 48 && event.charCode <= 57;
    //|| event.charCode == 44
  }

  goToUploadForm() {
    if (!this.validateLisType()) {
      return false;
    }

    if (!this.validateExchangeCurrency()) {
      return false;
    }

    if (!this.isSupportingDocValidate()) {
      return false;
    }

    if (this.crrRate !== '0' && this.isExceptionalCrrRate) {
      this.uobCreditLimit.crrRate = parseFloat(this.crrRate);
    }
    this.uobCreditLimitService.setUOBCreditLimit(this.uobCreditLimit);
    this.router.navigate(['/loan/sponsor-eform-upload']);
  }

  saveAsDraft() {
    this.updateLoan();
  }

  submitLoan() {
    this.updateLoan('In Processing');
  }

  updateLoan(status?: string) {
    this.getDBDate();
    this.setValidSponsorValue();
    const dateofIncorporation = this.sponsorForm.dateofIncorporation;

    if (this.sponsorForm.dateofIncorporation) {
      const date = new DateUtil().getDBDate(
        this.sponsorForm.dateofIncorporation
      );
      this.sponsorForm.dateofIncorporation = date;
    } else {
      this.sponsorForm.dateofIncorporation = '00-00-0000';
    }
    this.loanId = this.loanService.getId();
    this.uobLoan = new UOBLoan();
    this.uobLoan._id = this.loanId;
    this.uobLoan.creditInfo = this.uobCreditLimit;
    this.uobLoan.sponsorForm = this.sponsorForm;

    if (this.crrRate !== '0' && this.isExceptionalCrrRate) {
      if (this.crrRate) {
        const crrRate = parseFloat(this.crrRate).toFixed(3);
        this.uobLoan.creditInfo.crrRate = parseInt(crrRate, 10);
      }
    }

    this.isSaving = true;
    if (this.loanId) {
      if (status) {
        this.uobLoan.status = status;
        this.loanService.submitLoan(this.uobLoan).subscribe((res) => {
          this.loanService.setStatus(res.status);
          window.scrollTo(0, 0);
          const marshRefNo = res.marshRefNo;
          const message: Message = {
            severity: 'success',
            summary: 'Success',
            detail: 'Loan Application Submitted Sucessfully'
          };
          this.notificationService.showNotification(message);
          //   this.userMessage =
          //     'Application submitted successfully. \n Marsh Reference Id is ' +
          //     marshRefNo;
        });
      } else {
        this.loanService.updateLoan(this.uobLoan).subscribe((res) => {
          this.notificationService.showNotification();
          this.callAfterSaveAsDraft();
        });
      }
    }
    this.sponsorForm.dateofIncorporation = dateofIncorporation;
  }

  setValidSponsorValue() {
    this.sponsorForm.invStockFinancing =
      this.sponsorForm.invStockFinancing == null
        ? 0
        : this.sponsorForm.invStockFinancing;
    this.sponsorForm.workingCapital =
      this.sponsorForm.workingCapital == null
        ? 0
        : this.sponsorForm.workingCapital;
    this.sponsorForm.aRDiscount =
      this.sponsorForm.aRDiscount == null ? 0 : this.sponsorForm.aRDiscount;
    this.sponsorForm.capitalLoan =
      this.sponsorForm.capitalLoan == null ? 0 : this.sponsorForm.capitalLoan;
    this.sponsorForm.bankerGuarantee =
      this.sponsorForm.bankerGuarantee == null
        ? 0
        : this.sponsorForm.bankerGuarantee;
  }
}
