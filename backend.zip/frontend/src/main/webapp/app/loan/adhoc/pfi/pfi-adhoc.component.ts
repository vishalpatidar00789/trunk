import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';

import { PFIAdhoc } from './pfi-adhoc.model';
import { PFIAdhocService } from './pfi-adhoc.service';
import { Principal, FileUploadComponent } from '../../../shared';

@Component({
    selector: 'jhi-pfi-adhoc',
    templateUrl: './pfi-adhoc.component.html'
})
export class PFIAdhocComponent implements OnInit, OnDestroy {

    filesToUpload: Array<File> = [];

    displayMessage: boolean = false;
    userMessage: string;
    adhocApplicationStatus: string;

    currencies = ['AUD', 'CNY', 'EUR', 'HKD', 'IDR', 'INR', 'JPY', 'KRW', 'MYR', 'NOK', 'PHP', 'THB', 'TWD', 'USD'];
    pfiAdhoc: PFIAdhoc = new PFIAdhoc();
    currentAccount: any;
    eventSubscriber: Subscription;
    isSaving: Boolean;
    routeData: any;
    links: any;
    totalItems: any;
    queryCount: any;
    itemsPerPage: any;
    page: any;
    predicate: any;
    previousPage: any;
    reverse: any;

    constructor(
        private pfiCreditService: PFIAdhocService,
        private parseLinks: JhiParseLinks,
        private jhiAlertService: JhiAlertService,
        private eventManager: JhiEventManager,
        private router: Router,
        private principal: Principal) {
    }

    onCheckboxChange(checkbox: string) {
        // TODO: To implement the reset logic for sections like section1
        // if (this.pfiAdhoc[checkbox] == false) {
        //     confirm("All information in this section will be lost. Do you want to continue?");
        // }
    }

    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0 || event.charCode == 46 || event.charCode == 44) ? null : event.charCode >= 48 && event.charCode <= 57;
    }

    saveAsDraft() {
        window.scrollTo(0, 0);
        this.displayMessage = true;
        this.adhocApplicationStatus ="Draft";
        this.userMessage = "Additional information saved succesfully."
        setTimeout(() => { this.displayMessage = false; }, 4000);
    }

    save() {
        if (!this.isValidate()) {
            return;
        }
        window.scrollTo(0, 0);
        this.displayMessage = true;
        this.userMessage = "Application submitted successfully";
        setTimeout(() => { this.displayMessage = false; }, 4000);
    }

    clear() {
        if (confirm("Are you sure, you want to cancel?")) {
            this.pfiAdhoc = new PFIAdhoc();
            this.router.navigateByUrl('/');
        }
    }

    private subscribeToSaveResponse(result: Observable<PFIAdhoc>) {
        result.subscribe((res: PFIAdhoc) =>
            this.onSaveSuccess(res), (res: Response) => this.onSaveError());
    }

    private onSaveSuccess(result: PFIAdhoc) {
        this.eventManager.broadcast({ name: 'pfiAdhocListModification', content: 'OK' });
        this.isSaving = false;
    }

    private onSaveError() {
        this.isSaving = false;
    }

    ngOnInit() {

    }

    ngOnDestroy() {

    }

    sort() {
        const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
        if (this.predicate !== 'id') {
            result.push('id');
        }
        return result;
    }
    private onError(error) {
        this.jhiAlertService.error(error.message, null, null);
    }



    // isValidate() {
    //     let uploadDocumentFor = '';

    //     if (this.pfiAdhoc.exRate && !this.pfiAdhoc.foreignCurrency) {
    //         alert("Please enter Foreign Currency Amount to endorse as well with Eschange rate.");
    //     }
    //     else if (!this.pfiAdhoc.exRate && this.pfiAdhoc.foreignCurrency) {
    //         alert("Please enter Exchange rate with Foreign Currency Amount.");
    //     }

    //     if (uploadDocumentFor) {
    //         alert("Please upload document for" + uploadDocumentFor);
    //         return false;
    //     } else
    //         return true;

    // }

    reset(fields: string[]) {
        fields.forEach(element => {
            this.pfiAdhoc[element] = null;
        });
    }

    updateStack(event, supportDoc) {

        if (event.status == "success") {
            this.pfiAdhoc.supportingDocs.forEach(element => {
                if (element.name == supportDoc) {
                    element.status = true;
                    element.files += event.filename;
                    console.log(element.files);
                }
            });
        }
    }

    isValidate() {

        let uploadDocumentFor = '';
        this.pfiAdhoc.supportingDocs.forEach(element => {
            let field = element.name;
            switch (field) {
                case "preshipmentApproval":
                    if (!element.status && this.pfiAdhoc.insurersApprovalChkBx) {
                        uploadDocumentFor += '\n -Insurers’ approval for Pre-shipment financing.';
                    }
                    break;

                case "billInformation":
                    if (!element.status && this.pfiAdhoc.billInfoChkBx) {
                        uploadDocumentFor += '\n -Extension of Due Date of Bill.';
                    }
                    break;

                default:
                    break;
            }
        });

        if (uploadDocumentFor) {
            alert("Please upload document for" + uploadDocumentFor);
            return false;
        } else
            return true;
    }

    isDocumentValidate() {
        // TODO: Update the logic as per mandatory fields
        return !(this.pfiAdhoc.cancellationSectionChkBx || this.pfiAdhoc.expiryExtensionChkBx || this.pfiAdhoc.dueDateExtensionChkBx
            || this.pfiAdhoc.overseasBuyerChkBx || this.pfiAdhoc.preShipmentChkBx || this.pfiAdhoc.moreTimeLoChkBx
            || this.pfiAdhoc.adverseInformationChkBx || this.pfiAdhoc.newDisbursementsChkBx || this.pfiAdhoc.reValidateInsuranceChkBx
            || this.pfiAdhoc.processRequestChkBx);
    }
}
