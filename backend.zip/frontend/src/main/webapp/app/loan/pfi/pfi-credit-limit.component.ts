import {
  Component,
  OnInit,
  OnDestroy,
  ElementRef,
  ViewChild
} from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';
import { NgForm } from '@angular/forms';
import { PFICreditLimit } from './pfi-credit-limit.model';
import { PFICreditLimitService } from './pfi-credit-limit.service';
import { LoanService } from '../loan.service';
import {
  Principal,
  FileUploadComponent,
  Account,
  LookupService,
  Currencies
} from '../../shared';
import { SponsorEForm } from '../sponsor-eform/sponsor-eform.model';
import { DateUtil } from '../../shared/date-formatter/date-util';
import { SponsorEFormService } from '../sponsor-eform/sponsor-eform.service';
import { Message } from 'primeng/components/common/api';
import { NotificationService } from '../../shared/alert/notification.service';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { PFILoan, LoanProcess, CompletedStep } from '../loan.model';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'jhi-pfi-credit-limit',
  templateUrl: './pfi-credit-limit.component.html',
  host: {
    '(document:click)': 'onClick($event)'
  }
})
export class PFICreditLimitComponent implements OnInit, OnDestroy {
  loanProcess: LoanProcess;
  filesToUpload: Array<File> = [];
  data: any = [];
  pfiCreditLimit: PFICreditLimit = new PFICreditLimit();
  sponsorForm: SponsorEForm = new SponsorEForm();
  pfiLoan: PFILoan;
  eventSubscriber: Subscription;
  isSaving: Boolean;
  routeData: any;
  links: any;
  totalItems: any;
  queryCount: any;
  itemsPerPage: any;
  page: any;
  predicate: any;
  previousPage: any;
  reverse: any;
  loanId = '';
  currentAccount: Account;
  currencyList: Currencies[];
  disableFutureDate: Date;

  // @ViewChild('submissionDateRef') datePicker1;
  // @ViewChild('latestAuditedDateRef') datePicker2;
  // @ViewChild('latestSignedDateRef') datePicker3;
  //@ViewChildren("submissionDateRef", "latestAuditedDateRef","latestSignedDateRef") ngbdatepicker:

  constructor(
    private sponsorEFormService: SponsorEFormService,
    private pfiCreditService: PFICreditLimitService,
    private parseLinks: JhiParseLinks,
    private jhiAlertService: JhiAlertService,
    private eventManager: JhiEventManager,
    private principal: Principal,
    private loanService: LoanService,
    private router: Router,
    private lookup: LookupService,
    private _eref: ElementRef,
    private notificationService: NotificationService,
    private spinner: NgxSpinnerService
  ) {
    this.disableFutureDate = new Date();
    this.loanService.loanProcess$.subscribe((loanProcess) => {
      this.loanProcess = Object.assign({}, loanProcess);
    });
  }

  // public onClick(event) {
  //   // close the datepicker when user clicks outside the element
  //   if (this._eref.nativeElement.contains(event.target)) {
  //     if (event.target.children != undefined) {
  //       if (event.target.children.length > 0) {
  //         if (event.target.children[0].className != 'fa fa-calendar') {
  //           //this.datePicker1.close();
  //           this.datePicker2.close();
  //           this.datePicker3.close();
  //         }
  //       }
  //     }
  //   }
  // }

  getDBDate() {
    if (this.pfiCreditLimit.submissionDate) {
      this.pfiCreditLimit.submissionDate = new DateUtil().getDBDate(
        this.pfiCreditLimit.submissionDate
      );
    }
    if (this.pfiCreditLimit.latestAuditedDt) {
      this.pfiCreditLimit.latestAuditedDt = new DateUtil().getDBDate(
        this.pfiCreditLimit.latestAuditedDt
      );
    }
    if (this.pfiCreditLimit.latestSignedDt) {
      this.pfiCreditLimit.latestSignedDt = new DateUtil().getDBDate(
        this.pfiCreditLimit.latestSignedDt
      );
    }
  }

  setUIDate() {
    if (this.pfiCreditLimit.submissionDate) {
      this.pfiCreditLimit.submissionDate = new DateUtil().setUIDate(
        this.pfiCreditLimit.submissionDate
      );
    }
    if (this.pfiCreditLimit.latestAuditedDt) {
      this.pfiCreditLimit.latestAuditedDt = new DateUtil().setUIDate(
        this.pfiCreditLimit.latestAuditedDt
      );
    }
    if (this.pfiCreditLimit.latestSignedDt) {
      this.pfiCreditLimit.latestSignedDt = new DateUtil().setUIDate(
        this.pfiCreditLimit.latestSignedDt
      );
    }
  }

  add() {
    if (this.pfiCreditLimit.borrowersGroup) {
      if (this.pfiCreditLimit.borrowersGroup.length < 99) {
        this.pfiCreditLimit.borrowersGroup.push({ name: '' });
      } else {
        alert('99 Borrowers Group can bee added.!');
      }
    }
  }

  remove() {
    if (this.pfiCreditLimit.borrowersGroup) {
      this.pfiCreditLimit.borrowersGroup.pop();
    }
  }

  removeMe(me) {
    for (var i = 0; this.pfiCreditLimit.borrowersGroup.length; i++) {
      let borrower = this.pfiCreditLimit.borrowersGroup[i];
      if (borrower['name'] === me.name) {
        this.pfiCreditLimit.borrowersGroup.splice(i, 1);
        return;
      }
    }
  }

  clear() {
    this.pfiCreditLimit = new PFICreditLimit();
  }

  private onSaveError() {
    this.isSaving = false;
  }

  auditDateChange() {
    //this.datePicker2.close();
    this.pfiCreditLimit.latestAuditedDt = '';
  }

  signedDateChage() {
    //this.datePicker3.close();
    this.pfiCreditLimit.latestSignedDt = ';';
  }

  ngOnInit() {
    this.pfiCreditService.pfiCreditLimit$.subscribe(
      (pfiForm) => (this.pfiCreditLimit = pfiForm)
    );
    // this.loanService.currentPFICreditLimit.subscribe(
    //   (Result) => (this.pfiCreditLimit = Result)
    // );
    this.principal.identity().then((account) => {
      if (account) {
        this.currentAccount = account;
        if (this.currentAccount.bank) {
          this.lookup
            .getBankByCode(this.currentAccount.bank)
            .subscribe((bank) => {
              if (bank) {
                this.pfiCreditLimit.pfiName = bank.bankName;
              } else {
                //if b ank is not there
                alert('NO BANK IS ASSIGNED TO THIS USER..!');
              }
            });
        }
      }
    });

    this.lookup.getCurrencyList().subscribe((data) => {
      this.currencyList = data;
    });

    this.autoPopulateFromSponser();
  }

  private autoPopulateFromSponser() {
    this.sponsorEFormService.springEForm$.subscribe((sponsorForm) => {
      this.sponsorForm = sponsorForm;
      if (this.sponsorForm) {
        this.pfiCreditLimit.borrowerRegName = this.sponsorForm.regComName;
        this.pfiCreditLimit.aCRArefNo = this.sponsorForm.ACRANo;
        this.pfiCreditLimit.totalRequstedLimitSGD = this.sponsorForm.total;

        this.pfiCreditLimit.inventoryTradeTxt = this.sponsorForm.invStockFinancing;
        this.pfiCreditLimit.inventoryTradeChkBx = this.sponsorForm.invStockFinancingChecked;

        this.pfiCreditLimit.structuredWorkingCapTxt = this.sponsorForm.workingCapital;
        this.pfiCreditLimit.workingCapChkBx = this.sponsorForm.workingCapitalChecked;

        this.pfiCreditLimit.resourceFactoringTxt = this.sponsorForm.aRDiscount;
        this.pfiCreditLimit.resourceFactoringChkBx = this.sponsorForm.aRDiscountChecked;

        this.pfiCreditLimit.overseaseWorkingTxt = this.sponsorForm.capitalLoan;
        this.pfiCreditLimit.overseaseWorkingChkBx = this.sponsorForm.capitalLoanChecked;

        this.pfiCreditLimit.bankersGuaranteeTxt = this.sponsorForm.bankerGuarantee;
        this.pfiCreditLimit.bankersGuaranteeChkBx = this.sponsorForm.bankerGuaranteeChecked;
      }
    });
  }

  ngOnDestroy() {}

  private onError(error) {
    this.jhiAlertService.error(error.message, null, null);
  }

  updateStack(event, supportDoc) {
    if (event.status === 'success') {
      this.pfiCreditLimit.supportingDocs.forEach((element) => {
        if (element.name === supportDoc) {
          element.status = true;
          element.files += event.filename + ', ';
        }
      });
    }
  }

  isValidate() {
    let uploadDocumentFor = '';
    this.pfiCreditLimit.supportingDocs.forEach((element) => {
      let field = element.name;
      switch (field) {
        case 'overseasCapital':
          if (!element.status && this.pfiCreditLimit.overseaseWorkingChkBx) {
            uploadDocumentFor +=
              '\n -Overseas Working Capital Loans Support in section 1.';
          }
          break;

        case 'preshipmentApproval':
          if (!element.status && this.pfiCreditLimit.preshipmentApprovalChkBx) {
            uploadDocumentFor += '\n -Pre-shipment approval is required.';
          }
          break;

        case 'sponsersApplication':
          if (!element.status && this.pfiCreditLimit.lisSponsersApplChkBx) {
            uploadDocumentFor += '\n -Sponsors’ Application Form.';
          }
          break;

        case 'companySearches':
          if (!element.status && this.pfiCreditLimit.companySearchesChkBx) {
            uploadDocumentFor +=
              '\n -Company searches and/or individual searches.';
          }
          break;

        case 'pfiInternalCreditMemo':
          if (!element.status && this.pfiCreditLimit.pfiInternalCreditChkBx) {
            uploadDocumentFor += '\n -PFI’s internal Credit Memo Approval.';
          }
          break;

        case 'latestAudited':
          if (!element.status && this.pfiCreditLimit.latestAuditedChkBx) {
            uploadDocumentFor += '\n -Latest Audited Financials from Borrower.';
          }
          break;

        case 'latestSigned':
          if (!element.status && this.pfiCreditLimit.latestSignedChkBx) {
            uploadDocumentFor +=
              '\n -Latest signed Management Accounts from Borrower';
          }
          break;

        case 'additionalItems':
          if (!element.status && this.pfiCreditLimit.additionalItemChkBx) {
            uploadDocumentFor += '\n -Additional Items.';
          }
          break;

        case 'overseasCapital2':
          if (!element.status && this.pfiCreditLimit.forOverseasChkBx) {
            uploadDocumentFor += '\n -Oversease working capital in section 3.';
          }
          break;

        default:
          break;
      }
    });

    if (uploadDocumentFor) {
      alert('Please upload document for' + uploadDocumentFor);
      return false;
    } else return true;
  }

  isDocumentValidate() {
    this.pfiCreditLimit.supportingDocs.forEach((element) => {
      if (
        element.name == 'sponsersApplication' ||
        element.name == 'companySearches' ||
        element.name == 'pfiInternalCreditMemo' ||
        element.name == 'latestAudited' ||
        element.name == 'latestSigned'
      ) {
        if (!element.status) {
          alert('Please upload all the mandatory document.');
          return false;
        }
      }
    });

    return true;
  }

  validateExchangeCurrency() {
    if (
      this.pfiCreditLimit.foreignCurrencyAmount &&
      !this.pfiCreditLimit.exRate
    ) {
      alert('Please enter currency exchange rate as well.');
      return false;
    } else if (
      !this.pfiCreditLimit.foreignCurrencyAmount &&
      this.pfiCreditLimit.exRate
    ) {
      alert('Please enter Foreign Currency Amount to endorse.');
      return false;
    } else if (
      this.pfiCreditLimit.foreignCurrencyAmount &&
      this.pfiCreditLimit.exRate
    ) {
      if (!this.pfiCreditLimit.foreignCurrency) {
        alert('Please select Foreign Currency type.');
        return false;
      }
    }
    return true;
  }

  onlyNumberKey(event) {
    return event.charCode == 8 || event.charCode == 0 || event.charCode == 46
      ? null
      : event.charCode >= 48 && event.charCode <= 57;
    //|| event.charCode == 44
  }

  goToUploadForm() {
    if (!this.validateExchangeCurrency()) {
      return false;
    }

    if (!this.isValidate()) {
      return;
    }
    if (!this.isDocumentValidate()) {
      return;
    }
    this.pfiCreditService.setPFICreditLimit(this.pfiCreditLimit);
    this.router.navigate(['/loan/sponsor-eform-upload']);
  }

  saveAsDraft() {
    this.updateLoan();
  }

  updateLoan(status?: string) {
    this.spinner.show();
    //this.getDBDate();
    this.setValidSponsorValue();
    const dateofIncorporation = this.sponsorForm.dateofIncorporation;

    if (this.sponsorForm.dateofIncorporation) {
      const date = new DateUtil().getDBDate(
        this.sponsorForm.dateofIncorporation
      );
      this.sponsorForm.dateofIncorporation = date;
    } else {
      this.sponsorForm.dateofIncorporation = '00-00-0000';
    }
    this.loanId = this.loanService.getId();
    this.pfiLoan = new PFILoan();
    this.pfiLoan._id = this.loanId;
    this.pfiLoan.creditInfo = this.pfiCreditLimit;
    this.pfiLoan.sponsorForm = this.sponsorForm;

    this.isSaving = true;
    if (this.loanId) {
      if (status) {
        this.pfiLoan.status = status;
        this.loanService.submitLoan(this.pfiLoan).subscribe((loanResult) => {
          const loanProcess = this.loanProcess;
          loanProcess.status = loanResult.status;
          loanProcess.completedStep = CompletedStep.stepCompleted;
          loanProcess.marshRefNo = loanResult.marshRefNo;
          this.loanProcess = Object.assign({}, loanProcess);
          this.loanService.setLoanStepProcess(this.loanProcess);
          //this.loanService.setStatus(loanResult.status);
          //window.scrollTo(0, 0);
          const message: Message = {
            severity: 'success',
            summary: 'Success',
            detail: 'Application Submitted Sucessfully'
          };
          this.spinner.hide();
          this.notificationService.showNotification(message);
          //   this.userMessage =
          //     'Application submitted successfully. \n Marsh Reference Id is ' +
          //     marshRefNo;
        });
      } else {
        this.loanService.updateLoan(this.pfiLoan).subscribe((res) => {
          this.spinner.hide();
          this.notificationService.showNotification();
          this.callAfterSaveAsDraft();
        });
      }
    }
    this.sponsorForm.dateofIncorporation = dateofIncorporation;
  }

  callAfterSaveAsDraft() {
    //window.scrollTo(0, 0);
    //this.setUIDate();
  }

  submitLoan() {
    this.updateLoan('Processing');
  }

  setValidSponsorValue() {
    this.sponsorForm.invStockFinancing =
      this.sponsorForm.invStockFinancing == null
        ? 0
        : this.sponsorForm.invStockFinancing;
    this.sponsorForm.workingCapital =
      this.sponsorForm.workingCapital == null
        ? 0
        : this.sponsorForm.workingCapital;
    this.sponsorForm.aRDiscount =
      this.sponsorForm.aRDiscount == null ? 0 : this.sponsorForm.aRDiscount;
    this.sponsorForm.capitalLoan =
      this.sponsorForm.capitalLoan == null ? 0 : this.sponsorForm.capitalLoan;
    this.sponsorForm.bankerGuarantee =
      this.sponsorForm.bankerGuarantee == null
        ? 0
        : this.sponsorForm.bankerGuarantee;
  }
}
