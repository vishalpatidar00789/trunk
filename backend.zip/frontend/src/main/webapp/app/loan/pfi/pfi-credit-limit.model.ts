export class PFICreditLimit {
    constructor(
        public _id?: string,
        public lisCoinsurer?: string,
        public pfiName?: string,
        public requestorName?: string,
        public submissionDate?: any,
        public aCRArefNo?: string,
        public borrowerRegName?: string,
        public totalRequstedLimitSGD?: number,
        public preshipmentApprovalChkBx?: boolean,
        public exRate?: number,
        public foreignCurrencyAmount?: number,
        public primary?: number,
        public autoTopUp?: number,
        public bg?: number,
        public lisPlus?: number,
        public inventoryChkBx?: boolean,
        public workingCapChkBx?: boolean,
        public factoringChkBx?: boolean,
        public overseaseWorkingChkBx?: boolean,
        public overseaseWorkingTxt?: number,
        public bankersGuaranteeChkBx?: boolean,
        public tempIncreaseLimitChkBx?: boolean,
        public midTermIncreaseLimitChkBx?: boolean,
        public decreaseLimitChkBx?: boolean,
        public beforeMidTermIncreaseLimitChkBx?: boolean,
        public beforeDecreaseLimitChkBx?: boolean,
        public resourceFactoringChkBx?: boolean,
        public loanQuantumChkBx?: boolean,
        public operatongTrackChkBx?: boolean,
        public latestAuditedChkBx?: boolean,
        public auditedFinanceChkBx?: boolean,
        public applicationChkBx?: boolean,
        public bankersGuaranteeBChkBx?: boolean,
        public guaranteeAmountChkBx?: boolean,
        public guaranteeAmount2ChkBx?: boolean,
        public bankersGuaranteeB2ChkBx?: boolean,
        public principalChkBx?: boolean,
        public lisSponsersApplChkBx?: boolean,
        public companySearchesChkBx?: boolean,
        public pfiInternalCreditChkBx?: boolean,
        public latestSignedChkBx?: boolean,
        public additionalItemChkBx?: boolean,
        public forOverseasChkBx?: boolean,
        public inventoryTxt?: string,
        public structuredWorkingCapTxt?: number,
        public inventoryTradeTxt?: number,
        public resourceFactoringTxt?: number,
        public additionalItemTxt?: string,
        public beforeMidTermIncreaseLimitTxt?: number,
        public decreaseLimitTxt?: number,
        public beforeDecreaseLimitTxt?: number,
        public tempIncreaseLimitTxt?: number,
        public midTermIncreaseLimitTxt?: number,
        public bankersGuaranteeTxt?: number,
        public latestSignedDt?: any,
        public latestAuditedDt?: any,
        public borrowersGroup?: [{"name":string}],
        public inventoryTradeChkBx?: boolean,
        public latestAuditFinanceChkBx?:boolean,
        public foreignCurrency?:string,
        public supportingDocs?:any        

    ) {         

        this.borrowersGroup = [{ name: '' }];
        
        this.lisCoinsurer = "Coface, Chubb, Tokio Marine Kiln and Tokio Marine Insurance Singapore";

        this.supportingDocs= [
                {name: 'preshipmentApproval', id: '', status: false,files:''},
                {name: 'overseasCapital', id: '', status: false,files:''},
                {name: 'sponsersApplication', id: '', status: false,files:''},
                {name: 'companySearches', id: '', status: false,files:''},
                {name: 'pfiInternalCreditMemo', id: '', status: false,files:''},
                {name: 'latestAudited', id: '', status: false,files:''},
                {name: 'latestSigned', id: '', status: false,files:''},
                {name: 'additionalItems', id: '', status: false,files:''},
                {name: 'overseasCapital2', id: '', status: false,files:''}
        ]
          
    }
}