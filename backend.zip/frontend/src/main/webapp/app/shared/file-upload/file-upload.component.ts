import { Component, EventEmitter, Output } from '@angular/core';
import { FileUploadService } from './file-upload.service';


@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html'
})
export class FileUploadComponent {

  @Output() public uploadEvent = new EventEmitter();

  tickVisible : boolean;
  fileUploadResult: any;
  filename: string;
  filesToUpload: Array<File>;

  constructor(private fuService: FileUploadService) {
    this.tickVisible = false;
    this.filename = "";
    this.filesToUpload = [];
  }

  BrowseAndUpload(fileInput: any){
    this.filesToUpload = <Array<File>>fileInput.target.files;
    this.upload();
  }

  fileChangeEvent(fileInput: any, input: any) {
    this.tickVisible = false;

    this.filesToUpload = <Array<File>>fileInput.target.files;
    //console.log(this.filesToUpload);
    if (this.filesToUpload.length == 1){
      input.value = this.filesToUpload[0].name;
      this.filename = this.filesToUpload[0].name;
    }     
    else input.value = this.filesToUpload.length + ' files';
  }

  upload() {
    let fileSize: any;
    const formData = new FormData();
    const files: Array<File> = this.filesToUpload;

    if (files.length == 0) {
      alert("Please select file to upload..!")
      return;
    }
    for (let i = 0; i < files.length; i++) {
      formData.append("uploads", files[i], files[i]['name']);
      fileSize = (files[i].size / 1024);
    }

    if ((fileSize / 1024) > 20) {
      alert("File size must be less than 20 MB.");
      return;
    }

    this.fuService.uploadFile(formData).
      subscribe(result => {
        this.fileUploadResult = result;
        let message = this.fileUploadResult.message;        
        if (message === "success") {
          this.tickVisible = true;
          this.fileUploaded();
        }
        else if (message == "error")
          this.tickVisible = false;
      });

  }

  fileUploaded() {
    this.uploadEvent.emit({ status: "success", filename: this.filename });
  }

  getStyle(): any {
    return {
      'visibility': this.tickVisible ? 'visible' : 'hidden'
    };
  }

}