import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FileUploadComponent} from './file-upload/file-upload.component';
import { FileUploadService } from './file-upload/file-upload.service';
import { NgbDateMomentParserFormatter } from './date-formatter/ngb-date-formatter';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import {
    LisAppSharedLibsModule,
    LisAppSharedCommonModule,
    CSRFService,
    AuthServerProvider,
    AccountService,
    UserService,
    StateStorageService,
    LoginService,
    LoginModalService,
    JhiLoginModalComponent,
    Principal,
    HasAnyAuthorityDirective,
    BankTypeVerificationDirective,
    LookupService    
} from './';
import {MasterdataService} from './masterdata/masterdata.service';
import { NotificationService } from './alert/notification.service';

@NgModule({
    imports: [
        LisAppSharedLibsModule,
        LisAppSharedCommonModule
    ],
    declarations: [
        JhiLoginModalComponent,
        HasAnyAuthorityDirective,
        BankTypeVerificationDirective,
        FileUploadComponent
    ],
    providers: [
        LoginService,
        LoginModalService,
        AccountService,
        StateStorageService,
        Principal,
        CSRFService,
        AuthServerProvider,
        UserService,
        DatePipe,
        LookupService,
        MasterdataService,
        FileUploadService,
        NotificationService,
        {
            // provide: NgbDateParserFormatter, 
            // useClass: NgbDateFRParserFormatter
            provide: NgbDateParserFormatter, 
            useFactory: () => { return new NgbDateMomentParserFormatter("DD-MMM-YY") } 
        }
    ],
    entryComponents: [JhiLoginModalComponent,FileUploadComponent],
    exports: [
        LisAppSharedCommonModule,
        JhiLoginModalComponent,
        HasAnyAuthorityDirective,
        BankTypeVerificationDirective,
        DatePipe,        
        FileUploadComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]

})
export class LisAppSharedModule {}
