export class App {
    //public _id?: string;
    public trancheName: string;
    public app: number;
    public appFrom: string;
    public appto: string;
    public lastUpdatedBy: string;
    // public createdBy: string;
    // public lastModifiedBy: string;
    // public createdDate: string;
    // public lastModifiedDate: string;
    constructor(
        //_id?: any,
        trancheName?: string,
        app?: number,
        appFrom?: string,
        appto?: string,
        lastUpdatedBy?: string,
        // createdBy?: string,
        // createdDate?: string,
        // lastModifiedBy?: string,
        // lastModifiedDate?: string
    ) {
        //this._id = _id ? _id : null;
        this.trancheName = trancheName ? trancheName : null;
        this.app = app ? app : null;
        this.appFrom=appFrom?appFrom:'';
        this.appto=appto?appto:'';
        // this.createdBy = createdBy ? createdBy : null;
        // this.createdDate = createdDate ? createdDate : null;
        // this.lastModifiedBy = lastModifiedBy ? lastModifiedBy : null;
        // this.lastModifiedDate = lastModifiedDate ? lastModifiedDate : null;
    }
}