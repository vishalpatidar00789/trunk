import { Injectable } from '@angular/core';
import { MessageService } from 'primeng/components/common/messageservice';
import { Message } from 'primeng/components/common/api';

@Injectable()
export class NotificationService {
  constructor(private messageService: MessageService) {}

  showNotification(messageObj?: Message) {
    if (!messageObj) {
      messageObj = {
        severity: 'success',
        summary: 'Sucess',
        detail: 'Data Saved Sucessfully'
      };
    }
    this.messageService.clear();
    this.messageService.add(messageObj);
  }
}
