import * as Mongoose from "mongoose";
import { IDataConfiguration } from "./configurations";
import { ILogging, LoggingModel } from "./plugins/logging/logging";
import { IUser, UserModel } from "./api/users/user";
import { IBank, BankModel } from "./api/lookup/banks/bank";
import { IAuthority, AuthorityModel } from "./api/lookup/authorities/authority";
import { IDepartment, DepartmentModel } from "./api/lookup/departments/department";

export interface IDatabase {
  loggingModel: Mongoose.Model<ILogging>;
  userModel: Mongoose.Model<IUser>;
  bankModel: Mongoose.Model<IBank>;
  authorityModel: Mongoose.Model<IAuthority>;
  departmentModel: Mongoose.Model<IDepartment>;
}

export function init(config: IDataConfiguration): IDatabase {
  (<any>Mongoose).Promise = Promise;
  Mongoose.connect(process.env.MONGO_URL || config.connectionString);

  let mongoDb = Mongoose.connection;

  mongoDb.on("error", () => {
    console.log(`Unable to connect to database: ${config.connectionString}`);
  });

  mongoDb.once("open", () => {
    console.log(`Connected to database: ${config.connectionString}`);
  });

  return {
    loggingModel: LoggingModel,
    userModel: UserModel,
    bankModel: BankModel,
    authorityModel: AuthorityModel,
    departmentModel: DepartmentModel
  };
}
