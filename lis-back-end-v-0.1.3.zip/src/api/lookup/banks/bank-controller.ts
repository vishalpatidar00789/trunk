import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IBank } from "./bank";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest } from "../../../interfaces/request";
export default class BankController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }

  public async getAllBanks(request: IRequest, h: Hapi.ResponseToolkit) {
    let banks: IBank[] = await this.database.bankModel.find({ activated: true }).lean(true);
    if (banks) {
      return banks;
    } else {
      return Boom.notFound();
    }
  }
}