import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IAuthority } from "./authority";
import { IDatabase } from "../../../database";
import { IServerConfigurations } from "../../../configurations";
import { IRequest } from "../../../interfaces/request";
export default class AuthorityController {
  private database: IDatabase;
  private configs: IServerConfigurations;
  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }

  public async getAllAuthorities(request: IRequest, h: Hapi.ResponseToolkit) {
    let authorities: IAuthority[] = await this.database.authorityModel.find({ activated: true }).lean(true);
    if (authorities) {
      return authorities;
    } else {
      return Boom.notFound();
    }
  }
}