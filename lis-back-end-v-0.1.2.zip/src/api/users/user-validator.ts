import * as Joi from "joi";

export const createUserModel = Joi.object().keys({
    login: Joi.string().trim().required(),
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    email: Joi.string().email().trim().required(),
    langKey: Joi.string().default("en"),
    // password: Joi.string().trim().required(),
    authorities: Joi.array().items(Joi.string()),
    createdBy: Joi.string().required(),
    bank: Joi.string().allow(null).optional(),
    activated: Joi.boolean().optional(),
    createdDate: Joi.any().allow(null).optional(),
    lastModifiedBy: Joi.any().allow(null).optional(),
    lastModifiedDate: Joi.any().allow(null).optional()
});
// lastName: Joi.string().optional(), authorities: Joi.array().items(Joi.string())
export const updateUserModel = Joi.object().keys({
    login: Joi.string().trim().required(),
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    email: Joi.string().email().trim().required(),
    langKey: Joi.string().default("en"),
    // password: Joi.string().trim().required(),
    // createdBy: Joi.string().required(),
    // createdDate: Joi.date().required(),
    authorities: Joi.array().items(Joi.string()),
    bank: Joi.string().allow(null).optional(),
    activated: Joi.boolean().optional(),
    lastModifiedBy: Joi.string().required(),
    lastModifiedDate: Joi.any().allow(null).optional()
});

export const loginUserModel = Joi.object().keys({
    login: Joi.string().trim().required(),
    password: Joi.string().trim().required()
});

export const jwtValidator = Joi.object({'authorization': Joi.string().required()}).unknown();