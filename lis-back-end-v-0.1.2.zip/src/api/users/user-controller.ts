import * as Hapi from "hapi";
import * as Boom from "boom";
import * as Jwt from "jsonwebtoken";
import { IUser } from "./user";
import { IDatabase } from "../../database";
import { IServerConfigurations } from "../../configurations";
import { IRequest, ILoginRequest, IUserCreate, IUserUpdate } from "../../interfaces/request";

export default class UserController {
  private database: IDatabase;
  private configs: IServerConfigurations;

  constructor(configs: IServerConfigurations, database: IDatabase) {
    this.database = database;
    this.configs = configs;
  }

  private generateToken(user: IUser) {
    const jwtSecret = this.configs.jwtSecret;
    const jwtExpiration = this.configs.jwtExpiration;
    const payload = { id: user._id };

    return Jwt.sign(payload, jwtSecret, { expiresIn: jwtExpiration });
  }

  public async loginUser(request: ILoginRequest, h: Hapi.ResponseToolkit) {
    const { userId, password } = request.payload;

    let user: IUser = await this.database.userModel.findOne({ login: userId });

    if (!user) {
      return Boom.unauthorized("User does not exists.");
    }

    if (!user.validatePassword(password)) {
      return Boom.unauthorized("Password is invalid.");
    }

    return { token: this.generateToken(user) };
  }

  public async createUser(request: IUserCreate, h: Hapi.ResponseToolkit) {
    try {
      console.log(request.payload);
      request.payload.createdDate = new Date();
      request.payload.password = "Welcome@1";
      let user: any = await this.database.userModel.create(request.payload);
      // return h.response({ token: this.generateToken(user) }).code(201);
      if (user) {
        delete user.password;
        delete user["__v"];
        return user;
      } else {
        return Boom.notFound();
      }
    } catch (error) {
      console.log(error);
      return Boom.badImplementation(error);
    }
  }

  public async updateUser(request: IUserUpdate, h: Hapi.ResponseToolkit) {
    // const id = request.auth.credentials.id;
    const userId  = request.payload.login;
    request.payload.lastModifiedDate = new Date();
    console.log(request.payload);
    try {
      let user: IUser = await this.database.userModel.findOneAndUpdate(
        { login: userId},
        { $set: request.payload },
        { new: true }
      );
      if (user) {
        delete user.password;
        delete user["__v"];
        return user;
      } else {
        return Boom.notFound();
      }
    } catch (error) {
      return Boom.badImplementation(error);
    }
  }

  public async deleteUser(request: IRequest, h: Hapi.ResponseToolkit) {
    // const id = request.auth.credentials.id;
    const userId = request.params.id;
    let user: IUser = await this.database.userModel.findOneAndRemove({login: userId});
    return user;
  }

  public async infoUser(request: IRequest, h: Hapi.ResponseToolkit) {
    // const id = request.auth.credentials.id;
    const userId = request.params.id;
    console.log("user id:" + userId);
    let user: IUser = await this.database.userModel.findOne({login: userId}).lean(true);
    if (user) {
      delete user.password;
      delete user["__v"];
      return user;
    } else {
      return Boom.notFound();
    }
  }

  public async getAllUsers(request: IRequest, h: Hapi.ResponseToolkit) {
    // const id = request.auth.credentials.id;
    let users: IUser[] = await this.database.userModel.find({}).lean(true);

    return users;
  }
}
