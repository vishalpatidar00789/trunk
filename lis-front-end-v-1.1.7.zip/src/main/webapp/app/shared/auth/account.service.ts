import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { SERVER_API_URL } from '../../app.constants';
// in case server side api is not available
import { HttpHeaders } from '@angular/common/http';
@Injectable()
export class AccountService  {
    constructor(private http: HttpClient) { }

    get(): Observable<HttpResponse<Account>> {
        console.log('getting account for user');
        return this.http.get<Account>(SERVER_API_URL + 'useraccount', {observe : 'response'});
    }

    save(account: any): Observable<HttpResponse<any>> {
        return this.http.post(SERVER_API_URL + 'account', account, {observe: 'response'});
    }
}
