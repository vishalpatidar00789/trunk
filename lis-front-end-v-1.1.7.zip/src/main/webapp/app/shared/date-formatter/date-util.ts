
export class DateUtil {
    public getDBDate(date: any): string {
        return date.day + '-' + date.month + '-' + date.year;
    }
}