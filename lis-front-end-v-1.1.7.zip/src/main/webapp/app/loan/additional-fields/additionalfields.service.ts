import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { SERVER_API_URL } from '../../app.constants';

import { AdditionalFields } from './additionalFields.model';
import { createRequestOption } from '../../shared';

export type AdditionalFieldsResponseType = HttpResponse<AdditionalFields>;
export type AdditionalFieldsArrayResponseType = HttpResponse<AdditionalFields[]>;

@Injectable()
export class AdditionalFieldsService {

    private resourceUrl = SERVER_API_URL;

    // Review: set base url like this.resourceUrl  = SERVER_API_URL + 'additionalfields' and use it everywhere.

    constructor(private http: HttpClient) { }

    // create(additionalFields: AdditionalFields): Observable<any> {
    //     const copy = this.convert(additionalFields);
    //     return this.http.post<AdditionalFields>(this.resourceUrl, copy, { observe: 'response' })
    //         .map((res: AdditionalFieldsResponseType) => this.convertResponse(res));
    // }

    // update(additionalFields: AdditionalFields): Observable<AdditionalFieldsResponseType> {
    //     const copy = this.convert(additionalFields);
    //     return this.http.put<AdditionalFields>(this.resourceUrl, copy, { observe: 'response' })
    //         .map((res: AdditionalFieldsResponseType) => this.convertResponse(res));
    // }
    create(AdditionalFieldData) {
        return <any>this.http.post(this.resourceUrl + 'additionalfields', AdditionalFieldData); //change url
    }


    update(additionalFieldData) {
        let id = additionalFieldData.aFields._id;
        return <any>this.http.put(this.resourceUrl + 'additionalfields/' + id, additionalFieldData); //change url
    }

    createLoan(loanData) {
        console.log(JSON.stringify(loanData));
        return <any>this.http.post(this.resourceUrl + 'loanform', loanData); //change url
    }

    updateLoan(loanData) {
        let id = loanData._id;
        console.log(JSON.stringify(loanData));
        delete loanData['_id'];
        console.log(JSON.stringify(loanData));
        return <any>this.http.put(this.resourceUrl + 'loanform/'+id, loanData); //change url
    }

    private convertResponse(res: AdditionalFieldsResponseType): AdditionalFieldsResponseType {
        const body: AdditionalFields = this.convertItemFromServer(res.body);
        return res.clone({ body });
    }

    private convertArrayResponse(res: AdditionalFieldsArrayResponseType): AdditionalFieldsArrayResponseType {
        const jsonResponse: AdditionalFields[] = res.body;
        const body: AdditionalFields[] = [];
        for (let i = 0; i < jsonResponse.length; i++) {
            body.push(this.convertItemFromServer(jsonResponse[i]));
        }
        return res.clone({ body });
    }

    /**
     * Convert a returned JSON object to AdditionalFields.
     */
    private convertItemFromServer(json: any): AdditionalFields {
        const copy: AdditionalFields = Object.assign(new AdditionalFields(), json);
        return copy;
    }

    /**
     * Convert a AdditionalFields to a JSON which can be sent to the server.
     */
    private convert(additionalFields: AdditionalFields): AdditionalFields {
        const copy: AdditionalFields = Object.assign({}, additionalFields);
        return copy;
    }
}
