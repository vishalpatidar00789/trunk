import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LisAppSharedModule } from '../shared';
import { PFICreditLimitComponent } from './pfi/pfi-credit-limit.component';
import { PFICreditLimitService } from './pfi/pfi-credit-limit.service';
import { UobCreditLimitComponent } from './uob/uob-credit-limit.component';
import { UobCreditLimitService } from './uob/uob-credit-limit.service';
import { LoanApplicationRoute} from './loan.route';
import { LoanComponent } from './loan.component';
import { AdditionalFieldsComponent } from './additional-fields/additionalFields.component';
import { AdditionalFieldsService } from './additional-fields/additionalFields.service';
import { SpringeformComponent} from './spring-eform/springeform.component';
import { SpringeformService} from './spring-eform/springeform.service';
import { LoanService } from './loan.service';
import { MatTabsModule } from '@angular/material/tabs';
import { CdkTableModule } from '@angular/cdk/table';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DatePipe } from '@angular/common';


const PAGE_SET_STATES = [
    ...LoanApplicationRoute,
];

@NgModule({
    imports: [
        MatTabsModule,
        CdkTableModule,
        BrowserAnimationsModule,
        LisAppSharedModule,
        RouterModule.forRoot(PAGE_SET_STATES, { useHash: true })
    ],
    declarations: [    
        LoanComponent,
        PFICreditLimitComponent,
        UobCreditLimitComponent,
        AdditionalFieldsComponent,
        SpringeformComponent
        
],
    entryComponents: [    
        PFICreditLimitComponent
        //UobCreditLimitComponent
],
    providers: [    
        PFICreditLimitService,
        UobCreditLimitService,
        SpringeformService,
        AdditionalFieldsService,
        LoanService,
        DatePipe
],
schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class LoanApplicationModule {}
