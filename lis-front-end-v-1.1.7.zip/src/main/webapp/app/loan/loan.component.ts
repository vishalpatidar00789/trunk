import { Component, OnInit, ViewChildren, ViewChild, OnChanges, QueryList, AfterViewInit } from '@angular/core';
import { PFICreditLimitComponent } from './pfi/pfi-credit-limit.component';
import { Loan } from './loan.model';
import { LoanService } from './loan.service';
import { PFICreditLimit } from './pfi/pfi-credit-limit.model';
import { WSAVERNOTSUPPORTED } from 'constants';
import { RouterModule, Router, NavigationEnd } from '@angular/router';
import { Account, Principal } from '../shared';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'jhi-loan',
  templateUrl: './loan.component.html',
  styles: []
})
export class LoanComponent implements OnInit {
  isFormOneValid = false;
  UOBUser: boolean = false;
  PFIUser: boolean = true;
  currentAccount: Account;

  @ViewChild(PFICreditLimitComponent) child: PFICreditLimitComponent;
  //PFICreditLimit: PFICreditLimit;

  loan: Loan = new Loan();
  constructor(private loanService: LoanService,
    private titleService: Title,
    private router: Router, private principal: Principal, ) {
    this.router.navigate(['/loan/sform']);
  }

  test(t) {
    if (t.index == 0) {
      this.router.navigate(['/loan/sform']);

    }
    if (t.index == 1) {
      if (t.tab.textLabel == "PFI Form")
        this.router.navigate(['/loan/loan-pfiuser']);
      if (t.tab.textLabel == "UOB Form")
        this.router.navigate(['/loan/loan-uobuser']);
    }
    if (t.index == 2) {
      this.router.navigate(['/loan/afields']);
    }
    // if(t.index==3){
    //   this.router.navigate(['/loan/afields']);
    // }


  }

  ngOnInit() {
    this.principal.identity().then((account) => {
      this.currentAccount = account;
      if (this.currentAccount.bank && this.currentAccount.bank !== 'null' && this.currentAccount.bank === 'UOB') {
        this.UOBUser = true;
        this.PFIUser = false;
      } else if (this.currentAccount.bank && this.currentAccount.bank !== 'null' && this.currentAccount.bank !== 'UOB') {
        this.PFIUser = true;
        this.UOBUser = false;
      }
    });

    this.router.events.subscribe((event) => {
      if (!(event instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0)
    });
    // this.loanService.currentPFICreditLimit.subscribe(Result => this.loan.pfiCreditLimit = Result);
    // this.loanService.currentUobCreditLimit.subscribe(Result => this.loan.uobCreditLimit = Result);
    // this.loanService.currentSpringeform.subscribe(Result => this.loan.springeform = Result);
  }

  submit() {
    this.router.navigate(['loan-uobuser']);
  }

}
