import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';
import { LoanService } from '../loan.service';

import { UobCreditLimit } from './uob-credit-limit.model';
import { UobCreditLimitService } from './uob-credit-limit.service';
import { Principal,LookupService ,Currencies} from '../../shared';
import { Loan } from '../loan.model';
import { Springeform } from '../spring-eform/springeform.model';
import { DateUtil } from '../../shared/date-formatter/date-util';

@Component({
    selector: 'jhi-uob-credit-limit',
    templateUrl: './uob-credit-limit.component.html'
})
export class UobCreditLimitComponent implements OnInit, OnDestroy {

    uobCreditLimit: UobCreditLimit = new UobCreditLimit();
    springForm: Springeform = new Springeform();
    currentAccount: any;
    eventSubscriber: Subscription;
    isSaving: Boolean;
    routeData: any;
    links: any;
    totalItems: any;
    queryCount: any;
    itemsPerPage: any;
    page: any;
    predicate: any;
    previousPage: any;
    reverse: any;
    _id: string;
    successMessage: boolean;
    errorMessage: boolean;
    isExceptionalCrrRate:boolean;
    crrRate:number;
    currencyList:Currencies[];
    

    constructor(
        private uobCreditLimitService: UobCreditLimitService,
        private parseLinks: JhiParseLinks,
        private jhiAlertService: JhiAlertService,
        private eventManager: JhiEventManager,
        private principal: Principal,
        private loanService: LoanService,
        private lookup: LookupService,
        private router: Router) {
            this.isExceptionalCrrRate=false;
            this.crrRate=0;            
    }

    save() {

        // if(!this.isValidate()){
        //     return false;
        // }
        this._id = this.loanService.getId();
        let UOBdata: any = {};
        UOBdata.uob = this.uobCreditLimit;

        console.log("test:" + JSON.stringify(UOBdata));

        let submDt = this.uobCreditLimit.submissionDate;
        let latestSignedDt = this.uobCreditLimit.latestSignedDt;
        let latestAuditedDt = this.uobCreditLimit.latestAuditedDt;

        if (submDt) {
            let date = new DateUtil().getDBDate(submDt);
            UOBdata.uob.submissionDate = date;
        }
        if (latestSignedDt) {
            let date = new DateUtil().getDBDate(latestSignedDt);
            UOBdata.uob.latestSignedDt = date;
        }
        if (latestAuditedDt) {
            let date = new DateUtil().getDBDate(latestAuditedDt);
            UOBdata.uob.latestAuditedDt = date;
        }

        if(this.crrRate != 0 && this.isExceptionalCrrRate){            
            this.uobCreditLimit.crrRate=this.crrRate;
        } 

        if(UOBdata.uob.crrRate){
            UOBdata.uob.crrRate=parseFloat(UOBdata.uob.crrRate).toFixed(3);
        }
        
        this.isSaving = true;
        console.log(JSON.stringify(UOBdata));

        if (!this._id) {
            this.uobCreditLimitService.create(UOBdata).subscribe((res) => {
                this.loanService.setId(res._id);
                console.log(this.loanService.getId());
                window.scrollTo(0, 0);
                this.successMessage = true;
                setTimeout(() => { this.successMessage = false; }, 2000);
                
               /*  if(this.crrRate != 0 && this.isExceptionalCrrRate){            
                    this.uobCreditLimit.crrRate=0;
                } */
                if(UOBdata.uob.crrRate )
                { this.uobCreditLimit.crrRate=UOBdata.uob.crrRate.toString();}

            });
        } else {
            this.uobCreditLimit._id = this._id;
            UOBdata = JSON.parse(JSON.stringify(UOBdata));
            this.uobCreditLimitService.update(UOBdata).subscribe((res) => {
                console.log(this.loanService.getId());
                window.scrollTo(0, 0);
                this.successMessage = true;
                setTimeout(() => { this.successMessage = false; }, 2000);
               
               /*  if(this.crrRate != 0 && this.isExceptionalCrrRate){            
                    this.uobCreditLimit.crrRate=0;
                } */
                if(UOBdata.uob.crrRate )
                { this.uobCreditLimit.crrRate=UOBdata.uob.crrRate.toString();}

            });
        }         
       
        this.uobCreditLimit.submissionDate = submDt;
        this.uobCreditLimit.latestAuditedDt = latestAuditedDt;
        this.uobCreditLimit.latestSignedDt = latestSignedDt;
        
    }

    clear() {
        this.uobCreditLimit = new UobCreditLimit();
    }

    private onSaveError() {
        this.isSaving = false;
    }

    ngOnInit() {
        this.loanService.currentUobCreditLimit.subscribe(Result => this.uobCreditLimit = Result);
        this.principal.identity().then((account) => {
            this.currentAccount = account;
        });

        this.crrRate=this.uobCreditLimit.crrRate;

        this.lookup.getCurrencyList().subscribe(data=>{
            this.currencyList=data;
        })

        this.autoPopulateFromSponserForm();

    }

    autoPopulateFromSponserForm() {
        this.loanService.currentSpringeform.subscribe(result => {
            this.springForm = result;
            if (this.springForm) {
               
                    this.uobCreditLimit.borrowerRegName = this.springForm.regComName;
                    this.uobCreditLimit.rocRefNo = this.springForm.ACRANo;
                    this.uobCreditLimit.sgdCurrency = this.springForm.total;
                
                    this.uobCreditLimit.inventorySGDTxt = this.springForm.invStockFinancing;
                    this.uobCreditLimit.inventoryStockChkBx = this.springForm.invStockFinancingChecked;
                
                    this.uobCreditLimit.structuredWorkingCapitalSGDTxt = this.springForm.workingCapital;
                    this.uobCreditLimit.structuredWorkingCapitalChkBx =this.springForm.workingCapitalChecked; 
                
                    this.uobCreditLimit.withRecourseSGDTxt = this.springForm.aRDiscount;
                    this.uobCreditLimit.recourseFactoringBillChkBx = this.springForm.aRDiscountChecked;
                
                    this.uobCreditLimit.overseaseCapitalSGDTxt = this.springForm.capitalLoan;
                    this.uobCreditLimit.overseasWorkingCapitalChkBx = this.springForm.capitalLoanChecked;
                
                    this.uobCreditLimit.bankersGuaranteeAmountSGDTxt = this.springForm.bankerGuarantee;
                    this.uobCreditLimit.bankersGuaranteeAmountChkBx = this.springForm.bankerGuaranteeChecked;

            }
        })
    }

    ngOnDestroy() {
    }

    sort() {
        const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
        if (this.predicate !== 'id') {
            result.push('id');
        }
        return result;
    }
    private onError(error) {
        this.jhiAlertService.error(error.message, null, null);
    }

    changeCrr(){       
        if(this.uobCreditLimit.crrRate == 0){
            this.isExceptionalCrrRate=true;
            //this.uobCreditLimit.crrRate=this.crrRate;
        }            
        else{
            this.isExceptionalCrrRate=false;
            this.crrRate=null;
        }            
    }

    changeLisType(){
        if(this.uobCreditLimit.lisType){
            switch(this.uobCreditLimit.lisType){
                case 'new':
                this.uobCreditLimit.renewalFromSGDTxt=null;
                this.uobCreditLimit.renewalFromUSDTxt=null;
                this.uobCreditLimit.renewalToSGDTxt=null;
                this.uobCreditLimit.renewalToUSDTxt=null;
                this.uobCreditLimit.increaseLimitToSGD=null;
                this.uobCreditLimit.increaseLimitToUSD=null;
                this.uobCreditLimit.decreaseLimitToSGD=null;
                this.uobCreditLimit.decreaseLimitToUSD=null;
                break;
                case 'renewalAtSameAmount':
                this.uobCreditLimit.renewalFromSGDTxt=null;
                this.uobCreditLimit.renewalFromUSDTxt=null;
                this.uobCreditLimit.renewalToSGDTxt=null;
                this.uobCreditLimit.renewalToUSDTxt=null;
                this.uobCreditLimit.increaseLimitToSGD=null;
                this.uobCreditLimit.increaseLimitToUSD=null;
                this.uobCreditLimit.decreaseLimitToSGD=null;
                this.uobCreditLimit.decreaseLimitToUSD=null;
                break;
                case 'renewalFrom':               
                this.uobCreditLimit.increaseLimitToSGD=null;
                this.uobCreditLimit.increaseLimitToUSD=null;
                this.uobCreditLimit.decreaseLimitToSGD=null;
                this.uobCreditLimit.decreaseLimitToUSD=null;
                break;
                case 'increaseLimitTo':
                this.uobCreditLimit.renewalFromSGDTxt=null;
                this.uobCreditLimit.renewalFromUSDTxt=null;
                this.uobCreditLimit.renewalToSGDTxt=null;
                this.uobCreditLimit.renewalToUSDTxt=null;
                this.uobCreditLimit.decreaseLimitToSGD=null;
                this.uobCreditLimit.decreaseLimitToUSD=null;
                break;
                case 'decreaseLimitTo':
                this.uobCreditLimit.renewalFromSGDTxt=null;
                this.uobCreditLimit.renewalFromUSDTxt=null;
                this.uobCreditLimit.renewalToSGDTxt=null;
                this.uobCreditLimit.renewalToUSDTxt=null;
                this.uobCreditLimit.increaseLimitToSGD=null;
                this.uobCreditLimit.increaseLimitToUSD=null;
                break;
                default: return true;
            }
        }
        else{           
        }
    }

    add() {
        if (this.uobCreditLimit.borrowersGroup) {
            if (this.uobCreditLimit.borrowersGroup.length < 99) {
                this.uobCreditLimit.borrowersGroup.push({ name: '', limit: null });
            }
            else {
                alert('99 Borrowers Group can bee added.!')
            }
        } 
    }

    remove() {
        if (this.uobCreditLimit.borrowersGroup) {
            this.uobCreditLimit.borrowersGroup.pop();
        }
    }

    updateStack(status, filefor) {
        const documentFlag = this.uobCreditLimit.documentUploadList_Flag;

        if (status == "success") {
            switch (filefor) {

                case "overseaseWorkingChkBx":
                    documentFlag.overseasCapitalDoc = true;
                    break;
                case "companySearchesChkBx":
                    documentFlag.comapnySearchesDoc = true;
                    break;
                case "lisSponsersApplChkBx":
                    documentFlag.sponserApplicationDoc = true;
                    break;
                case "pfiInternalCreditChkBx":
                    documentFlag.pfiInternalCreditDoc = true;
                    break;
                case "latestAuditedChkBx":
                    documentFlag.latestAuditedDoc = true;
                    break;
                case "latestSignedChkBx":
                    documentFlag.latestSignedDoc = true;
                    break;
                case "additionalItemChkBx":
                    documentFlag.additionalItemsDoc = true;
                    break;
            }
        }
    }

    isValidate() {

        const documentFlag = this.uobCreditLimit.documentUploadList_Flag;
        let uploadDocumentFor = '';

        if (!documentFlag.sponserApplicationDoc && this.uobCreditLimit.lisSponsersApplChkBx) {
            uploadDocumentFor += '\n -Sponsors’ Application Form.';
        }
        if (!documentFlag.comapnySearchesDoc && this.uobCreditLimit.companySearchesChkBx) {
            uploadDocumentFor += '\n -Overseas Working Capital Loans Support.';
        }
        if (!documentFlag.pfiInternalCreditDoc && this.uobCreditLimit.pfiInternalCreditChkBx) {
            uploadDocumentFor += '\n -PFI’s internal Credit Memo Approval.';
        }
        if (!documentFlag.latestAuditedDoc && this.uobCreditLimit.latestAuditedChkBx) {
            uploadDocumentFor += '\n -Latest Audited Financials from Borrower.';
        }
        if (!documentFlag.latestSignedDoc && this.uobCreditLimit.latestSignedChkBx) {
            uploadDocumentFor += '\n -Latest signed Management Accounts from Borrower';
        }
        if (!documentFlag.additionalItemsDoc && this.uobCreditLimit.additionalItemChkBx) {
            uploadDocumentFor += '\n -Additional Items.';
        }

        if (uploadDocumentFor) {
            alert("Please upload document for" + uploadDocumentFor);
            return false;
        } else
            return true;

    }

    validateExchangeCurrency() {
        if (this.uobCreditLimit.usdCurrency && !this.uobCreditLimit.currencyExchangeRate) {
            alert('Please enter currency exchange rate as well.');
            return false;
        }
        else if (!this.uobCreditLimit.usdCurrency && this.uobCreditLimit.currencyExchangeRate) {
            alert('Please enter Foreign Currency Amount to endorse.');
            return false;
        }
        return true;
    }

    validateLisType(){
        if(this.uobCreditLimit.lisType){
            switch(this.uobCreditLimit.lisType){
                case 'new':

                return false;
                case 'renewalAtSameAmount':
                if(this.uobCreditLimit.renewalFromSGDTxt && this.uobCreditLimit.renewalToSGDTxt){
                    alert('Please enter renewal amount for Type of Application');
                    return false;
                }
                else if(this.uobCreditLimit.renewalFromSGDTxt && !this.uobCreditLimit.renewalToSGDTxt){
                    alert('Please enter amount for renewal to SGD.');
                    return false;
                }
                else if(!this.uobCreditLimit.renewalFromSGDTxt && this.uobCreditLimit.renewalToSGDTxt){
                    alert('Please enter amount for renewal From SGD.');
                    return false;
                }

                return false;
                case 'renewalFrom':

                return false;
                case 'increaseLimitTo':

                return false;
                case 'decreaseLimitTo':

                return false;
                default: return true;
            }

        }
        else{
            alert('Please select type of Application.');
            return false;
        }
    }
    

    next() {

        if (!this.validateExchangeCurrency())
            return false;

        if (!this.isValidate()) {
            return false;
        }
        this.loanService.changeuobCreditLimit(this.uobCreditLimit);
        this.router.navigate(['/loan/afields']);
    }
    previous() {
        this.loanService.changeuobCreditLimit(this.uobCreditLimit);
        this.router.navigate(['/loan/sform']);

    }

    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0 || event.charCode == 46) ? null : event.charCode >= 48 && event.charCode <= 57;
        //|| event.charCode == 44
    }


}
