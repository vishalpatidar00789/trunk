
export class UobCreditLimit {
    constructor(
        public _id?: string,
        //uobPolicyNo?:string,
        public toLIS5Insurer?: string,
        public requesterName?: string,
        public submissionDate?: any,
        public discretiolaryLimitDL?: boolean,
        public creditLimitCL?: boolean,
        public crrRate?: number,  
        public currencyExchangeRate?: number,      
        public borrowerRegName?:string,
        public rocRefNo?:string,
        public lisType?:string,
        // public newLIS?: boolean,        
        // public renewalAtSameAmount?: boolean,
        // public renewalFrom?: boolean,        
        // public increaseLimitTo?: boolean,
        // public decreaseLimitTo?: boolean,       
        public increaseLimitToSGD?: number,
        public increaseLimitToUSD?: number,
        public decreaseLimitToSGD?: number,
        public decreaseLimitToUSD?: number,
        public renewalFromSGDTxt?: number,
        public renewalFromUSDTxt?: number,
        public renewalToUSDTxt?: number,
        public renewalToSGDTxt?: number,
        public sgdCurrency?:number,
        public usdCurrency?:number,
        public usdCurrencyCurrent?:number,
        public sgdCurrencyCurrent?:number,
        public sgdCurrencyCurrentLIS?: number,
        public usdCurrencyCurrentLIS?: number,
        public usdCurrencyCurrentLISP?: number,
        public sgdCurrencyCurrentLISP?: number,
        public lisSponsersApplChkBx?: boolean,
        public companySearchesChkBx?: boolean,
        public uobInternalCreditChkBx?: boolean,
        public latestAuditedChkBx?: boolean,
        public latestAuditedDt?: any,
        public latestSignedChkBx?: boolean,
        public latestSignedDt?: any,
        public additionalItemChkBx?: boolean,
        public additionalItemTxt?: string,
        public forOverseasChkBx?: boolean,
        public pfiInternalCreditChkBx?: boolean,       
        public bankersGuaranteeAmountChkBx?:boolean,
        public inventoryStockChkBx?: boolean,
        public structuredWorkingCapitalChkBx?: boolean,
        public recourseFactoringBillChkBx?: boolean,
        public overseasWorkingCapitalChkBx?: boolean,
        public bankersGuarantee?: boolean,
        public tenureMonths?:number,
        public inventoryUSDTxt?:number,
        public inventorySGDTxt?:number,
        public withRecourseUSDTxt?:number,
        public withRecourseSGDTxt?:number,
        public structuredWorkingCapitalUSDTxt?:number,
        public structuredWorkingCapitalSGDTxt?:number,
        public overseaseCapitalSGDTxt?:number,
        public overseaseCapitalUSDTxt?:number,
        public bankersGuaranteeAmountSGDTxt?:number,
        public bankersGuaranteeAmountUSDTxt?:number,
        public documentUploadList?:any,
        public documentUploadList_Flag?:any,
        public borrowersGroup?: [{"name":string,"limit":number}],
        public foreignCurrency?:string
    ) {
        this.toLIS5Insurer = "United Overseas Insurance Limited";

        this.requesterName = "United Overseas Bank Limited";

        this.borrowersGroup = [{ name: '', limit: 0}];

        this.foreignCurrency="USD";

        this.documentUploadList = [{overseasCapitalDoc:''},{sponserApplicationDoc:''},{comapnySearchesDoc:''},
                                    {pfiInternalCreditDoc:''},{latestAuditedDoc:''},{latestSignedDoc:''},
                                    {additionalItemsDoc:''}];

         this.documentUploadList_Flag = [{comapnySearchesDoc:false},{overseasCapitalDoc:false},{sponserApplicationDoc:false},
                                    {pfiInternalCreditDoc:false},{latestAuditedDoc:false},{latestSignedDoc:false},
                                    {additionalItemsDoc:false}];
    }
}
