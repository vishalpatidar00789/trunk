import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';
import { NgForm } from '@angular/forms';
import { PFICreditLimit } from './pfi-credit-limit.model';
import { PFICreditLimitService } from './pfi-credit-limit.service';
import { LoanService } from '../loan.service';
import { Principal, FileUploadComponent, Account, LookupService, Currencies } from '../../shared';
import { Loan } from '../loan.model';
import { Springeform } from '../spring-eform/springeform.model';
import { DateUtil } from '../../shared/date-formatter/date-util';


@Component({
    selector: 'jhi-pfi-credit-limit',
    templateUrl: './pfi-credit-limit.component.html'
})
export class PFICreditLimitComponent implements OnInit, OnDestroy {

    filesToUpload: Array<File> = [];
    data: any = [];
    pfiCreditLimit: PFICreditLimit = new PFICreditLimit();
    springForm: Springeform = new Springeform();
    loan: Loan = new Loan();
    eventSubscriber: Subscription;
    isSaving: Boolean;
    routeData: any;
    links: any;
    totalItems: any;
    queryCount: any;
    itemsPerPage: any;
    page: any;
    predicate: any;
    previousPage: any;
    reverse: any;
    _id: string = "";
    currentAccount: Account;
    successMessage = false;
    errorMessage = false;
    currencyList:Currencies[];

    constructor(
        private pfiCreditService: PFICreditLimitService,
        private parseLinks: JhiParseLinks,
        private jhiAlertService: JhiAlertService,
        private eventManager: JhiEventManager,
        private principal: Principal,
        private loanService: LoanService,
        private router: Router,
        private lookup: LookupService) {
    }

    save() {
        this._id = this.loanService.getId();

        let pfiData: any = {};
        pfiData.pfi = this.pfiCreditLimit;

        let submDt = this.pfiCreditLimit.submissionDate;
        let latestSignedDt = this.pfiCreditLimit.latestSignedDt;
        let latestAuditedDt = this.pfiCreditLimit.latestAuditedDt;

        if (submDt) {
            let date = new DateUtil().getDBDate(submDt);
            pfiData.pfi.submissionDate = date;
        }
        if (latestSignedDt) {
            let date = new DateUtil().getDBDate(latestSignedDt);
            pfiData.pfi.latestSignedDt = date;
        }
        if (latestAuditedDt) {
            let date = new DateUtil().getDBDate(latestAuditedDt);
            pfiData.pfi.latestAuditedDt = date;
        }

        this.isSaving = true;
        console.log(JSON.stringify(pfiData));

        if (!this._id) {
            this.pfiCreditService.create(pfiData).subscribe((res) => {
                this.loanService.setId(res._id);
                window.scrollTo(0, 0);
                this.successMessage = true;
                setTimeout(() => { this.successMessage = false; }, 2000);
                console.log(this.loanService.getId());
            });
        } else {
            this.pfiCreditLimit._id = this._id;
            pfiData.pfi = this.pfiCreditLimit;
            this.pfiCreditService.update(pfiData).subscribe((res) => {
                window.scrollTo(0, 0);
                this.successMessage = true;
                setTimeout(() => { this.successMessage = false; }, 2000);
                this.successMessage = true;
                console.log(this.loanService.getId());
            });
        }

        this.pfiCreditLimit.submissionDate = submDt;
        this.pfiCreditLimit.latestAuditedDt = latestAuditedDt;
        this.pfiCreditLimit.latestSignedDt = latestSignedDt;
    }

    add() {
        if (this.pfiCreditLimit.borrowersGroup) {
            if (this.pfiCreditLimit.borrowersGroup.length < 99) {
                this.pfiCreditLimit.borrowersGroup.push({ name: '' });
            }
            else {
                alert('99 Borrowers Group can bee added.!')
            }
        }

    }

    remove() {
        if (this.pfiCreditLimit.borrowersGroup) {
            this.pfiCreditLimit.borrowersGroup.pop();
        }
    }

    removeMe(me){
        for(var i=0;this.pfiCreditLimit.borrowersGroup.length;i++){
            let borrower=this.pfiCreditLimit.borrowersGroup[i];
            if(borrower["name"] === me.name){
                this.pfiCreditLimit.borrowersGroup.splice(i,1);
                return;
            }
        }
    }

    clear() {
        this.pfiCreditLimit = new PFICreditLimit();
    }

    // private subscribeToSaveResponse(result: Observable<PFICreditLimit>) {
    //     result.subscribe((res: PFICreditLimit) =>
    //         this.onSaveSuccess(res), (res: Response) => this.onSaveError());
    // }

    // private onSaveSuccess(result: PFICreditLimit) {
    //     this.eventManager.broadcast({ name: 'pfiCreditLimitListModification', content: 'OK' });
    //     this._id = result._id;
    //     this.isSaving = false;
    // }

    private onSaveError() {
        this.isSaving = false;
    }

    ngOnInit() {

        this.loanService.currentPFICreditLimit.subscribe(Result => this.pfiCreditLimit = Result);
        this.principal.identity().then((account) => {
            if (account) {
                this.currentAccount = account;
                if (this.currentAccount.bank) {
                    this.lookup.getBankByCode(this.currentAccount.bank).subscribe((bank) => {
                        if (bank) {
                            this.pfiCreditLimit.pfiName = bank.bankName;
                        } else {
                            //if b ank is not there
                            alert('NO BANK IS ASSIGNED TO THIS USER..!');
                        }
                    })
                }
            }

        });

        this.lookup.getCurrencyList().subscribe(data=>{
            this.currencyList=data;
        })

        this.autoPopulateFromSponser();

    }

    private autoPopulateFromSponser() {
        this.loanService.currentSpringeform.subscribe(result => {
            this.springForm = result;
            if (this.springForm) {               
                this.pfiCreditLimit.borrowerRegName = this.springForm.regComName;
                this.pfiCreditLimit.aCRArefNo = this.springForm.ACRANo;
                this.pfiCreditLimit.totalRequstedLimitSGD = this.springForm.total;
            
                this.pfiCreditLimit.inventoryTradeTxt = this.springForm.invStockFinancing;
                this.pfiCreditLimit.inventoryTradeChkBx = this.springForm.invStockFinancingChecked;
            
                this.pfiCreditLimit.structuredWorkingCapTxt = this.springForm.workingCapital;
                this.pfiCreditLimit.workingCapChkBx = this.springForm.workingCapitalChecked;
            
                this.pfiCreditLimit.resourceFactoringTxt = this.springForm.aRDiscount;
                this.pfiCreditLimit.resourceFactoringChkBx = this.springForm.aRDiscountChecked;
                
                this.pfiCreditLimit.overseaseWorkingTxt = this.springForm.capitalLoan;
                this.pfiCreditLimit.overseaseWorkingChkBx = this.springForm.capitalLoanChecked;
            
                this.pfiCreditLimit.bankersGuaranteeTxt = this.springForm.bankerGuarantee;
                this.pfiCreditLimit.bankersGuaranteeChkBx = this.springForm.bankerGuaranteeChecked;
            }
        })
    }

    ngOnDestroy() {
    }

    // sort() {
    //     const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
    //     if (this.predicate !== 'id') {
    //         result.push('id');
    //     }
    //     return result;
    // }

    private onError(error) {
        this.jhiAlertService.error(error.message, null, null);
    }

    updateStack(status, filefor) {

        const documentFlag = this.pfiCreditLimit.documentUploadList_Flag;
        const documents = this.pfiCreditLimit.documentUploadList;

        if (status == "success") {
            switch (filefor) {

                case "preshipmentApprovalChkBx":
                    documentFlag.preshipmentApprovalDoc = true;
                    break;
                case "overseaseWorkingChkBx":
                    documentFlag.overseasCapitalDoc = true;
                    break;
                case "companySearchesChkBx":
                    documentFlag.comapnySearchesDoc = true;
                    break;
                case "lisSponsersApplChkBx":
                    documentFlag.sponserApplicationDoc = true;
                    break;
                case "pfiInternalCreditChkBx":
                    documentFlag.pfiInternalCreditDoc = true;
                    break;
                case "latestAuditedChkBx":
                    documentFlag.latestAuditedDoc = true;
                    break;
                case "latestSignedChkBx":
                    documentFlag.latestSignedDoc = true;
                    break;
                case "additionalItemChkBx":
                    documentFlag.additionalItemsDoc = true;
                    break;
                case "forOverseasChkBx":
                    documentFlag.overseaseDoc = true;
                    break;
            }
        }
    }

    isValidate() {
        let uploadDocumentFor = '';
        const documentFlag = this.pfiCreditLimit.documentUploadList_Flag;

        if (!documentFlag.overseasCapitalDoc && this.pfiCreditLimit.overseaseWorkingChkBx) {
            uploadDocumentFor += '\n -Overseas Working Capital Loans Support.';
        }
        if (!documentFlag.sponserApplicationDoc && this.pfiCreditLimit.lisSponsersApplChkBx) {
            uploadDocumentFor += '\n -Sponsors’ Application Form.';
        }
        if (!documentFlag.comapnySearchesDoc && this.pfiCreditLimit.companySearchesChkBx) {
            uploadDocumentFor += '\n -Overseas Working Capital Loans Support.';
        }
        if (!documentFlag.pfiInternalCreditDoc && this.pfiCreditLimit.pfiInternalCreditChkBx) {
            uploadDocumentFor += '\n -PFI’s internal Credit Memo Approval.';
        }
        if (!documentFlag.preshipmentApprovalDoc && this.pfiCreditLimit.preshipmentApprovalChkBx) {
            uploadDocumentFor += '\n -Pre-shipment approval is required.';
        }
        if (!documentFlag.latestAuditedDoc && this.pfiCreditLimit.latestAuditedChkBx) {
            uploadDocumentFor += '\n -Latest Audited Financials from Borrower.';
        }
        if (!documentFlag.latestSignedDoc && this.pfiCreditLimit.latestSignedChkBx) {
            uploadDocumentFor += '\n -Latest signed Management Accounts from Borrower';
        }
        if (!documentFlag.additionalItemsDoc && this.pfiCreditLimit.additionalItemChkBx) {
            uploadDocumentFor += '\n -Additional Items.';
        }
        if (!documentFlag.overseaseDoc && this.pfiCreditLimit.forOverseasChkBx) {
            uploadDocumentFor += '\n -Oversease working capital.';
        }

        if (this.pfiCreditLimit.exRate && !this.pfiCreditLimit.foreignCurrency) {
            alert("Please enter Foreign Currency Amount to endorse as well with Eschange rate.");
        }
        else if (!this.pfiCreditLimit.exRate && this.pfiCreditLimit.foreignCurrency) {
            alert("Please enter Exchange rate with Foreign Currency Amount.");
        }

        if (uploadDocumentFor) {
            alert("Please upload document for" + uploadDocumentFor);
            return false;
        } else
            return true;

    }

    isDocumentValidate() {
        const documentFlag = this.pfiCreditLimit.documentUploadList_Flag;
        if (!documentFlag.comapnySearchesDoc || !documentFlag.sponserApplicationDoc || !documentFlag.pfiInternalCreditDoc || !documentFlag.latestAuditedDoc || !documentFlag.latestSignedDoc) {
            alert("Please upload all the mandatory document.");
            return false;
        }
        else return true;

    }

    validateExchangeCurrency() {
        if (this.pfiCreditLimit.foreignCurrency && !this.pfiCreditLimit.exRate) {
            alert('Please enter currency exchange rate as well.');
            return false;
        }
        else if (!this.pfiCreditLimit.foreignCurrency && this.pfiCreditLimit.exRate) {
            alert('Please enter Foreign Currency Amount to endorse.');
            return false;
        }
        return true;
    }

    next() {

        if (!this.validateExchangeCurrency())
            return false;

        if (!this.isValidate()) {
            return;
        }
        if (!this.isDocumentValidate()) {
            return;
        }
        this.loanService.changepfiCreditLimit(this.pfiCreditLimit);
        this.router.navigate(['/loan/afields']);
    }
    previous() {
        this.loanService.changepfiCreditLimit(this.pfiCreditLimit);
        this.router.navigate(['/loan/sform']);
    }

    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0 || event.charCode == 46) ? null : event.charCode >= 48 && event.charCode <= 57;
        //|| event.charCode == 44
    }

}
