import { PFICreditLimit } from './pfi/pfi-credit-limit.model';
import { UobCreditLimit } from './uob/uob-credit-limit.model';
import { Springeform, subsideries } from './spring-eform/springeform.model';
import { AdditionalFields } from './additional-fields/additionalFields.model';
export class Loan {
    public _id: string;
    public marshRefNo: string;
    public status: string;
    public pfi: PFICreditLimit;
    public uob: UobCreditLimit;
    public springeform: Springeform;
    public aFields: AdditionalFields;

}

