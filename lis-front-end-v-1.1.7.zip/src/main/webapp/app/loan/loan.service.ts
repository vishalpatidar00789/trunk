import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { SERVER_API_URL } from '../app.constants';

import { JhiDateUtils } from 'ng-jhipster';

import { UobCreditLimit } from './uob/uob-credit-limit.model';
import { PFICreditLimit } from './pfi/pfi-credit-limit.model';
import { Springeform } from './spring-eform/springeform.model';
import { AdditionalFields } from './additional-fields/additionalfields.model';
import { createRequestOption } from '../shared';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class LoanService {

    private pfiCreditLimit: PFICreditLimit = new PFICreditLimit();
    private uobCreditLimit: UobCreditLimit = new UobCreditLimit();
    private springeform: Springeform = new Springeform();
    private additionalFields: AdditionalFields = new AdditionalFields();
    loanId: string;

    public setId(id) {
        this.loanId = id;
    }
    public getId() {
        return this.loanId;
    }
    //private resourceUrl = SERVER_API_URL + 'api/loan/uob-credit-limit';

    private pfiCreditLimitSource = new BehaviorSubject<PFICreditLimit>(this.pfiCreditLimit);
    currentPFICreditLimit = this.pfiCreditLimitSource.asObservable();

    private uobCreditLimitSource = new BehaviorSubject<UobCreditLimit>(this.uobCreditLimit);
    currentUobCreditLimit = this.uobCreditLimitSource.asObservable();

    private springeformSource = new BehaviorSubject<Springeform>(this.springeform);
    currentSpringeform = this.springeformSource.asObservable();

    private additionalFieldsFormSource = new BehaviorSubject<AdditionalFields>(this.additionalFields);
    currentAdditionalFields = this.additionalFieldsFormSource.asObservable();

    constructor(private http: HttpClient, private dateUtils: JhiDateUtils) { }

    changeuobCreditLimit(uobCreditLimit: UobCreditLimit) {
        this.uobCreditLimitSource.next(uobCreditLimit);
    }

    changepfiCreditLimit(pfiCreditLimit: PFICreditLimit) {
        this.pfiCreditLimitSource.next(pfiCreditLimit);        
    }

    changeSpringeform(springeform: Springeform) {
        this.springeformSource.next(springeform);
    }

    changeAdditionalFields(additionalFields: AdditionalFields) {
        this.additionalFieldsFormSource.next(additionalFields);
    }   

    public destroyMe() {
        this.pfiCreditLimit = new PFICreditLimit();
        this.uobCreditLimit = new UobCreditLimit();
        this.springeform = new Springeform();
        this.additionalFields = new AdditionalFields();
        this.loanId = "";        
        this.pfiCreditLimitSource.next(this.pfiCreditLimit);
        this.uobCreditLimitSource.next(this.uobCreditLimit);
        this.springeformSource.next(this.springeform);
        this.additionalFieldsFormSource.next(this.additionalFields);
    }
}
