import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { PFIAdhocComponent } from './pfi/pfi-adhoc.component';
import { PFIAdhocService } from './pfi/pfi-adhoc.service';
import { UobAdhocComponent } from './uob/uob-adhoc.component';
import { UobAdhocService } from './uob/uob-adhoc.service';
import { LoanAdhocRoute} from './adhoc.route';
import { LisAppSharedModule } from '../../shared';

const PAGE_SET_STATES = [
    ...LoanAdhocRoute,
];

@NgModule({
    imports: [
        LisAppSharedModule,
        RouterModule.forRoot(PAGE_SET_STATES, { useHash: true })
    ],
    declarations: [    
        PFIAdhocComponent,
        UobAdhocComponent
],
    entryComponents: [    
        PFIAdhocComponent,
        UobAdhocComponent
],
    providers: [    
        PFIAdhocService,
        UobAdhocService
],
schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class LoanAdhocApplicationModule {}
