import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';

import { UobAdhoc } from './uob-adhoc.model';
import { UobAdhocService } from './uob-adhoc.service';
import { Principal } from '../../../shared';

@Component({
    selector: 'jhi-uob-adhoc',
    templateUrl: './uob-adhoc.component.html'
})
export class UobAdhocComponent implements OnInit, OnDestroy {

    preshipmentApprovalDoc: boolean;
    overseasCapitalDoc: boolean;
    sponserApplicationDoc: boolean;
    comapnySearchesDoc: boolean;
    pfiInternalCreditDoc: boolean;
    latestAuditedDoc: boolean;
    latestSignedDoc: boolean;
    additionalItemsDoc: boolean;
    overseaseDoc: boolean;
    displaySuccessMessage: boolean;

    currencies = ['AUD', 'CNY', 'EUR', 'HKD', 'IDR', 'INR', 'JPY', 'KRW', 'MYR', 'NOK', 'PHP', 'THB', 'TWD', 'USD'];
    uobAdhoc: UobAdhoc = new UobAdhoc();

    currentAccount: any;
    eventSubscriber: Subscription;
    isSaving: Boolean;
    routeData: any;
    links: any;
    totalItems: any;
    queryCount: any;
    itemsPerPage: any;
    page: any;
    predicate: any;
    previousPage: any;
    reverse: any;

    constructor(
        private uobAdhocService: UobAdhocService,
        private parseLinks: JhiParseLinks,
        private jhiAlertService: JhiAlertService,
        private eventManager: JhiEventManager,
        private router: Router,
        private principal: Principal) {
        this.resetDocStack();
    }

    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0 || event.charCode == 46 || event.charCode == 44) ? null : event.charCode >= 48 && event.charCode <= 57;
    }

    resetDocStack() {
        this.preshipmentApprovalDoc = false;
        this.overseasCapitalDoc = false;
        this.sponserApplicationDoc = false;
        this.comapnySearchesDoc = false;
        this.pfiInternalCreditDoc = false;
        this.latestAuditedDoc = false;
        this.latestSignedDoc = false;
        this.additionalItemsDoc = false;
        this.overseaseDoc = false;
    }

    saveAsDraft() {
        window.scrollTo(0, 0);
        this.displaySuccessMessage = true;
        setTimeout(() => { this.displaySuccessMessage = false; }, 2000);
        // alert("Application saved as draft.");
    }

    save() {

        if (!this.isValidate()) {
            return false;
        }

        this.isSaving = true;
        this.subscribeToSaveResponse(
            this.uobAdhocService.create(this.uobAdhoc));
    }

    clear() {
        if (confirm("Are you sure, you want to cancel?")) {
            this.uobAdhoc = new UobAdhoc();
            this.router.navigateByUrl('/');
        }
    }

    private subscribeToSaveResponse(result: Observable<UobAdhoc>) {
        result.subscribe((res: UobAdhoc) =>
            this.onSaveSuccess(res), (res: Response) => this.onSaveError());
    }

    private onSaveSuccess(result: UobAdhoc) {
        this.eventManager.broadcast({ name: 'uobAdhocListModification', content: 'OK' });
        this.isSaving = false;
    }

    private onSaveError() {
        this.isSaving = false;
    }

    ngOnInit() {
        this.principal.identity().then((account) => {
            this.currentAccount = account;
        });

    }

    ngOnDestroy() {

    }

    sort() {
        const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
        if (this.predicate !== 'id') {
            result.push('id');
        }
        return result;
    }
    private onError(error) {
        this.jhiAlertService.error(error.message, null, null);
    }

    //this.uobAdhoc.borrowersGroup = [{name: '',limit:''}];

    add() {
        // this.uobAdhoc.borrowersGroup.push({name: '',limit:''});    
    }

    remove() {
        // this.uobAdhoc.borrowersGroup.pop();
    }


    updateStack(status, filefor) {

        if (status == "success") {
            switch (filefor) {

                case "preshipmentApprovalChkBx":
                    this.preshipmentApprovalDoc = true;
                    break;
                case "overseaseWorkingChkBx":
                    this.overseasCapitalDoc = true;
                    break;
                case "companySearchesChkBx":
                    this.comapnySearchesDoc = true;
                    break;
                case "lisSponsersApplChkBx":
                    this.sponserApplicationDoc = true;
                    break;
                case "pfiInternalCreditChkBx":
                    this.pfiInternalCreditDoc = true;
                    break;
                case "latestAuditedChkBx":
                    this.latestAuditedDoc = true;
                    break;
                case "latestSignedChkBx":
                    this.latestSignedDoc = true;
                    break;
                case "additionalItemChkBx":
                    this.additionalItemsDoc = true;
                    break;
                case "forOverseasChkBx":
                    this.overseaseDoc = true;
                    break;
            }
        }
    }

    reset(field: string) {
        this.uobAdhoc[field] = null;
    }

    isValidate() {

        // TODO: Update the logic as per mandatory fields

    }
}
