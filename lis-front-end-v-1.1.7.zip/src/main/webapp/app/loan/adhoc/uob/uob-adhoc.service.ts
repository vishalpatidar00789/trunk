import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { SERVER_API_URL } from '../../../app.constants';

import { JhiDateUtils } from 'ng-jhipster';

import { UobAdhoc } from './uob-adhoc.model';
import { createRequestOption } from '../../../shared';

export type UobAdhocResponseType = HttpResponse<UobAdhoc>;
export type UobAdhocArrayResponseType = HttpResponse<UobAdhoc[]>;

@Injectable()
export class UobAdhocService {

    private resourceUrl = SERVER_API_URL + 'api/loan/uob-credit-limit';

    constructor(private http: HttpClient, private dateUtils: JhiDateUtils) { }

    create(uobCreditLimit: UobAdhoc): Observable<any> {
        console.log(uobCreditLimit);
        const copy = this.convert(uobCreditLimit);
        return this.http.post<UobAdhoc>(this.resourceUrl, copy, { observe: 'response' })
            .map((res: UobAdhocResponseType) => this.convertResponse(res));
    }

    update(uobCreditLimit: UobAdhoc): Observable<UobAdhocResponseType> {
        const copy = this.convert(uobCreditLimit);
        return this.http.put<UobAdhoc>(this.resourceUrl, copy, { observe: 'response' })
            .map((res: UobAdhocResponseType) => this.convertResponse(res));
    }

    private convertResponse(res: UobAdhocResponseType): UobAdhocResponseType {
        const body: UobAdhoc = this.convertItemFromServer(res.body);
        return res.clone({body});
    }

    private convertArrayResponse(res: UobAdhocArrayResponseType): UobAdhocArrayResponseType {
        const jsonResponse: UobAdhoc[] = res.body;
        const body: UobAdhoc[] = [];
        for (let i = 0; i < jsonResponse.length; i++) {
            body.push(this.convertItemFromServer(jsonResponse[i]));
        }
        return res.clone({body});
    }

    /**
     * Convert a returned JSON object to UobCreditLimit.
     */
    private convertItemFromServer(json: any): UobAdhoc {
        const copy: UobAdhoc = Object.assign(new UobAdhoc(), json);
        // copy.submissionDate = this.dateUtils
        //     .convertLocalDateFromServer(json.submissionDate);
      
        return copy;
    }

    /**
     * Convert a UobCreditLimit to a JSON which can be sent to the server.
     */
    private convert(uobCreditLimit: UobAdhoc): UobAdhoc {
        const copy: UobAdhoc = Object.assign({}, uobCreditLimit);
        // copy.submissionDate = this.dateUtils
        //     .convertLocalDateToServer(uobCreditLimit.submissionDate);
       
        return copy;
    }
}
