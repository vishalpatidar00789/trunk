import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';

import { PFIAdhoc } from './pfi-adhoc.model';
import { PFIAdhocService } from './pfi-adhoc.service';
import { Principal, FileUploadComponent } from '../../../shared';

@Component({
    selector: 'jhi-pfi-adhoc',
    templateUrl: './pfi-adhoc.component.html'
})
export class PFIAdhocComponent implements OnInit, OnDestroy {

    filesToUpload: Array<File> = [];

    preshipmentApprovalDoc: boolean;
    overseasCapitalDoc: boolean;
    sponserApplicationDoc: boolean;
    comapnySearchesDoc: boolean;
    pfiInternalCreditDoc: boolean;
    latestAuditedDoc: boolean;
    latestSignedDoc: boolean;
    additionalItemsDoc: boolean;
    overseaseDoc: boolean;
    displaySuccessMessage: boolean = false;

    currencies = ['AUD', 'CNY', 'EUR', 'HKD', 'IDR', 'INR', 'JPY', 'KRW', 'MYR', 'NOK', 'PHP', 'THB', 'TWD', 'USD'];
    pfiAdhoc: PFIAdhoc = new PFIAdhoc();
    currentAccount: any;
    eventSubscriber: Subscription;
    isSaving: Boolean;
    routeData: any;
    links: any;
    totalItems: any;
    queryCount: any;
    itemsPerPage: any;
    page: any;
    predicate: any;
    previousPage: any;
    reverse: any;

    constructor(
        private pfiCreditService: PFIAdhocService,
        private parseLinks: JhiParseLinks,
        private jhiAlertService: JhiAlertService,
        private eventManager: JhiEventManager,
        private router: Router,
        private principal: Principal) {
        this.resetDocStack();
    }

    resetDocStack() {
        this.preshipmentApprovalDoc = false;
        this.overseasCapitalDoc = false;
        this.sponserApplicationDoc = false;
        this.comapnySearchesDoc = false;
        this.pfiInternalCreditDoc = false;
        this.latestAuditedDoc = false;
        this.latestSignedDoc = false;
        this.additionalItemsDoc = false;
        this.overseaseDoc = false;
    }

    onCheckboxChange(checkbox: string) {
        // TODO: To implement the reset logic for sections like section1
        // if (this.pfiAdhoc[checkbox] == false) {
        //     confirm("All information in this section will be lost. Do you want to continue?");
        // }
    }

    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0 || event.charCode == 46 || event.charCode == 44) ? null : event.charCode >= 48 && event.charCode <= 57;
    }

    saveAsDraft() {
        window.scrollTo(0, 0);
        this.displaySuccessMessage = true;
        setTimeout(() => { this.displaySuccessMessage = false; }, 2000);
        // alert("Application saved as draft.");
    }

    save() {
        if (!this.isValidate()) {
            return;
        }
        if (!this.isDocumentValidate()) {
            return;
        }
        this.isSaving = true;
        this.subscribeToSaveResponse(
            this.pfiCreditService.create(this.pfiAdhoc));
    }

    clear() {
        if (confirm("Are you sure, you want to cancel?")) {
            this.pfiAdhoc = new PFIAdhoc();
            this.router.navigateByUrl('/');
        }
    }

    private subscribeToSaveResponse(result: Observable<PFIAdhoc>) {
        result.subscribe((res: PFIAdhoc) =>
            this.onSaveSuccess(res), (res: Response) => this.onSaveError());
    }

    private onSaveSuccess(result: PFIAdhoc) {
        this.eventManager.broadcast({ name: 'pfiAdhocListModification', content: 'OK' });
        this.isSaving = false;
    }

    private onSaveError() {
        this.isSaving = false;
    }

    ngOnInit() {

    }

    ngOnDestroy() {

    }

    sort() {
        const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
        if (this.predicate !== 'id') {
            result.push('id');
        }
        return result;
    }
    private onError(error) {
        this.jhiAlertService.error(error.message, null, null);
    }



    isValidate() {
        let uploadDocumentFor = '';

        if (this.pfiAdhoc.exRate && !this.pfiAdhoc.foreignCurrency) {
            alert("Please enter Foreign Currency Amount to endorse as well with Eschange rate.");
        }
        else if (!this.pfiAdhoc.exRate && this.pfiAdhoc.foreignCurrency) {
            alert("Please enter Exchange rate with Foreign Currency Amount.");
        }

        if (uploadDocumentFor) {
            alert("Please upload document for" + uploadDocumentFor);
            return false;
        } else
            return true;

    }

    reset(field: string) {
        this.pfiAdhoc[field] = null;
    }

    isDocumentValidate() {
        // TODO: Update the logic as per mandatory fields
        return !(this.pfiAdhoc.cancellationSectionChkBx || this.pfiAdhoc.expiryExtensionChkBx || this.pfiAdhoc.dueDateExtensionChkBx
            || this.pfiAdhoc.overseasBuyerChkBx || this.pfiAdhoc.preShipmentChkBx || this.pfiAdhoc.moreTimeLoChkBx
            || this.pfiAdhoc.adverseInformationChkBx || this.pfiAdhoc.newDisbursementsChkBx || this.pfiAdhoc.reValidateInsuranceChkBx
            || this.pfiAdhoc.processRequestChkBx);
    }
}
