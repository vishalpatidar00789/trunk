import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { JhiPaginationUtil } from 'ng-jhipster';
import { PFIAdhocComponent } from './pfi/pfi-adhoc.component';
import { UobAdhocComponent } from './uob/uob-adhoc.component'


export const LoanAdhocRoute: Routes = [
    {   
        path: 'adhoc-pfiuser',
        component: PFIAdhocComponent,
        data: {
            //authorities: ['ROLE_USER'],
            pageTitle: 'Adhoc Request'
        },
        //canActivate: [UserRouteAccessService]
    },
    {   
        path: 'adhoc-uobuser',
        component: UobAdhocComponent,
        data: {
            //authorities: ['ROLE_USER'],
            pageTitle: 'Adhoc Request'
        },
        //canActivate: [UserRouteAccessService]
    }
];
