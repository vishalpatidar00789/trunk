import { Component, OnInit, OnDestroy, Pipe, PipeTransform } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';

import { Springeform, subsideries } from './springeform.model';
import { SpringeformService } from './springeform.service';
import { Principal, Account } from '../../shared';
import { error } from 'util';

import { LoanService } from '../loan.service';
import { DateUtil } from '../../shared/date-formatter/date-util';



@Component({
    selector: 'jhi-springeform',
    templateUrl: './springeform.component.html'
})
export class SpringeformComponent implements OnInit, OnDestroy {
    springeform: Springeform = new Springeform();
    countries: Array<any> = [{ "id": "MY", "name": "Malaysia" }, { "id": "SG", "name": "Singapore" }, { "id": "Other", "name": "Other" }];

    fileData: Array<File> = [];
    tickVisible: boolean;
    // currentAccount: any;
    eventSubscriber: Subscription;
    isSaving: Boolean;
    routeData: any;
    links: any;
    totalItems: any;
    queryCount: any;
    itemsPerPage: any;
    page: any;
    predicate: any;
    previousPage: any;
    reverse: any;
    displayFileMessage: boolean = false;
    displaySuccessMessage: boolean = false;
    displayErrorMessage: boolean = false;
    displayErrorMessageTypeOfFTotal: boolean = false;
    displaySpinner: boolean = false;
    ShowEditTable: boolean = false;
    shareHoldingEditRowId: any = '';
    subsidiariesEditRowId: any = '';

    invStockFinancingChecked: boolean = false;
    workingCapitalChecked: boolean = false;
    aRDiscountChecked: boolean = false;
    capitalLoanChecked: boolean = false;
    bankerGuaranteeChecked: boolean = false;

    _id: string

    isInventoryChecked = false;
    UOBUser: boolean = false;
    PFIUser: boolean = true;
    currentAccount: Account;

    constructor(
        private springeformService: SpringeformService,
        private parseLinks: JhiParseLinks,
        private jhiAlertService: JhiAlertService,
        private eventManager: JhiEventManager,
        private principal: Principal,
        private loanService: LoanService,
        private router: Router,
        public datePipe: DatePipe

    ) {
    }

    shareHoldingEditRowIdValidated: boolean = true;


    addRowShareholdingSub(obj) {

        this.shareHoldingEditRowIdValidated = true;
        if (!this.springeform.shareholdingSub) {
            this.springeform.shareholdingSub = [];
        }

        var subsideries = {
            level: "0",
            name: "",
            aCRA: "",
            type: "",
            country: "",
            share: 0.0,
            parentUEN: "",
            turnover: 0.0,
            noOfStaff: 0
        }

        if (this.springeform.shareholdingSub.length < 50) {
            this.springeform.shareholdingSub.push(subsideries);
            this.shareHoldingEditRowId = this.springeform.shareholdingSub.length - 1;
        } else {
            alert("Maximum of 50 Records would be allowed.")
        }


    }


    edit(val) {

        this.shareHoldingEditRowId = val;

        // this.isValidate(this.shareHoldingEditRowId);

        // if (this.shareHoldingEditRowId) {
        //     if (this.shareHoldingEditRowIdValidated) {
        //         this.shareHoldingEditRowId = val;
        //     } else {
        //         this.shareHoldingEditRowId = this.shareHoldingEditRowId;

        //     }
        // }
        // alert("not validated");
    }


    isValidate(shareHoldingEditRowId) {
        this.shareHoldingEditRowIdValidated = false;
        let currentElement: subsideries = this.springeform.shareholdingSub[shareHoldingEditRowId];


        //    if(false){
        //     this.shareHoldingEditRowIdValidated = true;
        //    }

        return this.shareHoldingEditRowIdValidated;
    }

    editSubsidiariesEditRowId(val) {
        this.subsidiariesEditRowId = val;
    }

    setValidValues() {
        this.springeform.invStockFinancing = (this.springeform.invStockFinancing == null) ? 0 : this.springeform.invStockFinancing;
        this.springeform.workingCapital = (this.springeform.workingCapital == null) ? 0 : this.springeform.workingCapital;
        this.springeform.aRDiscount = (this.springeform.aRDiscount == null) ? 0 : this.springeform.aRDiscount;
        this.springeform.capitalLoan = (this.springeform.capitalLoan == null) ? 0 : this.springeform.capitalLoan;
        this.springeform.bankerGuarantee = (this.springeform.bankerGuarantee == null) ? 0 : this.springeform.bankerGuarantee;
    }


    save() {

        // if(!this.isValidate()){
        //     return;
        // }
        // if(!this.isDocumentValidate()){
        //     return;
        // }
        this._id = this.loanService.getId();
        let springeFormdata: any = {};

        let date1 = this.springeform.dateofIncorporation;

        this.setValidValues();

        if (this.springeform.dateofIncorporation) {

            // let date = this.springeform.dateofIncorporation.day + "/" + this.springeform.dateofIncorporation.month + "/" + this.springeform.dateofIncorporation.year;
            let date = new DateUtil().getDBDate(this.springeform.dateofIncorporation);
            console.log('db date::' + date);
            this.springeform.dateofIncorporation = date;

        } else {
            this.springeform.dateofIncorporation = "00-00-0000";
        }

        springeFormdata.springeform = this.springeform;
        this.isSaving = true;
        if (!this._id) {
            this.springeformService.create(springeFormdata).subscribe((res) => {
                window.scrollTo(0, 0);
                console.log(JSON.stringify(res));
                this.loanService.setId(res._id);
                this.displaySuccessMessage = true;
                setTimeout(() => { this.displaySuccessMessage = false; }, 2000);
            });
        } else {
            this.springeform._id = this._id;
            springeFormdata.springeform = this.springeform;

            this.springeformService.update(springeFormdata).subscribe((res) => {
                window.scrollTo(0, 0);
                console.log(this.loanService.getId());
                this.displaySuccessMessage = true;

                setTimeout(() => { this.displaySuccessMessage = false; }, 2000);

            });

        }

        this.springeform.dateofIncorporation = date1;
    }

    saveAsDraft() {
        this.isSaving = true;

        console.log(JSON.stringify(this.springeform));

        this.subscribeToSaveResponse(
            this.springeformService.create(this.springeform));
    }

    clear() {
        this.springeform = new Springeform();
        this.displayFileMessage = false;
        this.displayErrorMessage = false;
    }



    private subscribeToSaveResponse(result: Observable<Springeform>) {
        result.subscribe((res: Springeform) =>
            this.onSaveSuccess(res), (res: Response) => this.onSaveError());
    }

    private onSaveSuccess(result: Springeform) {
        this.eventManager.broadcast({ name: 'springeformListModification', content: 'OK' });
        this.isSaving = false;
    }

    private onSaveError() {
        this.isSaving = false;
    }

    ngOnInit() {
        this.tickVisible = false;

        this.loanService.currentSpringeform.subscribe(Result => {
            this.springeform = Result;
            this.checkBoxCheckUncheck();
        });
        // this.springeform.subsidiaries = [];
        // this.springeform.shareholdingSub = [];
        // this.springeform.dateofIncorporation = "";

        // this.addRowShareholdingSub();
        // this.addRowSubsidiaries();

        // this.principal.identity().then((account) => {
        //     this.currentAccount = account;
        // }),

        this.principal.identity().then((account) => {
            this.currentAccount = account;
            if (this.currentAccount.bank && this.currentAccount.bank !== 'null' && this.currentAccount.bank === 'UOB') {
                this.UOBUser = true;
                this.PFIUser = false;
            } else if (this.currentAccount.bank && this.currentAccount.bank !== 'null' && this.currentAccount.bank !== 'UOB') {
                this.PFIUser = true;
                this.UOBUser = false;
            }
        });

    }

    ngOnDestroy() {

    }

    sort() {
        const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
        if (this.predicate !== 'id') {
            result.push('id');
        }
        return result;
    }
    private onError(error) {
        this.jhiAlertService.error(error.message, null, null);
    }


    public restrictNumeric(event, obj) {
        return true;
    }

    public sumTotal() {
        // this.springeform.total = 0;
        let total: number = 0;


        if (this.springeform.invStockFinancing) {
            total += parseFloat(this.springeform.invStockFinancing.toString());
        }

        if (this.springeform.workingCapital) {
            total += parseFloat(this.springeform.workingCapital.toString());
        }

        if (this.springeform.aRDiscount) {
            total += parseFloat(this.springeform.aRDiscount.toString());
        }

        if (this.springeform.capitalLoan) {
            total += parseFloat(this.springeform.capitalLoan.toString());
        }

        if (this.springeform.bankerGuarantee) {
            total += parseFloat(this.springeform.bankerGuarantee.toString());
        }

        this.springeform.total = total;
    }


    addRowSubsidiaries() {

        if (!this.springeform.subsidiaries) {
            this.springeform.subsidiaries = [];
        }
        var addSubsideries = {
            subsidLevel: "",
            name: "",
            sharePercent: "",
            noStaff: ""
        }

        if (this.springeform.subsidiaries.length < 50) {
            this.springeform.subsidiaries.push(addSubsideries);
            this.subsidiariesEditRowId = this.springeform.subsidiaries.length - 1;
        } else {
            alert("Maximum of 50 Records would be allowed.")
        }
    }

    removeCurrentsubsidiaries(currentsubsidiaries) {
        this.springeform.subsidiaries.splice(this.springeform.subsidiaries.indexOf(currentsubsidiaries), 1);
    }




    removeShareholdingSub(shareholdingSub) {
        console.log(this.springeform.shareholdingSub);
        //this.springeform.shareholdingSub.splice(this.springeform.subsidiaries.indexOf(shareholdingSub), 1);
        this.springeform.shareholdingSub.splice(shareholdingSub, 1);

        console.log(this.springeform.shareholdingSub);
    }

    getTickStyle(): any {
        return {
            'visibility': this.tickVisible ? 'visible' : 'hidden'
        };
    }

    uploadFile() {

        let formData = new FormData();
        let files: Array<File> = this.fileData;

        if (files.length == 0) {
            alert("Please select file to upload..!")
            return;
        }

        let file: File = files[0];
        formData.append('file', file, file.name);

        this.displaySpinner = true;

        this.springeformService.uploadFile(formData).
            subscribe(result => {
                this.springeform = <Springeform>result;
                this.displayFileMessage = true;
                this.displayErrorMessage = false;
                this.tickVisible = true;
                setTimeout(() => { this.displayFileMessage = false; this.displayErrorMessage = false; }, 3000);
                this.checkBoxCheckUncheck();
                this.displaySpinner = false;
            }, error => {
                this.displayErrorMessage = true;
                this.displayFileMessage = false;
            });

    }

    fileChangeEvent(fileInput: any, input: any) {
        this.tickVisible = false;
        this.fileData = <Array<File>>fileInput.target.files;
        console.log("file Name:: " + JSON.stringify(fileInput.target.files[0]));
        input.value = this.fileData[0].name;
    }

    newSpring() {

        if (this.springeform.total <= 0) {
            //alert('Please fill "Type of Loan Facility"');

            this.displayErrorMessageTypeOfFTotal = true;
            setTimeout(() => { this.displayErrorMessageTypeOfFTotal = false; }, 2000);
            return;
        }


        let totalPurposeOfLoan: number = this.springeform.loanDomesticTrade1 + this.springeform.loanDomesticTrade2;

        if (totalPurposeOfLoan != 100) {
            alert('"Purpose of Loan Facilities" Should be equal to 100%');
            return;
        }

        console.log(this.springeform)
        this.loanService.changeSpringeform(this.springeform);
        if (this.PFIUser) {
            this.router.navigate(['/loan/loan-pfiuser']);
            //this.router.navigate(['/loan/sform']);
        }
        if (this.UOBUser) {
            this.router.navigate(['/loan/loan-uobuser']);
            //this.router.navigate(['/loan/sform']);
        }

    }



    checkBoxCheckUncheck() {
        if (this.springeform.invStockFinancing > 0) {
            this.invStockFinancingChecked = true;
        } else {
            this.springeform.invStockFinancing = null;
        }


        if (this.springeform.workingCapital > 0) {
            this.workingCapitalChecked = true;
        } else {
            this.springeform.workingCapital = null;
        }


        if (this.springeform.aRDiscount > 0) {
            this.aRDiscountChecked = true;
        } else {
            this.springeform.aRDiscount = null;
        }

        if (this.springeform.capitalLoan > 0) {
            this.capitalLoanChecked = true;
        } else {
            this.springeform.capitalLoan = null;
        }

        if (this.springeform.bankerGuarantee > 0) {
            this.bankerGuaranteeChecked = true;
        } else {
            this.springeform.bankerGuarantee = null;
        }


    }

    checkBoxchanged(changeValue) {
        if (changeValue == "invStockFinancing") {
            this.invStockFinancingChecked = !this.invStockFinancingChecked;


            if (!this.invStockFinancingChecked) {
                this.springeform.invStockFinancing = null;
            }

        }

        if (changeValue == "workingCapital") {
            this.workingCapitalChecked = !this.workingCapitalChecked;

            if (!this.workingCapitalChecked) {
                this.springeform.workingCapital = null;
            }
        }



        if (changeValue == "aRDiscount") {
            this.aRDiscountChecked = !this.aRDiscountChecked;

            if (!this.aRDiscountChecked) {
                this.springeform.aRDiscount = null;
            }
        }


        if (changeValue == "capitalLoan") {
            this.capitalLoanChecked = !this.capitalLoanChecked;

            if (!this.capitalLoanChecked) {
                this.springeform.capitalLoan = null;
            }
        }


        if (changeValue == "bankerGuarantee") {
            this.bankerGuaranteeChecked = !this.bankerGuaranteeChecked;


            if (!this.bankerGuaranteeChecked) {
                this.springeform.bankerGuarantee = null;
            }

        }
        this.checkBoxCheckUncheck();

        this.sumTotal();
    }


}

@Pipe({ name: 'myPipe' })
export class MyPipe implements PipeTransform {
    transform(val) {
        console.log("val=" + val);
        return new Date();
    }


}