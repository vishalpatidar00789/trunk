import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpRequest, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { SERVER_API_URL } from '../../app.constants';
import { JhiDateUtils } from 'ng-jhipster';

import { Springeform } from './springeform.model';
import { createRequestOption } from '../../shared';

export type SpringeformResponseType = HttpResponse<Springeform>;
export type SpringeformArrayResponseType = HttpResponse<Springeform[]>;

@Injectable()
export class SpringeformService {

    private resourceUrl = SERVER_API_URL + 'springforms';

    constructor(private http: HttpClient, private dateUtils: JhiDateUtils) { }


    create(springData) {
        console.log(JSON.stringify(springData));
        return <any>this.http.post(this.resourceUrl, springData); //change url
    }


    update(springData) {
        let id = springData.springeform._id;
        return <any>this.http.put(this.resourceUrl + '/' + id, springData); //change url
    }



    // create(springeform: Springeform): Observable<any> {
    //     const copy = this.convert(springeform);
    //     console.log("my springeform" + springeform);
    //     return this.http.post<Springeform>(this.resourceUrl, copy, { observe: 'response' })
    //         .map((res: SpringeformResponseType) => this.convertResponse(res));
    // }

    // update(springeform: Springeform): Observable<SpringeformResponseType> {
    //     const copy = this.convert(springeform);
    //     return this.http.put<Springeform>(this.resourceUrl, copy, { observe: 'response' })
    //         .map((res: SpringeformResponseType) => this.convertResponse(res));
    // }

    private convertResponse(res: SpringeformResponseType): SpringeformResponseType {
        const body: Springeform = this.convertItemFromServer(res.body);
        return res.clone({ body });
    }

    private convertArrayResponse(res: SpringeformArrayResponseType): SpringeformArrayResponseType {
        const jsonResponse: Springeform[] = res.body;
        const body: Springeform[] = [];
        for (let i = 0; i < jsonResponse.length; i++) {
            body.push(this.convertItemFromServer(jsonResponse[i]));
        }
        return res.clone({ body });
    }

    /**
     * Convert a returned JSON object to Springeform.
     */
    private convertItemFromServer(json: any): Springeform {
        const copy: Springeform = Object.assign(new Springeform(), json);
        copy.dateofIncorporation = this.dateUtils
            .convertLocalDateFromServer(json.dateofIncorporation);
        copy.dateOfSingature = this.dateUtils
            .convertLocalDateFromServer(json.dateOfSingature);
        return copy;
    }

    /**
     * Convert a Springeform to a JSON which can be sent to the server.
     */
    private convert(springeform: Springeform): Springeform {
        const copy: Springeform = Object.assign({}, springeform);
        copy.dateofIncorporation = this.dateUtils
            .convertLocalDateToServer(springeform.dateofIncorporation);
        copy.dateOfSingature = this.dateUtils
            .convertLocalDateToServer(springeform.dateOfSingature);
        return copy;
    }


    uploadFile(fileData) {
        let headers = new HttpHeaders();
        headers.append('Access-Control-Allow-Origin', '*');
        
        return <any>this.http.post(this.resourceUrl + '/uploadspringeform'
            // ,
            //     { headers: { 'Access-Control-Allow-Origin': '*' } }
            , fileData , { headers: headers });
    }



    /*
    uploadFile(formData){
        console.log("---------------------------");
        // console.log(this.resourceUrl + '/upload');
        console.log("---------------------------");
        console.log(formData);
        console.log("---------------------------");        
        this.http.post("http://AUMLBCVDIF00068:5000/springforms" , formData) ; 
        const copy = this.convert(formData);
        console.log("my springeform"+formData);
        return this.http.post<Springeform>(this.resourceUrl, copy, { observe: 'response' })
            .map((res: SpringeformResponseType) => this.convertResponse(res));
    }*/
}
