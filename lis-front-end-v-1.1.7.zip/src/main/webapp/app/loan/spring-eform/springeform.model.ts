
export class Springeform {
    constructor(
        public _id?:string,
        public registeredCompanyName?: string,
        public uniqueEntityNumber?: string,
        public correspondenceAddress?: string,
        public contactPersonDesignation?: string,
        public phoneNumber?: string,
        public contactEmail?: string,
        public numberofStaff?: number,
        public dateofIncorporation?: any,
        public dateOfSingature?: any,
        public contactPersonNo?: string,
        public ACRANo?: string,
        public regComName?: string,
        public corrAddress1?: string,
        public corrAddress2?: string,
        public corrAddress3?: string,
        public contactPerson?: string,
        public contactPersonEmail?: string,
        public businessActivity?: string,
        public numStaff?: string,
        public dateOfIncorporation?: string,
        public appLFY?: string,
        public appSubLFY?: number,
        public appSales?: number,
        public appSubSales?: number,
        public appNetProfit?: number,
        public appNetProfitsubsidiaries?: number,
        public appSubNetProfit?: number,
        public shareholdingSub?: subsideries[],
        public level?: string,
        public name?: string,
        public aCRA?: string,
        public type?: string,
        public country?: string,
        public share?: number,
        public parentUEN?: string,
        public turnover?: number,
        public noOfStaff?: number,
        public subsidiaries?: subsideries[],
        //  [ { subsidLevel?: string, name?: string, sharePercent?: string, noStaff?: string } ],
        public invStockFinancing?: number,
        public workingCapital?: number,
        public aRDiscount?: number,
        public capitalLoan?: number,
        public bankerGuarantee?: number,
        public total?: number,
        public loanDomesticTrade1?: number,
        public loanDomesticTrade2?: number,
        public invStockFinancingChecked?: boolean,
        public workingCapitalChecked?: boolean,
        public aRDiscountChecked?: boolean,
        public capitalLoanChecked?: boolean,
        public bankerGuaranteeChecked?: boolean

    ) {
    }
}


export class subsideries {
    constructor(public level?: string,
        public name?: string,
        public aCRA?: string,
        public type?: string,
        public country?: string,
        public share?: number,
        public parentUEN?: string,
        public turnover?: number,
        public noOfStaff?: number) { }


}