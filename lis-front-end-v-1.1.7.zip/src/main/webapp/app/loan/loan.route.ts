import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';

import { UserRouteAccessService } from '../shared';
import { JhiPaginationUtil } from 'ng-jhipster';
import { PFICreditLimitComponent } from './pfi/pfi-credit-limit.component';
import { UobCreditLimitComponent } from './uob/uob-credit-limit.component';
import { LoanComponent } from './loan.component';
import { SpringeformComponent } from './spring-eform/springeform.component';
import { AdditionalFieldsComponent } from './additional-fields/additionalFields.component';
import { UobAdhocComponent } from './adhoc';
export const LoanApplicationRoute: Routes = [

    {
        path: 'loan',
        component: LoanComponent,

        children: [{
            path: 'loan-pfiuser',
            component: PFICreditLimitComponent,
            data: {
                authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN'],
                pageTitle: 'Loan Application'
            },
            canActivate: [UserRouteAccessService]
        }, {
            path: 'loan-uobuser',
            component: UobCreditLimitComponent,
            data: {
                authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN'],
                pageTitle: 'Loan Application'
            },
            canActivate: [UserRouteAccessService]
        },
        {
            path: 'sform',
            component: SpringeformComponent,
            data: {
                authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN'],
                pageTitle: 'Loan Application'
            },
            canActivate: [UserRouteAccessService]
        },
        {
            path: 'afields',
            component: AdditionalFieldsComponent,
            data: {
                authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN'],
                pageTitle: 'Loan Application'
            },
            canActivate: [UserRouteAccessService]
        },
		{
        path: 'adhoc-uobuser',
        component: UobAdhocComponent,
        data: {
            authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN'],
            pageTitle: 'Loan Application'
        },
    }
        ],

        data: {
            authorities: ['IT_ADMIN', 'PFI_USER', 'PFI_ADMIN'],
            pageTitle: 'Loan Application',
            outlet: 'loan_app'
        },
        canActivate: [UserRouteAccessService]
    }


];
