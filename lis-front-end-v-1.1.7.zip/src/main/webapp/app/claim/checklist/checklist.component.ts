import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs/Rx';
import { Checklist } from './checklist.model';
import { Principal } from '../../shared';

@Component({
    selector: 'jhi-checklist',
    templateUrl: './checklist.component.html'
})
export class ChecklistComponent implements OnInit, OnDestroy {

    checklist: Checklist = new Checklist();
    currentAccount: any;
    eventSubscriber: Subscription;
    isSaving: Boolean;
    routeData: any;
    links: any;
    totalItems: any;
    queryCount: any;
    itemsPerPage: any;
    page: any;
    predicate: any;
    previousPage: any;
    reverse: any;
    fileSize: any;
    filesToUpload: Array<File> = [];
    claimApplicationStatus: String;
    displaySuccessMessage: boolean = false;

    constructor(
        private parseLinks: JhiParseLinks,
        private jhiAlertService: JhiAlertService,
        private eventManager: JhiEventManager,
        private principal: Principal,
        private router: Router
    ) {
    }

    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0 || event.charCode == 46 || event.charCode == 44) ? null : event.charCode >= 48 && event.charCode <= 57;
    }

    reset(field: string) {
        this.checklist[field] = " ";
    }

    clear() {
        if (confirm("Are you sure, you want to cancel?")) {
            this.checklist = new Checklist();
            this.router.navigateByUrl('/');
        }
    }

    private subscribeToSaveResponse(result: Observable<Checklist>) {
        result.subscribe((res: Checklist) =>
            this.onSaveSuccess(res), (res: Response) => this.onSaveError());
    }

    private onSaveSuccess(result: Checklist) {
        this.eventManager.broadcast({ name: 'checklistListModification', content: 'OK' });
        this.isSaving = false;
    }

    private onSaveError() {
        this.isSaving = false;
    }

    ngOnInit() {
        this.claimApplicationStatus = "New";
        this.principal.identity().then((account) => {
            this.currentAccount = account;
        });

    }

    ngOnDestroy() {
        this.filesToUpload = [];
    }

    sort() {
        const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
        if (this.predicate !== 'id') {
            result.push('id');
        }
        return result;
    }

    saveAsDraft() {
        this.claimApplicationStatus = "Draft";
        window.scrollTo(0, 0);
        this.displaySuccessMessage = true;
        setTimeout(() => { this.displaySuccessMessage = false; }, 2000);
        //alert("Checklist successfully saved as draft.");
    }

    private onError(error) {
        this.jhiAlertService.error(error.message, null, null);
    }

    btnClick = function () {
        this.router.navigateByUrl('./additional');
    };
}