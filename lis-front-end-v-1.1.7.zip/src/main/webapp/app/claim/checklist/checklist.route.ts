import { Route } from '@angular/router';

import { ChecklistComponent } from './checklist.component';
import { UserRouteAccessService } from '../../shared';

export const checklistRoute: Route = {
    path: 'checklist',
    pathMatch: 'full',
    component: ChecklistComponent,
    data: {
        pageTitle: 'Claim'
    },
    canActivate: [UserRouteAccessService]
};
