import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { LisAppSharedModule } from '../shared';
import {
    claimState,
    ClaimComponent,
    ChecklistComponent,
    AdditionalComponent
} from './';

@NgModule({
    imports: [
        LisAppSharedModule,
        RouterModule.forChild(claimState),
    ],
    declarations: [
        ChecklistComponent,
        AdditionalComponent,
        ClaimComponent,
    ],
    entryComponents: [
        AdditionalComponent,
        ChecklistComponent,
        ClaimComponent,
    ],
    providers: [
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class LisAppClaimModule { }
