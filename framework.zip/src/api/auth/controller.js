import { sign } from '../../services/jwt'
import { success } from '../../services/response/'
import User, { schema } from '../user/model'

export const login = async (req , res, next) => {
  console.log('in login', req.body.email)
  try {
    const user = await User.findOne({ email: req.body.email })

    if (!user) {
      res.status(401).json({
        valid: false,
        param: 'email',
        message: 'User not found'
      })
    } else {
      user.authenticate(req.body.password, user.password).then((user) => {
        delete user.password
        console.log('inside user pass auth', user)
        sign(user.id)
        .then((token) => ({ token, user: user }))
        .then(success(res, 201))
        .catch(next)
      }).catch(next)
    }
  } catch (error) {
    console.log(error);
    next(error)
  }  
}
  
