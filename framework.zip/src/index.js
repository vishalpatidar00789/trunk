require('@babel/register')

exports = module.exports = require('./app')
